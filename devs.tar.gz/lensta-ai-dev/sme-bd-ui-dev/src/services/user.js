import Cookies from "js-cookie";
import { userTypes } from "../redux/user/types";
import { store } from "../redux";
import { getURL } from "../configs/apiURL";
import { fetchRequest } from "../utils/fetchRequest";
import { notifications } from "../utils/notifications";
import { message } from "../utils/message";

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT;
const THEME = process.env.REACT_APP_THEME

export const getAllUsers = async (query) => {
    store.dispatch({ type: userTypes.GET_USER_LOADING });
    const entityCategory = localStorage.getItem("entityCategory");
    const entityId = Cookies.get("entityId");
    const params = query || "";
    let _res = {};
    try {
        switch (entityCategory) {
            case "BUYER" :
            case "SELLER" : 
            case "FINANCIER" :
                _res = await fetchRequest(getURL(`platform/users/entity/${entityId}?limit=${PAGE_LIMIT}&${params}`));
                break;
            default:
                _res = await fetchRequest(getURL(`platform/users?limit=${PAGE_LIMIT}&${params}`));
                break;
        }
    } catch (error) {
        console.warn(error);
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: userTypes.GET_USER_FAILURE });
            !query && notifications.error({ message: "something went wrong" });
        } else {
            store.dispatch({
                type: userTypes.GET_USER_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const editUserStatus = async (id, data) => {
    let _res = {};
    try {
        _res = await fetch(getURL(`platform/users/${id}`), {
            method: "PUT",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${Cookies.get("ACCESS_TOKEN")}`,
            },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        if (_res.status === 200) {
            await _res.json();
            notifications.success({ message: message.UPDATE_STATUS });
            getAllUsers();
        }
    }
};

export const getProfile = async (id) => {
    store.dispatch({ type: userTypes.GET_PROFILE_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`platform/users/profile`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: userTypes.GET_PROFILE_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            if (["BUYER", "SELLER"].includes(_res.data?.data?.entity?.entityCategory)) {
                localStorage.setItem("createdByFinancierId", _res.data?.data?.entity?.createdByFinancier?.id);
                localStorage.setItem( "themeHexcode", _res.data?.data?.entity?.createdByFinancier?.themeHexcode ? `#${_res.data?.data?.entity?.createdByFinancier?.themeHexcode}` : THEME);
                localStorage.setItem("kycProvider", _res.data?.data?.entity?.kycApiProvider);
                store.dispatch({
                    type: userTypes.GET_PROFILE_SUCCESS,
                    payload: {
                        ..._res.data?.data,
                        entityCategory: _res.data?.data?.entity?.entityCategory,
                        entityId: _res.data?.data?.entity?.id,
                        themeHexcode: _res.data?.data?.entity?.createdByFinancier?.themeHexcode ? `#${_res.data?.data?.entity?.createdByFinancier?.themeHexcode}` : THEME,
                    },
                });
            } else {
                localStorage.setItem("themeHexcode", _res.data?.data?.entity?.themeHexcode ? `#${_res.data?.data?.entity?.themeHexcode}` : THEME );
                localStorage.setItem("kycProvider", _res.data?.data?.entity?.kycApiProvider);
                store.dispatch({
                    type: userTypes.GET_PROFILE_SUCCESS,
                    payload: {
                        ..._res.data?.data,
                        entityCategory: _res.data?.data?.entity?.entityCategory,
                        entityId: _res.data?.data?.entity?.id,
                        themeHexcode: _res.data?.data?.entity?.themeHexcode ? `#${_res.data?.data?.entity?.themeHexcode}` : THEME,
                    },
                });
            }
        }
    }
};

export const getAllUserByEntity = async (id) => {
    store.dispatch({ type: userTypes.GET_USER_BY_ENTITY_LOADING });
    let _res = {};
    try {
        const _res_checker_exist = await fetchRequest(getURL(`platform/users/checker-levels`));
        const userIds = _res_checker_exist.data?.data?.map((checker) => checker.user?.id);
        if (userIds.length) {
            _res = await fetchRequest(getURL(`platform/users/entity/${id}?userType=CHECKER&excludeUserIds=${encodeURIComponent(userIds)}`));
        } else {
            _res = await fetchRequest(getURL(`platform/users/entity/${id}?userType=CHECKER`));
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: userTypes.GET_USER_BY_ENTITY_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: userTypes.GET_USER_BY_ENTITY_SUCCESS,
                payload: _res.data?.data,
            });
        }
    }
};
