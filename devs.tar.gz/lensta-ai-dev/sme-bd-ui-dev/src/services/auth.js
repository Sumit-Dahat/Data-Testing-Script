import jwt_decode from "jwt-decode";
import Cookies from "js-cookie";
import { getURL } from "../configs/apiURL";
import { notifications } from "../utils/notifications";
import { store } from "../redux";
import { message } from "../utils/message";

export const login = async (formData) => {
    let res = {};
    try {
        res = await fetch(getURL("platform/auth/login"), {
            method: "POST",
            body: JSON.stringify(formData),
            headers: { "Content-Type": "application/json" },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        const { data, error, token } = await res.json();
        if (res.status === 200) {
            if (jwt_decode(token).token_payload.finLogoDocId) {
                const resp = await fetch(getURL(`/financiers/logo/${jwt_decode(token).token_payload.finLogoDocId}/signed-url?action=VIEW&expiresIn=1800`), { method: "GET", headers: { Authorization: `Bearer ${token}` } });
                if (resp.status === 200) {
                    const { data: { url } } = await resp.json();
                    localStorage.setItem("logoImage", url);
                }
            }

            ["entityCategory", "userType", "userId"].forEach((key) => localStorage.setItem(key, key === 'userId' ? data["id"] : data[key]));

            ["entityId", "ACCESS_TOKEN"].forEach((key) => Cookies.set(key, key === 'entityId' ? data?.entityId : token))

            notifications.success({
                message: message.LOGIN
            });
            return true;
        } else {
            notifications.error({
                message: error?.message || "something went wrong",
            });
        }
        return false;
    }
};


export const sendResetPasswordLink = async (formData) => {
    let res = {};
    try {
        res = await fetch(getURL("platform/auth/reset-password"), {
            method: "POST",
            body: JSON.stringify(formData),
            headers: { "Content-Type": "application/json" },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        const data = await res.json();
        if (res.status === 200) {
            notifications.success({
                message: `Password reset link successfully sent on ${formData.emailId || formData.mobileNo}`
            })
            return true;
        } else {
            notifications.error({
                message: data?.error?.message || "something went wrong",
            });
        }
        return false;
    }
};

export const resetPassword = async (userId, token, formData) => {
    let res = {};
    try {
        res = await fetch(getURL(`platform/auth/reset-password/${userId}/${token}`), {
            method: "POST",
            body: JSON.stringify({ password: formData.password }),
            headers: { "Content-Type": "application/json" },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        const data = await res.json();
        if (res.status === 200) {
            notifications.success({
                message: `Password reset Successfully.`
            })
            return true;
        } else {
            notifications.error({
                message: data?.error?.message || "something went wrong",
            });
        }
        return false;
    }
}

export const showPassword = async (id) => {
    let res = {};
    try {
        res = await fetch(getURL(`platform/users/${id}/password`), {
            method: "GET",
            headers: {
                Authorization: `Bearer ${Cookies.get("ACCESS_TOKEN")}`,
            },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        if (res.status === 200) {
            const { data } = await res.json();
            return data.password;
        }
        return false;
    }
};

export const logout = async () => store.dispatch({ type: "USER_LOGOUT" });
