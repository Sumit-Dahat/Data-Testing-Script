import { store } from "../redux";
import { getURL } from "../configs/apiURL";
import { fetchRequest } from "../utils/fetchRequest";
import { notifications } from "../utils/notifications";
import {
    paymentTypes,
    factoredUnitTypes,
    factoringUnitTypes,
    notFactoredUnitTypes,
    openForFinanceTypes,
    transactionHistoryTypes,
    invoiceDocumentTypes,
    checkerLevelTypes,
    factoringUnitByIdTypes,
    acceptBankFinance,
} from "../redux/factoringUnit/types";
import Cookies from "js-cookie";

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT

export const getAllFactoringUnit = async (id, query) => {
    store.dispatch({ type: factoringUnitTypes.GET_FACTORING_UNIT_LOADING });
    const params = query || "";
    const userId = localStorage.getItem("userId");
    let _res = {};
    try {
        switch (localStorage.getItem("userType")) {
            case "MAKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=PENDING&createdByUserId=${userId}&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            case "CHECKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=PENDING&nextCheckerUserId=${userId}&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            default:
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=PENDING&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: factoringUnitTypes.GET_FACTORING_UNIT_FAILURE,
            });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: factoringUnitTypes.GET_FACTORING_UNIT_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getAllOpenForFinance = async (id, query) => {
    store.dispatch({ type: openForFinanceTypes.GET_OPEN_FOR_FINANCE_LOADING });
    const params = query || "";
    const userId = localStorage.getItem("userId");
    const entityCategory = localStorage.getItem("entityCategory");
    let _res = {};
    try {
        switch (localStorage.getItem("userType")) {
            case "MAKER":
                if (entityCategory === "FINANCIER") {
                    _res = await fetchRequest(
                        getURL(
                            `factoring-units?status=OPEN_FOR_FINANCE&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                        )
                    );
                } else {
                    _res = await fetchRequest(
                        getURL(
                            `factoring-units?status=OPEN_FOR_FINANCE&createdByUserId=${userId}&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                        )
                    );
                }
                break;
            case "CHECKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=OPEN_FOR_FINANCE&nextCheckerUserId=${userId}&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            default:
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=OPEN_FOR_FINANCE&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: openForFinanceTypes.GET_OPEN_FOR_FINANCE_FAILURE,
            });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: openForFinanceTypes.GET_OPEN_FOR_FINANCE_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getAllAcceptBankFinance = async (id, query) => {
    store.dispatch({ type: acceptBankFinance.GET_ACCEPT_BANK_FINANCE_LOADING });
    const params = query || "";
    const userId = localStorage.getItem("userId");
    const entityCategory = Cookies.get("entityCategory");
    let _res = {};
    try {
        switch (localStorage.getItem("userType")) {
            case "MAKER":
                if (entityCategory === "SELLER") {
                    _res = await fetchRequest(
                        getURL(
                            `factoring-units?status=ROI_ADDED&invCreatedByUserId=${userId}&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                        )
                    );
                } else {
                    _res = await fetchRequest(
                        getURL(
                            `factoring-units?status=ROI_ADDED&createdByUserId=${userId}&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                        )
                    );
                }
                break;
            case "CHECKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=ROI_ADDED&nextCheckerUserId=${userId}&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            default:
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=ROI_ADDED&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: acceptBankFinance.GET_ACCEPT_BANK_FINANCE_FAILURE,
            });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: acceptBankFinance.GET_ACCEPT_BANK_FINANCE_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getAllFactoredUnit = async (id, query) => {
    store.dispatch({ type: factoredUnitTypes.GET_FACTORED_UNIT_LOADING });
    const params = query || "";
    const userId = localStorage.getItem("userId");
    const currentTab = localStorage.getItem("currentTab");

    const status = {
        OPEN_FOR_DISBURSEMENT: "AMT_DISBURSED",
        ACTIVE_DISBURSEMENT: "ACTIVE_DISBURSEMENT",
        OVERDUE_DISBURSEMENT: "OVERDUE_DISBURSEMENT",
        PAYMENT_CLOSED: "PAYMENT_CLOSED"
    }

    let _res = {};
    try {
        switch (localStorage.getItem("userType")) {
            case "MAKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=${status[currentTab]}&createdByUserId=${userId}&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            case "CHECKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=${status[currentTab]}&nextCheckerUserId=${userId}&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            default:
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=${status[currentTab]}&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: factoredUnitTypes.GET_FACTORED_UNIT_FAILURE,
            });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: factoredUnitTypes.GET_FACTORED_UNIT_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getFUPayments = async (FUId, query) => {
    store.dispatch({ type: paymentTypes.GET_PAYMENTS_LOADING });
    let _res = {};
    const params = query || "";
    try {
        _res = await fetchRequest(getURL(`factoring-units/${FUId}/payments?limit=${PAGE_LIMIT}&${params}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: paymentTypes.GET_PAYMENTS_FAILURE,
            });
        } else {
            store.dispatch({
                type: paymentTypes.GET_PAYMENTS_SUCCESS,
                payload: _res?.data,
            });
        }
        return _res?.data
    }
};


export const getAllNotFactoredUnit = async (id, query) => {
    store.dispatch({
        type: notFactoredUnitTypes.GET_NOT_FACTORED_UNIT_LOADING,
    });
    const params = query || "";
    const userId = localStorage.getItem("userId");
    let _res = {};
    try {
        switch (localStorage.getItem("userType")) {
            case "MAKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=REJECTED&createdByUserId=${userId}&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            case "CHECKER":
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=REJECTED&nextCheckerUserId=${userId}&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            default:
                _res = await fetchRequest(
                    getURL(
                        `factoring-units?status=REJECTED&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: notFactoredUnitTypes.GET_NOT_FACTORED_UNIT_FAILURE,
            });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: notFactoredUnitTypes.GET_NOT_FACTORED_UNIT_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getFactoringUnitById = async (id) => {
    store.dispatch({
        type: factoringUnitByIdTypes.GET_FACTORING_UNIT_BY_ID_LOADING,
    });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`factoring-units/${id}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: factoringUnitByIdTypes.GET_FACTORING_UNIT_BY_ID_FAILURE,
            });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: factoringUnitByIdTypes.GET_FACTORING_UNIT_BY_ID_SUCCESS,
                payload: _res.data?.data,
            });
        }
    }
};

export const getAllTransactionHistory = async (id, query) => {
    store.dispatch({
        type: transactionHistoryTypes.GET_TRANSACTION_HISTORY_LOADING,
    });
    let _res = {};
    const params = query || "";
    try {
        if (query) {
            _res = await fetchRequest(
                getURL(`factoring-units/${id}/transactions?limit=${PAGE_LIMIT}&${params}`)
            );
        } else {
            _res = await fetchRequest(
                getURL(`factoring-units/${id}/transactions?limit=${PAGE_LIMIT}`)
            );
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: transactionHistoryTypes.GET_TRANSACTION_HISTORY_FAILURE,
            });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: transactionHistoryTypes.GET_TRANSACTION_HISTORY_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getAllInvoiceDocuments = async (id, query) => {
    store.dispatch({ type: invoiceDocumentTypes.GET_INVOICE_DOCUMENT_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(
            getURL(`/invoices/${id}/documents?limit=${PAGE_LIMIT}&${params}`)
        );
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: invoiceDocumentTypes.GET_INVOICE_DOCUMENT_FAILURE,
            });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: invoiceDocumentTypes.GET_INVOICE_DOCUMENT_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getAllCheckerLevel = async (query) => {
    store.dispatch({ type: checkerLevelTypes.GET_CHECKER_LEVEL_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(
            getURL(
                `platform/users/checker-levels?limit=${PAGE_LIMIT}&${params}`
            )
        );
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: checkerLevelTypes.GET_CHECKER_LEVEL_FAILURE,
            });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: checkerLevelTypes.GET_CHECKER_LEVEL_SUCCESS,
                payload: _res.data,
            });
        }
    }
};
