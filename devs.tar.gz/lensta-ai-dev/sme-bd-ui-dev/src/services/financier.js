import Cookies from "js-cookie";
import { financierTypes } from "../redux/financier/types";
import { store } from "../redux";
import { getURL } from "../configs/apiURL";
import { fetchRequest } from "../utils/fetchRequest";
import { notifications } from "../utils/notifications";
import { message } from "../utils/message";

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT

export const getAllFinancier = async (query) => {
    store.dispatch({ type: financierTypes.GET_FINANCIER_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`financiers?limit=${PAGE_LIMIT}&${params}`));
    } catch (error) {
        console.warn(error);
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: financierTypes.GET_FINANCIER_FAILURE });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: financierTypes.GET_FINANCIER_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getFinancierBanks = async (query) => {
    store.dispatch({ type: financierTypes.GET_FINANCIER_BANKS_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`/financiers/profile/bank-details?limit=${PAGE_LIMIT}&${params}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: financierTypes.GET_FINANCIER_BANKS_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: financierTypes.GET_FINANCIER_BANKS_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getFinancierProfile = async () => {
    store.dispatch({ type: financierTypes.GET_FINANCIER_PROFILE_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`financiers/profile`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: financierTypes.GET_FINANCIER_PROFILE_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: financierTypes.GET_FINANCIER_PROFILE_SUCCESS,
                payload: _res.data?.data,
            });
        }
    }
};

export const updateFinancierStatus = async (id, data) => {
    let _res = {};
    try {
        _res = await fetch(getURL(`financiers/${id}`), {
            method: "PUT",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${Cookies.get("ACCESS_TOKEN")}`,
            },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        if (_res.status === 200) {
            await _res.json();
            notifications.success({ message: message.UPDATE_STATUS });
            getAllFinancier();
        }
    }
};
