import Cookies from "js-cookie";
import { store } from "../redux";
import { getURL } from "../configs/apiURL";
import { fetchRequest } from "../utils/fetchRequest";
import { notifications } from "../utils/notifications";
import { buyerSellerTypes } from "../redux/buyerSeller/types";
import { message } from "../utils/message";

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT

export const getBuyerSellerProfile = async () => {
    store.dispatch({ type: buyerSellerTypes.GET_BUYER_SELLER_PROFILE_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`buyer-seller/profile`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_PROFILE_FAILURE,
            });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_PROFILE_SUCCESS,
                payload: _res.data?.data,
            });
        }
    }
};

export const getAllBuyerSeller = async (query) => {
    store.dispatch({ type: buyerSellerTypes.GET_BUYER_SELLER_LOADING });
    let _res = {};
    const params = query || "";
    try {
        if (query) {
            _res = await fetchRequest(getURL(`buyer-seller?limit=${PAGE_LIMIT}&${params}`));
        } else {
            _res = await fetchRequest(getURL(`buyer-seller`));
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_BUYER_SELLER_FAILURE });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getAllBuyerSellerLink = async (query, all = false) => {
    store.dispatch({ type: buyerSellerTypes.GET_BUYER_SELLER_LINK_LOADING });
    let _res = {};
    const params = query || "";
    try {
        if (all) {
            _res = await fetchRequest(getURL(`buyer-seller/links`));
        } else {
            _res = await fetchRequest(getURL(`buyer-seller/links?limit=${PAGE_LIMIT}&${params}`));
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_LINK_FAILURE,
            });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_LINK_SUCCESS,
                payload: _res?.data,
            });
        }
    }
};

export const getAllInvoices = async (query) => {
    store.dispatch({ type: buyerSellerTypes.GET_BUYER_SELLER_INVOICE_LOADING });
    const userId = localStorage.getItem("userId");
    const params = query || "";
    let _res = {};
    try {
        switch (localStorage.getItem("userType")) {
            case "MAKER":
                _res = await fetchRequest(
                    getURL(
                        `invoices?approved=0&createdByUserId=${userId}&nextCheckerUserId=null&limit=${PAGE_LIMIT}&${params}`
                    )
                );
                break;
            case "CHECKER":
                _res = await fetchRequest(
                    getURL(`invoices?approved=0&nextCheckerUserId=${userId}&limit=${PAGE_LIMIT}&${params}`)
                );
                break;
            default:
                _res = await fetchRequest(getURL(`invoices?approved=0&limit=${PAGE_LIMIT}&${params}`));
                break;
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_INVOICE_FAILURE,
            });
            !query &&
                notifications.error({
                    message: "something went wrong",
                });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_INVOICE_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getInvoiceById = async (id) => {
    store.dispatch({
        type: buyerSellerTypes.GET_BUYER_SELLER_INVOICE_LOADING_BY_ID,
    });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`invoices/${id}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_INVOICE_FAILURE_BY_ID,
            });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_BUYER_SELLER_INVOICE_SUCCESS_BY_ID,
                payload: _res.data?.data,
            });
        }
    }
};

export const getBuyerSellerBanks = async (id, query, all = false) => {
    store.dispatch({ type: buyerSellerTypes.GET_BANKS_LOADING });
    const params = query || "";
    let _res = {};
    try {
        if (all) {
            _res = await fetchRequest(getURL(`buyer-seller/${id}/bank-details`));
        } else {
            _res = await fetchRequest(getURL(`buyer-seller/${id}/bank-details?limit=${PAGE_LIMIT}&${params}`));
        }
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_BANKS_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_BANKS_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getBuyerSellerAddress = async (id, query) => {
    store.dispatch({ type: buyerSellerTypes.GET_ADDRESS_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`buyer-seller/${id}/address-details?limit=${PAGE_LIMIT}&${params}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_ADDRESS_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_ADDRESS_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getBuyerSellerPromoters = async (id, query) => {
    store.dispatch({ type: buyerSellerTypes.GET_PROMOTER_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`buyer-seller/${id}/promoter-details?limit=${PAGE_LIMIT}&${params}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_PROMOTER_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_PROMOTER_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getBuyerSellerDocuments = async (id, query) => {
    store.dispatch({ type: buyerSellerTypes.GET_DOCUMENT_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`buyer-seller/${id}/documents?limit=${PAGE_LIMIT}&${params}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_DOCUMENT_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_DOCUMENT_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const updateBuyerSellerStatus = async (_id, data) => {
    let _res = {};
    try {
        _res = await fetch(getURL(`buyer-seller/${_id}`), {
            method: "PUT",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${Cookies.get("ACCESS_TOKEN")}`,
            },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        if (_res.status === 200) {
            await _res.json();
            const approved =
                ["ADMIN", "OPERATION_MANAGER"].includes(localStorage.getItem("userType")) &&
                ["OPERATION"].includes(localStorage.getItem("currentTab"))
                    ? 0
                    : 1;

            getAllBuyerSeller(`approved=${approved}`);
            notifications.success({ message: message.UPDATE_STATUS });
        }
    }
};

export const updateBuyerSellerLinkStatus = async (_id, status) => {
    let _res = {};
    try {
        _res = await fetch(getURL(`buyer-seller/links/${_id}`), {
            method: "PUT",
            body: JSON.stringify({ active: status }),
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${Cookies.get("ACCESS_TOKEN")}`,
            },
        });
    } catch (error) {
        console.warn(error);
    } finally {
        if (_res.status === 200) {
            await _res.json();
            notifications.success({ message: message.UPDATE_STATUS });
            getAllBuyerSellerLink();
        }
    }
};

export const getIfscData = async (ifscCode) => {
    store.dispatch({ type: buyerSellerTypes.GET_IFSC_DETAILS_LOADING });

    let _res = {};
    let data = [];
    try {
        _res = await fetch(`https://ifsc.razorpay.com/${ifscCode}`, {
            "Content-Type": "application/json",
        });

        data = await _res.json();
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.status === 404) {
            store.dispatch({ type: buyerSellerTypes.GET_IFSC_DETAILS_FAILURE });
            notifications.error({
                message: "invalid ifsc code",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_IFSC_DETAILS_SUCCESS,
                payload: data,
            });
        }
    }
};

export const getPinData = async (pinCode) => {
    store.dispatch({ type: buyerSellerTypes.GET_PIN_CODE_DETAILS_LOADING });

    let _res = {};
    let data = [];
    try {
        _res = await fetch(`https://api.postalpincode.in/pincode/${pinCode}`, {
            "Content-Type": "application/json",
        });

        data = await _res.json();
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (data[0]?.Status === "Error") {
            store.dispatch({
                type: buyerSellerTypes.GET_PIN_CODE_DETAILS_FAILURE,
            });
            notifications.error({
                message: "invalid pin code",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_PIN_CODE_DETAILS_SUCCESS,
                payload: data[0]?.PostOffice ? data[0]?.PostOffice[0] : {},
            });
        }
    }
};

export const getAllLinkedGst = async (apiProvider, panNo, query) => {
    store.dispatch({ type: buyerSellerTypes.GET_LINKED_GST_LOADING });
    const params = query || "";
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/kyc/pan/${panNo}/linked-gstins?limit=${PAGE_LIMIT}&${params}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_LINKED_GST_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_LINKED_GST_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getPanKycDetails = async (apiProvider, panNo) => {
    store.dispatch({ type: buyerSellerTypes.GET_PAN_KYC_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/kyc/pan/${panNo}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_PAN_KYC_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_PAN_KYC_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getGstKycDetails = async (apiProvider, gstin) => {
    store.dispatch({ type: buyerSellerTypes.GET_GST_KYC_LOAING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/kyc/gst/${gstin}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_GST_KYC_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_GST_KYC_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getGstItrDetails = async (apiProvider, gstin) => {
    store.dispatch({ type: buyerSellerTypes.GET_GST_ITR_KYC_LOAING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/kyc/gst-itr/${gstin}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_GST_ITR_KYC_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_GST_ITR_KYC_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getUdyamKycDetails = async (apiProvider, udyamRegNo) => {
    store.dispatch({ type: buyerSellerTypes.GET_UDYAM_KYC_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/kyc/udyam/${udyamRegNo}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_UDYAM_KYC_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_UDYAM_KYC_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getBankKycDetails = async (apiProvider, accountNo) => {
    store.dispatch({ type: buyerSellerTypes.GET_BANK_KYC_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/kyc/bank-account/${accountNo}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_BANK_KYC_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_BANK_KYC_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getBankStmtDetails = async (apiProvider, accountNo) => {
    store.dispatch({ type: buyerSellerTypes.GET_BANK_STMT_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/stmt/bank-account/${accountNo}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_BANK_STMT_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            console.log(_res.data)
            store.dispatch({
                type: buyerSellerTypes.GET_BANK_STMT_SUCCESS,
                payload: _res.data,
            });
        }
    }
};

export const getAadhaarKycDetails = async (apiProvider, aadhaarNo) => {
    store.dispatch({ type: buyerSellerTypes.GET_AADHAAR_KYC_LOADING });
    let _res = {};
    try {
        _res = await fetchRequest(getURL(`${apiProvider}/kyc/aadhaar/${aadhaarNo}`));
    } catch (error) {
        console.warn(error);
        notifications.error({
            message: "something went wrong",
        });
    } finally {
        if (_res.hasError) {
            store.dispatch({ type: buyerSellerTypes.GET_AADHAAR_KYC_FAILURE });
            notifications.error({
                message: "something went wrong",
            });
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_AADHAAR_KYC_SUCCESS,
                payload: _res.data,
            });
        }
    }
};
