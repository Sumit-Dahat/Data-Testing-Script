import { Select, DatePicker } from "antd";
import { useState, useCallback } from "react";
import { tw } from "twind";
import { useSelector } from "react-redux";
import { setFilterQuery, setDocFilterQuery, setFilter } from "../redux/filters/actions";
import { generateFilterQuery } from "./generateQuery";
import Input from "antd/es/input";

var timeOutId;

export const TextFilter = ({ type, filter }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [value, setValue] = useState("");

    const handleSearch = (value) => {
        let obj = {};
        obj[type] = value;
        obj["offset"] = 0;
        const searchQuery = generateFilterQuery(obj, query);
        setFilterQuery(searchQuery);
        setFilter(filter || null)
    };

    const debounce = (func, delay) => {
        return (...args) => {
            if (timeOutId) {
                clearTimeout(timeOutId);
            }
            timeOutId = setTimeout(() => func.apply(null, args), delay);
        };
    };

    const debounceSearch = useCallback(debounce(handleSearch, 300), []); // eslint-disable-line

    return (
        <div className={tw`w-full flex justify-center`}>
            <Input
                value={value}
                placeholder="Search"
                onChange={(e) => {
                    setValue(e.target.value);
                    debounceSearch(e.target.value);
                }}
            />
        </div>
    );
};

export const DocTextFilter = ({ type, filter }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.docquery,
    }));

    const [value, setValue] = useState("");

    const handleSearch = (value) => {
        let obj = {};
        obj[type] = value;
        obj["offset"] = 0;
        const searchQuery = generateFilterQuery(obj, query);
        setDocFilterQuery(searchQuery);
        setFilter(filter || null)
    };

    const debounce = (func, delay) => {
        return (...args) => {
            if (timeOutId) {
                clearTimeout(timeOutId);
            }
            timeOutId = setTimeout(() => func.apply(null, args), delay);
        };
    };

    const debounceSearch = useCallback(debounce(handleSearch, 300), []); // eslint-disable-line

    return (
        <div className={tw`w-full flex justify-center`}>
            <Input
                value={value}
                placeholder="Search"
                onChange={(e) => {
                    setValue(e.target.value);
                    debounceSearch(e.target.value);
                }}
            />
        </div>
    );
};

export const DateFilter = ({ type, filter }) => {
    const { RangePicker } = DatePicker;

    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [value, setValue] = useState("");

    return (
        <div className={tw`w-full flex justify-center`}>
            <RangePicker
                value={value}
                placeholder="Search"
                onChange={(value) => {
                    const date = value
                        ? `${value[0].format("YYYY/MM/DD")},${value[1].format("YYYY/MM/DD")}`
                        : "";
                    let obj = {};
                    obj[type] = date;
                    obj["offset"] = 0;
                    const searchQuery = generateFilterQuery(obj, query);
                    setFilterQuery(searchQuery);
                    setValue(value);
                    setFilter(filter || null)
                }}
            />
        </div>
    );
};

export const UserTypeFilter = ({ type, filter }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [value, setValue] = useState("");

    return (
        <div className={tw`w-full flex justify-center`}>
            <Select
                value={value}
                className={tw`w-full`}
                defaultValue={""}
                onChange={(value) => {
                    let obj = {};
                    obj[type] = value;
                    obj["offset"] = 0;
                    const searchQuery = generateFilterQuery(obj, query);
                    setFilterQuery(searchQuery);
                    setValue(value);
                    setFilter(filter || null)
                }}
                allowClear={true}
                options={[
                    { label: "All", value: "" },
                    { label: "Admin", value: "ADMIN" },
                    { label: "Operation Manager", value: "OPERATION_MANAGER" },
                ]}
            />
        </div>
    );
};

export const StatusFilter = ({ type, filter }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [value, setValue] = useState("");

    return (
        <div className={tw`w-full flex justify-center`}>
            <Select
                value={value}
                className={tw`w-full`}
                defaultValue={""}
                onChange={(value) => {
                    let obj = {};
                    obj[type] = value;
                    obj["offset"] = 0;
                    const searchQuery = generateFilterQuery(obj, query);
                    setFilterQuery(searchQuery);
                    setValue(value);
                    setFilter(filter || null)
                }}
                allowClear={true}
                options={[
                    { label: "All", value: "" },
                    { label: "Active", value: "1" },
                    { label: "Inactive", value: "0" },
                ]}
            />
        </div>
    );
};

export const EntityFilter = ({ type, filter }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [value, setValue] = useState("");

    return (
        <div className={tw`w-full flex justify-center`}>
            <Select
                value={value}
                className={tw`w-full`}
                defaultValue={""}
                onChange={(value) => {
                    let obj = {};
                    obj[type] = value;
                    obj["offset"] = 0;
                    const searchQuery = generateFilterQuery(obj, query);
                    setFilterQuery(searchQuery);
                    setValue(value);
                    setFilter(filter || null)
                }}
                allowClear={true}
                options={[
                    { label: "All", value: "" },
                    { label: "Buyer", value: "BUYER" },
                    { label: "Seller", value: "SELLER" },
                ]}
            />
        </div>
    );
};

export const PaymentStatusFilter = ({ type, filter }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [value, setValue] = useState("");

    return (
        <div className={tw`w-full flex justify-center`}>
            <Select
                value={value}
                className={tw`w-full`}
                defaultValue={""}
                onChange={(value) => {
                    let obj = {};
                    obj[type] = value;
                    obj["offset"] = 0;
                    const searchQuery = generateFilterQuery(obj, query);
                    setFilterQuery(searchQuery);
                    setValue(value);
                    setFilter(filter || null)
                }}
                allowClear={true}
                options={[
                    { label: "All", value: "" },
                    { label: "Initiated", value: "INITIATED" },
                    { label: "Successful", value: "SUCCESSFUL" },
                    { label: "Failed", value: "FAILED" },
                    { label: "Cancelled", value: "CANCELLED" },
                ]}
            />
        </div>
    );
};