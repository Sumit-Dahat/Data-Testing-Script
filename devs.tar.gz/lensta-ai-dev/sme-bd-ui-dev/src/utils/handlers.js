import moment from "moment";

export const consentInit = {
    agree: false,
    stage: "",
    formInitial: {},
    formData: {},
    panNumber: null,
    panKyc: 0,
    panKycVerified: 0,
    dob: null,
    udyamNumber: null,
    udyamRegNoKyc: 0,
    udyamRegNoKycVerified: 0,
    gstinNumber: null,
    gstinKyc: 0,
    gstinKycVerified: 0,
    bankAccNo: null,
    bankAcckyc: 0,
    bankAccKycVerified: 0,
    aadhaarNo: null,
    aadhaarKyc: 0,
    aadhaarKycVerified: 0,
    otpKyc: 0,
    otpKycVerified: 0,
};

export const onEntitySubmit = async (kwargs) => {
    const { value, consent, setConsent, defaultValue, isUpdate, onSubmit, mobileIsdCode, contactIsdCode } = { ...kwargs };
    let data = {
        ...consent,
        formData: {
            ...value,
            mobileNo: mobileIsdCode + value.mobileNo,
            contactNo: contactIsdCode + value.contactNo,
        },
    };
    if (!isUpdate) {
        if (
            ((value.panNumber && !consent.panKyc) ||
                (consent.panKyc && (value.panNumber !== consent.panNumber || ((value.incorporationDate._i ? moment(value.incorporationDate._i).format("YYYY-MM-DD") : value.incorporationDate.format("YYYY-MM-DD"))) !== consent.dob._i ? moment(consent.dob._i).format("YYYY-MM-DD") : consent.dob.format("YYYY-MM-DD")))) &&
            !consent.panKyc
        ) {
            setConsent({ ...data, stage: "panNumber", agree: !consent.agree });
            return;
        }
        if (
            ((value.udyamNumber && !consent.udyamRegNoKyc) ||
                (consent.udyamRegNoKyc && value.udyamNumber !== consent.udyamNumber)) &&
            !consent.udyamRegNoKyc
        ) {
            setConsent({ ...data, stage: "udyamNumber", agree: !consent.agree });
            return;
        }
    } else {
        if (
            value.panNumber &&
            (value.panNumber !== defaultValue?.entityDetails?.pan || (value.incorporationDate._i ? moment(value.incorporationDate._i).format("YYYY-MM-DD") : value.incorporationDate.format("YYYY-MM-DD")) !== moment(defaultValue?.entityDetails?.dateOfIncorporation).format("YYYY-MM-DD")) &&
            !defaultValue.entityDetails?.panKycVerified &&
            !consent.panKyc
        ) {
            setConsent({ ...data, stage: "panNumber", agree: !consent.agree });
            return;
        }
        if (
            value.udyamNumber &&
            value.udyamNumber !== defaultValue?.entityDetails?.udyamRegNo &&
            !defaultValue.entityDetails?.udyamRegNoKycVerified &&
            !consent.udyamRegNoKyc
        ) {
            setConsent({ ...data, stage: "udyamNumber", agree: !consent.agree });
            return;
        }
    }
    const response = await onSubmit({
        ...value,
        incorporationDate: value.incorporationDate._i ? moment(value.incorporationDate._i) : value.incorporationDate,
        mobileNo: mobileIsdCode + value.mobileNo,
        contactNo: contactIsdCode + value.contactNo,
        panKycVerified: consent.panKycVerified,
        udyamRegNoKycVerified: consent.udyamRegNoKycVerified,
    });
    if (response) {
        setConsent({ ...consentInit });
    }
};

export const onBankSubmit = async (kwargs) => {
    const { value, consent, setConsent, defaultValue, isUpdate, onSubmit, resetForm } = { ...kwargs };
    let data = {
        ...consent,
        formData: { ...value },
    };
    if (!isUpdate) {
        if (((value.accountNo && !consent.bankAcckyc) || (consent.bankAcckyc && value.accountNo !== consent.bankAccNo)) && !consent.bankAccKyc) {
            setConsent({ ...data, stage: "accountNo", agree: !consent.agree });
            return;
        }
    } else {
        if (value.accountNo && value.accountNo !== defaultValue?.accountNo && !defaultValue.bankAccKycVerified && !consent.bankAccKyc) {
            setConsent({ ...data, stage: "accountNo", agree: !consent.agree });
            return;
        }
    }
    const response = await onSubmit({
        ...value,
        bankAccKycVerified: consent.bankAccKycVerified,
    });
    if (response && resetForm) {
        setTimeout(() => {
            resetForm();
            setConsent({ ...consentInit });
        }, 500);
    }
};

export const onPromoterSubmit = async (kwargs) => {
    const { value, consent, setConsent, defaultValue, isUpdate, onSubmit, isdCode, resetForm } = { ...kwargs };

    let data = {
        ...consent,
        formData: { ...value, contactNo: isdCode + value.contactNo },
    };
    if (!isUpdate) {
        if (((value.panNumber && !consent.panKyc) ||
            (consent.panKyc && (value.panNumber !== consent.panNumber || (value.dobOrDateOfIncorporation._i ? moment(value.dobOrDateOfIncorporation._i).format("YYYY-MM-DD") : value.dobOrDateOfIncorporation.format("YYYY-MM-DD")) !== consent.dob._i ? moment(consent.dob._i).format("YYYY-MM-DD") : consent.dob.format("YYYY-MM-DD")))) &&
            !consent.panKyc
        ) {
            setConsent({ ...data, stage: "panNumber", agree: !consent.agree });
            return;
        }
        if (
            (value.promoterType === 'INDIVIDUAL') &&
            ((value.adhaarOrRegistrationNumber && !consent.aadhaarKyc) ||
            (consent.aadhaarKyc && value.adhaarOrRegistrationNumber !== consent.aadhaarNo)) &&
            !consent.aadhaarKyc
        ) {
            setConsent({ ...data, stage: "adhaarNumber", agree: !consent.agree });
            return;
        }
    } else {
        if (value.panNumber && (value.panNumber !== defaultValue?.pan || (value.dobOrDateOfIncorporation._i ? moment(value.dobOrDateOfIncorporation._i).format("YYYY-MM-DD") : value.dobOrDateOfIncorporation.format("YYYY-MM-DD")) !== moment(defaultValue?.dobOrDoi).format("YYYY-MM-DD")) && !defaultValue.panKycVerified && !consent.panKyc) {
            setConsent({ ...data, stage: "panNumber", agree: !consent.agree });
            return;
        }
        if (
            (value.promoterType === 'INDIVIDUAL') &&
            (value.adhaarOrRegistrationNumber) &&
            (value.adhaarOrRegistrationNumber !== defaultValue?.aadhaarOrRegNo) &&
            !defaultValue.aadhaarKycVerified &&
            !consent.aadhaarKyc
        ) {
            setConsent({ ...data, stage: "adhaarNumber", agree: !consent.agree });
            return;
        }
    }
    const response = await onSubmit({
        ...value,
        dobOrDateOfIncorporation: value.dobOrDateOfIncorporation._i ? moment(value.dobOrDateOfIncorporation._i) : value.dobOrDateOfIncorporation,
        contactNo: isdCode + value.contactNo,
        panKycVerified: consent.panKycVerified,
        aadhaarKycVerified: consent.aadhaarKycVerified,
    });
    if (response && resetForm) {
        setTimeout(() => {
            resetForm();
            setConsent({ ...consentInit });
        }, 500);
    }
};
