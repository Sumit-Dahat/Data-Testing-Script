export const ACTION_TYPES = {
    FETCH_START: "FETCH_START",
    FETCH_SUCCESS: "FETCH_SUCCESS",
    FETCH_ERROR: "FETCH_ERROR",
    EDIT: "EDIT",
};

export const FINANCIER_USER_TYPES = [
    {
        label: "Maker",
        value: "MAKER",
    },
    {
        label: "Checker",
        value: "CHECKER",
    },
    {
        label: "Operation Manager",
        value: "OPERATION_MANAGER",
    }
]

export const BUYER_SELLER_USER_TYPES = [
    {
        label: "Maker",
        value: "MAKER",
    },
    {
        label: "Checker",
        value: "CHECKER",
    }
]

export const PLATFORM_USER_TYPES = [
    {
        label: "Admin",
        value: "ADMIN"
    },
    {
        label: "Operation Manager",
        value: "OPERATION_MANAGER",
    },
]

export const PROMOTER_TYPES = {
    default: {
        nameOrentityName: {
            name: "Name/Entity Name",
            placeholder: "Name/Entity Name",
        },
        dobOrDateOfIncorporation: {
            name: "DOB/ DO Incorporation",
            placeholder: "DOB/ DO Incorporation",
        },
        adhaarOrRegistrationNumber: {
            name: "Aadhaar/Registration Number",
            placeholder: "Aadhaar/Registration Number",
        },
        dinCin: {
            name: "DIN/CIN",
            placeholder: "DIN/CIN",
        },
        gender: true,
    },
    individual: {
        nameOrentityName: {
            name: "Name",
            placeholder: "Enter Name",
        },
        dobOrDateOfIncorporation: {
            name: "Date of Birth",
            placeholder: "Select Date",
        },
        adhaarOrRegistrationNumber: {
            name: "Aadhaar Number",
            placeholder: "Enter Aadhaar Number",
        },
        dinCin: {
            name: "Corporate Identification Number",
            placeholder: "Enter CIN",
        },
        gender: true,
    },
    entity: {
        nameOrentityName: {
            name: "Entity Name",
            placeholder: "Enter Entity Name",
        },
        dobOrDateOfIncorporation: {
            name: "Date of Incorporation",
            placeholder: "Select Date",
        },
        adhaarOrRegistrationNumber: {
            name: "Registration Number",
            placeholder: "Enter Registration Number",
        },
        dinCin: {
            name: "Director Identification  Number",
            placeholder: "Enter DIN",
        },
        gender: false,
    },
};

export function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

export function getIsdCode(mobile) {
    return mobile && mobile.length > 10 ? mobile.slice(0, mobile.length - 10) : "+91";
}

export function getMobileNo(mobile) {
    return mobile ? mobile.slice(mobile.length - 10) : "";
}

export function getCollectionAmount(data) {
    return parseFloat((data.factoringAmount + parseFloat((data.buyerFees + data.buyerInterest).toFixed(2))).toFixed(2));
}

export function getDisbursementAmount(data) {
    return parseFloat((data.factoringAmount - parseFloat((data.sellerFees + data.sellerInterest).toFixed(2))).toFixed(2));
}
