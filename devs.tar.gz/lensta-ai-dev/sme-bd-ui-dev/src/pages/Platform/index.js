import React from "react";
import Cookies from "js-cookie";
import useFetch from "../../hooks/useFetch";
import FinancierAdd from "../../component/PlatformFinancier/FinancierAdd";
import PlatformFinancier from "../../component/PlatformFinancier";
import PlatformSettings from "../../component/PlatformSettings";
import PlatformConfigurations from "../../component/PlatformConfigurations";
import { useState, useEffect } from "react";
import { getAllFinancier } from "../../services/financier";
import { useSelector } from "react-redux";
import { getURL } from "../../configs/apiURL";
import { editFinancier } from "../../redux/financier/actions";
import { getAllUsers } from "../../services/user";
import { notifications } from "../../utils/notifications";
import { platformRolesPermission } from "../../configs/permissions";
import { editUser } from "../../redux/user/actions";
import { Menu } from "antd";
import { message } from "../../utils/message";
import { setFilterQuery } from "../../redux/filters/actions";

const getItem = (label, key, children, component) => {
    return {
        key,
        label,
        children,
        component,
    };
};

const PlatformContainer = () => {
    const {
        financierData = {},
        financierLoading = false,
        editFinanciers,
        users = {},
        loadingUser = false,
        editUsers = {},
    } = useSelector((state) => ({
        financierData: state.financier?.financiers,
        financierLoading: state.financier?.loadingFinancier,
        editFinanciers: state.financier?.editFinancier,
        users: state.user?.users,
        loadingUser: state.user?.loadingUser,
        editUsers: state.user?.editUser,
    }));

    const ACCESS_TOKEN = Cookies.get("ACCESS_TOKEN");

    const [userFetch] = useFetch();
    const [loading, setLoading] = useState(false);
    const [current, setCurrent] = useState("HOME");
    const [financierAdd, setFinancierAdd] = useState(false);

    const onSubmitFinancier = async (value) => {
        setLoading(true);
        let response;
        const name = value?.adminName.split(" ");
        const data = {
            entityDetails: {
                entityCategory: "FINANCIER",
                entityTypeId: null,
                entityName: value.entityName,
                kycApiProvider: "KARZA",
                registrationNo: value.registrationNumber,
                pan: value.panNumber,
                panKycVerified: editFinanciers?.data?.entityDetails?.panKycVerified || value.panKycVerified,
                udyamRegNo: value.udyamNumber || null,
                udyamRegNoKycVerified: editFinanciers?.data?.entityDetails?.udyamRegNoKycVerified || value.udyamRegNoKycVerified,
                dateOfIncorporation: value.incorporationDate || null,
                active: 1,
                themeHexcode: value.themeHexcode
                    ? value.themeHexcode.slice(1, 7)
                    : null,
            },
            adminDetails: {
                userType: "ADMIN",
                firstName: name[0] || "",
                lastName: name[1] || "",
                userStatus: 1,
                mobileNo: value.mobileNo,
                emailId: value.email,
                password: value.password,
                active: 1,
            },
            approvalDetails: {
                dateOfExpiry: value.expiryDate || null,
                approvalType: value.approvalType || null,
            },
        };

        if (editFinanciers?.data?.adminDetails?.id) {
            data["adminDetails"].id = editFinanciers?.data?.adminDetails?.id;
        }

        const formData = new FormData();
        formData.append("entityDetails", JSON.stringify(data.entityDetails));
        formData.append("adminDetails", JSON.stringify(data.adminDetails));
        formData.append(
            "approvalDetails",
            JSON.stringify(data.approvalDetails)
        );

        if (value?.uploadDocuments && value?.uploadDocuments[0])
            formData.append(
                "entityLogo",
                value?.uploadDocuments[0]?.originFileObj,
                value?.uploadDocuments[0]?.originFileObj.name
            );

        let res;
        let _data = {};
        if (editFinanciers?.openEdit === true) {
            const _id = editFinanciers?.data?.entityDetails?.id;
            res = await fetch(getURL(`financiers/${_id}`), {
                method: "PUT",
                body: formData,
                headers: {
                    Authorization: `Bearer ${ACCESS_TOKEN}`,
                },
            });
            if (res.headers.get("content-type")?.includes("application/json")) {
                _data = await res.json();
            }
            res = {
                data: _data,
                hasError: !(res.status === 200),
                status: res.status,
            };
            if (res && res.status === 200) {
                notifications.success({ message: message.FINANCIER_UPDATED });
                editFinancier(false, {});
                response = true;
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                response = false;
            }
        } else {
            res = await fetch(getURL(`financiers`), {
                method: "POST",
                body: formData,
                headers: {
                    Authorization: `Bearer ${ACCESS_TOKEN}`,
                },
            });
            if (res.headers.get("content-type")?.includes("application/json")) {
                _data = await res.json();
            }
            res = {
                data: _data,
                hasError: !(res.status === 200),
                status: res.status,
            };
            if (res && res.status === 200) {
                notifications.success({ message: message.FINANCIER_CREATED });
                setFinancierAdd(false);
                response = true;
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                response = false;
            }
        }
        if (response) getAllFinancier();

        setLoading(false);
        return response;
    };

    const onSubmitUser = async (value) => {
        const name = value?.name.split(" ");
        const _data = {
            firstName: name[0] || "",
            lastName: name[1] || "",
            emailId: value.emailId,
            mobileNo: value.mobileNo,
            userType: value.userType,
            entityId: null,
            entityCategory: null,
            active: 1,
            password: value.password,
        };

        if (editUsers?.openEdit === true) {
            const res = await userFetch(
                getURL(`platform/users/${editUsers?.data?.id}`),
                {
                    method: "PUT",
                    body: JSON.stringify(_data),
                }
            );
            if (res && res.status === 200) {
                getAllUsers();
                notifications.success({ message: message.USER_UPDATED });
                editUser(false, {});
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
            return res;
        } else {
            const res = await userFetch(getURL(`platform/users`), {
                method: "POST",
                body: JSON.stringify(_data),
            });
            if (res && res.status === 200) {
                getAllUsers();
                notifications.success({ message: message.USER_CREATED });
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
            return res;
        }
    };

    const onClick = (e) => {
        setCurrent(e.key);
        localStorage.setItem("currentTab", e.key);
    };

    const items = [
        platformRolesPermission(null, null, "homeTab") &&
            platformRolesPermission("home", "visibility") &&
            getItem("Home", "HOME"),
        platformRolesPermission(null, null, "financierTab") &&
            platformRolesPermission("financier", "visibility") &&
            getItem("Financier", "FINANCIER"),
        platformRolesPermission(null, null, "settingsTab") &&
            platformRolesPermission("settings", "visibility") &&
            getItem("Settings", "SETTINGS"),
        platformRolesPermission(null, null, "configurationsTab") &&
            platformRolesPermission("configurations", "visibility") &&
            getItem("Configurations", "CONFIGURATIONS"),
    ];

    useEffect(() => {
        setFilterQuery(undefined);
    }, [current]); // eslint-disable-line

    return (
        <div>
            <Menu
                defaultSelectedKeys={["HOME"]}
                defaultOpenKeys={["HOME"]}
                mode="horizontal"
                items={items}
                onClick={onClick}
                selectedKeys={[current]}
            />
            {current === "FINANCIER" &&
                (financierAdd || editFinanciers?.openEdit ? (
                    <FinancierAdd
                        defaultValue={editFinanciers?.data || {}}
                        setFinancierAdd={setFinancierAdd}
                        onSubmit={onSubmitFinancier}
                        onSubmitLoader={loading}
                        isUpdate={editFinanciers?.openEdit}
                    />
                ) : (
                    <PlatformFinancier
                        financierData={financierData}
                        loading={financierLoading}
                        setFinancierAdd={setFinancierAdd}
                    />
                ))}
            {current === "SETTINGS" && (
                <PlatformSettings
                    users={users}
                    loading={loadingUser}
                    editUser={editUsers}
                    onSubmit={onSubmitUser}
                />
            )}

            {current === "CONFIGURATIONS" && <PlatformConfigurations />}
        </div>
    );
};

export default PlatformContainer;
