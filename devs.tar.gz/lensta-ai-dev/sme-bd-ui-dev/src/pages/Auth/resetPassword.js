import React, { useState } from "react";
import Cookies from "js-cookie";
import jwt_decode from "jwt-decode";
import * as ROUTES from "../../configs/routes";
import PasswordInput from "../../component/AntdComponent/Password";
import WhiteLogo from "../../component/AntdComponent/Logo/WhiteLogo";
import ColorLogo from "../../component/AntdComponent/Logo/ColorLogo";
import { Button, Form } from "antd";
import { tw } from "twind";
import { useNavigate } from "react-router";
import { Navigate, useParams } from "react-router-dom";
import { theme, ConfigProvider, Layout } from "antd";
import { resetPassword } from "../../services/auth";
import { RULES } from "../../utils/formValidations";

const { useToken } = theme;

const { Header, Content } = Layout;

const ResetPasswordPage = () => {
    const { token } = useToken();

    const params = useParams()

    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);

    const onSubmit = async (value) => {
        setLoading(true);
        const response = await resetPassword(params.userId, params.token, value);
        if (response) {
            navigate(ROUTES["LOGIN"]["path"])
        }
        setLoading(false);
    };

    try { jwt_decode(params.token) } catch (err) {
        return <Navigate to={ROUTES["LOGIN"]["path"]} />
    };

    return (
        <ConfigProvider theme={{ token: { colorPrimary: token.defaultThemeColor } }}>
            {Cookies.get("ACCESS_TOKEN") ? (
                <Navigate
                    to={redirectPaths[jwt_decode(Cookies.get("ACCESS_TOKEN")).token_payload.entityCategory]}
                />
            ) : (
                <Layout style={styles.layout}>
                    <Header style={{ ...styles.header, background: token.defaultThemeColor }}>
                        <WhiteLogo />
                    </Header>
                    <Content className={classNames.content} style={styles.content}>
                        <ColorLogo />
                        <Form
                            size="large"
                            initialValues={{ remember: true }}
                            onFinish={onSubmit}
                            onFinishFailed={(errorInfo) => console.log(errorInfo)}
                            autoComplete="off"
                            style={styles.form}
                        >

                            <Form.Item name="password" rules={RULES.password} style={styles.password} hasFeedback>
                                <PasswordInput
                                    label="New Password"
                                    placeholder="Enter New Password"
                                    required
                                />
                            </Form.Item>

                            <Form.Item name="repassword" rules={RULES.repassword} hasFeedback>
                                <PasswordInput
                                    label="Confirm Password"
                                    placeholder="Enter Password"
                                    required
                                />
                            </Form.Item>

                            <Button type="primary" htmlType="submit" style={styles.btn} loading={loading}>
                                Reset Password
                            </Button>
                        </Form>
                    </Content>
                </Layout>
            )}
        </ConfigProvider>
    );
};

export default ResetPasswordPage;

const redirectPaths = {
    null: ROUTES["FINANCIER_PLATFORM"]["path"],
    FINANCIER: ROUTES["FINANCIER"]["path"],
    BUYER: ROUTES["BUYER"]["path"],
    SELLER: ROUTES["SELLER"]["path"],
};

const styles = {
    layout: {
        backgroundColor: "#C1C8CB",
        height: "100vh",
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    header: {
        zIndex: 2,
        width: "100%",
        boxShadow: "0 3px 10px rgb(0 0 0 / 0.2)",
        padding: "0px 30px",
        display: "flex",
    },
    content: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        boxShadow: "0 3px 10px rgb(0 0 0 / 0.2)",
    },
    form: {
        padding: "10px",
        width: "80%",
        paddingTop: "50px",
        display: "flex",
        flexDirection: "column",
        gap: 10
    },
    btn: {
        width: "100%",
        borderRadius: "4px",
    }
};

const classNames = {
    content: tw`w-full flex flex-col bg-white rounded-lg shadow sm:my-12 sm:max-w-md xl:p-0`,
}
