import React, { Fragment, useState } from "react";
import Cookies from "js-cookie";
import jwt_decode from "jwt-decode";
import * as ROUTES from "../../configs/routes";
import TextInput from "../../component/AntdComponent/Input";
import PasswordInput from "../../component/AntdComponent/Password";
import WhiteLogo from "../../component/AntdComponent/Logo/WhiteLogo";
import ColorLogo from "../../component/AntdComponent/Logo/ColorLogo";
import { Button, Form } from "antd";
import { tw } from "twind";
import { useNavigate } from "react-router";
import { Navigate } from "react-router-dom";
import { theme, ConfigProvider, Layout, Typography } from "antd";
import { login, sendResetPasswordLink } from "../../services/auth";
import IsdCode from "../../component/AntdComponent/Mobile";

const { useToken } = theme;

const { Header, Content } = Layout;

const { Text } = Typography;

const initialValue = {
    value: null,
    label: "Email/Mobile Number",
    placeholder: "Enter Email or Mobile Number"
}

const LoginContainer = () => {
    const { token } = useToken();

    const navigate = useNavigate();

    const [form] = Form.useForm();
    const [forgetPassword, setForgetPassword] = useState(false);
    const [contactIsdCode, setContactIsdCode] = useState("+91");
    const [loading, setLoading] = useState(false);
    const [input, setInput] = useState(initialValue)

    const onSubmit = async (value) => {
        setLoading(true);

        let response, formData = {};
        formData[value.email.includes("@") ? "emailId" : "mobileNo"] = value.email.includes("@") ? value.email : `${contactIsdCode}${value.email}`;
        formData["password"] = value.password;

        if ((formData.emailId || formData.mobileNo) && formData.password) {
            response = await login(formData);
            if (response) {
                navigate(redirectPaths[localStorage.getItem("entityCategory")]);
            }
        }
        else {
            delete formData["password"];
            response = await sendResetPasswordLink(formData);
            if (response) {
                form.resetFields();
            }
        }
        
        setLoading(false);
    };

    const handleOnChange = e => {
        setInput((prev) => {
            if (e.target.value) {
                return (
                    {
                        ...prev,
                        value: e.target.value,
                        label: /^\d+$/.test(e.target.value) ? "Mobile Number" : "Email",
                        placeholder: /^\d+$/.test(e.target.value) ? "Enter Mobile Number" : "Enter Email"
                    }
                )
            }
            return initialValue;
        })
    }

    return (
        <ConfigProvider theme={{ token: { colorPrimary: token.defaultThemeColor } }}>
            {Cookies.get("ACCESS_TOKEN") ? (
                <Navigate
                    to={redirectPaths[jwt_decode(Cookies.get("ACCESS_TOKEN")).token_payload.entityCategory]}
                />
            ) : (
                <Layout style={styles.layout}>
                    <Header style={{ ...styles.header, background: token.defaultThemeColor }}>
                        <WhiteLogo />
                    </Header>
                    <Content className={classNames.content} style={styles.content}>
                        <ColorLogo />
                        <Form
                            form={form}
                            size="large"
                            initialValues={{ remember: true }}
                            onFinish={onSubmit}
                            onFinishFailed={(errorInfo) => console.log(errorInfo)}
                            autoComplete="off"
                            style={styles.form}
                        >
                            <Form.Item name="email" rules={rules.email} style={{ ...styles.email, paddingBottom: forgetPassword ? 0 : 20 }}>
                                <TextInput
                                    label={input.label}
                                    placeholder={input.placeholder}
                                    addonBefore={
                                        /^\d+$/.test(input?.value) && (
                                            <IsdCode
                                                isdCode={contactIsdCode}
                                                setIsdCode={(code) => setContactIsdCode(code)}
                                            />
                                        )
                                    }
                                    onChange={handleOnChange}
                                    required
                                />
                            </Form.Item>
                            {!forgetPassword && (
                                <Fragment>
                                    <Form.Item name="password" rules={rules.password} style={styles.password}>
                                        <PasswordInput
                                            label="Password"
                                            placeholder="Enter Password"
                                            required
                                        />
                                    </Form.Item>
                                    <Text style={styles.resetPassword} onClick={() => setForgetPassword(true)}>
                                        Forget password ?
                                    </Text>
                                </Fragment>
                            )}
                            {forgetPassword && (
                                <Text style={styles.resetPassword} onClick={() => setForgetPassword(false)}>
                                    Continue to Sign in ?
                                </Text>
                            )}
                            <Button type="primary" htmlType="submit" style={styles.btn} loading={loading}>
                                {forgetPassword ? "Send Reset Link" : "Login"}
                            </Button>
                        </Form>
                    </Content>
                </Layout>
            )}
        </ConfigProvider>
    );
};

export default LoginContainer;

const redirectPaths = {
    null: ROUTES["FINANCIER_PLATFORM"]["path"],
    FINANCIER: ROUTES["FINANCIER"]["path"],
    BUYER: ROUTES["BUYER"]["path"],
    SELLER: ROUTES["SELLER"]["path"],
};

const styles = {
    layout: {
        backgroundColor: "#f5f7f7" || "rgba(162, 163, 163, 0.2)",
        height: "100vh",
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    header: {
        zIndex: 2,
        width: "100%",
        boxShadow: "0 3px 10px rgb(0 0 0 / 0.2)",
        padding: "0px 30px",
        display: "flex",
    },
    content: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        boxShadow: "0 3px 10px rgb(0 0 0 / 0.2)",
    },
    form: {
        padding: "10px",
        width: "80%",
        paddingTop: "50px"
    },
    resetPassword: {
        display: "block",
        textAlign: 'right',
        marginBottom: 15,
        cursor: 'pointer',
        color: '#175764'
    },
    btn: {
        width: "100%",
        borderRadius: "4px",
    }
};

const classNames = {
    content: tw`w-full flex flex-col bg-white rounded-lg shadow sm:my-12 sm:max-w-md xl:p-0`,
}

const rules = {
    email: [
        {
            required: true,
            message: "Please input valid Email/Mobile Number"
        }
    ],
    password: [
        {
            required: true,
            message: "Please input valid Password!"
        }
    ]
}
