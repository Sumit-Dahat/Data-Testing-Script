import React, { Fragment } from "react";
import FinancierUserSettings from "../../component/FinancierUserSettings";
import Invoice from "../../component/Invoice";
import AcceptBankFinance from "../../component/Finance/AcceptBankFinance";
import FactoringUnitContainer from "../../component/Finance/FactoringUnit";
import FactoredUnitContainer from "../../component/Finance/FactoredUnit";
import CheckerLevel from "../../component/CheckerLevel";
import NotFactoredUnitContainer from "../../component/Finance/NotFactoredUnit";
import BuyerSellerLink from "../../component/BuyerSellerLink";
import BuyerSellerAdd from "../../component/BuyerSeller/Tabs";
import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Permissions } from "../../configs/permissions";
import { Menu } from "antd";
import { setDocFilterQuery, setFilterQuery } from "../../redux/filters/actions";

const getItem = (label, key, children, component) => {
    return {
        key,
        label,
        children,
        component,
    };
};

const SellerContainer = () => {
    const {
        profile,
        userLoading = false,
        users = {},
        editUser = {},
    } = useSelector((state) => ({
        profile: state.user?.profile,
        userLoading: state.user?.loadingUsers,
        users: state.user?.users,
        editUser: state.user?.editUser,
    }));

    const [buyerSellerAdd, setBuyerSellerAdd] = useState(false);
    const [current, setCurrent] = useState("HOME");

    const items = [
        Permissions(null, null, "homeTab") &&
            Permissions("home", "visibility") &&
            getItem("Home", "HOME"),
        Permissions(null, null, "invoiceTab") &&
            Permissions("invoices", "visibility") &&
            getItem("Invoice", "INVOICE"),
        Permissions(null, null, "factoringUnitTab") &&
            Permissions("factoringUnit", "visibility") &&
            getItem("Factoring Unit", "FACTORING_UNIT"),
        Permissions(null, null, "factoredTab") &&
            getItem("FactoredUnit", "FACTORED", [
                Permissions("acceptBankFinance", "visibility") &&
                    getItem("Accept Bank Finance", "BANK_FINANCE"),
                Permissions("factoredUnit", "visibility") &&
                    getItem("Successful Factored", "FACTORED_UNIT", [
                        Permissions("factoredUnit","openDisbursement") && getItem("Open for disbursement", "OPEN_FOR_DISBURSEMENT"),
                        Permissions("factoredUnit","activeDisbursement") && getItem("Active disbursementt", "ACTIVE_DISBURSEMENT"),
                        Permissions("factoredUnit","overdue") && getItem("Overdue", "OVERDUE_DISBURSEMENT"),
                        Permissions("factoredUnit","paymentClosed") && getItem("Payment closed", "PAYMENT_CLOSED"),
                    ]),
                Permissions("notFactoredUnit", "visibility") &&
                    getItem("UnSuccessful Factored", "NOT_FACTORED_UNIT"),
            ]),
        Permissions(null, null, "settingsTab") &&
            getItem("Settings", "settings", [
                Permissions("buyerSellerLink", "visibility") &&
                    getItem("Buyer-Seller Link", "BUYER_SELLER_LINK"),
                Permissions("users", "visibility") && getItem("Users", "USERS"),
                Permissions("checkerLevel", "visibility") &&
                    getItem("Checker Level", "CHECKER_LEVEL"),
            ]),
        Permissions(null, null, "reportsTab") && getItem("Reports", "REPORTS"),
    ];

    /* Clearing all the filters on routes change */
    useEffect(() => {
        setFilterQuery(undefined);
        setDocFilterQuery(undefined);
    }, [current]);

    const onClick = (e) => {
        setCurrent(e.key);
        localStorage.setItem("currentTab", e.key);
    };

    const editBuyerSellerData = {
        entityDetails: {
            ...profile?.entity,
        },
        adminDetails: {
            ...profile,
        },
    };

    return (
        <Fragment>
            {profile?.entity.approved === 0 && (
                <BuyerSellerAdd
                    selfOnBoard={true}
                    isUpdate={true}
                    editBuyerSellerData={editBuyerSellerData}
                    buyerSellerAdd={buyerSellerAdd}
                    setBuyerSellerAdd={setBuyerSellerAdd}
                />
            )}
            {profile?.entity.approved === 1 && (
                <Fragment>
                    <Menu
                        defaultSelectedKeys={["home"]}
                        defaultOpenKeys={["home"]}
                        mode="horizontal"
                        items={items}
                        onClick={onClick}
                        selectedKeys={[current]}
                    />
                    {current === "INVOICE" && <Invoice />}
                    {current === "FACTORING_UNIT" && <FactoringUnitContainer />}
                    {current === "CHECKER_LEVEL" && <CheckerLevel />}
                    {current === "BUYER_SELLER_LINK" && <BuyerSellerLink />}
                    {current === "NOT_FACTORED_UNIT" && <NotFactoredUnitContainer />}
                    {current === "BANK_FINANCE" && <AcceptBankFinance />}
                    {[ 
                        "OPEN_FOR_DISBURSEMENT", 
                        "ACTIVE_DISBURSEMENT", 
                        "OVERDUE_DISBURSEMENT", 
                        "PAYMENT_CLOSED"
                    ].includes(current) && <FactoredUnitContainer />}
                    {current === "USERS" && (
                        <FinancierUserSettings
                            loading={userLoading}
                            users={users}
                            editUser={editUser}
                        />
                    )}
                </Fragment>
            )}
        </Fragment>
    );
};

export default SellerContainer;
