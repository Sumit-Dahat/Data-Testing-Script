import React from "react";
import TextInput from "../AntdComponent/Input";
import IsdCode from "../AntdComponent/Mobile";
import Date from "../AntdComponent/Date";
import PasswordInput from "../AntdComponent/Password";
import moment from "moment";
import { useEffect, useMemo, useState } from "react";
import { Form, Card, Button, Spin, Row, Col } from "antd";
import { tw } from "twind";
import { RULES } from "../../utils/formValidations";
import { showPassword } from "../../services/auth";
import { Permissions } from "../../configs/permissions";
import { getIsdCode, getMobileNo } from "../../utils/helpers";

const FinancierUserProfileForms = ({ onSubmit, defaultValue }) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState();
    const [isdCode, setIsdCode] = useState(getIsdCode(defaultValue?.adminDetails?.mobileNo));

    const userId = localStorage.getItem("userId");

    const initialValue = useMemo(
        () =>
            Object.keys(defaultValue).length !== 0
                ? {
                    entityName: defaultValue?.entityDetails?.entityName,
                    registrationNumber: defaultValue?.entityDetails?.registrationNo,
                    panNumber: defaultValue?.entityDetails?.pan,
                    udyamNumber: defaultValue?.entityDetails?.udyamRegNo,
                    incorporationDate: defaultValue?.entityDetails?.dateOfIncorporation ? moment(defaultValue?.entityDetails?.dateOfIncorporation) : null,
                    adminName: `${defaultValue?.adminDetails?.firstName} ${defaultValue?.adminDetails?.lastName}`,
                    mobileNo: getMobileNo(defaultValue?.adminDetails?.mobileNo),
                    email: defaultValue?.adminDetails?.emailId,
                  }
                : {},
        [defaultValue]
    );

    const onSubmitHandler = (value) => {
        onSubmit({
            ...value,
            mobileNo: isdCode + value.mobileNo
        });
    };

    const showUserPassword = async (id) => {
        setLoading(true);
        const password = await showPassword(id);
        form.setFieldsValue({
            password: password,
            repassword: password,
        });
        setLoading(false);
    };

    useEffect(() => {
        if (userId) showUserPassword(userId);
        form.setFieldsValue(initialValue);
        setIsdCode(getIsdCode(defaultValue?.adminDetails?.mobileNo));
    }, [initialValue]); // eslint-disable-line

    if (loading) {
        return (
            <div style={{ textAlign: "center", marginTop: "100px" }}>
                <Spin spinning={loading} />
            </div>
        );
    }

    return (
        <div>
            <Form
                form={form}
                size="large"
                initialValues={initialValue}
                onFinish={onSubmitHandler}
                onFinishFailed={(errorInfo) => {
                    console.log(errorInfo);
                }}
                autoComplete="off"
            >
                <Card title="Entity Details" style={{ width: "100%" }}>
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="entityName"
                                rules={RULES.entityName}
                            >
                                <TextInput
                                    label="Entity Name"
                                    placeholder="Entity Name"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="registrationNumber"
                                rules={RULES.registrationNumber}
                            >
                                <TextInput
                                    label="Registration Number"
                                    placeholder="Enter Number"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="panNumber"
                                rules={RULES.panNumber}
                                required
                            >
                                <TextInput
                                    label="PAN Number"
                                    placeholder="Enter PAN"
                                    required
                                    maxLength={10}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="udyamNumber"
                                rules={RULES.udyamNumber}
                            >
                                <TextInput
                                    label="Udyam Number"
                                    placeholder="Enter Udyam No"
                                    maxLength={19}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                style={{ marginLeft: 12 }}
                                name="incorporationDate"
                                rules={RULES.date}
                            >
                                <Date
                                    required
                                    label="Date of Incorporation"
                                    placeholder="Select Date"
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Card>
                <Card
                    title="Admin Details"
                    style={{ width: "100%", marginTop: "20px" }}
                >
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="adminName" rules={RULES.name}>
                                <TextInput
                                    label="Admin Name"
                                    placeholder="Enter Name"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="mobileNo"
                                rules={RULES.mobileNo}
                                style={{ position: "relative", bottom: 7 }}
                            >
                                <TextInput
                                    label="Mobile No"
                                    placeholder="Enter Number"
                                    required
                                    addonBefore={
                                        <IsdCode
                                            isdCode={isdCode}
                                            setIsdCode={(code) =>
                                                setIsdCode(code)
                                            }
                                        />
                                    }
                                    maxLength={10}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="email" rules={RULES.email}>
                                <TextInput
                                    label="Email"
                                    placeholder="Enter Email"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="password"
                                rules={RULES.password}
                                hasFeedback
                            >
                                <PasswordInput
                                    label="Password"
                                    placeholder="Enter Password"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="repassword"
                                rules={RULES.repassword}
                                hasFeedback
                            >
                                <PasswordInput
                                    label="Re-Password"
                                    placeholder="Enter Password"
                                    required
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Card>
                <br />
                {Permissions("profile", "editProfile") && (
                    <Button type="primary" htmlType="submit" size="middle">
                        {"Update"}
                    </Button>
                )}
                <br />
            </Form>
        </div>
    );
};

export default FinancierUserProfileForms;
