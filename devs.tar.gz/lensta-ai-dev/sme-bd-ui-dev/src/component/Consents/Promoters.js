import React from "react";
import useFetch from "../../hooks/useFetch";
import moment from "moment";
import { useEffect, useState, useCallback } from "react";
import { tw } from "twind";
import { getURL } from "../../configs/apiURL";
import { notifications } from "../../utils/notifications";
import { Modal, Button, Form, Checkbox, Statistic, Space, Input } from "antd";
import { RiErrorWarningFill } from "react-icons/ri";
import { MdCancel, MdCheckCircle } from "react-icons/md";
import { consentInit } from "../../utils/handlers";
import { useSelector } from "react-redux";

const { Countdown } = Statistic;

const PromoterConsent = ({ isUpdate, onSubmit, consent, setConsent, resetForm }) => {
    const apiProvider = `${localStorage.getItem("kycProvider")}`.toLowerCase();

    const {
        editPromoters,
    } = useSelector((state) => ({
        editPromoters: state?.buyerSeller?.editPromter
    }));

    const {
        agree,
        stage,
        formInitial,
        formData,
        aadhaarNo,
        aadhaarKyc,
        aadhaarKycVerified,
        otpKycVerified,
        panKyc,
        panKycVerified,
        otpKyc,
    } = consent;

    const [form] = Form.useForm();
    const [fetch, loading] = useFetch();
    const [checked, setChecked] = useState(false);
    const [otp, setOtp] = useState("");
    const [pending, setPending] = useState(false);
    const [requestId, setRequestId] = useState("");
    const [timer, setTimer] = useState({ disabled: true, value: Date.now() + 60 * 1000 });

    const handleKycSubmit = async (action) => {
        let response, next;
        switch (action) {
            case "panSubmit":
                response = await fetch(getURL(`${apiProvider}/kyc/pan`), {
                    method: "POST",
                    body: JSON.stringify({
                        consent: "Y",
                        pan: formData.panNumber,
                        name: formData.nameOrentityName,
                        dob: formData.dobOrDateOfIncorporation.format("YYYY-MM-DD"),
                        entityOrPromoterId: editPromoters?.data?.id
                    }),
                });
                setConsent({ panNumber: formData?.panNumber, panKyc: 1, dob: formData?.dobOrDateOfIncorporation, panKycVerified: response.status === 200 ? 1 : 0 });
                if (!isUpdate) {
                    if (
                        (formData.promoterType === 'INDIVIDUAL' && formData.adhaarOrRegistrationNumber && !aadhaarKyc) ||
                        (aadhaarKyc && formData.adhaarOrRegistrationNumber !== aadhaarNo)
                    ) {
                        next = "adhaarNumber";
                    } else {
                        next = "submit";
                    }
                } else {
                    if (
                        (formData.promoterType === 'INDIVIDUAL') &&
                        (formData.adhaarOrRegistrationNumber) &&
                        (formData.adhaarOrRegistrationNumber !== formInitial?.aadhaarOrRegNo) &&
                        !formInitial.aadhaarKycVerified
                    ) {
                        next = "adhaarNumber";
                    } else {
                        next = "submit";
                    }
                }
                break;
            case "adhaarSubmit":
                response = await fetch(getURL(`${apiProvider}/kyc/aadhaar/otp`), {
                    method: "POST",
                    body: JSON.stringify({
                        consent: "Y",
                        aadhaarNo: formData.adhaarOrRegistrationNumber,
                        promoterId: editPromoters?.data?.id
                    }),
                });
                if (response.status === 200) {
                    setRequestId(response?.data?.data?.requestId);
                    setTimer({ disabled: true, value: Date.now() + 60 * 1000 });
                    if (formData.promoterType === "INDIVIDUAL" && !otpKyc) {
                        next = "otp";
                    } else {
                        next = "submit";
                    }
                    notifications.success({
                        message: "OTP Sended Successfully.",
                    });
                } else {
                    next = "submit";
                }
                break;
            case "otpSubmit":
                response = await fetch(getURL(`${apiProvider}/kyc/aadhaar`), {
                    method: "POST",
                    body: JSON.stringify({
                        consent: "Y",
                        name: formData.nameOrentityName,
                        aadhaarNo: formData.adhaarOrRegistrationNumber,
                        otp: otp,
                        requestId: requestId,
                        promoterId: editPromoters?.data?.id
                    }),
                });
                if (response.status === 200) {
                    setConsent({
                        aadhaarNo: formData?.adhaarOrRegistrationNumber,
                        aadhaarKyc: 1,
                        aadhaarKycVerified: response.status === 200 ? 1 : 0,
                        otpKyc: 1,
                        otpKycVerified: response.status === 200 ? 1 : 0,
                    });
                    next = "submit";
                } else {
                    notifications.error({
                        message: response?.data?.error || "Something went wrong",
                    });
                }
                break;
            default:
                next = "panNumber";
                break;
        }
        setConsent({ stage: next });
    };

    const handleResendOTP = async () => {
        setPending(true);
        const response = await fetch(getURL(`${apiProvider}/kyc/aadhaar/otp`), {
            method: "POST",
            body: JSON.stringify({
                consent: "Y",
                aadhaarNo: formData.adhaarOrRegistrationNumber,
                promoterId: editPromoters?.data?.id
            }),
        });
        if (response.status === 200) {
            setRequestId(response?.data?.data?.requestId);
            notifications.success({ message: "OTP Sended Successfully." });
        } else {
            notifications.error({
                message: response.data?.error?.message || "Something went wrong.",
            });
        }
        setTimer((timer) => ({
            ...timer,
            disabled: !timer.disabled,
            value: Date.now() + 60 * 1000,
        }));
        setPending(false);
    };

    const handleSubmit = async () => {
        const response = await onSubmit({
            ...formData,
            panKycVerified: panKycVerified,
            aadhaarKycVerified: aadhaarKycVerified,
        });
        if (response && resetForm) {
            setTimeout(() => {
                resetForm();
                setConsent({ ...consentInit });
            }, 500);
        }
    };

    const handleLoading = useCallback((action) => stage === action && loading, [loading]); // eslint-disable-line
    const handleDisable = useCallback((action) => stage !== action, [loading]); // eslint-disable-line

    useEffect(() => {
        form.setFieldsValue({
            panNumber: formData.panNumber,
            adhaarNumber: formData.adhaarOrRegistrationNumber,
        });
    }, [form]); // eslint-disable-line

    const viewConsent = (type) => {
        switch (type) {
            case "panNumber":
                if (
                    isUpdate &&
                    formData.panNumber &&
                    (formData.panNumber !== formInitial?.pan || formData.dobOrDateOfIncorporation.format("YYYY-MM-DD") !== moment(formInitial?.dobOrDoi).format("YYYY-MM-DD")) &&
                    !formInitial.entityDetails?.panKycVerified
                ) {
                    return true;
                }
                return !isUpdate && formData.panNumber ? true : false;
            case "adhaarNumber":
                if (
                    isUpdate &&
                    formData.adhaarOrRegistrationNumber &&
                    formData.adhaarOrRegistrationNumber !== formInitial?.aadhaarOrRegNo &&
                    !formInitial?.aadhaarKycVerified
                ) {
                    return true;
                }
                return !isUpdate && formData.adhaarOrRegistrationNumber ? true : false;
            default:
                return false;
        }
    };

    return (
        <Modal open={agree} className="ant-consent-modal" onCancel={() => setConsent({ agree: !agree })} footer={null}>
            {checked && <h1 className={tw`text-center text-lg font-serif`}>KYC Consent & Policy</h1>}
            <Form
                form={form}
                size="medium"
                onFinishFailed={(err) => console.log(err)}
                autoComplete="off"
            >
                {checked && (
                    <div>
                        <br />
                        {viewConsent("panNumber") && (
                            <div className={tw`mb-4`}>
                                <h3 className={tw`font-medium mb-2 ml-1`}>PAN Number</h3>
                                <Space>
                                    <Form.Item name="panNumber" style={{ margin: 0 }}>
                                        <Input
                                            placeholder="ENTER PAN"
                                            disabled
                                            suffix={
                                                (panKyc && panKycVerified && <MdCheckCircle color="green" />) || (
                                                    <MdCancel color="red" />
                                                )
                                            }
                                        />
                                    </Form.Item>
                                    <Button
                                        type="primary"
                                        style={{ height: 31 }}
                                        onClick={() => handleKycSubmit("panSubmit")}
                                        loading={handleLoading("panNumber")}
                                        disabled={handleDisable("panNumber")}
                                    >
                                        Confirm
                                    </Button>
                                </Space>
                            </div>
                        )}
                        {viewConsent("adhaarNumber") && formData.promoterType === "INDIVIDUAL" && (
                            <div className={tw`mb-4`}>
                                <h3 className={tw`font-medium mb-2 ml-1`}>Aadhaar Number</h3>
                                <Space>
                                    <Form.Item name="adhaarNumber" style={{ margin: 0 }}>
                                        <Input
                                            placeholder="Enter Aadhaar Number"
                                            disabled
                                            suffix={
                                                (aadhaarKyc && aadhaarKycVerified && <MdCheckCircle color="green" />) || (
                                                    <MdCancel color="red" />
                                                )
                                            }
                                        />
                                    </Form.Item>
                                    <Button
                                        type="primary"
                                        style={{ height: 31 }}
                                        onClick={() => handleKycSubmit("adhaarSubmit")}
                                        loading={handleLoading("adhaarNumber")}
                                        disabled={handleDisable("adhaarNumber")}
                                    >
                                        Confirm
                                    </Button>
                                </Space>
                            </div>
                        )}
                        {stage === "otp" && (
                            <div className={tw`mb-4`}>
                                <h3 className={tw`font-medium mb-2 ml-1`}>OTP Number</h3>
                                <Space
                                    style={{
                                        display: "flex",
                                        alignItems: "flex-start",
                                    }}
                                >
                                    <Form.Item
                                        name="otp"
                                        style={{
                                            margin: 0,
                                            alignItems: "start",
                                        }}
                                        rules={[
                                            {
                                                required: true,
                                                message: "Enter 6 digit OTP",
                                            },
                                            {
                                                pattern: /^\d+$/,
                                                whitespace: false,
                                                message: "must be number!",
                                            },
                                        ]}
                                    >
                                        <Input
                                            placeholder="ENTER OTP*"
                                            onChange={(e) => setOtp(e.target.value)}
                                            suffix={
                                                (otpKyc && otpKycVerified && <MdCheckCircle color="green" />) || (
                                                    <MdCancel color="red" />
                                                )
                                            }
                                        />
                                    </Form.Item>
                                    <Button
                                        type="primary"
                                        onClick={() => handleKycSubmit("otpSubmit")}
                                        style={{
                                            height: 31,
                                        }}
                                        loading={handleLoading("otp") && !pending}
                                        disabled={handleDisable("otp")}
                                    >
                                        Confirm
                                    </Button>
                                    <Button
                                        type="primary"
                                        loading={loading && pending}
                                        disabled={timer.disabled}
                                        onClick={handleResendOTP}
                                    >
                                        Resend OTP
                                        <Countdown
                                            value={timer.value}
                                            valueStyle={{
                                                fontSize: "14.55px",
                                                marginTop: "10px",
                                            }}
                                            onFinish={() =>
                                                setTimer((timer) => ({
                                                    ...timer,
                                                    disabled: !timer.disabled,
                                                }))
                                            }
                                        />
                                    </Button>
                                </Space>
                            </div>
                        )}
                        <br />
                        {checked && (
                            <div className={tw`flex flex-row-reverse gap-2`}>
                                <Button
                                    danger
                                    name="delete"
                                    type="primary"
                                    onClick={() => setChecked((checked) => !checked)}
                                    htmlType="submit"
                                >
                                    Cancel
                                </Button>
                                <Button
                                    type="primary"
                                    size="md"
                                    loading={handleLoading("submit")}
                                    disabled={handleDisable("submit")}
                                    onClick={handleSubmit}
                                >
                                    Submit
                                </Button>
                            </div>
                        )}
                    </div>
                )}
                {!checked && (
                    <div>
                        <div className={tw`flex flex-col justify-center items-center`}>
                            <RiErrorWarningFill size={50} color="darkorange" />
                            <p className={tw`text-xl font-serif`}>Are you sure ?</p>
                        </div>
                        <div className={tw`flex justify-center mt-2`}>
                            <Form.Item name="remember" valuePropName="checked">
                                <Checkbox onChange={() => setChecked(() => !checked)}>
                                    Yes, I understand and agree for the KYC Consent & Policy.
                                </Checkbox>
                            </Form.Item>
                        </div>
                    </div>
                )}
            </Form>
        </Modal>
    );
};
export default PromoterConsent;
