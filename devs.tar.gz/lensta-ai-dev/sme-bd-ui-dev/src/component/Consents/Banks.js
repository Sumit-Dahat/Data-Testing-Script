import React from "react";
import useFetch from "../../hooks/useFetch";
import { useEffect, useState } from "react";
import { consentInit } from "../../utils/handlers";
import { tw } from "twind";
import { getURL } from "../../configs/apiURL";
import { Modal, Button, Form, Checkbox, Space, Input } from "antd";
import { RiErrorWarningFill } from "react-icons/ri";
import { MdCancel, MdCheckCircle } from "react-icons/md";
import { useCallback } from "react";
import { useSelector } from "react-redux";

const Bank = ({ isUpdate, onSubmit, consent, setConsent, resetForm, editBuyerSellerData }) => {
    const apiProvider = `${localStorage.getItem("kycProvider")}`.toLowerCase();

    const { agree, stage, formInitial, formData, bankAcckyc, bankAccKycVerified } = consent;

    const {
        editBanks
    } = useSelector((state) => ({
        editBanks: state?.buyerSeller?.editBank
    }));

    const [form] = Form.useForm();
    const [fetch, loading] = useFetch();
    const [checked, setChecked] = useState(false);

    const handleKycSubmit = async (action) => {
        let response, next;
        switch (action) {
            case "accountSubmit":
                response = await fetch(getURL(`${apiProvider}/kyc/bank-account`), {
                    method: "POST",
                    body: JSON.stringify({
                        consent: "Y",
                        accountNumber: formData.accountNo,
                        accountHolderName: editBuyerSellerData.entityDetails.entityName,
                        ifsc: formData.ifscCode,
                        nameMatchType: "entity",
                        bankAccId: editBanks?.data?.id
                    }),
                });
                setConsent({
                    bankAccNo: formData.accountNo,
                    bankAcckyc: 1,
                    bankAccKycVerified: response.status === 200 ? 1 : 0,
                });
                next = "submit";
                break;
            default:
                next = "accountNo";
                break;
        }
        setConsent({ stage: next });
    };

    const handleSubmit = async () => {
        const response = await onSubmit({
            ...formData,
            bankAccKycVerified: bankAccKycVerified,
        });
        if (response && resetForm) {
            setTimeout(() => {
                resetForm();
                setConsent({ ...consentInit });
            }, 500);
        }
    };

    const viewConsent = (type) => {
        switch (type) {
            case "accountNo":
                if (
                    isUpdate &&
                    formData.accountNo &&
                    formData.accountNo !== formInitial.accountNo &&
                    !formInitial.bankAccKycVerified
                ) {
                    return true;
                }
                return !isUpdate && formData.accountNo ? true : false;
            default:
                return false;
        }
    };

    const handleLoading = useCallback((action) => stage === action && loading, [loading]); // eslint-disable-line
    const handleDisable = useCallback((action) => stage !== action, [loading]); // eslint-disable-line

    useEffect(() => {
        form.setFieldsValue({
            accountNo: formData?.accountNo,
        });
    }, []); // eslint-disable-line

    return (
        <Modal open={agree} className="ant-consent-modal" onCancel={() => setConsent({ agree: !agree })} footer={null}>
            {checked && <h1 className={tw`text-center text-lg font-serif`}>KYC Consent & Policy</h1>}
            <Form form={form} size="medium" autoComplete="off">
                {checked && (
                    <div>
                        <br />
                        {viewConsent("accountNo") && (
                            <div className={tw`mb-4`}>
                                <h3 className={tw`font-medium mb-2 ml-1`}>Account Number</h3>
                                <Space>
                                    <Form.Item name="accountNo" style={{ margin: 0 }}>
                                        <Input
                                            placeholder="ENTER Account Number"
                                            disabled
                                            suffix={
                                                (bankAcckyc && bankAccKycVerified && <MdCheckCircle color="green" />) || (
                                                    <MdCancel color="red" />
                                                )
                                            }
                                        />
                                    </Form.Item>
                                    <Button
                                        type="primary"
                                        style={{ height: 31 }}
                                        onClick={() => handleKycSubmit("accountSubmit")}
                                        loading={handleLoading("accountNo")}
                                        disabled={handleDisable("accountNo")}
                                    >
                                        Confirm
                                    </Button>
                                </Space>
                            </div>
                        )}
                        {checked && (
                            <div className={tw`flex flex-row-reverse gap-2`}>
                                <Button
                                    type="primary"
                                    danger
                                    name="delete"
                                    onClick={() => setChecked(() => !checked)}
                                    htmlType="submit"
                                >
                                    Cancel
                                </Button>
                                <Button
                                    type="primary"
                                    size="md"
                                    loading={handleLoading("submit")}
                                    disabled={handleDisable("submit")}
                                    onClick={handleSubmit}
                                >
                                    Submit
                                </Button>
                            </div>
                        )}
                    </div>
                )}
                {!checked && (
                    <div>
                        <div className={tw`flex flex-col justify-center items-center`}>
                            <RiErrorWarningFill size={50} color="darkorange" />
                            <p className={tw`text-xl font-serif`}>Are you sure ?</p>
                        </div>
                        <div className={tw`flex justify-center mt-2`}>
                            <Form.Item name="remember" valuePropName="checked">
                                <Checkbox onChange={() => setChecked(() => !checked)}>
                                    Yes, I understand and agree for the KYC Consent & Policy.
                                </Checkbox>
                            </Form.Item>
                        </div>
                    </div>
                )}
            </Form>
        </Modal>
    );
};
export default Bank;
