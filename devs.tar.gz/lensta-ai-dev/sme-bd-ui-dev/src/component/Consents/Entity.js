import React from "react";
import useFetch from "../../hooks/useFetch";
import moment from "moment";
import { consentInit } from "../../utils/handlers";
import { useEffect, useState } from "react";
import { tw } from "twind";
import { getURL } from "../../configs/apiURL";
import { Modal, Button, Form, Checkbox, Space, Input } from "antd";
import { RiErrorWarningFill } from "react-icons/ri";
import { MdCancel, MdCheckCircle } from "react-icons/md";
import { useCallback } from "react";
import { useSelector } from "react-redux";

const BuyerSellerConsent = ({ isUpdate, onSubmit, onSubmitLoader, consent, setConsent }) => {
    const apiProvider = `${localStorage.getItem("kycProvider")}`.toLowerCase();

    const [form] = Form.useForm();
    const [fetch, loading] = useFetch();
    const [checked, setChecked] = useState(false);

    const {
        editBuyerSeller,
    } = useSelector((state) => ({
        editBuyerSeller: state.buyerSeller?.editBuyerSeller
    }));

    const {
        agree,
        stage,
        formInitial,
        formData,
        udyamNumber,
        udyamRegNoKyc,
        udyamRegNoKycVerified,
        panKyc,
        panKycVerified,
    } = consent;

    const handleKycSubmit = async (action) => {
        let response, next;
        switch (action) {
            case "panSubmit":
                response = await fetch(getURL(`${apiProvider}/kyc/pan`), {
                    method: "POST",
                    body: JSON.stringify({
                        consent: "Y",
                        pan: formData?.panNumber,
                        name: formData?.entityName,
                        dob: formData?.incorporationDate.format("YYYY-MM-DD"),
                        entityOrPromoterId: editBuyerSeller?.data?.entityDetails?.id
                    }),
                });
                setConsent({ panNumber: formData?.panNumber, panKyc: 1, dob: formData?.incorporationDate, panKycVerified: response.status === 200 ? 1 : 0 });
                if (!isUpdate) {
                    if (
                        (formData.udyamNumber && !udyamRegNoKyc) ||
                        (udyamRegNoKyc && formData.udyamNumber !== udyamNumber)
                    ) {
                        next = "udyamNumber";
                    } else {
                        next = "submit";
                    }
                } else {
                    if (
                        formData.udyamNumber &&
                        formInitial.entityDetails?.udyamRegNo !== formData?.udyamNumber &&
                        !formInitial?.entityDetails?.udyamRegNoKycVerified
                    ) {
                        next = "udyamNumber";
                    } else {
                        next = "submit";
                    }
                }
                break;
            case "udyamSubmit":
                response = await fetch(getURL(`${apiProvider}/kyc/udyam`), {
                    method: "POST",
                    body: JSON.stringify({
                        consent: "Y",
                        udyamRegistrationNo: formData?.udyamNumber,
                        name: formData?.entityName,
                        entityId: editBuyerSeller?.data?.entityDetails?.id
                    }),
                });
                setConsent({
                    udyamNumber: formData?.udyamNumber,
                    udyamRegNoKyc: 1,
                    udyamRegNoKycVerified: response.status === 200 ? 1 : 0,
                });
                next = "submit";
                break;
            default:
                next = "panNumber";
                break;
        }
        setConsent({ stage: next });
    };

    const viewConsent = (type) => {
        switch (type) {
            case "panNumber":
                if (
                    isUpdate &&
                    formData.panNumber &&
                    (formData.panNumber !== formInitial?.entityDetails?.pan || formData.incorporationDate.format("YYYY-MM-DD") !== moment(formInitial?.entityDetails?.dateOfIncorporation).format("YYYY-MM-DD")) &&
                    !formInitial.entityDetails?.panKycVerified
                ) {
                    return true;
                }
                return !isUpdate && formData.panNumber ? true : false;
            case "udyamNumber":
                if (
                    isUpdate &&
                    formData.udyamNumber &&
                    formData.udyamNumber !== formInitial?.entityDetails?.udyamRegNo &&
                    !formInitial.entityDetails?.udyamRegNoKycVerified
                ) {
                    return true;
                }
                return !isUpdate && formData.udyamNumber ? true : false;
            default:
                return false;
        }
    };

    const handleSubmit = async () => {
        const response = await onSubmit({
            ...formData,
            panKycVerified: panKycVerified,
            udyamRegNoKycVerified: udyamRegNoKycVerified,
        });
        if (response) {
            setConsent({ ...consentInit });
        }
    };

    const handleLoading = useCallback((action) => stage === action && loading, [loading]); // eslint-disable-line
    const handleDisable = useCallback((action) => stage !== action, [loading]); // eslint-disable-line

    useEffect(() => {
        form.setFieldsValue({
            panNumber: formData?.panNumber,
            udyamNumber: formData?.udyamNumber,
        });
    }, []); // eslint-disable-line

    return (
        <Modal open={agree} className="ant-consent-modal" onCancel={() => setConsent({ agree: !agree })} footer={null}>
            {checked && <h1 className={tw`text-center text-lg font-serif`}>KYC Consent & Policy</h1>}
            <Form form={form} size="medium" autoComplete="off">
                {checked && (
                    <div>
                        <br />
                        {viewConsent("panNumber") && (
                            <div className={tw`mb-4`}>
                                <h3 className={tw`font-medium mb-2 ml-1`}>PAN Number</h3>
                                <Space>
                                    <Form.Item name="panNumber" style={{ margin: 0 }}>
                                        <Input
                                            placeholder="ENTER PAN"
                                            disabled
                                            suffix={
                                                (panKyc && panKycVerified && <MdCheckCircle color="green" />) || (
                                                    <MdCancel color="red" />
                                                )
                                            }
                                        />
                                    </Form.Item>
                                    <Button
                                        type="primary"
                                        style={{ height: 31 }}
                                        onClick={() => handleKycSubmit("panSubmit")}
                                        loading={handleLoading("panNumber")}
                                        disabled={handleDisable("panNumber")}
                                    >
                                        Confirm
                                    </Button>
                                </Space>
                            </div>
                        )}
                        {viewConsent("udyamNumber") && (
                            <div className={tw`mb-4`}>
                                <h3 className={tw`font-medium mb-2 ml-1`}>Udyam Number</h3>
                                <Space>
                                    <Form.Item name="udyamNumber" style={{ margin: 0 }}>
                                        <Input
                                            placeholder="ENTER UDYAM NO"
                                            disabled
                                            suffix={
                                                (udyamRegNoKyc && udyamRegNoKycVerified && (
                                                    <MdCheckCircle color="green" />
                                                )) || <MdCancel color="red" />
                                            }
                                        />
                                    </Form.Item>
                                    <Button
                                        type="primary"
                                        style={{ height: 31 }}
                                        onClick={() => handleKycSubmit("udyamSubmit")}
                                        loading={handleLoading("udyamNumber")}
                                        disabled={handleDisable("udyamNumber")}
                                    >
                                        Confirm
                                    </Button>
                                </Space>
                            </div>
                        )}
                        {checked && (
                            <div className={tw`flex flex-row-reverse gap-2`}>
                                <Button
                                    type="primary"
                                    danger
                                    name="delete"
                                    onClick={() => setConsent({ agree: !agree })}
                                    htmlType="submit"
                                >
                                    Cancel
                                </Button>
                                <Button
                                    type="primary"
                                    size="md"
                                    loading={onSubmitLoader}
                                    disabled={handleDisable("submit")}
                                    onClick={handleSubmit}
                                >
                                    Submit
                                </Button>
                            </div>
                        )}
                    </div>
                )}
                {!checked && (
                    <div>
                        <div className={tw`flex flex-col justify-center items-center`}>
                            <RiErrorWarningFill size={50} color="darkorange" />
                            <p className={tw`text-xl font-serif`}>Are you sure ?</p>
                        </div>
                        <div className={tw`flex justify-center mt-2`}>
                            <Form.Item name="remember" valuePropName="checked">
                                <Checkbox onChange={() => setChecked(() => !checked)}>
                                    Yes, I understand and agree for the KYC Consent & Policy.
                                </Checkbox>
                            </Form.Item>
                        </div>
                    </div>
                )}
            </Form>
        </Modal>
    );
};
export default BuyerSellerConsent;
