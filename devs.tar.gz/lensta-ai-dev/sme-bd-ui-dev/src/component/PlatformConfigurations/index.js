import React from "react";
import ConfigType from "./ConfigType";
import ConfigSector from "./ConfigSector";
import { useState, useEffect } from "react";
import { Tabs } from "antd";
import { ACTION_TYPES } from "../../utils/helpers";
import { setBuyerSellerFilterQuery } from "../../redux/buyerSeller/actions";

const { TabPane } = Tabs;

const initialState = {
    data: {},
    loading: false,
    error: false,
    edit: null,
};

const reducer = (state, action) => {
    switch (action.type) {
        case ACTION_TYPES.FETCH_START:
            return {
                ...state,
                loading: true,
            };
        case ACTION_TYPES.FETCH_SUCCESS:
            return {
                ...state,
                loading: false,
                data: action.payload,
            };
        case ACTION_TYPES.FETCH_ERROR:
            return {
                ...state,
                loading: false,
                error: true,
            };
        case ACTION_TYPES.EDIT:
            return {
                ...state,
                edit: action.payload,
            };
        default:
            return state;
    }
};

const Configurations = () => {
    const [currentTab, setCurrentTab] = useState("1");
    const [width, setWidth] = useState(window.innerWidth);

    useEffect(() => {
        window.addEventListener("resize", () => setWidth(window.innerWidth));
        return () => window.removeEventListener("resize", () => setWidth(window.innerWidth));
    }, []);

    useEffect(() => {
        setBuyerSellerFilterQuery(undefined);
    }, [currentTab]);

    return (
        <div
            style={{
                display: "flex",
                flexDirection: "column",
            }}
        >
            <div className="card-container">
                <Tabs
                    type="line"
                    size="middle"
                    tabPosition={width > 768 ? "left" : "top"}
                    activeKey={currentTab}
                    onChange={(key) => {
                        setCurrentTab(key);
                    }}
                >
                    <TabPane tab="Entity Type" key="1">
                        {currentTab === "1" && (
                            <ConfigType
                                type="entity-types"
                                title="Entity Type"
                                initialState={initialState}
                                reducer={reducer}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Account Type" key="2">
                        {currentTab === "2" && (
                            <ConfigType
                                type="bank-account-types"
                                title="Bank Account Type"
                                initialState={initialState}
                                reducer={reducer}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Address Type" key="3">
                        {currentTab === "3" && (
                            <ConfigType
                                type="address-types"
                                title="Address Type"
                                initialState={initialState}
                                reducer={reducer}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Business Sector" key="4">
                        {currentTab === "4" && (
                            <ConfigType
                                type="business-sectors"
                                title="Business Sector"
                                initialState={initialState}
                                reducer={reducer}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Industry Sector" key="5">
                        {currentTab === "5" && (
                            <ConfigSector
                                type="industry-sectors"
                                title="Industry Sector"
                                initialState={initialState}
                                reducer={reducer}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Industry Sub Sector" key="6">
                        {currentTab === "6" && (
                            <ConfigSector
                                type="industry-sub-sectors"
                                title="Industry Sub Sector"
                                initialState={initialState}
                                reducer={reducer}
                            />
                        )}
                    </TabPane>
                </Tabs>
            </div>
        </div>
    );
};

export default Configurations;
