import useFetch from "../../hooks/useFetch";
import TextInput from "../AntdComponent/Input";
import TableComponent from "../AntdComponent/Table";
import SelectComponent from "../AntdComponent/Select";
import { Button, Form, Card, Row, Col, Switch, Space, Divider, Typography } from "antd";
import { useEffect, useState, useReducer } from "react";
import { tw } from "twind";
import { TextFilter, StatusFilter } from "../../utils/formFilters";
import { useSelector } from "react-redux";
import { capitalizeFirstLetter } from "../../utils/helpers";
import { getURL } from "../../configs/apiURL";
import { ACTION_TYPES } from "../../utils/helpers";
import { RULES } from "../../utils/formValidations";
import { MdModeEditOutline } from "react-icons/md";
import { notifications } from "../../utils/notifications";
import { platformRolesPermission } from "../../configs/permissions";

const { Text } = Typography;

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT;

const ConfigType = ({ type, title, initialState, reducer }) => {
    const { query } = useSelector((state) => ({
        query: state.filters?.query,
    }));

    const [state, dispatch] = useReducer(reducer, initialState);
    const [form] = Form.useForm();
    const [fetch] = useFetch();
    const [dropDown, setDropDown] = useState();

    const getData = async () => {
        dispatch({ type: ACTION_TYPES.FETCH_START });
        try {
            const res = await fetch(`${getURL(type)}?limit=${PAGE_LIMIT}&${query || ""}`);
            if (res && res.status === 200) {
                dispatch({
                    type: ACTION_TYPES.FETCH_SUCCESS,
                    payload: res.data,
                });
            }
        } catch (error) {
            dispatch({ type: ACTION_TYPES.FETCH_ERROR });
        }
    };

    const onStatusUpdate = async (id, status) => {
        const res = await fetch(getURL(`${type}/${id}`), {
            method: "PUT",
            body: JSON.stringify({
                active: status ? 1 : 0,
            }),
        });
        if (res && res.status === 200) {
            notifications.success({ message: `${title} updated successfully` });
            getData();
        } else {
            notifications.error({
                message: res.data?.error?.message || "something went wrong",
            });
        }
    };

    const onSubmit = async (value) => {
        if (state.edit) {
            const data = { name: value?.name };
            if (type === "industry-sectors") {
                data["businessSectorId"] = value?.sector;
            } else {
                data["industrySectorId"] = value?.sector;
            }
            const res = await fetch(getURL(`${type}/${state.edit.id}`), {
                method: "PUT",
                body: JSON.stringify(data),
            });
            if (res && res.status === 200) {
                notifications.success({
                    message: `${capitalizeFirstLetter(title)} Updated Successfully`,
                });
                form.setFieldsValue({ name: undefined, sector: undefined });
                dispatch({ type: ACTION_TYPES.EDIT, payload: null });
                getData();
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
        } else {
            const data = {
                name: value?.name,
                active: 1,
                createdByUserId: localStorage.getItem("userId"),
            };
            if (type === "industry-sectors") {
                data["businessSectorId"] = value?.sector;
            } else {
                data["industrySectorId"] = value?.sector;
            }
            const res = await fetch(getURL(`${type}`), {
                method: "POST",
                body: JSON.stringify(data),
            });
            if (res && res.status === 200) {
                notifications.success({
                    message: `${capitalizeFirstLetter(title)} Created Successfully`,
                });
                form.setFieldsValue({ name: undefined, sector: undefined });
                getData();
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
        }
    };

    const getDropDown = async () => {
        const url = new URL(
            getURL(type === "industry-sectors" ? "business-sectors" : "industry-sectors")
        );
        const res = await fetch(url);
        if (res && res.status === 200) {
            setDropDown(
                res.data.data?.map((option) => ({
                    value: option.id,
                    label: option?.name,
                }))
            );
        }
    };

    useEffect(() => {
        getDropDown();
    }, []); // eslint-disable-line

    useEffect(() => {
        if (state.edit) {
            form.setFieldsValue({
                name: state.edit?.name,
                sector:
                    type === "industry-sectors"
                        ? state.edit?.businessSector?.id
                        : state.edit?.industrySector?.id,
            });
        }
    }, [form, state.edit]); // eslint-disable-line

    useEffect(() => {
        getData();
    }, [query]); // eslint-disable-line

    const columns = [
        {
            title: (
                <div>
                    <Text>
                        {type === "industry-sectors" ? "Business Sectors" : "Industry Sectors"}
                    </Text>
                    <Divider />
                    <TextFilter
                        type={
                            type === "industry-sectors"
                                ? "businessSectorName"
                                : "industrySectorName"
                        }
                    />
                </div>
            ),
            dataIndex: "parent",
            key: "parent",
            render: (_, record) => (
                <Text>
                    {type === "industry-sectors"
                        ? `${record?.businessSector?.name}`
                        : `${record?.industrySector?.name}`}
                </Text>
            ),
        },
        {
            title: (
                <div>
                    <Text>{title}</Text>
                    <Divider />
                    <TextFilter type="name" />
                </div>
            ),
            dataIndex: "level",
            key: "level",
            render: (_, record) => <Text>{record?.name}</Text>,
        },
        {
            title: (
                <div>
                    <Text>Actions</Text>
                    <Divider />
                    <StatusFilter type="active" />
                </div>
            ),
            key: "action",
            render: (_, record) => (
                <div className={tw`flex justify-center`}>
                    <Space size="middle" align="center">
                        {platformRolesPermission("configurations", "editConfiguration") && (
                            <Button
                                name="update-configuration"
                                style={{ borderRadius: "8px", padding: "5px" }}
                                onClick={() =>
                                    dispatch({
                                        type: ACTION_TYPES.EDIT,
                                        payload: record,
                                    })
                                }
                            >
                                <MdModeEditOutline size="20px" color="black" />
                            </Button>
                        )}
                        {platformRolesPermission("configurations", "editConfigurationStatus") && (
                            <Switch
                                checked={record?.active ? true : false}
                                onChange={(checked) => onStatusUpdate(record?.id, checked)}
                            />
                        )}
                    </Space>
                </div>
            ),
        },
    ];

    return (
        <>
            <Form
                form={form}
                size="large"
                autoComplete="off"
                initialValues={state.edit || {}}
                onFinish={onSubmit}
                onFinishFailed={(errorInfo) => console.log(errorInfo)}
            >
                <Card style={{ width: "100%", paddingTop: "20px", marginTop: "10px" }}>
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                    >
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="sector" rules={RULES.selectRequired}>
                                <SelectComponent
                                    label={
                                        type === "industry-sectors"
                                            ? "Business Sectors"
                                            : "Industry Sectors"
                                    }
                                    placeholder="Select"
                                    required
                                    allowClear={true}
                                    options={dropDown}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="name" rules={RULES.inputRequired}>
                                <TextInput label={title} placeholder={`Enter ${title}`} required />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Button
                                type="primary"
                                htmlType="submit"
                                className={tw`w-full md:w-auto px-12`}
                            >
                                {state.edit ? "Update" : "Add"}
                            </Button>
                        </Col>
                    </Row>
                </Card>
            </Form>
            <div className={tw`mt-5`}>
                <TableComponent columns={columns} data={state.data} loading={state.loading} />
            </div>
        </>
    );
};

export default ConfigType;
