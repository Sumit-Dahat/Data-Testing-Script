import React, { useState } from "react";
import { Button, Card, Modal, Space, Typography, Form, Table, Input } from "antd";
import { Permissions } from "../../../configs/permissions";
import { getAllOpenForFinance } from "../../../services/factoringUnit";
import { getURL } from "../../../configs/apiURL";
import { tw } from "twind";
import { notifications } from "../../../utils/notifications";
import { RULES } from "../../../utils/formValidations";
import { message } from "../../../utils/message";
import { FactoringUnitViewColumns } from "../ViewModal/FactoringUnitViewColumns";
import { invoiceViewColumns } from "../ViewModal/InvoiceViewColumns";
import useFetch from "../../../hooks/useFetch";
import Cookies from "js-cookie";
import moment from "moment";
import TextInput from "../../AntdComponent/Input";
import "./styles.css";

const { Text } = Typography;
const { TextArea } = Input;

export const ApproveFactoringUnitModal = ({ label, data }) => {
    const [update] = useFetch();
    const [roiForm] = Form.useForm();
    const [approveForm] = Form.useForm();
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [approve, setApprove] = useState(1);

    const factorUnitViewData = [
        {
            key1: "Factoring Unit No",
            value1: data?.factoringUnitNo,
            key2: "Listed Date",
            value2: moment(data?.fuListedDate).format("DD-MM-YYYY"),
        },
        {
            key1: "Buyer",
            value1: data?.buyerSellerLink?.buyer?.entityName,
            key2: "Seller",
            value2: data?.buyerSellerLink?.seller?.entityName,
        },
        {
            key1: "Invoice Date",
            value1: moment(data?.invoices[0]?.invoiceDate).format("DD-MM-YYYY"),
            key2: "Due Date",
            value2: moment(data?.invoices[0]?.invoiceDueDate).format("DD-MM-YYYY"),
        },
        {
            key1: "Invoice Amount",
            value1: data?.sumOfInvoiceAmounts?.invoiceAmount,
            key2: "Discount Amount",
            value2: data?.sumOfInvoiceAmounts?.discountAmount,
        },
        {
            key1: "Tax Amount",
            value1: data?.sumOfInvoiceAmounts?.taxAmount,
            key2: "Total",
            value2: data?.sumOfInvoiceAmounts?.totalAmount,
        },
    ];

    const showModal = () => {
        setIsModalVisible(true);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };

    const onROISubmit = async (value) => {
        const res = await update(getURL(`factoring-units/${data?.factoringUnitNo}`), {
            method: "PUT",
            body: JSON.stringify({
                buyerFees: parseFloat(value?.buyerFees),
                sellerFees: parseFloat(value?.sellerFees),
                rateOfInterest: parseFloat(value?.rateOfInterest),
            }),
        });
        if (res && res.status === 200) {
            notifications.success({
                message: message.FEE_AND_ROI_ADDED,
            });
            roiForm.resetFields();
            setIsModalVisible(false);
            getAllOpenForFinance(Cookies.get("entityId"));
        } else {
            notifications.error({
                message: res.data?.error?.message || "something went wrong",
            });
        }
    };

    const onApproveSubmit = async (value) => {
        const res = await update(getURL(`factoring-units/${data?.factoringUnitNo}/validate-roi`), {
            method: "PUT",
            body: JSON.stringify({
                status: "OPEN_FOR_FINANCE",
                approved: approve,
                remarks: value?.remarks,
            }),
        });
        if (res && res.status === 200) {
            notifications.success({
                message: message.OPEN_FOR_FINANCE_APPROVED,
            });
            approveForm.resetFields();
            setIsModalVisible(false);
            getAllOpenForFinance(Cookies.get("entityId"));
        } else {
            notifications.error({
                message: res.data?.error?.message || "something went wrong",
            });
        }
    };

    return (
        <>
            <Button
                name="approve-btn"
                style={{ borderRadius: "8px", padding: "4px" }}
                onClick={showModal}
            >
                {label}
            </Button>
            <Modal
                title={
                    data?.buyerFees === null &&
                    data?.sellerFees === null &&
                    data?.rateOfInterest === null
                        ? "Add Fees & ROI"
                        : "Approve Factoring Unit"
                }
                open={isModalVisible}
                footer={
                    <>
                        {Permissions("openForFinance", "approveOpenForFinance") &&
                            data?.buyerFees !== null &&
                            data?.sellerFees !== null &&
                            data?.rateOfInterest !== null && (
                                <Form
                                    form={approveForm}
                                    size="large"
                                    className={tw`mx-2 flex flex-col md:flex-row justify-center items-start md:items-center gap-3`}
                                    onFinish={(value) => {
                                        onApproveSubmit(value);
                                        approveForm.resetFields();
                                    }}
                                    onFinishFailed={(errorInfo) => {
                                        console.log(errorInfo);
                                    }}
                                    autoComplete="off"
                                >
                                    <div style={{ flex: 1 }} className={tw`w-full`}>
                                        <Form.Item name="remarks" rules={RULES.inputRequired}>
                                            <TextArea
                                                rows={4}
                                                label="Remarks"
                                                placeholder="Enter Remarks"
                                            />
                                        </Form.Item>
                                    </div>
                                    <div className={tw`flex md:pt-16`}>
                                        <Button
                                            size="middle"
                                            type="primary"
                                            name="approve"
                                            htmlType="submit"
                                        >
                                            Approve
                                        </Button>
                                        <Button
                                            size="middle"
                                            danger
                                            type="primary"
                                            name="reject"
                                            htmlType="submit"
                                            onClick={() => setApprove(0)}
                                        >
                                            Reject
                                        </Button>
                                    </div>
                                </Form>
                            )}
                    </>
                }
                onCancel={handleCancel}
                centered
            >
                <div className="table-responsive">
                    <Table
                        columns={FactoringUnitViewColumns}
                        dataSource={factorUnitViewData}
                        rowKey="key"
                        loading={false}
                        bordered
                        showHeader={false}
                        pagination={false}
                    />
                </div>
                <br />
                <div className="table-responsive">
                    <Table
                        columns={invoiceViewColumns}
                        dataSource={data?.invoices?.map((row) => ({
                            ...row,
                            buyerSellerLink: data?.buyerSellerLink,
                        }))}
                        rowKey="key"
                        loading={false}
                        bordered
                        pagination={false}
                    />
                </div>
                <br />
                <Card>
                    <div className={tw`flex flex-col md:flex-row justify-between`}>
                        <Space>
                            <Text className="font-semibold">Buyer Available Limit: </Text>
                            <Text>{data?.buyerSellerLink?.buyer?.sanctionedLimit}</Text>
                        </Space>
                        <Space>
                            <Text className="font-semibold">Seller Available Limit : </Text>
                            <Text>{data?.buyerSellerLink?.seller?.sanctionedLimit}</Text>
                        </Space>
                    </div>
                </Card>
                <br />
                <Form
                    form={roiForm}
                    initialValues={[]}
                    onFinish={(value) => {
                        onROISubmit(value);
                        roiForm.resetFields();
                    }}
                    onFinishFailed={(errorInfo) => {
                        console.log(errorInfo);
                    }}
                    autoComplete="off"
                >
                    {Permissions("openForFinance", "addOpenForFinanceFeesAndROI") &&
                        data?.buyerFees === null &&
                        data?.sellerFees === null &&
                        data?.rateOfInterest === null && (
                            <Card>
                                <div className={tw`flex flex-col md:flex-row justify-between`}>
                                    <div className={tw`flex flex-col xl:flex-row gap-1`}>
                                        <Text className={tw`font-semibold mt-3`}>
                                            Buyer Fees* :{" "}
                                        </Text>
                                        <Form.Item name="buyerFees" rules={RULES.amount}>
                                            <TextInput type="text" placeholder="Fee Amount" />
                                        </Form.Item>
                                    </div>
                                    <div className={tw`flex flex-col xl:flex-row gap-1`}>
                                        <Text className={tw`font-semibold mt-3`}>
                                            Seller Fees* :{" "}
                                        </Text>
                                        <Form.Item name="sellerFees" rules={RULES.amount}>
                                            <TextInput type="text" placeholder="Fee Amount" />
                                        </Form.Item>
                                    </div>
                                    <div className={tw`flex flex-col xl:flex-row gap-1`}>
                                        <Text className={tw`font-semibold mt-3`}>
                                            Rate of Interest* :{" "}
                                        </Text>
                                        <Form.Item
                                            name="rateOfInterest"
                                            rules={RULES.rateOfInterest}
                                        >
                                            <TextInput placeholder="Percentage" />
                                        </Form.Item>
                                    </div>
                                </div>
                                <div className={tw`flex justify-between`}>
                                    <Button type="primary" name="process" htmlType="submit">
                                        Process
                                    </Button>
                                    <Button
                                        key="back"
                                        onClick={handleCancel}
                                        name="close"
                                        type="primary"
                                    >
                                        Close
                                    </Button>
                                </div>
                            </Card>
                        )}
                </Form>
            </Modal>
        </>
    );
};
