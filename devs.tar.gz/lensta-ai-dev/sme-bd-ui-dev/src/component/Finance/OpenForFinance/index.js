import React, { Fragment } from "react";
import { Typography } from "antd";
import { useEffect } from "react";
import { tw } from "twind";
import { getAllOpenForFinance } from "../../../services/factoringUnit";
import { OpenForFinanceColumns } from "./OpenForFinanceColumns";
import { useSelector } from "react-redux";
import TableComponent from "../../AntdComponent/Table";
import Cookies from "js-cookie";

const { Text } = Typography;

const OpenForFinanceContainer = () => {
    const {
        query,
        loadingOpenForFinance = false,
        openForFinance = [],
    } = useSelector((state) => ({
        query: state?.filters?.query,
        loadingOpenForFinance: state.factoringUnit?.loadingOpenForFinance,
        openForFinance: state.factoringUnit?.openForFinance,
    }));

    const id = Cookies.get("entityId");

    useEffect(() => {
        getAllOpenForFinance(id, query);
    }, [query]); // eslint-disable-line

    return (
        <Fragment>
            <div className={tw`flex items-center gap-4 content-divider`}>
                <Text className={tw`text-xl`}>Open For Finance</Text>
            </div>
            <TableComponent
                columns={OpenForFinanceColumns}
                data={openForFinance}
                loading={loadingOpenForFinance}
            />
        </Fragment>
    );
};

export default OpenForFinanceContainer;
