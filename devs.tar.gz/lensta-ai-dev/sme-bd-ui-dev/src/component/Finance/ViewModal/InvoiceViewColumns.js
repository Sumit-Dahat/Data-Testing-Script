import { Typography } from "antd";
import { ViewModal } from "../../Invoice/ViewModal";

const { Text } = Typography;

export const invoiceViewColumns = [
  {
    title: "Invoice No",
    key: "invoiceNo",
    render: (_, record) => {
      return <ViewModal label={record?.invoiceNo} data={record} />;
    },
  },
  {
    title: "Invoice Amount",
    dataIndex: "invoiceAmount",
    key: "invoiceAmount",
    render: (_, record) => {
      return <Text>{record?.invoiceAmount}</Text>;
    },
  },
  {
    title: "Discount Amount",
    dataIndex: "discountAmount",
    key: "discountAmount",
    render: (_, record) => {
      return <Text>{record?.discountAmount}</Text>;
    },
  },
  {
    title: "TAX Amount",
    dataIndex: "taxAmount",
    key: "taxAmount",
    render: (_, record) => {
      return <Text>{record?.taxAmount}</Text>;
    },
  },
  {
    title: "Total Amount",
    dataIndex: "totalAmount",
    key: "totalAmount",
    render: (_, record) => {
      return <Text>{record?.totalAmount}</Text>;
    },
  },
];
