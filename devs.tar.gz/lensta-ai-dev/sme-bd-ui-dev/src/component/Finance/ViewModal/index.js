import React, { useState, Fragment } from "react";
import { Button, Card, Modal, Table } from "antd";
import { FactoringUnitViewColumns } from "./FactoringUnitViewColumns";
import { invoiceViewColumns } from "./InvoiceViewColumns";
import { tw } from "twind";
import moment from "moment";
import "./styles.css";

export const ViewModal = ({ label, data }) => {

  const [isModalVisible, setIsModalVisible] = useState(false);

  const factorUnitViewData = [
    {
      key1: "Factoring Unit No",
      value1: data?.factoringUnitNo,
      key2: "Listed Date",
      value2: moment(data?.invoices[0]?.invoiceDueDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Buyer",
      value1: data?.buyerSellerLink?.buyer?.entityName,
      key2: "Seller",
      value2: data?.buyerSellerLink?.seller?.entityName,
    },
    {
      key1: "Invoice Date",
      value1: moment(data?.invoices[0]?.invoiceDate).format("DD-MM-YYYY"),
      key2: "Due Date",
      value2: moment(data?.invoices[0]?.invoiceDueDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Invoice Amount",
      value1: data?.sumOfInvoiceAmounts?.invoiceAmount,
      key2: "Discount Amount",
      value2: data?.sumOfInvoiceAmounts?.discountAmount,
    },
    {
      key1: "Tax Amount",
      value1: data?.sumOfInvoiceAmounts?.taxAmount,
      key2: "Total",
      value2: data?.sumOfInvoiceAmounts?.totalAmount,
    },
  ];

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  return (
    <Fragment>
      <div className={tw`flex justify-center`}>
        <Button
          style={{ borderRadius: "8px", padding: "4px" }}
          onClick={showModal}
        >
          {label}
        </Button>
      </div>
      <Modal
        title={`View Factoring Unit`}
        open={isModalVisible}
        onCancel={handleCancel}
        footer={
          <Button key="back" onClick={handleCancel} type="primary">
            Close
          </Button>
        }
        centered
      >
        <Card title="View Factoring Unit" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={FactoringUnitViewColumns}
              dataSource={factorUnitViewData}
              rowKey="key"
              bordered
              loading={false}
              showHeader={false}
              pagination={false}
            />
          </div>
        </Card>
        <div className="table-responsive">
          <Table
            columns={invoiceViewColumns}
            dataSource={data?.invoices?.map(row => ({ ...row, buyerSellerLink: data?.buyerSellerLink }))}
            rowKey="key"
            bordered
            loading={false}
            pagination={false}
          />
        </div>
      </Modal>
    </Fragment>
  );
};
