import React, { useState, useEffect } from "react";
import { Button, Card, Modal, Table, Form, Input } from "antd";
import { getAllFactoringUnit } from "../../../services/factoringUnit";
import { getURL } from "../../../configs/apiURL";
import { tw } from "twind";
import { RULES } from "../../../utils/formValidations";
import { getFactoringUnitById } from "../../../services/factoringUnit";
import { notifications } from "../../../utils/notifications";
import { FactoringUnitViewColumns } from "../ViewModal/FactoringUnitViewColumns";
import { invoiceViewColumns } from "../ViewModal/InvoiceViewColumns";
import { useSelector } from "react-redux";
import { actionHistory } from "./FactoringUnitActionColumns";
import useFetch from "../../../hooks/useFetch";
import Cookies from "js-cookie";
import moment from "moment";
import "./styles.css";

const { TextArea } = Input;

export const ApproveFactoringUnitModal = ({ label, data }) => {


  const {
    factoringUnitById = {},
    loadingFactoringUnitById = false
  } = useSelector(
    (state) => ({
      factoringUnitById: state?.factoringUnit?.factoringUnitById,
      loadingFactoringUnitById: state?.factoringUnit?.loadingFactoringUnitById,
    })
  );

  const [update] = useFetch();
  const [approve, setApprove] = useState(1);
  const [form] = Form.useForm();
  const [isModalVisible, setIsModalVisible] = useState(false);

  const factorUnitViewData = [
    {
      key1: "Factoring Unit No",
      value1: data?.factoringUnitNo,
      key2: "Listed Date",
      value2: data?.fuListedDate ? moment(data?.fuListedDate).format("DD-MM-YYYY") : "—",
    },
    {
      key1: "Buyer",
      value1: data?.buyerSellerLink?.buyer?.entityName,
      key2: "Seller",
      value2: data?.buyerSellerLink?.seller?.entityName,
    },
    {
      key1: "Invoice Date",
      value1: moment(data?.invoices[0]?.invoiceDate).format("DD-MM-YYYY"),
      key2: "Due Date",
      value2: data?.invoices[0]?.invoiceDate ? moment(data?.invoices[0]?.invoiceDueDate).format("DD-MM-YYYY") : "—",
    },
    {
      key1: "Invoice Amount",
      value1: data?.sumOfInvoiceAmounts?.invoiceAmount,
      key2: "Discount Amount",
      value2: data?.sumOfInvoiceAmounts?.discountAmount,
    },
    {
      key1: "Tax Amount",
      value1: data?.sumOfInvoiceAmounts?.taxAmount,
      key2: "Total",
      value2: data?.sumOfInvoiceAmounts?.totalAmount,
    },
  ];

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const onSubmit = async (value) => {
    const res = await update(getURL(`factoring-units/${data?.factoringUnitNo}/send-for-finance`),
      {
        method: "PUT",
        body: JSON.stringify({
          approved: approve,
          status: "PENDING",
          remarks: value?.remarks
        })
      }
    );
    if (res && res.status === 200) {
      notifications.success({
        message: "Factoring Unit is now Open For Finance",
      });
      form.resetFields();
      setIsModalVisible(false);
      if (localStorage.getItem("userType") === "ADMIN") {
        const formData = {
          buyerId: data?.buyerSellerLink?.buyer?.id,
          sellerId: data?.buyerSellerLink?.seller?.id,
          invoiceDetails: {
            invoiceDate: data?.invoices[0]?.invoiceDate,
            invoiceDueDate: data?.invoices[0]?.invoiceDueDate,
            invoiceAmount: data?.invoices[0]?.invoiceAmount,
            discountAmount: data?.invoices[0]?.discountAmount,
            taxAmount: data?.invoices[0]?.taxAmount,
            invoiceNo: data?.invoices[0]?.invoiceNo,
            createdByUserId: localStorage.getItem("userId"),
          },
          createdByUserId: localStorage.getItem("userId"),
        };
        await update(getURL(`factoring-units/${data?.factoringUnitNo}`), { method: "PUT", body: JSON.stringify(formData) });
      }
      getAllFactoringUnit(Cookies.get("entityId"));
    } else {
      notifications.error({ message: res.data?.error?.message || "something went wrong" });
    }
  };

  useEffect(() => {
    if (isModalVisible) {
      getFactoringUnitById(data.factoringUnitNo)
    }
  }, [isModalVisible]); // eslint-disable-line


  return (
    <>
      <Button
        style={{ borderRadius: "8px", padding: "4px" }}
        onClick={showModal}
      >
        {label}
      </Button>
      <Modal
        title={`Approve Factoring Unit `}
        open={isModalVisible}
        onCancel={handleCancel}
        footer={
          <Form
            form={form}
            name="bank"
            size="large"
            className={tw`mx-2 flex flex-col md:flex-row justify-center items-start md:items-center gap-3`}
            onFinish={(value) => {
              onSubmit(value);
              form.resetFields();
            }}
            onFinishFailed={(errorInfo) => {
              console.log(errorInfo);
            }}
            autoComplete="off"
          >
            <div style={{ flex: 1 }} className={tw`w-full`}>
              <Form.Item name="remarks" rules={RULES.inputRequired} >
                <TextArea rows={4} label="Remarks" placeholder="Enter Remarks" />
              </Form.Item>
            </div>
            <div className={tw`flex md:pt-16`}>
              <Button
                type="primary"
                size="middle"
                htmlType="submit"
              >
                Approve
              </Button>
              <Button
                danger
                type="primary"
                size="middle"
                htmlType="submit"
                onClick={() => setApprove(0)}
              >
                Reject
              </Button>
            </div>
          </Form>
        }
        centered
      >
        <Card title="View Factoring Unit" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={FactoringUnitViewColumns}
              dataSource={factorUnitViewData}
              rowKey="key"
              loading={false}
              bordered
              showHeader={false}
              pagination={false}
            />
          </div>
        </Card>
        <Card title="Invoice Details" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={invoiceViewColumns}
              dataSource={data?.invoices}
              rowKey="key"
              loading={false}
              bordered
              pagination={false}
            />
          </div>
        </Card>
        <Card title="Action History" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={actionHistory}
              dataSource={factoringUnitById?.actionHistory}
              rowKey="key"
              loading={loadingFactoringUnitById}
              pagination={false}
              bordered
            />
          </div>
        </Card>
      </Modal>
    </>
  );
};
