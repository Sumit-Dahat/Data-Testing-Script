import React, { useEffect, useMemo, useState } from "react";
import { Button, Card, Form, Typography, Row, Col, Input } from "antd";
import { MdOutlineArrowBack } from "react-icons/md";
import { tw } from "twind";
import { getURL } from "../../../configs/apiURL";
import { RULES } from "../../../utils/formValidations";
import { editFactoringUnit } from "../../../redux/factoringUnit/actions";
import TextInput from "../../AntdComponent/Input";
import Cookies from "js-cookie";
import useFetch from "../../../hooks/useFetch";
import SelectComponent from "../../AntdComponent/Select";
import DateComponent from "../../AntdComponent/Date";
import moment from "moment";

const { Text } = Typography;

const FactoringUnitAdd = ({
    setShowFactoringUnitAdd,
    onSubmit,
    defaultValue,
    isUpdate,
    buyerOnChange,
    setDisableDropdown,
    disableDropdown,
    buyerDropdown,
    sellerDropdown,
}) => {
    const [form] = Form.useForm();
    const [select, setSelect] = useState(true);
    const [creditPeriod, setCreditPeriod] = useState();

    const invoiceAmount = Form.useWatch("invoiceAmount", form);
    const discountAmount = Form.useWatch("discountAmount", form);
    const taxAmount = Form.useWatch("taxAmount", form);
    const [fetch] = useFetch();

    const entityId = Cookies.get("entityId");
    const entityCategory = localStorage.getItem("entityCategory");

    const initialValue = useMemo(
        () =>
            Object.keys(defaultValue).length !== 0
                ? {
                      sellerName: defaultValue?.buyerSellerLink?.seller?.id,
                      buyerName: defaultValue?.buyerSellerLink?.buyer?.id,
                      discountAmount: defaultValue?.invoices[0]?.discountAmount,
                      dueDate: moment(
                          defaultValue?.invoices[0]?.invoiceDueDate
                      ),
                      invoiceAmount: defaultValue?.invoices[0]?.invoiceAmount,
                      invoiceDate: moment(
                          defaultValue?.invoices[0]?.invoiceDate
                      ),
                      invoiceNumber: defaultValue?.invoices[0]?.invoiceNo,
                      taxAmount: defaultValue?.invoices[0]?.taxAmount,
                      totalAmount: defaultValue?.invoices[0]?.totalAmount,
                  }
                : {},
        [defaultValue]
    );

    const fetchCreditPeriod = async (buyerId, sellerId) => {
        const res = await fetch(
            getURL(`buyer-seller/links?buyerId=${buyerId}&sellerId=${sellerId}`)
        );
        if (res && res.status === 200) {
            setCreditPeriod(res?.data?.data[0]?.creditPeriod);
            if (!isUpdate) {
                const dueDate =
                    form.getFieldValue("invoiceDate") &&
                    res?.data?.data[0]?.creditPeriod
                        ? form
                              .getFieldValue("invoiceDate")
                              .add(res?.data?.data[0]?.creditPeriod, "days")
                        : null;
                form.setFieldValue("dueDate", dueDate);
            }
        }
    };

    useEffect(() => {
        form.setFieldsValue(initialValue);
    }, [form, initialValue]); // eslint-disable-line

    useEffect(() => {
        switch (entityCategory) {
            case "SELLER": {
                form.setFieldsValue({
                    sellerName: entityId,
                });
                break;
            }
            case "BUYER": {
                form.setFieldsValue({
                    buyerName: entityId,
                });
                break;
            }
            default:
                break;
        }
    }, []); // eslint-disable-line

    useEffect(() => {
        if (invoiceAmount && discountAmount && taxAmount) {
            const totalAmount =
                parseInt(form.getFieldValue(["invoiceAmount"])) +
                parseInt(form.getFieldValue(["taxAmount"])) -
                parseInt(form.getFieldValue(["discountAmount"]));
            form.setFieldsValue({
                totalAmount: totalAmount,
            });
        }
    }, [invoiceAmount, discountAmount, taxAmount]); // eslint-disable-line

    useEffect(() => {
        const buyerId = form.getFieldValue("buyerName");
        const sellerId = form.getFieldValue("sellerName");
        if (buyerId && sellerId) {
            fetchCreditPeriod(buyerId, sellerId);
        }
    }, [select]); // eslint-disable-line

    return (
        <div>
            <div className={tw`flex items-center gap-4 content-divider`}>
                <Button
                    type="default"
                    onClick={() => {
                        setDisableDropdown(true);
                        setShowFactoringUnitAdd(false);
                        editFactoringUnit(false, {});
                    }}
                >
                    <MdOutlineArrowBack size="20px" />
                </Button>
                <Text className={tw`text-lg`}>
                    {isUpdate ? "Update Factoring Unit" : " Add Factoring Unit"}
                </Text>
            </div>
            <Form
                form={form}
                size="large"
                onFinish={onSubmit}
                onFinishFailed={(errorInfo) => {
                    console.log(errorInfo);
                }}
                autoComplete="off"
            >
                <Card
                    title={
                        isUpdate
                            ? "Update Factoring Unit"
                            : " Add Factoring Unit"
                    }
                    className="mb-4"
                >
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col span={24}>
                            <Row
                                gutter={[
                                    { xs: 8, sm: 16, md: 24 },
                                    { xs: 12, sm: 16, md: 24 },
                                ]}
                                className={tw`mb-4 md:mb-0`}
                            >
                                <Col xs={24} sm={12} md={6}>
                                    <Form.Item
                                        name="buyerName"
                                        rules={RULES.selectRequired}
                                    >
                                        <SelectComponent
                                            label="Buyer Name"
                                            placeholder="Select"
                                            required
                                            onChange={(buyerId) => {
                                                buyerOnChange(buyerId);
                                                setSelect(!select);
                                                if (
                                                    entityCategory ===
                                                    "FINANCIER"
                                                )
                                                    form.setFieldsValue({
                                                        sellerName: undefined,
                                                    });
                                            }}
                                            allowClear={true}
                                            options={buyerDropdown}
                                            disabled={
                                                entityCategory === "BUYER"
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col xs={24} sm={12} md={6}>
                                    <Form.Item
                                        name="sellerName"
                                        rules={RULES.selectRequired}
                                    >
                                        <SelectComponent
                                            label="Seller Name"
                                            placeholder="Select"
                                            required
                                            onChange={(sellerId) => {
                                                setSelect(!select);
                                                form.setFieldsValue({
                                                    sellerName: sellerId,
                                                });
                                            }}
                                            allowClear={true}
                                            options={sellerDropdown}
                                            disabled={(() => {
                                                if (
                                                    entityCategory === "SELLER"
                                                ) {
                                                    return true;
                                                } else if (
                                                    disableDropdown &&
                                                    entityCategory ===
                                                        "FINANCIER"
                                                ) {
                                                    return !isUpdate
                                                        ? true
                                                        : false;
                                                }
                                                return false;
                                            })()}
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>
                        </Col>
                        <Col span={24}>
                            <Row
                                gutter={[
                                    { xs: 8, sm: 16, md: 24 },
                                    { xs: 12, sm: 16, md: 24 },
                                ]}
                                className={tw`mb-4 md:mb-0`}
                            >
                                <Col xs={24} sm={8} md={6}>
                                    <Form.Item
                                        name="invoiceNumber"
                                        rules={RULES.invoiceNo}
                                    >
                                        <TextInput
                                            required
                                            label="Invoice Number"
                                            placeholder="Invoice Number"
                                            uppercase
                                        />
                                    </Form.Item>
                                </Col>
                                <Col xs={24} sm={8} md={6}>
                                    <Form.Item
                                        name="invoiceDate"
                                        rules={RULES.date}
                                    >
                                        <DateComponent
                                            required
                                            onChange={(date) => {
                                                const dueDate =
                                                    date && creditPeriod
                                                        ? date.add(
                                                              creditPeriod,
                                                              "days"
                                                          )
                                                        : null;
                                                form.setFieldValue(
                                                    "invoiceDate",
                                                    date
                                                );
                                                form.setFieldValue(
                                                    "dueDate",
                                                    dueDate
                                                );
                                            }}
                                            label="Invoice Date"
                                            placeholder="Select Date"
                                            className="w-full"
                                        />
                                    </Form.Item>
                                </Col>
                                <Col xs={24} sm={8} md={2}>
                                    <Input
                                        placeholder="Days"
                                        value={creditPeriod}
                                        type="number"
                                        onChange={(e) => {
                                            const dueDate =
                                                form.getFieldValue(
                                                    "invoiceDate"
                                                ) && e.target.value
                                                    ? form
                                                          .getFieldValue(
                                                              "invoiceDate"
                                                          )
                                                          .add(
                                                              e.target.value,
                                                              "days"
                                                          )
                                                    : null;
                                            form.setFieldValue(
                                                "dueDate",
                                                dueDate
                                            );
                                            setCreditPeriod(e.target.value);
                                        }}
                                    />
                                </Col>
                                <Col xs={24} sm={8} md={4}>
                                    <Form.Item
                                        name="dueDate"
                                        rules={RULES.date}
                                    >
                                        <DateComponent
                                            disabled
                                            label="Due Date"
                                            placeholder="Select Date"
                                            className="w-full"
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>
                        </Col>
                        <Col span={24}>
                            <Row
                                gutter={[
                                    { xs: 8, sm: 16, md: 24 },
                                    { xs: 12, sm: 16, md: 24 },
                                ]}
                                className={tw`mb-4 md:mb-0`}
                            >
                                <Col xs={24} sm={8} md={6}>
                                    <Form.Item
                                        name="invoiceAmount"
                                        rules={RULES.amount}
                                    >
                                        <TextInput
                                            required
                                            label="Invoice Amount"
                                            placeholder=" Invoice Amount"
                                            onChange={(e) =>
                                                !e.target.value
                                                    ? form.setFieldValue(
                                                          "totalAmount",
                                                          null
                                                      )
                                                    : null
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col xs={24} sm={8} md={6}>
                                    <Form.Item
                                        name="discountAmount"
                                        rules={RULES.amount}
                                    >
                                        <TextInput
                                            required
                                            label="Discount Amount"
                                            placeholder="Discount Amount"
                                            onChange={(e) =>
                                                !e.target.value
                                                    ? form.setFieldValue(
                                                          "totalAmount",
                                                          null
                                                      )
                                                    : null
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col xs={24} sm={8} md={6}>
                                    <Form.Item
                                        name="taxAmount"
                                        rules={RULES.amount}
                                    >
                                        <TextInput
                                            required
                                            label="Tax Amount"
                                            placeholder="Tax Amount"
                                            onChange={(e) =>
                                                !e.target.value
                                                    ? form.setFieldValue(
                                                          "totalAmount",
                                                          null
                                                      )
                                                    : null
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col xs={24} sm={8} md={6}>
                                    <Form.Item
                                        name="totalAmount"
                                        rules={RULES.amount}
                                    >
                                        <TextInput
                                            required
                                            label="Total Amount"
                                            placeholder=" Total Amount"
                                            disabled
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>
                        </Col>
                    </Row>
                    <Button
                        className={tw`mt-2`}
                        size="middle"
                        type="primary"
                        htmlType="submit"
                    >
                        {isUpdate ? "Update" : "Add"}
                    </Button>
                </Card>
            </Form>
        </div>
    );
};

export default FactoringUnitAdd;
