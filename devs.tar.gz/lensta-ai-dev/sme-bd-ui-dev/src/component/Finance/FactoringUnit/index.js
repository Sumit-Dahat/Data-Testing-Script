import React from "react";
import Cookies from "js-cookie";
import FactoringUnit from "./FactoringUnit";
import FactoringUnitAdd from "./FactoringUnitAdd";
import useFetch from "../../../hooks/useFetch";
import { notification } from "antd";
import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { editFactoringUnit } from "../../../redux/factoringUnit/actions";
import { getAllFactoringUnit } from "../../../services/factoringUnit";
import { getURL } from "../../../configs/apiURL";
import { notifications } from "../../../utils/notifications";
import { message } from "../../../utils/message";
import { setDocFilterQuery, setFilterQuery } from "../../../redux/filters/actions";

const FactoringUnitContainer = () => {
    const {
        loadingFactoringUnit = false,
        factoringUnit = {},
        editFactoringUnits,
    } = useSelector((state) => ({
        loadingFactoringUnit: state.factoringUnit?.loadingFactoringUnit,
        factoringUnit: state.factoringUnit?.factoringUnit,
        editFactoringUnits: state.factoringUnit?.editFactoringUnit,
    }));

    const [showFactoringUnitAdd, setShowFactoringUnitAdd] = useState(false);
    const [createFactoringUnit] = useFetch();
    const [updateFactoringUnit] = useFetch();
    const [buyerDropdown, setBuyerDropdown] = useState();
    const [sellerDropdown, setSellerDropdown] = useState();
    const [disableDropdown, setDisableDropdown] = useState(true);
    const [fetch] = useFetch();

    const userId = localStorage.getItem("userId");
    const entityId = Cookies.get("entityId");
    const entityCategory = localStorage.getItem("entityCategory");

    const onSubmitFactoringUnitAdd = async (value) => {
        const data = {
            buyerId: value.buyerName,
            sellerId: value.sellerName,
            invoiceDetails: {
                invoiceDate: value.invoiceDate,
                invoiceDueDate: value.dueDate,
                invoiceAmount: parseFloat(value.invoiceAmount),
                discountAmount: parseFloat(value.discountAmount),
                taxAmount: parseFloat(value.taxAmount),
                invoiceNo: value.invoiceNumber,
                createdByUserId: userId,
            },
            createdByUserId: userId,
        };

        if (editFactoringUnits?.openEdit) {
            if (editFactoringUnits?.data?.invoices?.length > 1) {
                delete data?.invoiceDetails;
            }
            const _id = editFactoringUnits?.data?.factoringUnitNo;
            const res = await updateFactoringUnit(getURL(`factoring-units/${_id}`), {
                method: "PUT",
                body: JSON.stringify(data),
            });
            if (res && res.status === 200) {
                notification.success({
                    message: message.FACTORING_UPDATED,
                });
                setShowFactoringUnitAdd(false);
                editFactoringUnit(false, {});
                getAllFactoringUnit(Cookies.get("entityId"));
            } else {
                notifications.error({
                    message: res?.data?.error?.message,
                });
            }
        } else {
            data["invoiceDetails"]["invoiceNo"] = value.invoiceNumber;
            const res = await createFactoringUnit(getURL(`factoring-units`), {
                method: "POST",
                body: JSON.stringify({ ...data, status: "PENDING" }),
            });

            if (res && res.status === 200) {
                notification.success({
                    message: message.FACTORING_CREATED,
                });
                setShowFactoringUnitAdd(false);
                editFactoringUnit(false, {});
                setDisableDropdown(true);
                getAllFactoringUnit(Cookies.get("entityId"));
            } else {
                notifications.error({
                    message: res?.data?.error?.message,
                });
            }
        }
    };

    const fetchBuyerSellerData = async () => {
        switch (entityCategory) {
            case "FINANCIER": {
                const res = await fetch(
                    getURL("buyer-seller?approved=1&active=1&entityCategory=BUYER")
                );
                const buyerData = res.data?.data?.map((item) => ({
                    value: item.entityDetails?.id,
                    label: item.entityDetails?.entityName,
                }));
                if (res && res.status === 200) {
                    setBuyerDropdown(buyerData);
                }
                break;
            }
            case "SELLER": {
                const resp = await fetch(getURL("buyer-seller/profile"));
                if (resp && resp.status === 200) {
                    setSellerDropdown([
                        {
                            value: resp.data?.data?.entityDetails?.id,
                            label: resp.data?.data?.entityDetails?.entityName,
                        },
                    ]);
                }
                const res = await fetch(getURL(`buyer-seller/links?sellerId=${entityId}`));
                const buyerData = res.data?.data?.map((item) => ({
                    value: item.buyer?.id,
                    label: item.buyer?.entityName,
                }));
                if (res && res.status === 200) {
                    setBuyerDropdown(buyerData);
                }
                break;
            }
            case "BUYER": {
                const resp = await fetch(getURL("buyer-seller/profile"));
                if (resp && resp.status === 200) {
                    setBuyerDropdown([
                        {
                            value: resp.data?.data?.entityDetails?.id,
                            label: resp.data?.data?.entityDetails?.entityName,
                        },
                    ]);
                }
                const res = await fetch(getURL(`buyer-seller/links?buyerId=${entityId}`));
                const sellerData = res.data?.data?.map((item) => ({
                    value: item.seller?.id,
                    label: item.seller?.entityName,
                }));
                if (res && res.status === 200) {
                    setSellerDropdown(sellerData);
                }
                break;
            }
            default:
                break;
        }
    };

    const buyerOnChange = async (id) => {
        const res = await fetch(getURL(`buyer-seller/links?buyerId=${id}`));
        const sellerData = res.data?.data?.map((item) => ({
            value: item.seller?.id,
            label: item.seller?.entityName,
        }));
        if (res && res.status === 200) {
            setSellerDropdown(sellerData);
            setDisableDropdown(false);
        }
    };

    useEffect(() => {
        if (editFactoringUnits?.openEdit) {
            setBuyerDropdown([
                {
                    value: editFactoringUnits?.data?.buyerSellerLink?.buyer?.id,
                    label: editFactoringUnits?.data?.buyerSellerLink?.buyer?.entityName,
                },
            ]);
            setSellerDropdown([
                {
                    value: editFactoringUnits.data?.buyerSellerLink?.seller?.id,
                    label: editFactoringUnits.data?.buyerSellerLink?.seller?.entityName,
                },
            ]);
        } else {
            fetchBuyerSellerData();
        }
    }, [editFactoringUnits?.openEdit]); // eslint-disable-line

    /* Clearing all the filters on Change */
    useEffect(() => {
        setFilterQuery(undefined);
        setDocFilterQuery(undefined);
    }, [showFactoringUnitAdd, editFactoringUnits?.openEdit]);

    return (
        <React.Fragment>
            {showFactoringUnitAdd || editFactoringUnits?.openEdit ? (
                <FactoringUnitAdd
                    setShowFactoringUnitAdd={setShowFactoringUnitAdd}
                    onSubmit={onSubmitFactoringUnitAdd}
                    defaultValue={editFactoringUnits?.openEdit ? editFactoringUnits?.data : []}
                    isUpdate={editFactoringUnits?.openEdit}
                    buyerOnChange={buyerOnChange}
                    setDisableDropdown={setDisableDropdown}
                    disableDropdown={disableDropdown}
                    buyerDropdown={buyerDropdown}
                    sellerDropdown={sellerDropdown}
                />
            ) : (
                <FactoringUnit
                    setShowFactoringUnitAdd={setShowFactoringUnitAdd}
                    loading={loadingFactoringUnit}
                    factoringUnit={factoringUnit}
                    buyerOnChange={buyerOnChange}
                    setDisableDropdown={setDisableDropdown}
                    disableDropdown={disableDropdown}
                    buyerDropdown={buyerDropdown}
                    sellerDropdown={sellerDropdown}
                />
            )}
        </React.Fragment>
    );
};

export default FactoringUnitContainer;
