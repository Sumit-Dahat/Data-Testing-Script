import React, { useEffect, useMemo, useState } from "react";
import { Button, Typography } from "antd";
import { RiAddCircleFill } from "react-icons/ri";
import { factoringUnitColumns } from "./FactoringUnitColumns";
import { getURL } from "../../../configs/apiURL";
import { tw } from "twind";
import { Permissions } from "../../../configs/permissions";
import { notifications } from "../../../utils/notifications";
import { getAllFactoringUnit } from "../../../services/factoringUnit";
import { useSelector } from "react-redux";
import Cookies from "js-cookie";
import TableComponent from "../../AntdComponent/Table";
import UploadModal from "./UploadModal";
import useFetch from "../../../hooks/useFetch";
import moment from "moment";

const { Text } = Typography;

const FactoringUnit = ({
    setShowFactoringUnitAdd,
    loading,
    factoringUnit,
    buyerOnChange,
    setDisableDropdown,
    disableDropdown,
    buyerDropdown,
    sellerDropdown,
}) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [selectedRow, setSelectedRow] = useState([]);
    const [combine] = useFetch();
    const id = Cookies.get("entityId");

    const combineFUHandler = async () => {
        const res = await combine(getURL("factoring-units/combine"), {
            method: "PUT",
            body: JSON.stringify({
                factoringUnit1No: selectedRow[0]?.factoringUnitNo,
                factoringUnit2No: selectedRow[1]?.factoringUnitNo,
            }),
        });

        if (res && res.status === 200) {
            notifications.success({ message: "Factoring Unit Combined" });
            getAllFactoringUnit(Cookies.get("entityId"));
        }
    };

    const combineDataCheck = useMemo(
        () =>
            selectedRow[0]?.buyerSellerLink?.buyer?.id ===
                selectedRow[1]?.buyerSellerLink?.buyer?.id &&
            selectedRow[0]?.buyerSellerLink?.seller?.id ===
                selectedRow[1]?.buyerSellerLink?.seller?.id &&
            moment(selectedRow[0]?.invoices[0]?.invoiceDate).format("DD-MM-YYYY") ===
                moment(selectedRow[1]?.invoices[0]?.invoiceDate).format("DD-MM-YYYY") &&
            moment(selectedRow[0]?.invoices[0]?.invoiceDueDate).format("DD-MM-YYYY") ===
                moment(selectedRow[1]?.invoices[0]?.invoiceDueDate).format("DD-MM-YYYY")
                ? true
                : false,
        [selectedRow]
    );

    const rowSelection = {
        onChange: (selectedRowKeys, selectedRows) => {
            setSelectedRow(selectedRows);
        },
        getCheckboxProps: (record) => ({
            disabled:
                selectedRow.length < 2
                    ? false
                    : record?.factoringUnitNo !== selectedRow[0]?.factoringUnitNo &&
                      record?.factoringUnitNo !== selectedRow[1]?.factoringUnitNo,
        }),
    };

    useEffect(() => {
        getAllFactoringUnit(id, query);
    }, [query]); // eslint-disable-line

    return (
        <div>
            <div className={tw`flex flex-col md:flex-row justify-between content-divider`}>
                <Text style={{ fontSize: "20px", fontWeight: "600px", textAlign: "center" }}>
                    Factoring Unit
                </Text>
                <div className={tw`flex flex-row flex-wrap gap-2`}>
                    {Permissions("factoringUnit", "uploadFactoringUnit") && (
                        <UploadModal
                            title={"Upload Factoring Unit"}
                            name="upload-factoring"
                            setDisableDropdown={setDisableDropdown}
                            disableDropdown={disableDropdown}
                            buyerDropdown={buyerDropdown}
                            sellerDropdown={sellerDropdown}
                            buyerOnChange={buyerOnChange}
                        />
                    )}
                    {Permissions("factoringUnit", "addFactoringUnit") && (
                        <Button
                            type="primary"
                            name="add-factoring"
                            className="rounded"
                            onClick={() => {
                                setShowFactoringUnitAdd(true);
                            }}
                        >
                            <div className={tw`text-xs md:text-sm flex gap-1 items-center`}>
                                <RiAddCircleFill size="20px" /> Add Factoring Unit
                            </div>
                        </Button>
                    )}
                    {Permissions("factoringUnit", "combineFactoringUnit") && (
                        <Button
                            type="primary"
                            className="rounded"
                            disabled={selectedRow.length < 2}
                            onClick={() => {
                                if (combineDataCheck) {
                                    combineFUHandler();
                                } else {
                                    notifications.error({
                                        message: "Selected data cannot be combined",
                                    });
                                }
                            }}
                        >
                            <div className={tw`text-xs md:text-sm flex items-center`}>
                                Combine Factoring Unit
                            </div>
                        </Button>
                    )}
                </div>
            </div>
            <TableComponent
                columns={factoringUnitColumns}
                data={factoringUnit}
                rowSelection={{
                    ...rowSelection,
                }}
                loading={loading}
            />
        </div>
    );
};

export default FactoringUnit;
