import React, { useEffect } from "react";
import { Typography } from "antd";
import { tw } from "twind";
import { getAllNotFactoredUnit } from "../../../services/factoringUnit";
import { notFactoredUnitColumns } from "./NotFactoredUnitColumns";
import { useSelector } from "react-redux";
import TableComponent from "../../AntdComponent/Table";
import Cookies from "js-cookie";


const { Text } = Typography;

const NotFactoredUnit = () => {

  const {
    query,
    loadingNotFactoredUnit = false,
    notFactoredUnit = []
  } = useSelector((state) => ({
    query: state?.filters?.query,
    loadingNotFactoredUnit: state.factoringUnit?.loadingNotFactoredUnit,
    notFactoredUnit: state.factoringUnit?.notFactoredUnit,
  }));

  const id = Cookies.get("entityId");

  useEffect(() => {
    getAllNotFactoredUnit(id, query);
  }, [query]); // eslint-disable-line

  return (
    <>
      <div className={tw`flex items-center gap-4 content-divider`}>
        <Text className=" text-xl">Not Factored Unit</Text>
      </div>
      <TableComponent
        columns={notFactoredUnitColumns}
        data={notFactoredUnit}
        loading={loadingNotFactoredUnit}
      />
    </>
  );
};

export default NotFactoredUnit;
