import React, { useEffect, useState } from "react";
import {
  Button,
  Card,
  Modal,
  Table,
  Space,
  Typography,
  Divider,
} from "antd";
import { tw } from "twind";
import { getFactoringUnitById } from "../../../services/factoringUnit";
import { FactoringUnitViewColumns } from "../ViewModal/FactoringUnitViewColumns";
import { useSelector } from "react-redux";
import moment from "moment";
import { setFilter } from "../../../redux/filters/actions";

const { Text } = Typography;

export const FactoredUnitModal = ({ label, data }) => {

  const [isModalVisible, setIsModalVisible] = useState(false);

  const {
    factoredUnitData = {},
    factoredUnitLoading = false
  } = useSelector(
    (state) => ({
      factoredUnitData: state?.factoringUnit?.factoringUnitById,
      factoredUnitLoading: state?.factoringUnit?.loadingFactoringUnitById,
    })
  );

  const factoredUnitViewData = [
    {
      key1: "Factoring Unit No",
      value1: factoredUnitData?.factoringUnitNo,
      key2: "Listed Date",
      value2: moment(factoredUnitData?.fuListedDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Buyer",
      value1: factoredUnitData?.buyerSellerLink?.buyer?.entityName,
      key2: "Seller",
      value2: factoredUnitData?.buyerSellerLink?.seller?.entityName,
    },
    {
      key1: "Invoice Date",
      value1: moment(factoredUnitData?.invoiceDate).format("DD-MM-YYYY"),
      key2: "Due Date",
      value2: moment(factoredUnitData?.invoiceDueDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Invoice Amount",
      value1: factoredUnitData?.sumOfInvoiceAmounts?.invoiceAmount,
      key2: "Discount Amount",
      value2: factoredUnitData?.sumOfInvoiceAmounts?.discountAmount,
    },
    {
      key1: "Tax Amount",
      value1: factoredUnitData?.sumOfInvoiceAmounts?.taxAmount,
      key2: "Total",
      value2: factoredUnitData?.sumOfInvoiceAmounts?.totalAmount,
    },

    {
      key1: "Advance Tax (%)",
      value1: 0,
      key2: " Advance Tax Amount",
      value2: 0,
    },
    {
      key1: "Factored Date",
      value1: moment(factoredUnitData?.factoredDate).format("DD-MM-YYYY"),
      key2: "Factored Days",
      value2: factoredUnitData?.buyerSellerLink?.creditPeriod,
    },
    {
      key1: "ROI (%)",
      value1: factoredUnitData?.rateOfInterest,
      key2: "Interest",
      value2: factoredUnitData?.interest,
    },
    {
      key1: "Cost Bearer",
      value1: factoredUnitData?.buyerSellerLink?.costBearer,
      key2: "Amount without Tax",
      value2: factoredUnitData?.sumOfInvoiceAmounts?.totalAmount,
    },
  ];

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  useEffect(() => {
    if (isModalVisible) {
      getFactoringUnitById(data?.factoringUnitNo);
    } else{
      setFilter(null);
    }
  }, [isModalVisible]); // eslint-disable-line

  return (
    <>
      <Button
        style={{ borderRadius: "8px", padding: "4px" }}
        onClick={showModal}
      >
        {label}
      </Button>
      <Modal
        title={`Factored Unit Breakup`}
        open={isModalVisible}
        onCancel={handleCancel}
        footer={
          <Button key="back" onClick={handleCancel} type="primary" className="ml-auto">
            Close
          </Button>
        }
        centered
      >
        <Card title="View Breakup" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={FactoringUnitViewColumns}
              dataSource={factoredUnitViewData}
              loading={factoredUnitLoading}
              rowKey="key"
              bordered
              pagination={false}
              showHeader={false}
            />
          </div>
        </Card>
        <Card className="mb-4" loading={factoredUnitLoading}>
          <div className={tw`flex flex-col md:flex-row justify-between`}>
            <Space>
              <Text className={tw`font-semibold	`}>Buyer % : </Text>
              <Text>
                {data?.buyerSellerLink?.buyerPercentage}
              </Text>
            </Space>
            <Space>
              <Text className={tw`font-semibold	`}>Seller % : </Text>
              <Text>
                {data?.buyerSellerLink?.sellerPercentage}
              </Text>
            </Space>
          </div>
          <div className={tw`flex flex-col md:flex-row justify-between`}>
            <Space>
              <Text className={tw`font-semibold	`}> Buyer Fees : </Text>
              <Text>{factoredUnitData?.buyerFees}</Text>
            </Space>
            <Space>
              <Text className={tw`font-semibold	`}>Seller Fees : </Text>
              <Text>{factoredUnitData?.sellerFees}</Text>
            </Space>
          </div>
          <div className={tw`flex flex-col md:flex-row justify-between`}>
            <Space>
              <Text className={tw`font-semibold	`}>Buyer Interest Sharing : </Text>
              <Text>
                {factoredUnitData?.buyerInterest}
              </Text>
            </Space>
            <Space>
              <Text className={tw`font-semibold	`}>Seller Interest Sharing : </Text>
              <Text>
                {factoredUnitData?.sellerInterest}
              </Text>
            </Space>
          </div>

          <Divider />

          <div className={tw`flex flex-col md:flex-row justify-between`}>
            <Space>
              <Text className={tw`font-semibold	`}>
                Buyer Interest Sharing Fees :{" "}
              </Text>
              <Text>
                {factoredUnitData?.factoredUnitBreakup?.buyerInterestAndFees}
              </Text>
            </Space>
            <Space>
              <Text className={tw`font-semibold	`}>Seller Interest and Fees : </Text>
              <Text>
                {factoredUnitData?.factoredUnitBreakup?.sellerInterestAndFees}
              </Text>
            </Space>
          </div>

          <div className={tw`flex flex-col md:flex-row justify-between`}>
            <Space>
              <Text className={tw`font-semibold	`}>Collection Amount : </Text>
              <Text>
                {factoredUnitData?.factoredUnitBreakup?.collectedAmount}
              </Text>
            </Space>
            <Space>
              <Text className={tw`font-semibold	`}>Disbursement Amount : </Text>
              <Text>
                {factoredUnitData?.factoredUnitBreakup?.disbursementAmount}
              </Text>
            </Space>
          </div>
        </Card>
      </Modal>
    </>
  );
};
