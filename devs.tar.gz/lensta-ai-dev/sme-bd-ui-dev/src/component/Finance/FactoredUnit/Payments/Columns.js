import React from "react";
import moment from "moment";
import { PaymentViewModal } from "./Modal";
import { Divider, Space, Typography } from "antd";
import { DateFilter, EntityFilter, TextFilter, PaymentStatusFilter } from "../../../../utils/formFilters";
import { MdOutlinePreview } from "react-icons/md";

const { Text } = Typography;

export const paymentColumns = [
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Release To</Text>
                <Divider />
                <EntityFilter type="releaseTo" filter="payment" />
            </div>
        ),
        key: "releaseTo",
        render: (_, record) => {
            return (
                <Text>{record?.releaseTo}</Text>
            );
        },
    },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Amount</Text>
                <Divider />
                <TextFilter type="paymentAmount" filter="payment" />
            </div>
        ),
        dataIndex: "paymentAmount",
        key: "paymentAmount",
        render: (_, record) => {
            return <Text>{record?.paymentAmount}</Text>;
        },
    },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Payment Date</Text>
                <Divider />
                <DateFilter type="dateOfInitiate" filter="payment" />
            </div>
        ),
        dataIndex: "initiateDate",
        key: "initiateDate",
        render: (_, record) => {
            const initiateDate = moment(record?.dateOfInitiate).format(
                "YYYY-MM-DD"
            );
            return <Text>{initiateDate}</Text>;
        },
    },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Remaining Amount</Text>
                <Divider />
                <TextFilter type="remainingAmount" filter="payment" />
            </div>
        ),
        dataIndex: "remainingAmount",
        key: "remainingAmount",
        render: (_, record) => {
            return <Text>{record?.remainingAmount}</Text>;
        },
    },
    // {
    //     title: (
    //         <div style={{ textAlign: "center" }}>
    //             <Text>Account No.</Text>
    //             <Divider />
    //             <TextFilter type="accountNo" filter="payment" />
    //         </div>
    //     ),
    //     dataIndex: "accountNo",
    //     key: "accountNo",
    //     render: (_, record) => {
    //         return <Text>{record?.accountNo}</Text>;
    //     },
    // },
    // {
    //     title: (
    //         <div style={{ textAlign: "center" }}>
    //             <Text>IFSC</Text>
    //             <Divider />
    //             <TextFilter type="ifsc" filter="payment" />
    //         </div>
    //     ),
    //     dataIndex: "ifsc",
    //     key: "ifsc",
    //     render: (_, record) => {
    //         return <Text>{record?.ifsc}</Text>;
    //     },
    // },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Status</Text>
                <Divider />
                <PaymentStatusFilter type="status" filter="payment" />
            </div>
        ),
        dataIndex: "status",
        key: "status",
        render: (_, record) => {
            return <Text>{record?.status}</Text>;
        },
    },
    {
        title: <Text>Action</Text>,
        key: "action",
        render: (_, record) => {
            return (
                <Space
                    size="small"
                    style={{ display: "flex", flexDirection: "column" }}
                >
                    <PaymentViewModal
                        label={<MdOutlinePreview size="20px" color="black" />}
                        data={record}
                    />
                </Space>
            );
        },
    },
]
