import React from "react";
import Cookies from "js-cookie";
import TableComponent from "../../AntdComponent/Table";
import { Fragment } from "react";
import { Typography } from "antd";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import { factoredUnitColumns, overdueFactoredUnitColumns, activeFactoredUnitColumns } from "./FactoredUnitColumns";
import { getAllFactoredUnit } from "../../../services/factoringUnit";
import { tw } from "twind";

const { Text } = Typography;

const FactoredUnit = () => {

    const {
        query,
        filter,
        loadingFactoredUnit,
        factoredUnit = []
    } = useSelector((state) => ({
        query: state?.filters?.query,
        filter: state?.filters?.filter,
        loadingFactoredUnit: state.factoringUnit?.loadingFactoredUnit,
        factoredUnit: state.factoringUnit?.factoredUnit,
    }));

    const currentTab = localStorage.getItem("currentTab")


    useEffect(() => {
        if (!filter) {
            getAllFactoredUnit(Cookies.get("entityId"), query);
        }
    }, [query, currentTab]) // eslint-disable-line

    const getColumns = () => {
        switch (currentTab) {
            case "OPEN_FOR_DISBURSEMENT":
                return factoredUnitColumns;
            case "ACTIVE_DISBURSEMENT":
                return activeFactoredUnitColumns;
            case "OVERDUE_DISBURSEMENT":
                return overdueFactoredUnitColumns;
            case "PAYMENT_CLOSED":
                return factoredUnitColumns;
            default:
                return [];
        }
    };

    return (
        <Fragment>
            <div className={tw`flex items-center gap-4 content-divider`}>
                <Text className=" text-xl">Factored Unit</Text>
            </div>
            <TableComponent
                columns={getColumns()}
                loading={loadingFactoredUnit}
                size="small"
                data={factoredUnit}
            />
        </Fragment>
    );
};

export default FactoredUnit;
