import React from "react";
import moment from "moment";
import { Divider, Space, Typography } from "antd";
import { DateFilter, EntityFilter, TextFilter } from "../../../../utils/formFilters";
import { TransactionViewModal } from "./Modal";
import { MdOutlinePreview } from "react-icons/md";

const { Text } = Typography;

export const transactionHistoryColumns = [
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Collected From</Text>
                <Divider />
                <EntityFilter type="collectFrom" filter="transaction" />
            </div>
        ),
        key: "collectFrom",
        render: (_, record) => {
            return (
                <Text>{record?.collectFrom}</Text>
            );
        },
    },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Amount</Text>
                <Divider />
                <TextFilter type="transactionAmount" filter="transaction" />
            </div>
        ),
        dataIndex: "transactionAmount",
        key: "transactionAmount",
        render: (_, record) => {
            return <Text>{record?.transactionAmount}</Text>;
        },
    },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Transaction Date</Text>
                <Divider />
                <DateFilter type="dateOfTransaction" filter="transaction" />
            </div>
        ),
        dataIndex: "transactionDate",
        key: "transactionDate",
        render: (_, record) => {
            const transactionDate = moment(record?.dateOfTransaction).format(
                "YYYY-MM-DD"
            );
            return <Text>{transactionDate}</Text>;
        },
    },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Remaining Amount</Text>
                <Divider />
                <TextFilter type="remainingAmount" filter="transaction" />
            </div>
        ),
        dataIndex: "remainingAmount",
        key: "remainingAmount",
        render: (_, record) => {
            return <Text>{record?.remainingAmount}</Text>;
        },
    },
    {
        title: (
            <div style={{ textAlign: "center" }}>
                <Text>Narration</Text>
                <Divider />
                <TextFilter type="narration" filter="transaction" />
            </div>
        ),
        dataIndex: "narration",
        key: "narration",
        render: (_, record) => {
            return <Text>{record?.narration}</Text>;
        },
    },
    {
        title: <Text>Action</Text>,
        key: "action",
        render: (_, record) => {
            return (
                <Space
                    size="small"
                    style={{ display: "flex", flexDirection: "column" }}
                >
                    <TransactionViewModal
                        label={<MdOutlinePreview size="20px" color="black" />}
                        data={record}
                    />
                </Space>
            );
        },
    },
];
