import React from "react";
import TableComponent from "../../AntdComponent/Table";
import { useState, useEffect } from "react";
import { tw } from "twind";
import { PaymentForm } from "./Payments/Form";
import { TransactionForm } from './Transactions/Form';
import { useSelector } from "react-redux";
import { paymentColumns } from "./Payments/Columns";
import { transactionHistoryColumns } from "./Transactions/Columns";
import { Button, Modal, Tabs } from "antd";
import { getAllTransactionHistory, getFUPayments } from "../../../services/factoringUnit";
import { getBuyerSellerBanks } from "../../../services/buyerSeller";
import { setFilter } from "../../../redux/filters/actions";

const { TabPane } = Tabs;

export const FactoredViewModal = ({ label, data }) => {

    const {
        fUPayment = {},
        loadingFUPayment,
        transactionHistoryData = {},
        loadingTransactionHistory,
        query,
        filter
    } = useSelector((state) => ({
        fUPayment: state?.factoringUnit?.fUPayment,
        loadingFUPayment: state?.factoringUnit?.loadingFUPayment,
        transactionHistoryData: state.factoringUnit?.transactionHistory,
        loadingTransactionHistory: state.factoringUnit?.loadingTransactionHistory,
        query: state?.filters?.query,
        filter: state?.filters?.filter
    }));

    const currentTab = localStorage.getItem("currentTab");

    const getActiveTab = () => {
        switch (currentTab) {
            case "OPEN_FOR_DISBURSEMENT":
                return "1";
            case "PAYMENT_CLOSED":
                return "2"
            case "ACTIVE_DISBURSEMENT":
                return "3";
            case "OVERDUE_DISBURSEMENT":
                return "3";
            default:
                return "1";
        }
    }

    const [isModalVisible, setIsModalVisible] = useState(false);
    const [activeTab, setActiveTab] = useState(getActiveTab() || "1");

    const fetchPaymentData = async () => {
        const response = await getFUPayments(data?.factoringUnitNo);
        if (response.data.length) {
            getBuyerSellerBanks(data?.buyerSellerLink[response?.data[0]?.releaseTo?.toLowerCase()]?.id, null, true);
        } else {
            getBuyerSellerBanks(data?.buyerSellerLink?.seller?.id, null, true);
        }
    }

    useEffect(() => {
        if (isModalVisible) {
            if (filter === 'payment') {
                getFUPayments(data?.factoringUnitNo, query);
            }
            else if (filter === 'transaction') {
                getAllTransactionHistory(data.factoringUnitNo, query);
            }
            else {
                fetchPaymentData();
                getAllTransactionHistory(data.factoringUnitNo, query);
            }
        }
    }, [isModalVisible, query]); // eslint-disable-line

    return (
        <div className={tw`flex flex-col`}>
            <Button
                style={{ borderRadius: "8px", padding: "4px" }}
                onClick={() => {
                    setIsModalVisible(true);
                    setFilter(null);
                }}
            >
                {label}
            </Button>
            <Modal open={isModalVisible} onCancel={() => {
                setIsModalVisible(false);
                setFilter(null);
            }} footer={null}>
                <Tabs
                    type="line"
                    activeKey={activeTab}
                    onChange={async (key) => {
                        setActiveTab(key);
                    }}
                >
                    {["OPEN_FOR_DISBURSEMENT"].includes(currentTab) && (
                        <TabPane tab="Release Payment" key="1" >
                            <PaymentForm
                                isModalVisible={isModalVisible}
                                setIsModalVisible={setIsModalVisible}
                                fetchPaymentData={fetchPaymentData}
                                data={data}
                            />
                        </TabPane>
                    )}
                    {["ACTIVE_DISBURSEMENT", "OVERDUE_DISBURSEMENT"].includes(currentTab) && (
                        <TabPane tab="Collect Payment" key="3" >
                            <TransactionForm
                                isModalVisible={isModalVisible}
                                setIsModalVisible={setIsModalVisible}
                                fetchTransactionData={getAllTransactionHistory}
                                data={data}
                            />
                        </TabPane>
                    )}
                    {["OPEN_FOR_DISBURSEMENT", "ACTIVE_DISBURSEMENT", "OVERDUE_DISBURSEMENT", "PAYMENT_CLOSED"].includes(currentTab) && (
                        <TabPane tab="View Payment" key="2" >
                            <TableComponent
                                columns={paymentColumns}
                                data={fUPayment}
                                loading={loadingFUPayment}
                                filter="payment"
                            />
                        </TabPane>
                    )}
                    {["ACTIVE_DISBURSEMENT", "OVERDUE_DISBURSEMENT", "PAYMENT_CLOSED"].includes(currentTab) && (
                        <TabPane tab="View Receipts" key="4" >
                            <TableComponent
                                columns={transactionHistoryColumns}
                                data={transactionHistoryData}
                                loading={loadingTransactionHistory}
                                filter="transaction"
                            />
                        </TabPane>
                    )}
                </Tabs>
            </Modal>
        </div >
    );
};