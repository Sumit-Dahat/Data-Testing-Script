import React, { useState } from "react";
import { Button, Card, Modal, Table, Form, Input } from "antd";
import { FactoringUnitViewColumns } from "../ViewModal/FactoringUnitViewColumns";
import { getURL } from "../../../configs/apiURL";
import { notifications } from "../../../utils/notifications";
import { getAllAcceptBankFinance } from "../../../services/factoringUnit";
import { RULES } from "../../../utils/formValidations";
import { tw } from 'twind';
import { message } from '../../../utils/message';
import useFetch from "../../../hooks/useFetch";
import moment from "moment";

const { TextArea } = Input;

export const ApproveBankModal = ({ label, data }) => {

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [fetch] = useFetch();
  const [approve, setApprove] = useState(1);
  const [form] = Form.useForm();

  const factorUnitViewData = [
    {
      key1: "Factoring Unit",
      value1: data?.factoringUnitNo,
      key2: "Listed Date",
      value2: moment(data?.fuListedDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Buyer",
      value1: data?.buyerSellerLink?.buyer?.entityName,
      key2: "Seller",
      value2: data?.buyerSellerLink?.seller?.entityName,
    },
    {
      key1: "Invoice Date",
      value1: moment(data?.invoices[0]?.invoiceDate).format("DD-MM-YYYY"),
      key2: "Due Date",
      value2: moment(data?.invoices[0]?.invoiceDueDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Invoice Amount",
      value1: data?.sumOfInvoiceAmounts?.invoiceAmount,
      key2: "Discount Amount",
      value2: data?.sumOfInvoiceAmounts?.discountAmount,
    },
    {
      key1: "Tax Amount",
      value1: data?.sumOfInvoiceAmounts?.taxAmount,
      key2: "Total",
      value2: data?.sumOfInvoiceAmounts?.totalAmount,
    }
  ];

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const onSubmit = async (value) => {
    const res = await fetch(getURL(`factoring-units/${data?.factoringUnitNo}/disburse-amount`), {
      method: "PUT",
      body: JSON.stringify({
        status: "ROI_ADDED",
        approved: approve,
        remarks: value?.remarks
      }),
    });
    if (res && res.status === 200) {
      notifications.success({ message: approve ? message.ACCEPT_BANK_FINANCE_APPROVED : message.ACCEPT_BANK_FINANCE_REJECTED });
      form.resetFields();
      setIsModalVisible(false);
      getAllAcceptBankFinance();
    } else {
      notifications.error({ message: res.data?.error?.message || "something went wrong" });
    }
  }

  return (
    <>
      <Button
        name="approve-reject"
        style={{ borderRadius: "8px", padding: "4px" }}
        onClick={showModal}
      >
        {label}
      </Button>
      <Modal
        title={`Approve Invoice`}
        open={isModalVisible}
        onCancel={handleCancel}
        footer={
          <Form
            form={form}
            size="large"
            className={tw`mx-2 flex flex-col md:flex-row justify-center items-start md:items-center gap-3`}
            onFinish={(value) => {
              onSubmit(value);
            }}
            onFinishFailed={(errorInfo) => {
              console.log(errorInfo);
            }}
            autoComplete="off"
          >
            <div style={{ flex: 1 }} className={tw`w-full`}>
              <Form.Item name="remarks" rules={RULES.inputRequired} >
                <TextArea rows={4} label="Remarks" placeholder="Enter Remarks" />
              </Form.Item>
            </div>
            <div className={tw`flex md:pt-12`}>
              <Button
                name="approve"
                type="primary"
                size="middle"
                htmlType="submit"
              >
                Approve
              </Button>
              <Button
                danger
                name="reject"
                type="primary"
                size="middle"
                htmlType="submit"
                onClick={() => setApprove(() => 0)}
              >
                Reject
              </Button>
            </div>
          </Form>
        }
        centered
      >
        <Card title=" View Bank Accept" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={FactoringUnitViewColumns}
              dataSource={factorUnitViewData}
              rowKey="key"
              loading={false}
              pagination={false}
              showHeader={false}
              bordered
            />
          </div>
        </Card>
      </Modal>
    </>
  );
};
