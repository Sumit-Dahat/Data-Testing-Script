import React, { useEffect, Fragment } from "react";
import { Typography } from "antd";
import { tw } from "twind";
import { bankFinanceColumns } from "./BankFinanceColumns";
import { useSelector } from "react-redux";
import { getAllAcceptBankFinance } from "../../../services/factoringUnit";
import Cookies from "js-cookie";
import TableComponent from '../../AntdComponent/Table';

const { Text } = Typography;

const BankFinance = () => {

  const id = Cookies.get("entityId");

  const {
    query,
    data = {}
  } = useSelector((state) => ({
    query: state?.filters?.query,
    data: state.factoringUnit?.acceptBankFinance
  }));

  useEffect(() => {
    getAllAcceptBankFinance(id, query);
  }, [query]); // eslint-disable-line

  return (
    <Fragment>
      <div className={tw`content-divider`}>
        <Text className={tw`text-xl`}>Accept Bank Finance</Text>
      </div>
      <TableComponent
        columns={bankFinanceColumns}
        data={data}
      />
    </Fragment>
  );
};

export default BankFinance;
