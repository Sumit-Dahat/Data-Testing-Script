import { Table } from "antd";
import { tw } from "twind";
import { useSelector } from "react-redux";
import { generateFilterQuery } from "../../../utils/generateQuery";
import { setFilter, setFilterQuery } from "../../../redux/filters/actions";

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT

const TableComponent = ({ columns, data, loading, filter = null, ...rest }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    return (
        <div className={tw`table-responsive`}>
            <Table
                columns={columns}
                dataSource={data?.data}
                loading={loading || false}
                rowKey="key"
                bordered
                pagination={{
                    pageSize: PAGE_LIMIT,
                    total: data?.count || data?.data?.length,
                    onChange: (currentPage) => {
                        const searchQuery = generateFilterQuery({ offset: (currentPage - 1) * PAGE_LIMIT }, query);
                        setFilterQuery(searchQuery);
                        setFilter(filter);
                    },
                }}
                {...rest}
            />
        </div>
    );
};

export default TableComponent;
