import React, { useState } from "react";
import useFetch from "../../hooks/useFetch";
import Cookies from "js-cookie";
import { Button, Modal, notification } from "antd";
import { MdDelete } from "react-icons/md";
import { tw } from "twind";
import { editAddress, editBank, editPromter } from "../../redux/buyerSeller/actions";
import { getAllFactoringUnit, getAllCheckerLevel } from "../../services/factoringUnit";
import { getAllInvoiceDocuments } from "../../services/factoringUnit";
import { getURL } from "../../configs/apiURL";
import { getAllUserByEntity } from "../../services/user";
import { capitalizeFirstLetter } from "../../utils/helpers";
import { getFinancierBanks } from "../../services/financier";
import {
    getBuyerSellerAddress,
    getBuyerSellerBanks,
    getAllBuyerSellerLink,
    getBuyerSellerDocuments,
    getBuyerSellerPromoters,
    getAllInvoices,
    getAllBuyerSeller,
} from "../../services/buyerSeller";

let path = "";

const DeletePopup = ({ entityId, type, id, data, invoiceId }) => {
    const [deleteDetail] = useFetch();
    const [isModalVisible, setIsModalVisible] = useState(false);

    const url_extend = type === "document" ? "documents" : `${type}-details`;

    switch (type) {
        case "entity":
            path = `buyer-seller/${id}`;
            break;
        case "invoiceManagement":
            path = `invoices/${id}`;
            break;
        case "invoice":
            path = `invoices/${invoiceId}/documents/${id}`;
            break;
        case "checker":
            path = `platform/users/checker-levels/${id}`;
            break;
        case "financier-bank":
            path = `financiers/profile/bank-details/${id}`;
            break;
        default:
            path = type === "factoringUnit" ? `factoring-units/${id}` : type === "buyerSellerLink" ? `buyer-seller/links/${id}` : `buyer-seller/${entityId}/${url_extend}/${id}`;
            break;
    }

    const handleOk = async () => {
        const res = await deleteDetail(getURL(path), {
            method: "DELETE",
        });
        if (res && res.status === 200) {
            notification.success({
                message: `${type === "invoiceManagement" ? "Invoice" : type === "invoice" ? "Doucment" : capitalizeFirstLetter(type)} Deleted Successfully`,
            });
            setIsModalVisible(false);
            switch (type) {
                case "address":
                    getBuyerSellerAddress(entityId);
                    break;
                case "promoter":
                    getBuyerSellerPromoters(entityId);
                    break;
                case "document":
                    getBuyerSellerDocuments(entityId);
                    break;
                case "factoringUnit":
                    getAllFactoringUnit(entityId);
                    break;
                case "invoice":
                    getAllInvoiceDocuments(invoiceId);
                    break;
                case "bank":
                    getBuyerSellerBanks(entityId);
                    break;
                case "entity":
                    getAllBuyerSeller("allDetailsFilled=0&approved=0&active=1")
                    break;
                case "financier-bank":
                    getFinancierBanks("");
                    break;
                case "buyerSellerLink":
                    getAllBuyerSellerLink("");
                    break;
                case "invoiceManagement":
                    getAllInvoices("");
                    break;
                case "checker":
                    getAllCheckerLevel("");
                    getAllUserByEntity(Cookies.get("entityId"));
                    break;
                default:
                    break;
            }
            editBank(false, {});
            editPromter(false, {});
            editAddress(false, {});
        }
    };

    const showModal = () => setIsModalVisible(true);

    const handleCancel = () => setIsModalVisible(false);

    return (
        <div className={tw`flex`}>
            <Button
                name={`delete-${type === "invoiceManagement" ? "invoice" : type === "invoice" ? "doucment" : type}`}
                style={{ borderRadius: "8px", padding: "5px" }}
                onClick={showModal}
            >
                <MdDelete size="20px" color="red" />
            </Button>
            <Modal
                title={`Delete ${type === "invoiceManagement" ? "Invoice" : type === "invoice" ? "doucment" : type}`}
                className="ant-del-modal"
                open={isModalVisible}
                onCancel={handleCancel}
                footer={
                    <div className={tw`flex flex-row-reverse gap-2`}>
                        <Button
                            type="primary"
                            name="cancel"
                            onClick={handleCancel}
                            htmlType="submit"
                        >
                            Cancel
                        </Button>
                        <Button
                            danger
                            name="delete"
                            type="primary"
                            onClick={handleOk}
                            htmlType="submit"
                        >
                            Delete
                        </Button>
                    </div>
                }
            >
                <p>{data}</p>
            </Modal>
        </div>
    );
};

export default DeletePopup;
