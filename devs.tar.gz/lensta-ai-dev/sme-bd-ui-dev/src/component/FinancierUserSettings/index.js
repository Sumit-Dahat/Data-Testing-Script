import React from 'react';
import TextInput from "../AntdComponent/Input";
import PasswordInput from "../AntdComponent/Password";
import SelectComponent from "../AntdComponent/Select";
import useFetch from "../../hooks/useFetch";
import Cookies from "js-cookie";
import IsdCode from "../AntdComponent/Mobile";
import TableComponent from "../AntdComponent/Table";
import { useEffect, useMemo, useState } from "react";
import { Button, Card, Form, Spin, Row, Col, Typography } from "antd";
import { editUser as updateUser } from "../../redux/user/actions";
import { showPassword } from "../../services/auth";
import { tw } from "twind";
import { FinancierUserSettingsColumn } from "./FinancierUserSettingsColumn";
import { RULES } from "../../utils/formValidations";
import { getAllUsers } from "../../services/user";
import { getURL } from "../../configs/apiURL";
import { notifications } from "../../utils/notifications";
import { useSelector } from "react-redux";
import { message } from "../../utils/message";
import { getIsdCode, getMobileNo } from "../../utils/helpers";
import { FINANCIER_USER_TYPES, BUYER_SELLER_USER_TYPES } from "../../utils/helpers";
import { Permissions } from "../../configs/permissions";

const { Text } = Typography;

const FinancierUserSettings = ({ loading, editUser, users }) => {
    const { query } = useSelector((state) => ({
        query: state?.filters?.query,
    }));

    const [form] = Form.useForm();
    const [isdCode, setIsdCode] = useState(getIsdCode(editUser?.data?.mobileNo));
    const [passwordLoading, setPasswordLoading] = useState(false);

    const [createFinancierUser] = useFetch();
    const [editFinancierUsers] = useFetch();

    const entityCategory = localStorage.getItem("entityCategory");

    const initialValues = useMemo(() => {
        return editUser?.openEdit
            ? {
                name: `${editUser?.data?.firstName} ${editUser?.data?.lastName}`,
                emailId: editUser?.data?.emailId,
                mobileNo: getMobileNo(editUser?.data?.mobileNo),
                userType: editUser?.data?.userType,
            }
            : {};
    }, [editUser?.data]); // eslint-disable-line

    const showUserPassword = async (id) => {
        setPasswordLoading(true);
        const password = await showPassword(id);
        form.setFieldsValue({
            password: password,
            repassword: password,
        });
        setPasswordLoading(false);
    };

    useEffect(() => {
        if (editUser?.openEdit) {
            showUserPassword(editUser?.data.id);
        }
    }, [editUser?.openEdit]); // eslint-disable-line

    const onSubmit = async (value) => {
        const name = value?.name.split(" ");
        const firstName = name[0] ? name[0] : "";
        const lastName = name[1] ? name[1] : "";
        const _data = {
            firstName: firstName,
            lastName: lastName,
            emailId: value.emailId,
            mobileNo: isdCode + value.mobileNo,
            userType: value.userType,
            entityId: Cookies.get("entityId"),
            entityCategory: entityCategory,
            active: 1,
            password: value.password,
        };

        if (editUser?.openEdit === true) {
            const res = await editFinancierUsers(getURL(`platform/users/${editUser?.data?.id}`), {
                method: "PUT",
                body: JSON.stringify(_data),
            });
            if (res && res.status === 200) {
                notifications.success({ message: message.USER_UPDATED });
                updateUser(false, {});
                getAllUsers();
            } else {
                notifications.error({ message: res?.data?.error?.message });
            }
        } else {
            const res = await createFinancierUser(getURL(`platform/users`), {
                method: "POST",
                body: JSON.stringify(_data),
            });

            if (res && res.status === 200) {
                form.resetFields();
                getAllUsers();
                notifications.success({ message: message.USER_CREATED });
            } else {
                notifications.error({ message: res?.data?.error?.message });
            }
        }
    };

    useEffect(() => {
        getAllUsers(query);
    }, [query]); // eslint-disable-line

    useEffect(() => {
        form.resetFields();
        form.setFieldsValue(initialValues);
        setIsdCode(getIsdCode(editUser?.data?.mobileNo));
    }, [initialValues]); // eslint-disable-line

    if (passwordLoading) {
        return (
            <div style={{ textAlign: "center", marginTop: "100px" }}>
                <Spin spinning={passwordLoading} />
            </div>
        );
    }

    return (
        <div className={tw`content-divider`}>
            {Permissions("users", editUser?.openEdit ? "editUsers" : "addUsers") && (
                <Form
                    form={form}
                    size="large"
                    initialValues={initialValues || {}}
                    onFinish={onSubmit}
                    onFinishFailed={(errorInfo) => {
                        console.log(errorInfo);
                    }}
                    autoComplete="off"
                >
                    <Card title="User Details" style={{ width: "100%" }}>
                        <Row
                            gutter={[
                                { xs: 8, sm: 16, md: 24 },
                                { xs: 12, sm: 16, md: 24 },
                            ]}
                            className={tw`mb-4 md:mb-0`}
                        >
                            <Col xs={24} sm={12} md={6}>
                                <Form.Item name="userType" rules={RULES.selectRequired}>
                                    <SelectComponent
                                        label="User Type"
                                        placeholder="Select"
                                        required
                                        allowClear={true}
                                        options={localStorage.getItem("entityCategory") === "FINANCIER" ? FINANCIER_USER_TYPES : BUYER_SELLER_USER_TYPES}
                                    />
                                </Form.Item>
                            </Col>
                            <Col xs={24} sm={12} md={6}>
                                <Form.Item name="name" rules={RULES.name}>
                                    <TextInput label="Name" placeholder="Enter Name" required />
                                </Form.Item>
                            </Col>
                            <Col xs={24} sm={12} md={6}>
                                <Form.Item
                                    name="mobileNo"
                                    rules={RULES.mobileNo}
                                    style={{ position: "relative", bottom: 7 }}
                                >
                                    <TextInput
                                        label="Mobile No"
                                        placeholder="Enter Number"
                                        required
                                        addonBefore={<IsdCode isdCode={isdCode} setIsdCode={(code) => setIsdCode(code)} />}
                                        maxLength={10}
                                    />
                                </Form.Item>
                            </Col>
                            <Col xs={24} sm={12} md={6}>
                                <Form.Item name="emailId" rules={RULES.email}>
                                    <TextInput label="Email" placeholder="Enter Email" required />
                                </Form.Item>
                            </Col>
                            <Col xs={24} sm={12} md={6}>
                                <Form.Item name="password" rules={RULES.password} hasFeedback>
                                    <PasswordInput label="Password" placeholder="Enter Password" required />
                                </Form.Item>
                            </Col>
                            <Col xs={24} sm={12} md={6}>
                                <Form.Item name="repassword" rules={RULES.repassword} hasFeedback>
                                    <PasswordInput label="Re-Password" placeholder="Enter Password" required />
                                </Form.Item>
                            </Col>
                        </Row>
                        <Button size="middle" type="primary" htmlType="submit">
                            {editUser?.openEdit ? "Update" : "Add"}
                        </Button>
                    </Card>
                </Form>
            )}
            <div className={tw`content-divider`}>
                <Text className={tw`text-xl`}>Users</Text>
            </div>
            <TableComponent columns={FinancierUserSettingsColumn} data={users} loading={loading} />
        </div>
    );
};

export default FinancierUserSettings;
