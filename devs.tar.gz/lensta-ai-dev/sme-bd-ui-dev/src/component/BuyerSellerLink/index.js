import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getAllBuyerSellerLink } from "../../services/buyerSeller";
import { getURL } from "../../configs/apiURL";
import { notifications } from "../../utils/notifications";
import { BuyerSellerLinkColumns } from "./LinkColumns";
import { editBuyerSellerLink } from "../../redux/buyerSeller/actions";
import useFetch from "../../hooks/useFetch";
import Cookies from "js-cookie";
import BuyerSellerLinkManage from "./LinkManage";
import BuyerSellerLinkAdd from "./LinkAdd";
import { message } from "../../utils/message";

const BuyerSellerLinkContainer = ({ isUpdate }) => {
  const {
    query = "",
    loadingBuyerSellerLink = false,
    buyerSellerLinkData = [],
    editBuyerSellerLinks,
  } = useSelector((state) => ({
    query: state.filters?.query,
    loadingBuyerSellerLink: state.buyerSeller?.loadingBsLink,
    buyerSellerLinkData: state.buyerSeller?.buyerSellerLink,
    editBuyerSellerLinks: state.buyerSeller?.editBuyerSellerLink,
  }));

  const [buyerSellerLinkAdd, setBuyerSellerLinkAdd] = useState(false);
  const [updateBuyerSellerLink] = useFetch();
  const [createBuyerSellerLink] = useFetch();
  const [buyerDropdown, setBuyerDropdown] = useState();
  const [sellerDropdown, setSellerDropdown] = useState();
  const [disableDropdown, setDisableDropdown] = useState(true);
  const [fetch] = useFetch();

  const entityId = Cookies.get("entityId");
  const entityCategory = localStorage.getItem("entityCategory");

  const onSubmitBsLinkAdd = async (value) => {
    let buyerStartDate = null;
    let buyerEndDate = null;
    let sellerStartDate = null;
    let sellerEndDate = null;
    let totalPeriod =
      parseInt(value.creditPeriod) + parseInt(value.extendedCreditPeriod);
    let tillDays = parseInt(value.tillDays);

    if (
      value.costBearer === "PERIODIC_SPLIT" &&
      value.splitBuyerSeller === "BUYER"
    ) {
      buyerStartDate = 1;
      buyerEndDate = tillDays;
      sellerStartDate = tillDays + 1;
      sellerEndDate = totalPeriod;
    } else if (
      value.costBearer === "PERIODIC_SPLIT" &&
      value.splitBuyerSeller === "SELLER"
    ) {
      sellerStartDate = 1;
      sellerEndDate = tillDays;
      buyerStartDate = tillDays + 1;
      buyerEndDate = totalPeriod;
    }
    const data = {
      buyerId: value.buyerName,
      sellerId: value.sellerName,
      creditPeriod: parseInt(value.creditPeriod),
      extendedCreditPeriod: parseInt(value.extendedCreditPeriod),
      sendForFinance: value.approvedFinance,
      acceptPayment: value.acceptPayment,
      costBearer: value.costBearer,
      buyerPercentage: parseInt(value.buyerPercent),
      sellerPercentage: parseInt(value.sellerPercent),
      buyerStartDays: buyerStartDate,
      buyerEndDays: buyerEndDate,
      sellerStartDays: sellerStartDate,
      sellerEndDays: sellerEndDate,
    };

    if (editBuyerSellerLinks?.openEdit) {
      const _id = editBuyerSellerLinks?.data?.id;
      const res = await updateBuyerSellerLink(
        getURL(`buyer-seller/links/${_id}`),
        {
          method: "PUT",
          body: JSON.stringify(data),
        }
      );
      if (res && res.status === 200) {
        getAllBuyerSellerLink(query);
        notifications.success({ message: message.BUYER_SELLER_LINK_UPDATED });
        editBuyerSellerLink(false, {});
      } else {
        notifications.error({
          message: res.data?.error?.message || "something went wrong",
        });
      }
    } else {
      const res = await createBuyerSellerLink(getURL(`buyer-seller/links`), {
        method: "POST",
        body: JSON.stringify(data),
      });
      if (res && res.status === 200) {
        getAllBuyerSellerLink(query);
        notifications.success({ message: message.BUYER_SELLER_LINK_CREATED });
        setBuyerSellerLinkAdd(false);
      } else {
        notifications.error({
          message: res.data?.error?.message || "something went wrong",
        });
      }
    }
  };

  const bsLinkAddToggleHandler = (bool) => {
    setBuyerSellerLinkAdd(bool);
  };

  const fetchBuyerSellerData = async () => {
    switch (entityCategory) {
      case "FINANCIER": {
        const res = await fetch(
          getURL("buyer-seller?approved=1&active=1&entityCategory=BUYER")
        );
        const buyerData = res.data?.data?.map((item) => ({
          value: item.entityDetails?.id,
          label: item.entityDetails?.entityName,
        }));
        if (res && res.status === 200) {
          setBuyerDropdown(buyerData);
        }
        break;
      }
      case "SELLER": {
        const resp = await fetch(getURL("buyer-seller/profile"));
        if (resp && resp.status === 200) {
          setSellerDropdown([
            {
              value: resp.data?.data?.entityDetails?.id,
              label: resp.data?.data?.entityDetails?.entityName,
            },
          ]);
        }
        const linkResponse = await fetch(
          getURL(`buyer-seller/links?sellerId=${entityId}`)
        );
        const buyerLinkedIds = linkResponse.data?.data?.map(
          (item) => item.buyer?.id
        );
        const res = buyerLinkedIds.length
          ? await fetch(
              getURL(
                `buyer-seller?approved=1&active=1&entityCategory=BUYER&excludeEntityIds=${encodeURIComponent(
                  buyerLinkedIds
                )}`
              )
            )
          : await fetch(
              getURL(`buyer-seller?approved=1&active=1&entityCategory=BUYER`)
            );
        const buyerData = res.data?.data?.map((item) => ({
          value: item.entityDetails?.id,
          label: item.entityDetails?.entityName,
        }));
        if (res && res.status === 200) {
          setBuyerDropdown(buyerData);
        }
        break;
      }
      case "BUYER": {
        const resp = await fetch(getURL("buyer-seller/profile"));
        if (resp && resp.status === 200) {
          setBuyerDropdown([
            {
              value: resp.data?.data?.entityDetails?.id,
              label: resp.data?.data?.entityDetails?.entityName,
            },
          ]);
        }
        const linkResponse = await fetch(
          getURL(`buyer-seller/links?buyerId=${entityId}`)
        );
        const sellerLinkedIds = linkResponse.data?.data?.map(
          (item) => item.seller?.id
        );
        const res = sellerLinkedIds.length
          ? await fetch(
              getURL(
                `buyer-seller?approved=1&active=1&entityCategory=SELLER&excludeEntityIds=${encodeURIComponent(
                  sellerLinkedIds
                )}`
              )
            )
          : await fetch(
              getURL(`buyer-seller?approved=1&active=1&entityCategory=SELLER`)
            );
        const sellerData = res.data?.data?.map((item) => ({
          value: item.entityDetails?.id,
          label: item.entityDetails?.entityName,
        }));
        if (res && res.status === 200) {
          setSellerDropdown(sellerData);
        }
        break;
      }
      default:
        break;
    }
  };

  const buyerOnChange = async (id) => {
    const resp = await fetch(getURL(`buyer-seller/links?buyerId=${id}`));
    const sellerLinkedIds = resp.data?.data?.map((item) => item.seller?.id);
    const res = sellerLinkedIds.length
      ? await fetch(
          getURL(
            `buyer-seller?approved=1&active=1&entityCategory=SELLER&excludeEntityIds=${encodeURIComponent(
              sellerLinkedIds
            )}`
          )
        )
      : await fetch(
          getURL(`buyer-seller?approved=1&active=1&entityCategory=SELLER`)
        );
    if (res && res.status === 200) {
      const sellerData = res.data?.data?.map((item) => ({
        value: item.entityDetails?.id,
        label: item.entityDetails?.entityName,
      }));
      setSellerDropdown(sellerData);
      setDisableDropdown(false);
    }
  };

  useEffect(() => {
    if (editBuyerSellerLinks?.openEdit) {
      setBuyerDropdown([
        {
          value: editBuyerSellerLinks?.data?.buyer?.id,
          label: editBuyerSellerLinks?.data?.buyer?.entityName,
        },
      ]);
      setSellerDropdown([
        {
          value: editBuyerSellerLinks?.data?.seller?.id,
          label: editBuyerSellerLinks?.data?.seller?.entityName,
        },
      ]);
    } else {
      fetchBuyerSellerData();
    }
  }, [editBuyerSellerLinks?.openEdit]); // eslint-disable-line

  useEffect(() => {
    getAllBuyerSellerLink(query);
  }, [query]); // eslint-disable-line

  return (
    <React.Fragment>
      {buyerSellerLinkAdd || editBuyerSellerLinks?.openEdit ? (
        <BuyerSellerLinkAdd
          onSubmit={onSubmitBsLinkAdd}
          isUpdate={editBuyerSellerLinks?.openEdit}
          buyerSellerLinkAddToggle={bsLinkAddToggleHandler}
          entityDefaultValue={
            editBuyerSellerLinks?.openEdit ? editBuyerSellerLinks?.data : []
          }
          editBuyerSellerLinks={editBuyerSellerLinks}
          data={buyerSellerLinkData}
          buyerOnChange={buyerOnChange}
          setDisableDropdown={setDisableDropdown}
          disableDropdown={disableDropdown}
          buyerDropdown={buyerDropdown}
          sellerDropdown={sellerDropdown}
        />
      ) : (
        <BuyerSellerLinkManage
          columns={BuyerSellerLinkColumns}
          buyerSellerLinkData={buyerSellerLinkData}
          buyerSellerLinkAddToggle={bsLinkAddToggleHandler}
          loading={loadingBuyerSellerLink}
        />
      )}
    </React.Fragment>
  );
};

export default BuyerSellerLinkContainer;
