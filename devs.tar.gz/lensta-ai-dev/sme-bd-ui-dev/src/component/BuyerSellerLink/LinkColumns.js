import { Button, Space } from "antd";
import { MdModeEditOutline } from "react-icons/md";
import { Typography } from "antd";
import { Permissions } from "../../configs/permissions";
import { tw } from "twind";
import { editBuyerSellerLink } from "../../redux/buyerSeller/actions";
import DeletePopup from "../DeletePopUp";

const { Text } = Typography;

export const BuyerSellerLinkColumns = [
  {
    title: <Text>Buyer Name</Text>,
    key: "buyerName",
    render: (_, record) => {
      return <Text>{record?.buyer?.entityName}</Text>
    },
  },
  {
    title: <Text>Seller Name</Text>,
    dataIndex: "sellerName",
    key: "sellerName",
    render: (_, record) => {
      return <Text>{record?.seller?.entityName}</Text>
    },
  },

  {
    title: <Text>Credit Period</Text>,
    dataIndex: "creditPeriod",
    key: "creditPeriod",
    render: (_, record) => {
      return <Text>{record?.creditPeriod}</Text>
    },
  },
  {
    title: <Text>Cost Bearer</Text>,
    dataIndex: "costBearer",
    key: "costBearer",
    render: (_, record) => {
      return <Text>{record?.costBearer}</Text>
    },
  },
  {
    title: <Text>Action</Text>,
    key: "action",
    render: (_, record) => {
      const buyerSellerLink = `${record?.buyer?.entityName} - ${record?.seller?.entityName} - ${record?.creditPeriod} - ${record?.costBearer}`;
      return (
        <div className={tw`flex justify-center`}>
          <Space
            size="middle"
          >
            {Permissions('buyerSellerLink', 'editBuyerSellerLink') && (
              <Button
                name="update-link"
                style={{ borderRadius: "8px", padding: "4px" }}
                onClick={() => {
                  editBuyerSellerLink(true, record);
                }}
              >
                <MdModeEditOutline size="20px" color="black" />
              </Button>
            )}
            {Permissions('buyerSellerLink', 'deleteBuyerSellerLink') && (
              <DeletePopup
                type="buyerSellerLink"
                id={record?.id}
                data={buyerSellerLink}
                entityId={record?.createdByFinancierId}
              />
            )}
          </Space>
        </div>
      );
    },
  },
];
