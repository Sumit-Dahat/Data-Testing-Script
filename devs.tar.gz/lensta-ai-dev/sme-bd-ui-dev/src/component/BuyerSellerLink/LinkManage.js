import React from "react";
import { Button, Typography } from "antd";
import { RiAddCircleFill } from "react-icons/ri";
import { tw } from 'twind';
import { Permissions } from "../../configs/permissions";
import { BuyerSellerLinkColumns } from "./LinkColumns";
import TableComponent from "../AntdComponent/Table";

const { Text } = Typography;

const BuyerSellerLinkManage = ({ buyerSellerLinkAddToggle, loading, buyerSellerLinkData }) => {

  return (
    <div>
      <div className={tw`flex flex-col md:flex-row justify-between content-divider`}>
        <Text style={{ fontSize: "20px", fontWeight: "600px", textAlign: 'center' }}>
          Buyer-Seller Link
        </Text>
        <div className={tw`ml-auto`}>
          {Permissions('buyerSellerLink', 'addBuyerSellerLink') && (
            <Button
              name="add-link"
              type="primary"
              style={{ borderRadius: "4px" }}
              onClick={() => {
                buyerSellerLinkAddToggle(true);
              }}
            >
              <div className={tw`text-xs md:text-sm flex gap-1 items-center`}>
                <RiAddCircleFill size="20px" /> Add Buyer-Seller Link
              </div>
            </Button>
          )}
        </div>
      </div>
      <TableComponent
        columns={BuyerSellerLinkColumns}
        data={buyerSellerLinkData}
        loading={loading}
      />
    </div>
  );
};

export default BuyerSellerLinkManage;
