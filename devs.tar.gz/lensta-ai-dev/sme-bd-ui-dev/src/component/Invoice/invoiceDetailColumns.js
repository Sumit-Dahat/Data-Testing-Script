import { Space, Typography, Divider } from "antd";
import { DocTextFilter } from "../../utils/formFilters";
import { GoLinkExternal } from "react-icons/go";
import { Link } from "react-router-dom";

const { Text } = Typography;

export const invoiceDetailsColumns = [
  {
    title: <Text>#</Text>,
    key: "documentNo",
    render: (_, record, index) => {
      return <Text>{index + 1}</Text>;
    },
  },
  {
    title: (
      <div>
        <Text>Document Title</Text>
        <Divider />
        <DocTextFilter type="title" />
      </div>
    ),
    dataIndex: "documentTitle",
    key: "documentTitle",
    render: (_, record) => {
      return <Text>{record?.title}</Text>;
    },
  },

  {
    title: <Text>Action</Text>,
    key: "action",
    render: (_, record) => {
      return (
        <Space
          size="middle"
          style={{ display: "flex", justifyContent: "space-evenly" }}
        >
          <Link
            target={"_blank"}
            to={{
              pathname: `/invoices/${record?.entityId}/documents/${record?.id}/signed-url`,
              search: '?action=VIEW&expiresIn=300'
            }}
          >
            <GoLinkExternal size={24} color="#228be6" />
          </Link>
        </Space>
      );
    },
  },
];
