import React from "react";
import Cookies from "js-cookie";
import InvoiceAdd from "./InvoiceAdd";
import useFetch from "../../hooks/useFetch";
import UploadModal from "./InvoiceModalUpload";
import TableComponent from "../AntdComponent/Table";
import { Button, Typography } from "antd";
import { RiAddCircleFill } from "react-icons/ri";
import { useState, useEffect, useReducer } from "react";
import { useSelector } from "react-redux";
import { tw } from "twind";
import { ACTION_TYPES } from "../../utils/helpers";
import { invoiceColumns } from "./InvoiceColumns";
import { getAllInvoices } from "../../services/buyerSeller";
import { editInvoice } from "../../redux/buyerSeller/actions";
import { Permissions } from "../../configs/permissions";
import { getURL } from "../../configs/apiURL";
import { notifications } from "../../utils/notifications";
import { message } from "../../utils/message";
import { setDocFilterQuery, setFilterQuery } from "../../redux/filters/actions";

const { Text } = Typography;

const initialState = {
    dropDownData: {},
    loading: false,
    error: false,
    edit: null,
};

const reducer = (state, action) => {
    switch (action.type) {
        case ACTION_TYPES.FETCH_START:
            return {
                ...state,
                loading: true,
            };
        case ACTION_TYPES.FETCH_SUCCESS:
            return {
                ...state,
                loading: false,
                dropDownData: action.payload,
            };
        case ACTION_TYPES.FETCH_ERROR:
            return {
                ...state,
                loading: false,
                error: true,
            };
        case ACTION_TYPES.EDIT:
            return {
                ...state,
                edit: action.payload,
            };
        default:
            return state;
    }
};

const InvoiceManagement = () => {
    const [state, dispatch] = useReducer(reducer, initialState);

    const {
        query,
        invoiceData = {},
        loadingInvoiceData = false,
        editInvoiceData,
    } = useSelector((state) => ({
        query: state?.filters?.query,
        loadingInvoiceData: state.buyerSeller?.loadingInvoiceData,
        invoiceData: state.buyerSeller?.invoiceData,
        editInvoiceData: state.buyerSeller?.editInvoice,
    }));

    const [showInvoiceAdd, setShowInvoiceAdd] = useState(false);
    const [createInvoice] = useFetch();
    const [updateInvoice] = useFetch();
    const [fetch] = useFetch();

    const userId = localStorage.getItem("userId");
    const entityId = Cookies.get("entityId");
    const entityCategory = localStorage.getItem("entityCategory");

    const onSubmitInvoiceAdd = async (value) => {
        const data = {
            invoiceNo: value.invoiceNumber,
            buyerId: value.buyerName,
            sellerId: value.sellerName,
            invoiceDate: value.invoiceDate,
            invoiceDueDate: value.dueDate,
            invoiceAmount: parseFloat(value.invoiceAmount),
            discountAmount: parseFloat(value.discountAmount),
            taxAmount: parseFloat(value.taxAmount),
            createdByUserId: userId,
        };
        if (editInvoiceData?.openEdit) {
            const _id = editInvoiceData?.data?.id;
            const res = await updateInvoice(getURL(`invoices/${_id}`), {
                method: "PUT",
                body: JSON.stringify(data),
            });
            if (res && res.status === 200) {
                notifications.success({ message: message.INVOICE_UPDATED });
                setShowInvoiceAdd(false);
                editInvoice(false, {});
                getAllInvoices("");
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
        } else {
            const res = await createInvoice(getURL(`invoices`), {
                method: "POST",
                body: JSON.stringify(data),
            });
            if (res && res.status === 200) {
                notifications.success({ message: message.INVOICE_CREATED });
                setShowInvoiceAdd(false);
                getAllInvoices("");
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
        }
    };

    const fetchBuyerSellerData = async () => {
        dispatch({ type: ACTION_TYPES.FETCH_START });
        try {
            switch (entityCategory) {
                case "SELLER": {
                    const resp = await fetch(getURL("buyer-seller/profile"));
                    const sellerDropdown = [
                        {
                            value: resp.data?.data?.entityDetails?.id,
                            label: resp.data?.data?.entityDetails?.entityName,
                        },
                    ];
                    const res = await fetch(
                        getURL(`buyer-seller/links?sellerId=${entityId}`)
                    );
                    const buyerDropdown = res.data?.data?.map((item) => ({
                        value: item.buyer?.id,
                        label: item.buyer?.entityName,
                    }));
                    dispatch({
                        type: ACTION_TYPES.FETCH_SUCCESS,
                        payload: { buyerDropdown, sellerDropdown },
                    });
                    break;
                }
                case "BUYER": {
                    const resp = await fetch(getURL("buyer-seller/profile"));
                    const buyerDropdown = [
                        {
                            value: resp.data?.data?.entityDetails?.id,
                            label: resp.data?.data?.entityDetails?.entityName,
                        },
                    ];
                    const res = await fetch(
                        getURL(`buyer-seller/links?buyerId=${entityId}`)
                    );
                    const sellerDropdown = res.data?.data?.map((item) => ({
                        value: item.seller?.id,
                        label: item.seller?.entityName,
                    }));
                    dispatch({
                        type: ACTION_TYPES.FETCH_SUCCESS,
                        payload: { buyerDropdown, sellerDropdown },
                    });
                    break;
                }
                default:
                    break;
            }
        } catch (error) {
            dispatch({ type: ACTION_TYPES.FETCH_ERROR });
        }
    };

    useEffect(() => {
        fetchBuyerSellerData();
    }, []); // eslint-disable-line

    useEffect(() => {
        getAllInvoices(query);
    }, [query]); // eslint-disable-line

    /* Clearing all the filters on Change */
    useEffect(() => {
        setFilterQuery(undefined);
        setDocFilterQuery(undefined);
    }, [showInvoiceAdd, editInvoiceData?.openEdit]);

    return (
        <div>
            {showInvoiceAdd || editInvoiceData?.openEdit ? (
                <InvoiceAdd
                    setShowInvoiceAdd={setShowInvoiceAdd}
                    onSubmit={onSubmitInvoiceAdd}
                    defaultValue={
                        editInvoiceData?.openEdit ? editInvoiceData?.data : []
                    }
                    isUpdate={editInvoiceData?.openEdit}
                    buyerDropdown={state?.dropDownData?.buyerDropdown}
                    sellerDropdown={state?.dropDownData?.sellerDropdown}
                />
            ) : (
                <div>
                    <div
                        className={tw`flex flex-col md:flex-row justify-between content-divider`}
                    >
                        <Text
                            style={{
                                fontSize: "20px",
                                fontWeight: "600px",
                                textAlign: "center",
                            }}
                        >
                            Invoice
                        </Text>
                        <div
                            className={tw`flex flex-row justify-between gap-2`}
                        >
                            {Permissions("invoices", "uploadInvoice") && (
                                <UploadModal
                                    title={"Upload Invoice"}
                                    buyerDropdown={
                                        state?.dropDownData?.buyerDropdown
                                    }
                                    sellerDropdown={
                                        state?.dropDownData?.sellerDropdown
                                    }
                                />
                            )}
                            {Permissions("invoices", "addInvoice") && (
                                <Button
                                    name="add-invoice"
                                    type="primary"
                                    className="rounded"
                                    onClick={() => {
                                        setShowInvoiceAdd(true);
                                    }}
                                >
                                    <div
                                        className={tw`text-xs md:text-sm flex gap-1 items-center`}
                                    >
                                        <RiAddCircleFill size="20px" /> Add
                                        Invoice
                                    </div>
                                </Button>
                            )}
                        </div>
                    </div>
                    <TableComponent
                        data={invoiceData}
                        columns={invoiceColumns}
                        loading={loadingInvoiceData}
                    />
                </div>
            )}
        </div>
    );
};

export default InvoiceManagement;
