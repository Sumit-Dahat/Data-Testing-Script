import React, { useEffect, useState } from "react";
import { Button, Card, Modal, Table, Upload, Form, Row, Col, Progress } from "antd";
import { tw } from "twind";
import { setDocFilterQuery } from "../../../redux/filters/actions";
import { generateFilterQuery } from "../../../utils/generateQuery";
import { FactoringUnitViewColumns } from "../../Finance/ViewModal/FactoringUnitViewColumns";
import { UploadOutlined } from "@ant-design/icons";
import { invoiceDetailsColumns } from "./InvoiceDetailColumns";
import { getAllInvoiceDocuments } from "../../../services/factoringUnit";
import { useSelector } from "react-redux";
import { notifications } from "../../../utils/notifications";
import { getURL } from "../../../configs/apiURL";
import { RULES } from "../../../utils/formValidations";
import TextInput from "../../AntdComponent/Input";
import Cookies from "js-cookie";
import moment from "moment";
import axios from "axios";

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT
const MAX_FILE_SIZE = process.env.REACT_APP_MAX_FILE_SIZE * 1024;
const DOC_EXT = process.env.REACT_APP_DOC_EXT

export const ViewModal = ({ label, data }) => {

  const {
    documentsLoading = false,
    documentsData = [],
    docquery
  } = useSelector((state) => ({
    documentsLoading: state?.factoringUnit?.loadingInvoiceDocument,
    documentsData: state?.factoringUnit?.invoiceDocument,
    docquery: state.filters?.docquery,
  }));

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [loader, setLoader] = useState(false);
  const [error, setError] = useState(false);
  const [uploadPercentage, setUploadPercentage] = useState(0);
  const [form] = Form.useForm();

  const factorUnitViewData = [
    {
      key1: "Invoice No",
      value1: data?.invoiceNo,
      key2: "Factoring Unit",
      value2: data?.factoringUnitNo,
    },
    {
      key1: "Buyer",
      value1: data?.buyerSellerLink?.buyer?.entityName,
      key2: "Seller",
      value2: data?.buyerSellerLink?.seller?.entityName,
    },
    {
      key1: "Invoice Date",
      value1: moment(data?.invoiceDate).format("DD-MM-YYYY"),
      key2: "Due Date",
      value2: moment(data?.invoiceDueDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Invoice Amount",
      value1: data?.invoiceAmount,
      key2: "Discount Amount",
      value2: data?.discountAmount,
    },
    {
      key1: "Tax Amount",
      value1: data?.taxAmount,
      key2: "Total",
      value2: data?.totalAmount,
    },
  ];

  const getFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };

  const beforeUpload = file => {
    const fileSizeKiloBytes = file.size / 1024
    if (fileSizeKiloBytes > MAX_FILE_SIZE) {
      setError("File size is greater than maximum limit");
      return false
    }
    setError(false)
    return true;
  };

  const onSubmit = async (value) => {
    if (error) return
    setLoader(true);
    const file = value?.uploadDocuments[0];
    const enityId = Cookies.get("entityId");
    const formData = new FormData();
    formData.append("title", value?.title);
    formData.append("document", file?.originFileObj, file?.originFileObj.name);
    formData.append("userId", localStorage.getItem("userId"));
    formData.append("entityId", enityId);
    formData.append("documentType", "INVOICE");

    const ACCESS_TOKEN = Cookies.get("ACCESS_TOKEN");

    let config = {
      headers: {
        Authorization: `Bearer ${ACCESS_TOKEN}`,
      },
      onUploadProgress: function (progressEvent) {
        let percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
        setUploadPercentage(() => percentCompleted)
      }
    };

    const res = await axios.post(getURL(`invoices/${data?.id}/documents`), formData, config)

    if (res && res.status === 200) {
      notifications.success({ message: "document uploaded successfully" });
      getAllInvoiceDocuments(data?.id);
      form.resetFields();
    }
    setLoader(false);
  };

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  useEffect(() => {
    if (isModalVisible) {
      getAllInvoiceDocuments(data?.id, docquery);
    }
  }, [isModalVisible, docquery]); // eslint-disable-line

  return (
    <>
      <div className={tw`flex justify-center`}>
        <Button
          style={{ borderRadius: "8px", padding: "4px" }}
          onClick={showModal}
        >
          {label}
        </Button>
      </div>
      <Modal
        title={`View Invoice`}
        open={isModalVisible}
        onCancel={handleCancel}
        footer={
          <Button key="back" onClick={handleCancel} type="primary" className={tw`ml-auto`}>
            Close
          </Button>
        }
        centered
      >
        <Card title="View Invoice" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={FactoringUnitViewColumns}
              dataSource={factorUnitViewData}
              rowKey="key"
              loading={false}
              bordered
              showHeader={false}
              pagination={false}
            />
          </div>
        </Card>

        <Form
          form={form}
          name="documents"
          size="large"
          initialValues={[]}
          onFinish={(value) => {
            onSubmit(value);
          }}
          onFinishFailed={(errorInfo) => {
            console.log(errorInfo);
          }}
          autoComplete="off"
        >
          <Card title="Document Details" style={{ width: "100%" }}>
            <Row gutter={[{ xs: 8, sm: 16, md: 24 }, { xs: 12, sm: 16, md: 24 }]} className={tw`mb-4 md:mb-0`}>
              <Col xs={24} sm={12} md={6}>
                <Form.Item
                  name="title"
                  rules={RULES.inputRequired}
                >
                  <TextInput
                    label="Document Title"
                    placeholder="Document Title"
                    required
                  />
                </Form.Item>
              </Col>
              <Col xs={24} sm={12} md={6}>
                <Form.Item
                  name="uploadDocuments"
                  getValueFromEvent={getFile}
                  rules={RULES.upload}
                >
                  <Upload accept={DOC_EXT} beforeUpload={beforeUpload}>
                    <Button icon={<UploadOutlined />}>
                      Browse
                    </Button>
                    <br />
                    <p className={tw`text-red-500`}>
                      {uploadPercentage ?
                        <Progress className={tw`w-36`} percent={uploadPercentage} />
                        :
                        error}
                    </p>
                  </Upload>
                </Form.Item>
              </Col>
              <Col xs={24} sm={12} md={6}>
                <p style={{ marginTop: 10, marginLeft: 5, color: '#f5222d' }}>{error}</p>
              </Col>
            </Row>
            <div>
              <Button
                type="primary"
                htmlType="submit"
                size="middle"
                loading={loader}
              >
                Upload
              </Button>
            </div>
          </Card>
        </Form>
        <br />
        <div className="table-responsive">
          <Table
            columns={invoiceDetailsColumns}
            dataSource={documentsData?.data?.map(document => ({ ...document, invoice: data }))}
            loading={documentsLoading}
            rowKey="key"
            pagination={{
              pageSize: PAGE_LIMIT,
              total: documentsData?.count,
              onChange: currentPage => {
                const searchQuery = generateFilterQuery({ offset: ((currentPage - 1) * PAGE_LIMIT) }, docquery);
                setDocFilterQuery(searchQuery);
              }
            }}
            bordered
          />
        </div>
      </Modal>
    </>
  );
};
