import React from "react";
import moment from "moment";
import useFetch from "../../hooks/useFetch";
import { useEffect, useState } from "react";
import { Button, Card, Modal, Table, Form, Input } from "antd";
import { FactoringUnitViewColumns } from "../Finance/ViewModal/FactoringUnitViewColumns";
import { invoiceDetailsColumns } from "./invoiceDetailColumns";
import { getInvoiceById } from "../../services/buyerSeller";
import { getAllInvoiceDocuments } from "../../services/factoringUnit";
import { useSelector } from "react-redux";
import { generateFilterQuery } from "../../utils/generateQuery";
import { RULES } from "../../utils/formValidations";
import { tw } from "twind";
import { getURL } from "../../configs/apiURL";
import { notifications } from "../../utils/notifications";
import { actionHistory } from "./InvoiceActionColumns";
import { getAllInvoices } from "../../services/buyerSeller";
import { setDocFilterQuery } from "../../redux/filters/actions";

const { TextArea } = Input;

const PAGE_LIMIT = process.env.REACT_APP_PAGE_LIMIT

export const ApproveInvoiceModal = ({ label, data }) => {

  const {
    documentsLoading = false,
    documentsData = {},
    loadingInvoiceById = false,
    invoiceById = {},
    docquery
  } = useSelector((state) => ({
    documentsLoading: state?.factoringUnit?.loadingInvoiceDocument,
    documentsData: state?.factoringUnit?.invoiceDocument,
    loadingInvoiceById: state.buyerSeller?.loadingInvoiceById,
    invoiceById: state?.buyerSeller?.invoiceById,
    docquery: state.filters?.docquery,
  }));

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [approve, setApprove] = useState(1);
  const [form] = Form.useForm();
  const [update] = useFetch();


  const factorUnitViewData = [
    {
      key1: "Invoice No",
      value1: data?.invoiceNo,
      key2: "Factoring Unit",
      value2: data?.factoringUnitNo || "—",
    },
    {
      key1: "Buyer",
      value1: data?.buyerSellerLink?.buyer?.entityName,
      key2: "Seller",
      value2: data?.buyerSellerLink?.seller?.entityName,
    },
    {
      key1: "Invoice Date",
      value1: moment(data?.invoiceDate).format("DD-MM-YYYY"),
      key2: "Due Date",
      value2: moment(data?.invoiceDueDate).format("DD-MM-YYYY"),
    },
    {
      key1: "Invoice Amount",
      value1: data?.invoiceAmount,
      key2: "Discount Amount",
      value2: data?.discountAmount,
    },
    {
      key1: "Tax Amount",
      value1: data?.taxAmount,
      key2: "Total",
      value2: data?.totalAmount,
    },
  ];

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const onSubmit = async (value) => {
    const res = await update(getURL(`invoices/${data?.id}/approve-or-reject`), {
      method: "PUT",
      body: JSON.stringify({
        approved: approve,
        remarks: value?.remarks
      }),
    });
    if (res && res.status === 200) {
      notifications.success({ message: `Invoice ${approve ? "approved" : "rejected"} successfully` });
      setApprove(true);
      setIsModalVisible(false);
      getAllInvoices("");
    } else {
      notifications.error({ message: res.data?.error?.message || "something went wrong" });
    }
  }

  useEffect(() => {
    if (isModalVisible) {
      getInvoiceById(data?.id);
    }
  }, [isModalVisible]); // eslint-disable-line

  useEffect(() => {
    if (isModalVisible && docquery) {
      getAllInvoiceDocuments(data?.id, docquery);
    }
  }, [isModalVisible, docquery]); // eslint-disable-line

  return (
    <>
      <Button
        style={{ borderRadius: "8px", padding: "4px" }}
        onClick={showModal}
      >
        {label}
      </Button>
      <Modal
        title={`Approve Invoice`}
        open={isModalVisible}
        onCancel={handleCancel}
        footer={
          <Form
            form={form}
            name="bank"
            size="large"
            className={tw`mx-2 flex flex-col md:flex-row justify-center items-start md:items-center gap-3`}
            onFinish={(value) => {
              onSubmit(value);
              form.resetFields();
            }}
            onFinishFailed={(errorInfo) => {
              console.log(errorInfo);
            }}
            autoComplete="off"
          >
            <div style={{ flex: 1 }} className={tw`w-full`}>
              <Form.Item name="remarks" rules={RULES.inputRequired} >
                <TextArea rows={4} label="Remarks" placeholder="Enter Remarks" />
              </Form.Item>
            </div>
            <div className={tw`flex md:pt-16`}>
              <Button
                type="primary"
                size="middle"
                htmlType="submit"
              >
                Approve
              </Button>
              <Button
                danger
                type="primary"
                size="middle"
                htmlType="submit"
                onClick={() => setApprove(0)}
              >
                Reject
              </Button>
            </div>
          </Form>
        }
        centered
      >
        <Card title="View Invoice" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={FactoringUnitViewColumns}
              dataSource={factorUnitViewData}
              rowKey="key"
              loading={false}
              pagination={false}
              showHeader={false}
              bordered
            />
          </div>
        </Card>
        <Card title="Document Details" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={invoiceDetailsColumns}
              dataSource={docquery ? documentsData?.data : invoiceById?.documents}
              rowKey="key"
              loading={docquery ? documentsLoading : loadingInvoiceById}
              bordered
              pagination={{
                pageSize: PAGE_LIMIT,
                total: documentsData?.count,
                onChange: currentPage => {
                  const searchQuery = generateFilterQuery({ offset: ((currentPage - 1) * PAGE_LIMIT) }, docquery);
                  setDocFilterQuery(searchQuery);
                }
              }}
            />
          </div>
        </Card>
        <Card title="Action History" className="mb-4">
          <div className="table-responsive">
            <Table
              columns={actionHistory}
              dataSource={invoiceById?.actionHistory}
              rowKey="key"
              loading={loadingInvoiceById}
              pagination={false}
              bordered
            />
          </div>
        </Card>
      </Modal>
    </>
  );
};
