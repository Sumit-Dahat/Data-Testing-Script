import React from "react";
import { Fragment, useEffect, useState } from "react";
import { Button, Modal, Spin } from "antd";
import { tw } from "twind";
import { FaRegAddressCard } from "react-icons/fa";
import { getBankKycDetails } from "../../../services/buyerSeller";
import { useSelector } from "react-redux";
import { BankCardViewModal } from "./BankCard";


export const BankKycViewModal = ({ data }) => {

    const {
        bankKycDetails = {},
        loadingBankKycDetails
    } = useSelector((state) => ({
        bankKycDetails: state?.buyerSeller?.bankKycDetails,
        loadingBankKycDetails: state?.buyerSeller?.loadingBankKycDetails
    }));

    const apiProvider = `${localStorage.getItem("kycProvider")}`.toLowerCase();

    const [isModalVisible, setIsModalVisible] = useState(false);

    useEffect(() => {
        if (isModalVisible) {
            if (data?.bankAccKycVerified) {
                getBankKycDetails(apiProvider, data?.accountNo);
            }
        }
    }, [isModalVisible]); // eslint-disable-line

    return (
        <Fragment>
            <div className={tw`flex justify-center`}>
                <Button
                    style={{
                        borderRadius: "8px",
                        padding: "0px 5px 0px 5px"
                    }}
                    onClick={() => setIsModalVisible(true)}
                >
                    <FaRegAddressCard size="20px" color="black" />
                </Button>
            </div>
            <Modal open={isModalVisible} onCancel={() => setIsModalVisible(false)} footer={null} centered>
                {loadingBankKycDetails && (
                    <div style={{ textAlign: "center", marginTop: "100px" }}>
                        <Spin spinning={loadingBankKycDetails} />
                    </div>
                )}
                {!loadingBankKycDetails && (
                    <BankCardViewModal
                        bankData={data}
                        kycData={bankKycDetails}
                        loadingKycData={loadingBankKycDetails}
                    />
                )}
            </Modal>
        </Fragment>
    );
};
