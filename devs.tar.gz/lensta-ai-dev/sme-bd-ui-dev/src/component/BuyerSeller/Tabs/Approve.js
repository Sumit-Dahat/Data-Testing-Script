import React from "react";
import useFetch from "../../../hooks/useFetch";
import TextInput from "../../AntdComponent/Input";
import { useState } from "react";
import { Form, Button, Input } from "antd";
import { tw } from "twind";
import { getAllBuyerSeller } from "../../../services/buyerSeller";
import { RULES } from "../../../utils/formValidations";
import { notifications } from "../../../utils/notifications";
import { getURL } from "../../../configs/apiURL";
import { message } from "../../../utils/message";
import {
    editAddress,
    editBank,
    editBuyerSeller,
    editPromter,
} from "../../../redux/buyerSeller/actions";

const { TextArea } = Input;

const BuyerSellerApprove = ({ setBuyerSellerAdd, editBuyerSellerData }) => {
    const [approve, setApprove] = useState(true);

    const [updateBuyerSeller] = useFetch();

    const onSubmit = async (value) => {
        const data = {
            entityDetails: {
                ...editBuyerSellerData.entityDetails,
                active: approve ? 1 : 0,
                approved: approve ? 1 : 0,
                remarks: value?.remarks,
                sanctionedLimit: value?.sanctionedLimit,
            },
            adminDetails: editBuyerSellerData.adminDetails
        };
        const res = await updateBuyerSeller(
            getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}`),
            {
                method: "PUT",
                body: JSON.stringify(data),
            }
        );
        if (res && res.status === 200) {
            getAllBuyerSeller("approved=0");
            notifications.success({ message: message.BUYER_SELLER_APPROVED });
        } else {
            notifications.error({
                message: res.data?.error?.message || "something went wrong",
            });
        }

        setBuyerSellerAdd(false);
        editAddress(false, {});
        editBank(false, {});
        editPromter(false, {});
        editBuyerSeller(false, {});
    };

    const [form] = Form.useForm();

    return (
        <Form
            form={form}
            size="large"
            defaultValue={{ isDefault: true }}
            onFinish={onSubmit}
            onFinishFailed={(errorInfo) => {
                console.log(errorInfo);
            }}
            autoComplete="off"
        >
            <div className={tw`flex flex-col gap-1`}>
                <div className={tw`md:w-1/5 mt-3`}>
                    <Form.Item name="sanctionedLimit" rules={RULES.number}>
                        <TextInput rows={4} label="Sanctioned Limit*" placeholder="Enter Number" />
                    </Form.Item>
                </div>
                <div style={{ flex: 1 }} className={tw`md:w-2/4`}>
                    <Form.Item name="remarks" rules={RULES.inputRequired}>
                        <TextArea rows={4} placeholder="Enter Remarks*" />
                    </Form.Item>
                </div>
            </div>
            <div className={tw`flex gap-3 mt-1`}>
                <Button type="primary" size="middle" htmlType="submit">
                    Approve
                </Button>
                <Button
                    danger
                    type="primary"
                    size="middle"
                    htmlType="submit"
                    onClick={() => setApprove(false)}
                >
                    Reject
                </Button>
            </div>
        </Form>
    );
};

export default BuyerSellerApprove;
