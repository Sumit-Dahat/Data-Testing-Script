import React from "react";
import { useEffect } from "react";
import { tw } from "twind";
import { EntityKycDetails } from "../Modals/Entity";
import { getAllLinkedGst, getBuyerSellerBanks, getBuyerSellerPromoters, getPanKycDetails, getUdyamKycDetails, } from "../../../services/buyerSeller";
import { PromoterCardViewModal } from "../Modals/PromoterCard";
import { Card, Spin } from "antd";
import { BankCardViewModal } from "../Modals/BankCard";
import { useSelector } from "react-redux";
import { store } from "../../../redux";
import { buyerSellerTypes } from "../../../redux/buyerSeller/types";

const Analysis = ({ defaultValue, banksData, promotersData, loadingBanks, loadingPromoters }) => {

    const {
        bankKycDetails = {},
        loadingBankKycDetails
    } = useSelector((state) => ({
        bankKycDetails: state?.buyerSeller?.bankKycDetails,
        loadingBankKycDetails: state?.buyerSeller?.loadingBankKycDetails
    }));

    const apiProvider = `${localStorage.getItem("kycProvider")}`.toLowerCase();

    const fetchUdyamKycDetails = (verified) => {
        if (verified) {
            getUdyamKycDetails(apiProvider, defaultValue?.entityDetails?.udyamRegNo);
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_UDYAM_KYC_FAILURE
            });
        }
    }

    const fetchPanKycDetails = (verified) => {
        if (verified) {
            getPanKycDetails(apiProvider, defaultValue?.entityDetails?.pan);
            getAllLinkedGst(apiProvider, defaultValue?.entityDetails?.pan);
        } else {
            store.dispatch({
                type: buyerSellerTypes.GET_PAN_KYC_FAILURE
            });
            store.dispatch({
                type: buyerSellerTypes.GET_LINKED_GST_FAILURE
            });
        }
    }

    useEffect(() => {
        fetchUdyamKycDetails(defaultValue?.entityDetails?.udyamRegNoKycVerified);
        fetchPanKycDetails(defaultValue?.entityDetails?.panKycVerified);
        getBuyerSellerBanks(defaultValue?.entityDetails?.id);
        getBuyerSellerPromoters(defaultValue?.entityDetails?.id);
    }, []); // eslint-disable-line

    return (
        <div style={styles.container}>

            {/* Entity-Analysis */}
            <h3 className={classNames.heading}>
                {"Entity-Details"}
            </h3>
            <Card>
                <EntityKycDetails data={defaultValue} />
            </Card>

            {/* Banks-Analysis */}
            {(banksData.data?.length > 0) && (
                <h3 className={classNames.heading}>
                    {"Bank-Details"}
                </h3>
            )}
            {loadingBanks && (
                <div style={{ textAlign: "center", marginTop: "100px" }}>
                    <Spin spinning={loadingBanks} />
                </div>
            )}
            {banksData?.data?.map((record, index) => (
                <BankCardViewModal customFetch={true} bankData={record} kycData={bankKycDetails} loadingBankKycDetails={loadingBankKycDetails} index={index + 1} />
            ))}

            {/* Promoters-Analysis */}
            {(promotersData.data?.length > 0) && (
                <h3 className={classNames.heading}>
                    {"Promoter-Details"}
                </h3>
            )}
            {loadingPromoters && (
                <div style={{ textAlign: "center", marginTop: "100px" }}>
                    <Spin spinning={loadingPromoters} />
                </div>
            )}
            {promotersData.data?.map((record, index) => (
                <PromoterCardViewModal customFetch={true} promoterData={record} index={index + 1} />
            ))}
        </div>
    )
}

export default Analysis;

const styles = {
    container: {
        display: "flex",
        flexDirection: "column",
        gap: 20,
        marginTop: 20
    }
}

const classNames = {
    heading: tw`text-lg font-medium flex items-center gap-4`
}
