import React from "react";
import BuyerSellerApprove from "./Approve";
import BuyerSellerSanctioned from "./Limit";
import BuyerSellerDocumentsForm from "./Documents";
import BuyerSellerAddressForm from "./Address";
import BuyerSellerEntityForms from "./Entity";
import BuyerSellerPromotersForm from "./Promoters";
import BuyerSellerAnalysis from './Analysis';
import BuyerSellerBankForm from "./Banks";
import useFetch from "../../../hooks/useFetch";
import Cookies from "js-cookie";
import { consentInit } from "../../../utils/handlers";
import { useState, useReducer, useEffect } from "react";
import { Button, notification, Tabs, Typography } from "antd";
import { MdOutlineArrowBack } from "react-icons/md";
import { notifications } from "../../../utils/notifications";
import { tw } from "twind";
import { message } from "../../../utils/message";
import { useSelector } from "react-redux";
import { ACTION_TYPES } from "../../../utils/helpers";
import { getURL } from "../../../configs/apiURL";
import { setDocFilterQuery, setFilterQuery } from "../../../redux/filters/actions";
import { getBuyerSellerAddress, getBuyerSellerBanks, getBuyerSellerPromoters } from "../../../services/buyerSeller";
import { editAddress, editBank, editBuyerSeller, editPromter } from "../../../redux/buyerSeller/actions";

const { Text } = Typography;

const { TabPane } = Tabs;

const initialState = {
    dropDownData: {},
    loading: false,
    error: false,
};

const reducer = (state, action) => {
    switch (action.type) {
        case ACTION_TYPES.FETCH_START:
            return {
                ...state,
                loading: true,
            };
        case ACTION_TYPES.FETCH_SUCCESS:
            return {
                ...state,
                loading: false,
                dropDownData: action.payload,
            };
        case ACTION_TYPES.FETCH_ERROR:
            return {
                ...state,
                loading: false,
                error: true,
            };
        default:
            return state;
    }
};

const BuyerSellerAdd = ({ setBuyerSellerAdd, isUpdate, editBuyerSellerData, selfOnBoard }) => {

    const {
        query,
        addressData = {},
        addressLoading,
        editaddress,
        banksData = {},
        bankLoading,
        editBanks,
        promoterLoading,
        promotersData = {},
        editPromoters,
        documentsLoading,
        documentsData = {},
        ifscBanksData = {},
        ifscDataloading,
        pinCodeData,
        pinCodeDataloading,
    } = useSelector((state) => ({
        query: state?.filters?.query,
        addressData: state?.buyerSeller?.address,
        addressLoading: state?.buyerSeller?.loadingAddress,
        editaddress: state?.buyerSeller?.editAddress,
        banksData: state?.buyerSeller?.bank,
        bankLoading: state?.buyerSeller?.loadingBank,
        editBanks: state?.buyerSeller?.editBank,
        promoterLoading: state?.buyerSeller?.loadingPromoters,
        promotersData: state?.buyerSeller?.promoters,
        editPromoters: state?.buyerSeller?.editPromter,
        documentsLoading: state?.buyerSeller?.loadingDocument,
        documentsData: state?.buyerSeller?.documents,
        ifscBanksData: state?.buyerSeller?.ifscData,
        ifscDataloading: state?.buyerSeller?.loadingifscData,
        pinCodeDataloading: state?.buyerSeller?.loadingpinCodeData,
        pinCodeData: state?.buyerSeller?.pinData,
    }));

    const apiProvider = `${localStorage.getItem("kycProvider")}`.toUpperCase();

    const [state, dispatch] = useReducer(reducer, initialState);
    const [currentTab, setCurrentTab] = useState("1");
    const [activeTabs, setActiveTabs] = useState(["1"]);
    const [entity, setEntity] = useState(null);
    const [fetch, loading] = useFetch();
    const [consent, setConsent] = useState({ ...consentInit });

    const entityCategory = localStorage.getItem("entityCategory");
    const isAllDetailsPending = !editBuyerSellerData?.entityDetails?.allDetailsFilled;

    const entityOnSubmit = async (value) => {
        const name = value?.adminName.split(" ");
        const firstName = name[0] ? name[0] : "";
        const lastName = name[1] ? name[1] : "";

        const data = {
            entityDetails: {
                entityCategory: value.buyerSeller,
                entityName: value.entityName,
                pan: value.panNumber,
                kycApiProvider: apiProvider,
                panKycVerified: editBuyerSellerData?.entityDetails?.panKycVerified || value.panKycVerified,
                active: isUpdate ? editBuyerSellerData?.entityDetails?.active : 1,
                approved: isUpdate ? editBuyerSellerData?.entityDetails?.approved : 0,
                registrationNo: value.registrationNumber || null,
                entityTypeId: value.entityTypeId || null,
                udyamRegNo: value.udyamNumber || null,
                udyamRegNoKycVerified: editBuyerSellerData?.entityDetails?.udyamRegNoKycVerified || value.udyamRegNoKycVerified,
                dateOfIncorporation: value.incorporationDate || null,
                startOfOperation: value.startOfOperation || null,
                businessSectorId: value.businessSector || null,
                industrySectorId: value.industrySector || null,
                industrySubSectorId: value.industrySubsector || null,
                salesInLastFy: value.salesInLastFY || null,
                profitInLastFy: value.profitInLastFY || null,
                contactNo: value.contactNo || null,
                emailId: value.primaryEmail || null,
            },
            adminDetails: {
                entityCategory: value.buyerSeller,
                userType: "ADMIN",
                firstName: firstName,
                lastName: lastName,
                active: 1,
                mobileNo: value.mobileNo,
                emailId: value.email,
                password: value.password,
            },
        };

        if (isUpdate) {
            data["adminDetails"].id = editBuyerSellerData?.adminDetails?.id;
            const res = await fetch(getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}`), {
                method: "PUT",
                body: JSON.stringify(data),
            });

            if (res && res.status === 200) {
                if (["BUYER", "SELLER"].includes(entityCategory)) {
                    setEntity(res?.data.data);
                } else {
                    editBuyerSeller(true, res?.data.data);
                }
                notification.success({ message: message.ENTITY_UPDATED });
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                return false;
            }
        } else {
            const entityId = Cookies.get("entityId");
            data["entityDetails"]["createdByFinancierId"] = entityId;
            data["adminDetails"]["entityId"] = entity;
            const res = await fetch(getURL(`buyer-seller`), {
                method: "POST",
                body: JSON.stringify(data),
            });
            if (res && res.status === 200) {
                editBuyerSeller(true, res?.data.data);
                notification.success({ message: message.ENTITY_CREATED });
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                return false;
            }
        }
        return true;
    };

    const addressOnSubmit = async (value) => {
        const data = {
            entityId: editBuyerSellerData?.entityDetails?.id,
            addressTypeId: value.addressType,
            addressLineOne: value.addressLine1,
            addressLineTwo: value.addressLine2 || null,
            pinCode: value.pinNo,
            state: value.state,
            district: value.district,
            subDistrict: value.subDist,
            postOffice: value.postOffice,
        };

        if (editaddress?.openEdit) {
            const res = await fetch(
                getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}/address-details/${editaddress?.data?.id}`),
                {
                    method: "PUT",
                    body: JSON.stringify(data),
                }
            );

            if (res && res.status === 200) {
                notification.success({ message: message.ADDRESS_UPDATED });
                editAddress(false, {});
                getBuyerSellerAddress(editBuyerSellerData?.entityDetails?.id);
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
        } else {
            const res = await fetch(getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}/address-details`), {
                method: "POST",
                body: JSON.stringify(data),
            });

            if (res && res.status === 200) {
                notification.success({ message: message.ADDRESS_CREATED });
                getBuyerSellerAddress(editBuyerSellerData?.entityDetails?.id);
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
            }
        }
    };

    const bankOnSubmit = async (value) => {
        const data = {
            entityId: editBuyerSellerData?.entityDetails?.id,
            bankAccountTypeId: value.accountTypeId,
            accountTitle: value.accountTitle,
            bankAccKycVerified: editBanks?.data?.bankAccKycVerified || value.bankAccKycVerified,
            accountNo: value.accountNo,
            ifsc: value.ifscCode,
            bankName: value.bankName,
            branchName: value.branchName,
            micrCode: value.micrCode,
            swiftCode: value.swiftCode,
            isDefault: value.isDefault ? 1 : 0,
        };
        if (editBanks?.openEdit) {
            const res = await fetch(
                getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}/bank-details/${editBanks?.data?.id}`),
                {
                    method: "PUT",
                    body: JSON.stringify(data),
                }
            );

            if (res && res.status === 200) {
                notification.success({ message: message.BANK_UPDATED });
                editBank(false, {});
                getBuyerSellerBanks(editBuyerSellerData?.entityDetails?.id);
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                return false;
            }
        } else {
            const res = await fetch(getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}/bank-details`), {
                method: "POST",
                body: JSON.stringify(data),
            });

            if (res && res.status === 200) {
                notification.success({ message: message.BANK_CREATED });
                getBuyerSellerBanks(editBuyerSellerData?.entityDetails?.id);
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                return false;
            }
        }
        return true;
    };

    const promoterOnSubmit = async (value) => {
        const data = {
            entityId: editBuyerSellerData?.entityDetails?.id,
            promoterType: value?.promoterType,
            nameOrEntityName: value?.nameOrentityName,
            gender: value?.gender,
            dobOrDoi: value?.dobOrDateOfIncorporation,
            aadhaarOrRegNo: value?.adhaarOrRegistrationNumber,
            aadhaarKycVerified: editPromoters?.data?.aadhaarKycVerified || value.aadhaarKycVerified,
            dinOrCinNo: value?.dinCin,
            pan: value?.panNumber,
            panKycVerified: editPromoters?.data?.panKycVerified || value.panKycVerified,
            sharePercentage: parseInt(value?.shareholding),
            emailId: value?.email,
            contactNo: value?.contactNo,
            addressLineOne: value?.addressLine1,
            addressLineTwo: value?.addressLine2,
            pinCode: value?.pinNo,
            state: value?.state,
            district: value?.district,
            subDistrict: value?.subDist,
            postOffice: value?.postOffice,
        };

        if (editPromoters?.openEdit) {
            const res = await fetch(
                getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}/promoter-details/${editPromoters?.data?.id}`),
                {
                    method: "PUT",
                    body: JSON.stringify(data),
                }
            );

            if (res && res.status === 200) {
                notification.success({ message: message.PROMOTER_UPDATED });
                editPromter(false, {});
                getBuyerSellerPromoters(editBuyerSellerData?.entityDetails?.id, query);
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                return false;
            }
        } else {
            const res = await fetch(getURL(`buyer-seller/${editBuyerSellerData?.entityDetails?.id}/promoter-details`), {
                method: "POST",
                body: JSON.stringify(data),
            });

            if (res && res.status === 200) {
                notification.success({ message: message.PROMOTER_CREATED });
                getBuyerSellerPromoters(editBuyerSellerData?.entityDetails?.id, query);
            } else {
                notifications.error({
                    message: res.data?.error?.message || "something went wrong",
                });
                return false;
            }
        }
        return true;
    };

    const includeActiveTabs = (tabName) => setActiveTabs((tabs) => [...tabs, tabName]);

    /* Clearing all the filters on Tab change */

    useEffect(() => {
        setFilterQuery(undefined);
        setDocFilterQuery(undefined);
    }, [currentTab]); // eslint-disable-line

    return (
        <div>
            {!selfOnBoard && (
                <div className={tw`flex items-center gap-4 content-divider`}>
                    <Button
                        type="default"
                        onClick={() => {
                            setBuyerSellerAdd(false);
                            editBuyerSeller(false, {});
                            editAddress(false, {});
                            editBank(false, {});
                            editPromter(false, {});
                        }}
                    >
                        <MdOutlineArrowBack size="20px" />
                    </Button>
                    <Text className={tw`text-lg`}>{isUpdate ? "Update" : "Add"} Buyer Seller</Text>
                </div>
            )}
            <div className="card-container">
                <Tabs
                    type="line"
                    activeKey={currentTab}
                    onChange={async (key) => {
                        setCurrentTab(key);
                    }}
                >
                    <TabPane tab="Entity" key="1" disabled={!activeTabs.includes("1") && isAllDetailsPending}>
                        {currentTab === "1" && (
                            <BuyerSellerEntityForms
                                consent={consent}
                                setConsent={setConsent}
                                onSubmit={entityOnSubmit}
                                onSubmitLoader={loading}
                                defaultValue={entity || editBuyerSellerData}
                                currentTab={currentTab}
                                setCurrentTab={setCurrentTab}
                                isUpdate={isUpdate}
                                state={state}
                                dispatch={dispatch}
                                setActiveTabs={includeActiveTabs}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Address" key="2" disabled={!activeTabs.includes("2") && isAllDetailsPending}>
                        {currentTab === "2" && (
                            <BuyerSellerAddressForm
                                onSubmit={addressOnSubmit}
                                onSubmitLoader={loading}
                                tableData={addressData}
                                loading={addressLoading}
                                editAddress={editaddress}
                                currentTab={currentTab}
                                setCurrentTab={setCurrentTab}
                                pinCodeData={pinCodeData}
                                pinCodeDataloading={pinCodeDataloading}
                                editBuyerSellerData={editBuyerSellerData}
                                query={query}
                                state={state}
                                dispatch={dispatch}
                                setActiveTabs={includeActiveTabs}
                                isAllDetailsPending={isAllDetailsPending}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Banks" key="3" disabled={!activeTabs.includes("3") && isAllDetailsPending}>
                        {currentTab === "3" && (
                            <BuyerSellerBankForm
                                consent={consent}
                                setConsent={setConsent}
                                onSubmit={bankOnSubmit}
                                onSubmitLoader={loading}
                                tableData={banksData}
                                loading={bankLoading}
                                editBanks={editBanks}
                                currentTab={currentTab}
                                setCurrentTab={setCurrentTab}
                                ifscBanksData={ifscBanksData}
                                ifscDataloading={ifscDataloading}
                                editBuyerSellerData={editBuyerSellerData}
                                query={query}
                                state={state}
                                dispatch={dispatch}
                                setActiveTabs={includeActiveTabs}
                                isAllDetailsPending={isAllDetailsPending}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Promoters" key="4" disabled={!activeTabs.includes("4") && isAllDetailsPending}>
                        {currentTab === "4" && (
                            <BuyerSellerPromotersForm
                                consent={consent}
                                setConsent={setConsent}
                                onSubmit={promoterOnSubmit}
                                onSubmitLoader={loading}
                                tableData={promotersData}
                                loading={promoterLoading}
                                editPromoters={editPromoters}
                                currentTab={currentTab}
                                setCurrentTab={setCurrentTab}
                                pinCodeData={pinCodeData}
                                pinCodeDataloading={pinCodeDataloading}
                                editBuyerSellerData={editBuyerSellerData}
                                query={query}
                                state={state}
                                dispatch={dispatch}
                                setActiveTabs={includeActiveTabs}
                                isAllDetailsPending={isAllDetailsPending}
                            />
                        )}
                    </TabPane>
                    {editBuyerSellerData?.entityDetails?.approved && (
                        <TabPane tab="Sanctioned Limit" key="5" disabled={!activeTabs.includes("5") && isAllDetailsPending}>
                            {currentTab === "5" && (
                                <BuyerSellerSanctioned
                                    setCurrentTab={setCurrentTab}
                                    editBuyerSellerData={editBuyerSellerData}
                                    setActiveTabs={includeActiveTabs}
                                    isAllDetailsPending={isAllDetailsPending}
                                />
                            )}
                        </TabPane>
                    )}
                    <TabPane tab="Documents" key="6" disabled={!activeTabs.includes("6") && isAllDetailsPending}>
                        {currentTab === "6" && (
                            <BuyerSellerDocumentsForm
                                loading={documentsLoading}
                                tableData={documentsData}
                                setBuyerSellerAdd={setBuyerSellerAdd}
                                currentTab={currentTab}
                                setCurrentTab={setCurrentTab}
                                editBuyerSellerData={editBuyerSellerData}
                                query={query}
                                setActiveTabs={includeActiveTabs}
                                isAllDetailsPending={isAllDetailsPending}
                            />
                        )}
                    </TabPane>
                    <TabPane tab="Analysis" key="8" disabled={!activeTabs.includes("8") && isAllDetailsPending}>
                        {currentTab === "8" && (
                            <BuyerSellerAnalysis
                                currentTab={currentTab}
                                defaultValue={entity || editBuyerSellerData}
                                banksData={banksData}
                                loadingBanks={bankLoading}
                                promotersData={promotersData}
                                loadingPromoters={promoterLoading}
                            />
                        )}
                    </TabPane>
                    {localStorage.getItem("currentTab") === "OPERATION" && editBuyerSellerData?.approve && (
                        <TabPane tab="Approve-Reject" key="7" disabled={!activeTabs.includes("7") && isAllDetailsPending}>
                            {currentTab === "7" && (
                                <BuyerSellerApprove
                                    setBuyerSellerAdd={setBuyerSellerAdd}
                                    editBuyerSellerData={editBuyerSellerData}
                                />
                            )}
                        </TabPane>
                    )}
                </Tabs>
            </div>
        </div>
    );
};

export default BuyerSellerAdd;
