import React from "react";
import BuyerSellerConsent from "../../Consents/Entity";
import IsdCode from "../../AntdComponent/Mobile";
import TextInput from "../../AntdComponent/Input";
import useFetch from "../../../hooks/useFetch";
import SelectComponent from "../../AntdComponent/Select";
import DateComponent from "../../AntdComponent/Date";
import PasswordInput from "../../AntdComponent/Password";
import moment from "moment";
import { FaRegAddressCard } from "react-icons/fa";
import { useEffect, useMemo, useState, Fragment } from "react";
import { Form, Card, Button, Row, Col, Spin, Modal } from "antd";
import { tw } from "twind";
import { RULES } from "../../../utils/formValidations";
import { showPassword } from "../../../services/auth";
import { getURL } from "../../../configs/apiURL";
import { getAllLinkedGst, getPanKycDetails, getUdyamKycDetails, } from "../../../services/buyerSeller";
import { ACTION_TYPES, getIsdCode, getMobileNo } from "../../../utils/helpers";
import { onEntitySubmit } from "../../../utils/handlers";
import { MdCancel, MdCheckCircle } from "react-icons/md";
import { EntityKycDetails } from "../Modals/Entity";

const BuyerSellerEntityForms = ({
    consent,
    setConsent,
    isUpdate,
    onSubmit,
    onSubmitLoader,
    setCurrentTab,
    defaultValue,
    state,
    dispatch,
    setActiveTabs,
}) => {

    const [form] = Form.useForm();
    const [fetch, loading] = useFetch();
    const [pending, setPending] = useState(false);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [mobileIsdCode, setMobileIsdCode] = useState(getIsdCode(defaultValue?.adminDetails?.mobileNo));
    const [contactIsdCode, setContactIsdCode] = useState(getIsdCode(defaultValue?.entityDetails?.contactNo));

    const apiProvider = `${localStorage.getItem("kycProvider")}`.toLowerCase();

    const initialValue = useMemo(
        () => {
            return Object.keys(defaultValue).length !== 0
                ? {
                    buyerSeller: defaultValue?.entityDetails?.entityCategory,
                    entityTypeId: defaultValue?.entityDetails?.entityTypeId || defaultValue?.entityDetails?.entityType?.id,
                    entityName: defaultValue?.entityDetails?.entityName,
                    registrationNumber: defaultValue?.entityDetails?.registrationNo,
                    panNumber: defaultValue?.entityDetails?.pan,
                    gstinNumber: defaultValue?.entityDetails?.gstin,
                    udyamNumber: defaultValue?.entityDetails?.udyamRegNo,
                    incorporationDate: defaultValue?.entityDetails?.dateOfIncorporation ? moment(defaultValue?.entityDetails?.dateOfIncorporation) : null,
                    adminName: `${defaultValue?.adminDetails?.firstName} ${defaultValue?.adminDetails?.lastName}`,
                    mobileNo: getMobileNo(defaultValue?.adminDetails?.mobileNo),
                    email: defaultValue?.adminDetails?.emailId,
                    startOfOperation: defaultValue?.entityDetails?.startOfOperation ? moment(defaultValue?.entityDetails?.startOfOperation) : null,
                    businessSector: defaultValue?.entityDetails?.businessSectorId,
                    industrySector: defaultValue?.entityDetails?.industrySectorId,
                    industrySubsector: defaultValue?.entityDetails?.industrySubSectorId,
                    salesInLastFY: defaultValue?.entityDetails?.salesInLastFy,
                    profitInLastFY: defaultValue?.entityDetails?.profitInLastFy,
                    contactNo: getMobileNo(defaultValue?.entityDetails?.contactNo),
                    primaryEmail: defaultValue?.entityDetails?.emailId,
                }
                : {}
        },
        [defaultValue] // eslint-disable-line
    );

    const fetchDropdown = async () => {
        dispatch({ type: ACTION_TYPES.FETCH_START });
        try {
            const endPoints = [
                "entity-types",
                "business-sectors",
                "industry-sectors",
                "industry-sub-sectors",
            ].map((path) => {
                const url = new URL(getURL(path));
                url.searchParams.set("active", 1);
                return fetch(url);
            });

            const [entity, business, industry, subSector] = await Promise.all(endPoints);

            dispatch({
                type: ACTION_TYPES.FETCH_SUCCESS,
                payload: {
                    entityDropdown: entity?.data?.data.map((row) => ({
                        value: row?.id,
                        label: row?.name,
                    })),
                    businessDropdown: business?.data?.data.map((row) => ({
                        value: row?.id,
                        label: row?.name,
                    })),
                    industryDropdown: industry?.data?.data.map((row) => ({
                        value: row?.id,
                        label: row?.name,
                    })),
                    subSectorDropdown: subSector?.data?.data.map((row) => ({
                        value: row?.id,
                        label: row?.name,
                    })),
                },
            });
        } catch (error) {
            dispatch({ type: ACTION_TYPES.FETCH_ERROR });
        }
    };

    const showUserPassword = async (id) => {
        const password = await showPassword(id);
        form.setFieldsValue({
            password: password,
            repassword: password,
        });
    };

    useEffect(() => {
        if (isModalVisible) {
            if (defaultValue?.entityDetails?.udyamRegNoKycVerified)
                getUdyamKycDetails(apiProvider, defaultValue?.entityDetails?.udyamRegNo);
            if (defaultValue?.entityDetails?.panKycVerified) {
                getPanKycDetails(apiProvider, defaultValue?.entityDetails?.pan);
                getAllLinkedGst(apiProvider, defaultValue?.entityDetails?.pan);
            }
        }
    }, [isModalVisible]); // eslint-disable-line

    useEffect(() => {
        if (isUpdate) showUserPassword(defaultValue?.adminDetails?.id);
        form.setFieldsValue(initialValue);
        setMobileIsdCode(getIsdCode(defaultValue?.adminDetails?.mobileNo));
        setContactIsdCode(getIsdCode(defaultValue?.entityDetails?.contactNo));
    }, [initialValue]); // eslint-disable-line

    useEffect(() => {
        fetchDropdown();
    }, []); // eslint-disable-line

    if (loading || pending) {
        return (
            <div style={{ textAlign: "center", marginTop: "100px" }}>
                <Spin spinning={loading || pending} />
            </div>
        );
    }

    return (
        <div className={tw`mb-5`}>
            {consent.agree && (
                <BuyerSellerConsent
                    isUpdate={isUpdate}
                    onSubmit={onSubmit}
                    onSubmitLoader={onSubmitLoader}
                    consent={{ ...consent, formInitial: defaultValue }}
                    setConsent={(data) => setConsent((consent) => ({ ...consent, ...data }))}
                />
            )}
            <Form
                form={form}
                size="large"
                initialValues={initialValue}
                onFinish={async value => {
                    setPending(true)
                    await onEntitySubmit({
                        value,
                        consent,
                        setConsent,
                        defaultValue,
                        isUpdate,
                        onSubmit,
                        mobileIsdCode,
                        contactIsdCode,
                    });
                    setPending(false);
                }}
                onFinishFailed={(errorInfo) => {
                    console.log(errorInfo);
                }}
                autoComplete="off"
            >
                <Card title="Entity Details" style={{ width: "100%" }}>
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="buyerSeller" rules={RULES.selectRequired}>
                                <SelectComponent
                                    label="Buyer/Seller"
                                    placeholder="Buyer/Seller"
                                    required
                                    allowClear={true}
                                    options={[
                                        { label: "Buyer", value: "BUYER" },
                                        { label: "Seller", value: "SELLER" },
                                    ]}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="entityTypeId" rules={[]}>
                                <SelectComponent
                                    label="Entity Type"
                                    placeholder="Entity Type"
                                    allowClear={true}
                                    options={state?.dropDownData?.entityDropdown}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="entityName" rules={RULES.entityName}>
                                <TextInput
                                    label="Entity Name"
                                    required
                                    placeholder="Entity Name"
                                    disabled={
                                        defaultValue?.entityDetails?.panKycVerified ||
                                        consent.panKycVerified
                                    }
                                    suffix={
                                        defaultValue?.entityDetails?.panKycVerified ||
                                            consent.panKycVerified ? (
                                            <MdCheckCircle color="green" />
                                        ) : (
                                            isUpdate && <MdCancel color="red" />
                                        )
                                    }
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="panNumber" rules={RULES.panNumber}>
                                <TextInput
                                    label="PAN Number"
                                    placeholder="Enter PAN"
                                    required
                                    maxLength={10}
                                    disabled={
                                        defaultValue?.entityDetails?.panKycVerified ||
                                        consent.panKycVerified
                                    }
                                    suffix={
                                        defaultValue?.entityDetails?.panKycVerified ||
                                            consent.panKycVerified ? (
                                            <MdCheckCircle color="green" />
                                        ) : (
                                            isUpdate && <MdCancel color="red" />
                                        )
                                    }
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="udyamNumber" rules={RULES.udyamNumber}>
                                <TextInput
                                    label="Udyam Number"
                                    placeholder="Enter Udyam No"
                                    maxLength={19}
                                    disabled={
                                        defaultValue?.entityDetails?.udyamRegNoKycVerified ||
                                        consent.udyamRegNoKycVerified
                                    }
                                    suffix={
                                        defaultValue?.entityDetails?.udyamRegNoKycVerified ||
                                            consent.udyamRegNoKycVerified ? (
                                            <MdCheckCircle color="green" />
                                        ) : (
                                            isUpdate && <MdCancel color="red" />
                                        )
                                    }
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="registrationNumber"
                                rules={RULES.optionalRegistrationNumber}
                            >
                                <TextInput
                                    label="Registration Number"
                                    placeholder="Enter Registration Number"
                                    maxLength="12"
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="incorporationDate" rules={RULES.date}>
                                <DateComponent
                                    required
                                    label="Date of Incorporation"
                                    placeholder="Select Date"
                                    disabled={
                                        defaultValue?.entityDetails?.panKycVerified ||
                                        consent.panKycVerified
                                    }
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="startOfOperation">
                                <DateComponent
                                    label="Start of Operations"
                                    placeholder="Select Date"
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="businessSector">
                                <SelectComponent
                                    label="Business Sector"
                                    placeholder="Business Sector"
                                    allowClear={true}
                                    options={state?.dropDownData?.businessDropdown}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="industrySector">
                                <SelectComponent
                                    label="Industry Sector"
                                    placeholder="Industry Sector"
                                    allowClear={true}
                                    options={state?.dropDownData?.industryDropdown}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="industrySubsector">
                                <SelectComponent
                                    label="Industry Sub-sector"
                                    placeholder="Industry Sub-sector"
                                    allowClear={true}
                                    options={state?.dropDownData?.subSectorDropdown}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="salesInLastFY" rules={RULES.optionalNumber}>
                                <TextInput
                                    label="Sales in Last FY"
                                    placeholder="Enter Sales in Last FY"
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="profitInLastFY" rules={RULES.optionalNumber}>
                                <TextInput
                                    label="Profit in Last FY"
                                    placeholder="Profit in Last FY"
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="contactNo"
                                rules={RULES.mobileNo}
                                style={{
                                    position: "relative",
                                    bottom: 7,
                                    zIndex: 999,
                                }}
                            >
                                <TextInput
                                    label="Primary Contact Number"
                                    placeholder="Enter Number"
                                    maxLength={10}
                                    addonBefore={
                                        <IsdCode
                                            isdCode={contactIsdCode}
                                            setIsdCode={(code) => setContactIsdCode(code)}
                                        />
                                    }
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="primaryEmail" rules={RULES.email}>
                                <TextInput
                                    label="Primary Email"
                                    placeholder="Enter Email"
                                    required
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Card>
                <Card title="Admin Details" style={{ width: "100%", marginTop: "20px" }}>
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="adminName" rules={RULES.name}>
                                <TextInput label="Admin Name" placeholder="Enter Name" required />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="mobileNo"
                                rules={RULES.mobileNo}
                                style={{
                                    position: "relative",
                                    bottom: 7,
                                    zIndex: 999,
                                }}
                            >
                                <TextInput
                                    label="Mobile No"
                                    placeholder="Enter Number"
                                    required
                                    addonBefore={
                                        <IsdCode
                                            isdCode={mobileIsdCode}
                                            setIsdCode={(code) => setMobileIsdCode(code)}
                                        />
                                    }
                                    maxLength={10}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="email" rules={RULES.email}>
                                <TextInput label="Email" placeholder="Enter Email" required />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="password" rules={RULES.password} hasFeedback>
                                <PasswordInput
                                    label="Password"
                                    placeholder="Enter Password"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item name="repassword" rules={RULES.repassword} hasFeedback>
                                <PasswordInput
                                    label="Re-Password"
                                    placeholder="Enter Password"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            {isUpdate && (
                                <Fragment>
                                    <Button
                                        style={{ borderRadius: "8px", padding: "10px 15px" }}
                                        onClick={() => setIsModalVisible(true)}
                                    >
                                        <FaRegAddressCard size="20px" color="black" />
                                    </Button>
                                    <Modal
                                        open={isModalVisible}
                                        onCancel={() => setIsModalVisible(false)}
                                        footer={
                                            <Button key="back" onClick={() => setIsModalVisible(false)} type="primary" size="middle" className={tw`ml-auto`}>
                                                Close
                                            </Button>
                                        }
                                        centered
                                    >
                                        <EntityKycDetails data={defaultValue} />
                                    </Modal>
                                </Fragment>
                            )}
                        </Col>
                    </Row>
                </Card>
                <div className={tw`flex gap-2 mt-5`}>
                    <Button type="primary" size="middle" htmlType="submit" loading={onSubmitLoader}>
                        {isUpdate ? "Update" : "Save"}
                    </Button>
                    <Button
                        type="primary"
                        size="middle"
                        disabled={!isUpdate}
                        onClick={() => {
                            setCurrentTab("2");
                            setActiveTabs("2");
                        }}
                    >
                        Continue
                    </Button>
                </div>
            </Form>
        </div >
    );
};

export default BuyerSellerEntityForms;
