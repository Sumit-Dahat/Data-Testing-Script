import React from "react";
import BuyerSellerAdd from "../BuyerSeller/Tabs";
import TableComponent from "../AntdComponent/Table";
import { useEffect } from "react";
import { Button, Typography } from "antd";
import { RiAddCircleFill } from "react-icons/ri";
import { tw } from "twind";
import {
    editAddress,
    editBank,
    editPromter,
    editBuyerSeller as editBuyerSellers,
} from "../../redux/buyerSeller/actions";
import { useState, Fragment } from "react";
import { useSelector } from "react-redux";
import { Columns } from "./BSColumns";
import { Permissions } from "../../configs/permissions";
import { getAllBuyerSeller } from "../../services/buyerSeller";

const { Text } = Typography;

const BuyerSeller = () => {
    const {
        query = "",
        editBuyerSeller,
        buyerSellerData = {},
        loadingBuyerSeller = false,
    } = useSelector((state) => ({
        query: state?.filters?.query,
        editBuyerSeller: state.buyerSeller?.editBuyerSeller,
        loadingBuyerSeller: state.buyerSeller?.loadingBuyerSeller,
        buyerSellerData: state.buyerSeller?.buyerSeller,
    }));

    const [buyerSellerAdd, setBuyerSellerAdd] = useState(false);


    useEffect(() => {
        if (!buyerSellerAdd && !editBuyerSeller?.openEdit) {
            let api;
            if (
                ["ADMIN", "OPERATION_MANAGER"].includes(localStorage.getItem("userType")) &&
                ["OPERATION"].includes(localStorage.getItem("currentTab"))
            ) {
                api = `allDetailsFilled=1&approved=0&active=1`;
            } else if (["COMPLETED"].includes(localStorage.getItem("currentTab"))) {
                api = `approved=1&active=1`;
            } else {
                api = `allDetailsFilled=0&approved=0&active=1`;
            }
            getAllBuyerSeller(`${api}&${query}`);
        }
    }, [query, buyerSellerAdd, editBuyerSeller?.openEdit]); // eslint-disable-line

    return (
        <Fragment>
            {(buyerSellerAdd || editBuyerSeller?.openEdit) && (
                <BuyerSellerAdd
                    isUpdate={editBuyerSeller?.openEdit}
                    editBuyerSellerData={editBuyerSeller?.openEdit ? editBuyerSeller?.data : {}}
                    setBuyerSellerAdd={setBuyerSellerAdd}
                />
            )}
            {!buyerSellerAdd && !editBuyerSeller?.openEdit && (
                <Fragment>
                    <div className={tw`flex flex-col md:flex-row justify-between content-divider`}>
                        <Text
                            style={{
                                fontSize: "20px",
                                fontWeight: "600px",
                                textAlign: "center",
                            }}
                        >
                            Manage Buyer-Seller
                        </Text>
                        <div className={tw`ml-auto`}>
                            {Permissions(
                                localStorage.getItem("currentTab") === "OPERATION"
                                    ? "operations"
                                    : "manageBuyerSeller",
                                "addBuyerSeller"
                            ) && (
                                    <Button
                                        name="add-entity"
                                        type="primary"
                                        onClick={() => {
                                            setBuyerSellerAdd(true);
                                            editBuyerSellers(false, {});
                                            editAddress(false, {});
                                            editBank(false, {});
                                            editPromter(false, {});
                                        }}
                                    >
                                        <div
                                            className={tw`text - xs md: text - sm flex gap - 1 items - center`}
                                        >
                                            <RiAddCircleFill size="20px" /> Add Buyer-Seller
                                        </div>
                                    </Button>
                                )}
                        </div>
                    </div>
                    <TableComponent
                        columns={Columns}
                        data={buyerSellerData}
                        loading={loadingBuyerSeller}
                    />
                </Fragment>
            )}
        </Fragment>
    );
};

export default BuyerSeller;
