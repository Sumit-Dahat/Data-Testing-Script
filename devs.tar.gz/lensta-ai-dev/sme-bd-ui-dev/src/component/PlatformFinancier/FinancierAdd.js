import React from "react";
import IsdCode from "../AntdComponent/Mobile";
import TextInput from "../AntdComponent/Input";
import Date from "../AntdComponent/Date";
import PasswordInput from "../AntdComponent/Password";
import SelectComponent from "../AntdComponent/Select";
import moment from "moment";
import "./style.css";
import { useEffect, useMemo, useState } from "react";
import { Button, Card, Form, Spin, Row, Col, Upload, Input, Typography } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import { MdOutlineArrowBack } from "react-icons/md";
import { Link } from "react-router-dom";
import { GoLinkExternal } from "react-icons/go";
import { tw } from "twind";
import { editFinancier } from "../../redux/financier/actions";
import { showPassword } from "../../services/auth";
import { RULES } from "../../utils/formValidations";
import { getIsdCode, getMobileNo } from "../../utils/helpers";

const { Text } = Typography;

const MAX_FILE_SIZE = process.env.REACT_APP_MAX_FILE_SIZE * 1024;
const DOC_EXT = process.env.REACT_APP_DOC_EXT;
const THEME = process.env.REACT_APP_THEME

const FinancierAdd = ({
    setFinancierAdd,
    onSubmit,
    onSubmitLoader,
    defaultValue,
    isUpdate,
}) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(false);
    const [isdCode, setIsdCode] = useState(getIsdCode(defaultValue?.adminDetails?.mobileNo));
    const initialValue = useMemo(
        () =>
            Object.keys(defaultValue).length !== 0
                ? {
                      entityName: defaultValue?.entityDetails?.entityName,
                      registrationNumber: defaultValue?.entityDetails?.registrationNo,
                      panNumber: defaultValue?.entityDetails?.pan,
                      udyamNumber: defaultValue?.entityDetails?.udyamRegNo,
                      kycApiProvider: defaultValue?.entityDetails?.kycApiProvider,
                      incorporationDate: defaultValue?.entityDetails?.dateOfIncorporation ? moment(defaultValue?.entityDetails?.dateOfIncorporation) : null,
                      adminName: `${defaultValue?.adminDetails?.firstName} ${defaultValue?.adminDetails?.lastName}`,
                      mobileNo: getMobileNo(defaultValue?.adminDetails?.mobileNo),
                      email: defaultValue?.adminDetails?.emailId,
                      expiryDate: defaultValue?.approvalDetails?.dateOfExpiry ? moment(defaultValue?.approvalDetails?.dateOfExpiry) : null,
                      approvalType: defaultValue?.approvalDetails?.approvalType,
                      themeHexcode: defaultValue?.entityDetails?.themeHexcode ? `#${defaultValue.entityDetails.themeHexcode}` : THEME,
                  }
                : { themeHexcode: THEME },
        [defaultValue] // eslint-disable-line
    );

    const getFile = (e) => {
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    };

    const beforeUpload = (file) => {
        const fileSizeKiloBytes = file.size / 1024;
        if (fileSizeKiloBytes > MAX_FILE_SIZE) {
            setError("File size is greater than maximum limit");
            return false;
        }
        setError(false);
        return true;
    };

    const showUserPassword = async (id) => {
        setLoading(true);
        const password = await showPassword(id);
        form.setFieldsValue({
            password: password,
            repassword: password,
        });
        setLoading(false);
    };

    const onSubmitHandler = async (value) => {
        onSubmit({
            ...value,
            mobileNo: isdCode + value.mobileNo,
            panKycVerified: 0,
            udyamRegNoKycVerified: 0,
        });
    };

    useEffect(() => {
        if (isUpdate) {
            showUserPassword(defaultValue?.adminDetails?.id);
        }
    }, [isUpdate]); // eslint-disable-line

    useEffect(() => {
        form.setFieldsValue(initialValue);
        setIsdCode(getIsdCode(defaultValue?.adminDetails?.mobileNo));
    }, [form, initialValue]); // eslint-disable-line

    useEffect(() => {
        if (isUpdate) {
            showUserPassword(defaultValue?.adminDetails?.id);
        }
    }, [isUpdate]); // eslint-disable-line

    if (loading) {
        return (
            <div style={{ textAlign: "center", marginTop: "100px" }}>
                <Spin spinning={loading} />
            </div>
        );
    }

    return (
        <div>
            <div className={tw`flex items-center gap-4 content-divider`}>
                <Button
                    type="default"
                    style={{ borderRadius: "4px", padding: "5px" }}
                    onClick={() => {
                        setFinancierAdd(false);
                        editFinancier(false, {});
                    }}
                >
                    <MdOutlineArrowBack size="20px" />
                </Button>
                <Text className={tw`text-lg`}>
                    {isUpdate ? "Update" : "Add"} Financier
                </Text>
            </div>
            <Form
                form={form}
                size="large"
                onFinish={onSubmitHandler}
                onFinishFailed={(errorInfo) => {
                    console.log(errorInfo);
                }}
                autoComplete="off"
            >
                <Card title="Entity Details">
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="entityName"
                                rules={RULES.entityName}
                            >
                                <TextInput
                                    label="Entity Name"
                                    placeholder="Enter Name"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="registrationNumber"
                                rules={RULES.registrationNumber}
                            >
                                <TextInput
                                    label="Registration Number"
                                    placeholder="Enter Registration Number"
                                    required
                                    maxLength="12"
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item name="panNumber" rules={RULES.panNumber}>
                                <TextInput
                                    label="PAN Number"
                                    placeholder="Enter PAN"
                                    required
                                    maxLength={10}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="udyamNumber"
                                rules={RULES.udyamNumber}
                            >
                                <TextInput
                                    label="Udyam Number"
                                    placeholder="Enter Udyam No"
                                    maxLength={19}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="incorporationDate"
                                rules={RULES.date}
                            >
                                <Date
                                    required
                                    label="Date of Incorporation"
                                    placeholder="Select Date"
                                />
                            </Form.Item>
                        </Col>
                        {/* <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="kycApiProvider"
                                rules={RULES.selectRequired}
                            >
                                <SelectComponent
                                    label="KYC Provider"
                                    placeholder="KYC Provider"
                                    required
                                    allowClear={true}
                                    options={[
                                        { label: "Karza", value: "KARZA" },
                                        { label: "Gridlines", value: "GRIDLINES" }
                                    ]}
                                />
                            </Form.Item>
                        </Col> */}
                        <Col xs={24} sm={8} md={3}>
                            <Form.Item
                                name="uploadDocuments"
                                getValueFromEvent={getFile}
                                rules={[]}
                            >
                                <Upload
                                    accept={DOC_EXT}
                                    beforeUpload={beforeUpload}
                                >
                                    <Button icon={<UploadOutlined />}>
                                        Browse
                                    </Button>
                                    <br />
                                    <p className={tw`text-red-500`}>{error}</p>
                                </Upload>
                            </Form.Item>
                        </Col>
                        {isUpdate &&
                            defaultValue?.entityDetails?.finLogoDocId && (
                                <Col xs={24} sm={8} md={1}>
                                    <div className={tw`mt-2`}>
                                        <Link
                                            target={"_blank"}
                                            to={{
                                                pathname: `/financiers/logo/${defaultValue?.entityDetails?.finLogoDocId}/signed-url`,
                                                search: "?action=VIEW&expiresIn=300",
                                            }}
                                        >
                                            <GoLinkExternal
                                                size={24}
                                                color="#228be6"
                                            />
                                        </Link>
                                    </div>
                                </Col>
                            )}
                        <Col xs={24} sm={8} md={2}>
                            <Form.Item name="themeHexcode" rules={[]}>
                                <Input
                                    style={{ cursor: "pointer" }}
                                    type="color"
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Card>
                <Card
                    title="Admin Details"
                    style={{
                        width: "100%",
                        marginTop: "20px",
                    }}
                >
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item name="adminName" rules={RULES.name}>
                                <TextInput
                                    label="Admin Name"
                                    placeholder="Enter Name"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="mobileNo"
                                rules={RULES.mobileNo}
                                style={{ position: "relative", bottom: 7 }}
                            >
                                <TextInput
                                    label="Mobile No"
                                    placeholder="Enter Number"
                                    required
                                    addonBefore={
                                        <IsdCode
                                            isdCode={isdCode}
                                            setIsdCode={(code) =>
                                                setIsdCode(code)
                                            }
                                        />
                                    }
                                    maxLength={10}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item name="email" rules={RULES.email}>
                                <TextInput
                                    label="Email"
                                    placeholder="Enter Email"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="password"
                                rules={RULES.password}
                                hasFeedback
                            >
                                <PasswordInput
                                    label="Password"
                                    placeholder="Enter Password"
                                    required
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="repassword"
                                rules={RULES.repassword}
                                hasFeedback
                            >
                                <PasswordInput
                                    label="Re-Password"
                                    placeholder="Re-enter Password"
                                    required
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Card>
                <Card
                    title="Approval Details"
                    style={{ width: "100%", marginTop: "20px" }}
                >
                    <Row
                        gutter={[
                            { xs: 8, sm: 16, md: 24 },
                            { xs: 12, sm: 16, md: 24 },
                        ]}
                        className={tw`mb-4 md:mb-0`}
                    >
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item
                                name="expiryDate"
                                className=""
                                rules={[]}
                            >
                                <Date
                                    label="Date of Expiry"
                                    disabled
                                    placeholder="Select Date"
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={8} md={6}>
                            <Form.Item name="approvalType" rules={[]}>
                                <SelectComponent
                                    label="Trial/Permanent"
                                    placeholder="Select"
                                    allowClear={true}
                                    onChange={(type) => {
                                        form.setFieldsValue({
                                            approvalType: type,
                                            expiryDate:
                                                type === "TRIAL"
                                                    ? moment().add(15, "days")
                                                    : moment().add(1, "years"),
                                        });
                                    }}
                                    options={[
                                        { label: "Trial", value: "TRIAL" },
                                        {
                                            label: "Permanent",
                                            value: "PERMANENT",
                                        },
                                    ]}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Card>
                <Button
                    className={tw`my-5 w-full sm:w-32`}
                    size="middle"
                    type="primary"
                    htmlType="submit"
                    loading={onSubmitLoader}
                >
                    {isUpdate ? "Update" : "Add"}
                </Button>
            </Form>
        </div>
    );
};

export default FinancierAdd;
