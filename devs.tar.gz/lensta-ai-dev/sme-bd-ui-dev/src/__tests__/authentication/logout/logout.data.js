const LOGOUT = {
    email: "platform.admin@gmail.com",
    password: "platformadmin123",
};

module.exports = {
    LOGOUT: {
        ...LOGOUT,
    },
};
