const { getURL, getDriver, sleep, sleepEvents } = require("../../config");
const { message } = require("../../message");
const { expect } = require("@jest/globals");
const { LOGOUT } = require("./logout.data");
const {
    findByXPathAndWaitForLocatedAndClick,
    findByXPathAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
} = require("../../generic-service");

module.exports = describe("Logout", () => {
    let driver, resposne;

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("LOGOUT", () => {
        it("For valid input: Should return an Success string", async () => {
            // FILL THE LOGIN FORM
            for (let field of Object.keys(LOGOUT)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGOUT[field]
                );
            }

            // SUBMIT THE FORM
            await findByXPathAndClick(driver, "//button[@type='submit']");

            // WAIT FOR LOGIN MESSAGE TO DISAPPEAR [MAKES DROPDOWN CLICKABLE]
            await sleep(sleepEvents.notificationLoading);

            // CLICK ON LOGOUT BUTTON
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@type="button"][1]'
            );
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                `//span[@class="ant-dropdown-menu-title-content"]/div[contains(@class,"logout")]`
            );

            // WAIT FOR SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.LOGOUT
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Logout Successfully");
        });
    });
});
