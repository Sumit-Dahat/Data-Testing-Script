const { getURL, getDriver } = require("../../config");
const { expect } = require("@jest/globals");
const { message } = require("../../message");
const {
    LOGIN_REQUIRED_VALIDATION,
    LOGIN_INVALID_EMAIL_VALIDATION,
    LOGIN_INVALID_PASSWORD_VALIDATION,
    LOGIN,
} = require("./login.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
} = require("../../generic-service");

module.exports = describe("Login", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("LOGIN_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // FILL THE LOGIN FORM
            for (let field of Object.keys(LOGIN_REQUIRED_VALIDATION)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN_REQUIRED_VALIDATION[field].value
                );
                errors.push(LOGIN_REQUIRED_VALIDATION[field].error);
            }

            // SUBMIT THE FORM
            await findByXPathAndClick(driver, "//button[@type='submit']");

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("LOGIN_INVALID_EMAIL_VALIDATION", () => {
        it("For invalid email input: Should return an Error string", async () => {
            // FILL THE LOGIN FORM
            for (let field of Object.keys(LOGIN_INVALID_EMAIL_VALIDATION)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN_INVALID_EMAIL_VALIDATION[field]
                );
            }

            // SUBMIT THE FORM
            await findByXPathAndClick(driver, "//button[@type='submit']");

            // FORM ERRORS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                "User is not registered."
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toBe("User is not registered.");
        });
    });

    describe("LOGIN_INVALID_PASSWORD_VALIDATION", () => {
        it("For invalid password input: Should return an Error string", async () => {
            // FILL THE LOGIN FORM
            for (let field of Object.keys(LOGIN_INVALID_PASSWORD_VALIDATION)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN_INVALID_PASSWORD_VALIDATION[field]
                );
            }

            // SUBMIT THE FORM
            await findByXPathAndClick(driver, "//button[@type='submit']");

            // FORM ERRORS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                "Invalid credentials."
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toBe("Invalid credentials.");
        });
    });

    describe("LOGIN", () => {
        it("For valid input: Should return an Success string", async () => {
            // FILL THE LOGIN FORM
            for (let field of Object.keys(LOGIN)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN[field]
                );
            }

            // SUBMIT THE FORM
            await findByXPathAndClick(driver, "//button[@type='submit']");

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.LOGIN
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Login Successfully");
        });
    });
});
