const LOGIN = {
    email: "platform.admin@gmail.com",
    password: "platformadmin123",
};

module.exports = {
    LOGIN_REQUIRED_VALIDATION: {
        email: {
            value: "",
            error: "Please input valid Email/Mobile Number",
        },
        password: {
            value: "",
            error: "Please input valid Password!",
        },
    },
    LOGIN_INVALID_EMAIL_VALIDATION: {
        ...LOGIN,
        email: "wrong_email@gmail.com",
    },
    LOGIN_INVALID_PASSWORD_VALIDATION: {
        ...LOGIN,
        password: "wrong_password",
    },
    LOGIN: {
        ...LOGIN,
    },
};
