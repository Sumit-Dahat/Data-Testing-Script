const LOGIN = {
    email: "buyer.checker1@gmail.com",
    password: "buycercheckerone123",
};

const APPROVE_REJECT = {
    remarks: "Factoring Unit Remarks",
};

module.exports = {
    LOGIN: LOGIN,
    APPROVE_REJECT_FU_REQUIRED_VALIDATION: {
        remarks: {
            value: "",
            error: "above field can not be empty!",
        },
    },
    APPROVE_FU: {
        ...APPROVE_REJECT,
    },
    REJECT_FU: {
        ...APPROVE_REJECT,
    },
};
