const LOGIN = {
    email: "buyer.checker1@gmail.com",
    password: "buyercheckerone123",
};

const APPROVE = {
    remarks: "Approving Invoice",
};

module.exports = {
    LOGIN: LOGIN,
    APPROVE_REJECT_INVOICE_REQUIRED_VALIDATION: {
        remarks: {
            value: "",
            error: "above field can not be empty!",
        },
    },
    APPROVE_INVOICE: {
        ...APPROVE,
    },
};
