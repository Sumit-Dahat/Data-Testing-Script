const { getURL, getDriver, sleep } = require("../../config");
const { message } = require("../../message");
const {
    APPROVE_REJECT_FU_REQUIRED_VALIDATION,
    APPROVE_FU,
    REJECT_FU,
    LOGIN,
} = require("./approve-reject.data");
const {
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../generic-service");

module.exports = describe("Buyer Admin Factoring Units Approve Reject Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("APPROVE_REJECT_FU_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> ACCEPT-BANK FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[4]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(3200);

            // CLICK ON APPROVE-REJECT BUTTON
            await findByXPathAndClick(driver, `//button[@name="approve-reject"]`);

            // FILL THE FORM
            for (let field of Object.keys(APPROVE_REJECT_FU_REQUIRED_VALIDATION)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//textarea[@id="${field}"]`,
                    APPROVE_REJECT_FU_REQUIRED_VALIDATION[field].value
                );
                errors.push(APPROVE_REJECT_FU_REQUIRED_VALIDATION[field].error);
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@name="approve"]');

            // WAIT TILL ERRORS LOCATED
            await sleep(1600);

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("APPROVE_FU", () => {
        it("APPROVE_FU", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> ACCEPT-BANK FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[4]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(3200);

            // CLICK ON APPROVE-REJECT BUTTON
            await findByXPathAndClick(driver, `//button[@name="approve-reject"]`);

            // FILL THE FORM
            for (let field of Object.keys(APPROVE_FU)) {
                await findByXPathClearAndSendKeys(
                    driver,
                    `//textarea[@id="${field}"]`,
                    APPROVE_FU[field]
                );
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@name="approve"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.ACCEPT_BANK_FINANCE_APPROVED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Factoring Unit Factored Successfully");
        });
    });

    describe("REJECT_FU", () => {
        it("REJECT_FU", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> ACCEPT-BANK FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[4]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(3200);

            // CLICK ON APPROVE-REJECT BUTTON
            await findByXPathAndClick(driver, `//button[@name="approve-reject"]`);

            // FILL THE FORM
            for (let field of Object.keys(REJECT_FU)) {
                await findByXPathClearAndSendKeys(
                    driver,
                    `//textarea[@id="${field}"]`,
                    REJECT_FU[field]
                );
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@name="reject"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.ACCEPT_BANK_FINANCE_REJECTED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Factoring Unit Rejected Successfully");
        });
    });
});
