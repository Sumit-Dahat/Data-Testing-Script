const { getURL, getDriver, sleep } = require("../../config");
const { message } = require("../../message");
const {
    ADD_USER_REQUIRED_VALIDATION,
    ADD_USER_INVALID_VALIDATION,
    ADD_USER_PASSWORD_VALIDATION,
    ADD_USER,
    UPDATE_USER,
    LOGIN,
} = require("./user.data");
const {
    findByXPathClearAndSendKeys,
    findByXPathAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findAllByXPathAndWaitForLocated,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../generic-service");

module.exports = describe("Buyer Admin Users Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_USER_REQUIRED_VALIDATION", async () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> USER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[2]'
            );

            // FILL THE USER FORM AND PUSH ERRORS
            for (let field of Object.keys(ADD_USER_REQUIRED_VALIDATION)) {
                if (ADD_USER_REQUIRED_VALIDATION[field].choose) {
                    errors.push(ADD_USER_REQUIRED_VALIDATION[field].error);
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_USER_REQUIRED_VALIDATION[field].value
                    );
                    errors.push(ADD_USER_REQUIRED_VALIDATION[field].error);
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_USER_INVALID_VALIDATION", async () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> USER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[2]'
            );

            // FILL REMAINING THE FORM
            for (let field of Object.keys(ADD_USER_INVALID_VALIDATION)) {
                if (ADD_USER_INVALID_VALIDATION[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_USER_INVALID_VALIDATION[field].option}"]`
                    );
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_USER_INVALID_VALIDATION[field].value
                    );
                    errors.push(ADD_USER_INVALID_VALIDATION[field].error);
                }
            }

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_USER_PASSWORD_VALIDATION", async () => {
        it("For invalid password input: Should return an Error string", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> USER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[2]'
            );

            // FILL THE USER FORM I.E PASSWORDS & REPASSWORD
            await findByXPathAndSendKeys(
                driver,
                `//input[@id="password"]`,
                ADD_USER_PASSWORD_VALIDATION.password.value
            );
            await findByXPathAndSendKeys(
                driver,
                `//input[@id="repassword"]`,
                ADD_USER_PASSWORD_VALIDATION.repassword.value
            );

            // FORM ERRORS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-form-item-explain-error']",
                ADD_USER_PASSWORD_VALIDATION.repassword.error
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Passwords do not match!");
        });
    });

    describe("ADD_USER", async () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> USER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[2]'
            );

            // FILL REMAINING THE FORM
            for (let field of Object.keys(ADD_USER)) {
                if (ADD_USER[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_USER[field].option}"]`
                    );
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_USER[field]
                    );
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.USER_CREATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("User Created Successfully");
        });
    });

    describe("UPDATE_USER", async () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO SELLER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> USER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[2]'
            );

            // CLICK ON UPDATE USER -> ANY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-user"]'
            );

            // WAIT FOR STATE LOADING
            await sleep(2000);

            // FILL REMAINING THE FORM
            for (let field of Object.keys(UPDATE_USER)) {
                if (UPDATE_USER[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${UPDATE_USER[field].option}"]`
                    );
                } else {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        UPDATE_USER[field]
                    );
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.USER_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("User Updated Successfully");
        });
    });
});
