const LOGIN = {
    email: "john.doe@gmail.com",
    password: "johndoe123",
};

const USER = {
    userType: "Maker",
    name: "Test User",
    dob: "2002-03-09",
    emailId: "test.user@gmail.com",
    mobileNo: "9856784545",
    password: "test1234",
    repassword: "test1234",
};

module.exports = {
    LOGIN: LOGIN,
    ADD_USER_REQUIRED_VALIDATION: {
        userType: {
            choose: true,
            option: null,
            error: "Please select one!",
        },
        name: {
            value: "",
            error: "above field can not be empty!",
        },
        emailId: {
            value: "",
            error: "please enter the email id!",
        },
        mobileNo: {
            value: "",
            error: "please enter the mobile number!",
        },
        password: {
            value: "",
            error: "please enter the password!",
        },
        repassword: {
            value: "",
            error: "Please confirm the password!",
        },
    },
    ADD_USER_INVALID_VALIDATION: {
        userType: {
            choose: true,
            option: USER.userType,
        },
        name: {
            value: "User123",
            error: "only aplhabets required!",
        },
        emailId: {
            value: "123mail.com",
            error: "enter a valid email id!",
        },
        mobileNo: {
            value: "123",
            error: "please enter the valid mobile number!",
        },
        password: {
            value: "123",
            error: "minimum 8 characters required!",
        },
        repassword: {
            value: "123",
            error: "minimum 8 characters required!",
        },
    },
    ADD_USER_PASSWORD_VALIDATION: {
        password: {
            value: "123456789",
            error: "",
        },
        repassword: {
            value: "12345678910",
            error: "Passwords do not match!",
        },
    },
    ADD_USER: {
        ...USER,
        userType: {
            choose: true,
            option: USER.userType,
        },
    },
    UPDATE_USER: {
        name: "test user update",
        dob: "2002-01-01",
        emailId: "test.update.user@gmail.com",
        mobileNo: "8967562318",
    },
};
