const LOGIN = {
    email: "john.doe@gmail.com",
    password: "johndoe123",
};

const CHECKER = {
    levelName: "Buyer Level 1",
    userId: "Buyer Checker One",
};

module.exports = {
    LOGIN: LOGIN,
    ADD_CHECKER_REQUIRED_VALIDATION: {
        levelName: {
            value: "",
            error: "above field can not be empty!",
        },
        userId: {
            choose: true,
            option: undefined,
            error: "Please select one!",
        },
    },
    ADD_CHECKER: {
        ...CHECKER,
        userId: {
            choose: true,
            option: CHECKER.userId,
        },
    },
    UPDATE_CHECKER: {
        levelName: "Buyer Checker Update 1",
    },
    DELETE_CHECKER: {
        type: "delete",
    },
};
