const { getURL, getDriver, sleep } = require("../../config");
const { message } = require("../../message");
const {
    ADD_CHECKER_REQUIRED_VALIDATION,
    ADD_CHECKER,
    UPDATE_CHECKER,
    LOGIN,
} = require("./checker.data");
const {
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../generic-service");

module.exports = describe("Buyer Admin Checkers Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_CHECKER_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER OPERATION
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> CHECKER-LEVELS TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // WAIT FOR CHECKER TO FETCH FROM API
            await sleep(3200);

            // FILL THE FORM
            for (let field of Object.keys(ADD_CHECKER_REQUIRED_VALIDATION)) {
                if (ADD_CHECKER_REQUIRED_VALIDATION[field].choose) {
                    if (ADD_CHECKER_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_CHECKER_REQUIRED_VALIDATION[field].error);
                    }
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_CHECKER_REQUIRED_VALIDATION[field].value
                    );
                    if (ADD_CHECKER_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_CHECKER_REQUIRED_VALIDATION[field].error);
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // WAIT TILL ERRORS LOCATED
            await sleep(1600);

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("DELETE_CHECKER", () => {
        it("For delete checker levels: Should return an Success string", async () => {
            // LOGIN TO FINANCIER OPERATION
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> CHECKER-LEVELS TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // CLICK ON DELETE FACTORING-UNIT -> ANY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete-checker"]'
            );

            // PAUSE FOR WHILE
            await sleep(1600);

            // CLICK ON CONFIRM
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete"]'
            );

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.CHECKER_DELETED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Checker Deleted Successfully");
        });

        describe("ADD_CHECKER", () => {
            it("For invalid input: Should return an Error string", async () => {
                // LOGIN TO FINANCIER OPERATION
                await driver.get(getURL("login"));
                await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
                await findByXPathAndSendKeys(
                    driver,
                    '//input[@id="password"]',
                    LOGIN.password
                );
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // NAVIGATE TO FINANCIER -> CHECKER-LEVELS TAB
                await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
                );

                // WAIT FOR CHECKER TO FETCH FROM API
                await sleep(3200);

                // FILL THE FORM
                for (let field of Object.keys(ADD_CHECKER)) {
                    if (ADD_CHECKER[field].choose) {
                        try {
                            await findByXPathAndClick(
                                driver,
                                `//div[@title="${ADD_CHECKER[field].option}"]`
                            );
                        } catch (error) {
                            await findByXPathAndClick(
                                driver,
                                `//div[@title="Financier Checker Two"]`
                            );
                        }
                    } else {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            ADD_CHECKER[field]
                        );
                    }
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // FORM SUCCESS RESPONSE
                resposne = await findByXPathAndWaitForText(
                    driver,
                    "//div[@class='ant-notification-notice-message']",
                    message.CHECKER_CREATED
                );

                // CHECKING FOR SUCCESS
                expect(resposne).toBe("Checker Created Successfully");
            });
        });

        describe("UPDATE_CHECKER", () => {
            it("For valid update input: Should return an Success string", async () => {
                // LOGIN TO FINANCIER OPERATION
                await driver.get(getURL("login"));
                await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
                await findByXPathAndSendKeys(
                    driver,
                    '//input[@id="password"]',
                    LOGIN.password
                );
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // NAVIGATE TO FINANCIER -> CHECKER-LEVELS TAB
                await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
                );

                // WAIT FOR CHECKER TO FETCH FROM API
                await sleep(3200);

                // CLICK ON UPDATE CHECKER -> ANY
                await findByXPathAndClick(driver, '//button[@name="update-checker"]');

                // FILL THE FORM
                for (let field of Object.keys(UPDATE_CHECKER)) {
                    if (UPDATE_CHECKER[field].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${UPDATE_CHECKER[field].option}"]`
                        );
                    } else {
                        await findByXPathClearAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            UPDATE_CHECKER[field]
                        );
                    }
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // FORM SUCCESS RESPONSE
                resposne = await findByXPathAndWaitForText(
                    driver,
                    "//div[@class='ant-notification-notice-message']",
                    message.CHECKER_UPDATED
                );

                // CHECKING FOR SUCCESS
                expect(resposne).toBe("Checker Updated Successfully");
            });
        });
    });
});
