const LOGIN = {
    email: 'buyer.maker@gmail.com',
    password: 'buyermaker123'
}

const APPROVE_REJECT = {
    remarks: "Factoring Unit Remarks"
}

module.exports = {
    LOGIN: LOGIN,
    APPROVE_REJECT_FU_REQUIRED_VALIDATION: {
        remarks: {
            value: "",
            error: "above field can not be empty!"
        }
    },
    APPROVE_FU: {
        ...APPROVE_REJECT
    },
    REJECT_FU: {
        ...APPROVE_REJECT
    }
}