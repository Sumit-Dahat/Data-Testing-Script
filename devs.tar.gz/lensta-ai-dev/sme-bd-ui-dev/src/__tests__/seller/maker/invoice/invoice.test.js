const path = require("path");
const { getURL, getDriver, sleep } = require("../../config");
const { message } = require("../../message");
const {
    ADD_INVOICE_REQUIRED_VALIDATION,
    ADD_INVOICE_INVALID_VALIDATION,
    ADD_INVOICE,
    UPLOAD_INVOICE,
    UPDATE_INVOICE,
    LOGIN,
} = require("./invoice.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../generic-service");

module.exports = describe("Seller Maker Factoring Units Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_INVOICE_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO SELLER MAKER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> INVOICE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // NAVIGATE TO ADD INVOICE
            await findByXPathAndClick(driver, '//button[@name="add-invoice"]');

            // FILL THE FORM
            for (let field of Object.keys(ADD_INVOICE_REQUIRED_VALIDATION)) {
                if (
                    ADD_INVOICE_REQUIRED_VALIDATION[field].choose ||
                    ["dueDate", "totalAmount"].includes(field)
                ) {
                    if (ADD_INVOICE_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_INVOICE_REQUIRED_VALIDATION[field].error);
                    }
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_INVOICE_REQUIRED_VALIDATION[field].value
                    );
                    if (ADD_INVOICE_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_INVOICE_REQUIRED_VALIDATION[field].error);
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // WAIT TILL ERRORS LOCATED
            await sleep(1600);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_INVOICE_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO SELLER MAKER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> INVOICE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // NAVIGATE TO ADD INVOICE
            await findByXPathAndClick(driver, '//button[@name="add-invoice"]');

            // FILL THE FORM
            for (let field of Object.keys(ADD_INVOICE_INVALID_VALIDATION)) {
                if (
                    ADD_INVOICE_INVALID_VALIDATION[field].choose ||
                    ["dueDate", "totalAmount"].includes(field)
                ) {
                    if (ADD_INVOICE_INVALID_VALIDATION[field].error) {
                        errors.push(ADD_INVOICE_INVALID_VALIDATION[field].error);
                    }
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_INVOICE_INVALID_VALIDATION[field].value
                    );
                    if (ADD_INVOICE_INVALID_VALIDATION[field].error) {
                        errors.push(ADD_INVOICE_INVALID_VALIDATION[field].error);
                    }
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(1600);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_INVOICE", () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO SELLER MAKER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> INVOICE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // NAVIGATE TO ADD INVOICE
            await findByXPathAndClick(driver, '//button[@name="add-invoice"]');

            // FILL THE FORM
            for (let field of Object.keys(ADD_INVOICE)) {
                if (ADD_INVOICE[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_INVOICE[field].option}"]`
                    );
                    // WAIT TILL SELLER TO FETCH FROM API
                    if (field === "buyerName") {
                        await sleep(3200);
                    }
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_INVOICE[field]
                    );
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.INVOICE_CREATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Invoice Created Successfully");
        });
    });

    describe("UPLOAD_INVOICE", () => {
        it("For valid upload input: Should return an Success string", async () => {
            // LOGIN TO SELLER MAKER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> INVOICE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // CLICK ON UPLOAD INVOICE
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="upload-invoice"]'
            );

            // FILL THE FORM
            for (let field of Object.keys(UPLOAD_INVOICE)) {
                if (
                    UPLOAD_INVOICE[field].choose &&
                    ["buyerName", "sellerName"].includes(field)
                ) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_INVOICE[field].option}"]`
                    );
                    // WAIT TILL SELLER TO FETCH FROM API
                    if (field === "buyerName") {
                        await sleep(3200);
                    }
                } else {
                    console.log(path.resolve(__dirname, UPLOAD_INVOICE[field].option));
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        path.resolve(__dirname, UPLOAD_INVOICE[field].option)
                    );
                }
            }

            // WAIT FOR WHILE
            await sleep(1600);

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.DOCUMENT_UPLOADED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Document Uploaded Successfully");
        });
    });

    describe("UPDATE_INVOICE", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO SELLER MAKER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> INVOICE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // CLICK ON UPDATE INVOICE -> ANY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-invoice"]'
            );

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_INVOICE)) {
                if (UPDATE_INVOICE[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${UPDATE_INVOICE[field].option}"]`
                    );
                    // WAIT TILL SELLER TO FETCH FROM API
                    if (field === "buyerName") {
                        await sleep(3200);
                    }
                } else {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        UPDATE_INVOICE[field]
                    );
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.INVOICE_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Invoice Updated Successfully");
        });
    });

    describe("DELETE_INVOICE", () => {
        it("For delete invoice: Should return an Success string", async () => {
            // LOGIN TO SELLER MAKER
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> INVOICE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // CLICK ON DELETE INVOICE -> ANY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete-invoice"]'
            );

            // PAUSE FOR WHILE
            await sleep(1600);

            // CLICK ON CONFIRM
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete"]'
            );

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.INVOICE_DELETED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Invoice Deleted Successfully");
        });
    });
});
