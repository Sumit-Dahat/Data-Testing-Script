const LOGIN = {
    email: "seller.maker@gmail.com",
    password: "sellermaker123",
};

const INVOICE = {
    buyerName: "Larsen & Toubro Limited",
    invoiceNumber: "INV-01",
    invoiceDate: "2023-01-01",
    invoiceAmount: 100000,
    discountAmount: 100,
    taxAmount: 100,
};

module.exports = {
    LOGIN: LOGIN,
    ADD_INVOICE_REQUIRED_VALIDATION: {
        buyerName: {
            choose: true,
            option: undefined,
            error: "Please select one!",
        },
        invoiceNumber: {
            value: "",
            error: "please enter the invoice number!",
        },
        invoiceDate: {
            value: "",
            error: "please select the date!",
        },
        dueDate: {
            value: "",
            error: "please select the date!",
        },
        invoiceAmount: {
            value: "",
            error: "please enter the amount!",
        },
        discountAmount: {
            value: "",
            error: "please enter the amount!",
        },
        taxAmount: {
            value: "",
            error: "please enter the amount!",
        },
        totalAmount: {
            value: "",
            error: "please enter the amount!",
        },
    },
    ADD_INVOICE_INVALID_VALIDATION: {
        buyerName: {
            choose: true,
            option: INVOICE.buyerName,
        },
        invoiceNumber: {
            value: "INV-123@",
            error: "please enter a valid invoice number!",
        },
        invoiceDate: {
            value: "DATE 123@",
            error: undefined,
        },
        invoiceAmount: {
            value: "Z000",
            error: "must be number !",
        },
        discountAmount: {
            value: "Z00",
            error: "must be number !",
        },
        taxAmount: {
            value: "Z00",
            error: "must be number !",
        },
    },
    ADD_INVOICE: {
        ...INVOICE,
        buyerName: {
            choose: true,
            option: INVOICE.buyerName,
        },
    },
    UPLOAD_INVOICE: {
        buyerName: {
            choose: true,
            option: INVOICE.buyerName,
        },
        uploadDocuments: {
            choose: true,
            option: "test.xlsx",
        },
    },
    UPDATE_INVOICE: {
        invoiceDate: "2023-02-02",
        invoiceAmount: 200000,
        discountAmount: 200,
        taxAmount: 200,
    },
    DELETE_INVOICE: {
        type: "delete",
    },
};
