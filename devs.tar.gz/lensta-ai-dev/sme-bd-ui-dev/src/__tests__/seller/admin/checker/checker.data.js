const LOGIN = {
    email: 'mark.doe@gmail.com',
    password: 'markdoe123'
}

const CHECKER = {
    levelName: "Seller Level 1",
    userId: "Seller Checker One"
}


module.exports = {
    LOGIN: LOGIN,
    ADD_CHECKER_REQUIRED_VALIDATION: {
        levelName: {
            value: "",
            error: "above field can not be empty!"
        },
        userId: {
            choose: true,
            option: undefined,
            error: "Please select one!"
        }
    },
    ADD_CHECKER: {
        ...CHECKER,
        userId: {
            choose: true,
            option: CHECKER.userId
        }
    },
    UPDATE_CHECKER: {
        levelName: "Seller Checker Update 1",
    },
    DELETE_CHECKER: {
        type: 'delete'
    }
}