const LOGIN = {
    email: 'mark.doe@gmail.com',
    password: 'markdoe123'
}

const LINK = {
    buyerName: 'Larsen & Toubro Limited',
    creditPeriod: 120,
    extendedCreditPeriod: 100,
    approvedFinance: 'MANUAL',
    acceptPayment: 'MANUAL',
    costBearer: 'SELLER'
}

module.exports = {
    LOGIN: LOGIN,
    ADD_LINK_REQUIRED_VALIDATION: {
        buyerName: {
            choose: true,
            option: null,
            error: "Please select one!"
        },
        creditPeriod: {
            value: "",
            error: "above field can not be empty!"
        },
        extendedCreditPeriod: {
            value: "",
            error: "above field can not be empty!"
        },
        approvedFinance: {
            choose: true,
            option: null,
            error: "Please select one!"
        },
        acceptPayment: {
            choose: true,
            option: null,
            error: "Please select one!"
        },
        costBearer: {
            choose: true,
            option: null,
            error: "Please select one!"
        }
    },
    ADD_LINK_INVALID_VALIDATION: {
        buyerName: {
            choose: true,
            option: LINK.buyerName
        },
        creditPeriod: {
            value: "ZOO",
            error: "must be number!"
        },
        extendedCreditPeriod: {
            value: "ZOO",
            error: "must be number!"
        },
        approvedFinance: {
            choose: true,
            option: LINK.approvedFinance
        },
        acceptPayment: {
            choose: true,
            option: LINK.acceptPayment
        },
        costBearer: {
            choose: true,
            option: LINK.costBearer
        }
    },
    ADD_LINK_COST_BEARER_VALIDATION: {
        costBearer: [
            {
                value: 'SELLER',
                expecting: [
                    {
                        inputId: 'sellerPercent',
                        value: 100
                    },
                    {
                        inputId: 'buyerPercent',
                        value: 0
                    },
                ]
            },
            {
                value: 'BUYER',
                expecting: [
                    {
                        inputId: 'sellerPercent',
                        value: 0
                    },
                    {
                        inputId: 'buyerPercent',
                        value: 100
                    },
                ]
            },
            {
                value: 'PERCENTAGE_SPLIT',
                expecting: [
                    {
                        inputId: 'sellerPercent',
                        value: undefined
                    },
                    {
                        inputId: 'buyerPercent',
                        value: undefined
                    },
                ]
            },
            {
                value: 'PERIODIC_SPLIT',
                expecting: [
                    {
                        inputId: 'splitBuyerSeller',
                        value: undefined
                    },
                    {
                        inputId: 'tillDays',
                        value: undefined
                    }
                ]
            },
        ]
    },
    ADD_LINK: {
        ...LINK,
        buyerName: {
            choose: true,
            option: LINK.buyerName
        },
        approvedFinance: {
            choose: true,
            option: LINK.approvedFinance
        },
        acceptPayment: {
            choose: true,
            option: LINK.acceptPayment
        },
        costBearer: {
            choose: true,
            option: LINK.costBearer
        }
    },
    UPDATE_LINK: {
        creditPeriod: 150,
        extendedCreditPeriod: 120,
    },
    DELETE_LINK: {
        type: 'delete'
    }
}