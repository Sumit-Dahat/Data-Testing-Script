const path = require('path');
const { getURL, getDriver, sleep } = require('../../config');
const { message } = require('../../message');
const {
    ADD_FACTORING_REQUIRED_VALIDATION,
    ADD_FACTORING_INVALID_VALIDATION,
    ADD_FACTORING,
    UPLOAD_FACTORING,
    UPDATE_FACTORING,
    LOGIN
} = require('./factoring-unit.data');
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick
} = require('../../generic-service');

module.exports = describe('Financier Factoring Units Tests', () => {

    let driver, resposne, error, errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL('login'));
    });

    afterEach(async () => {
        await driver.quit();
    });
    describe('ADD_FACTORING_REQUIRED_VALIDATION', () => {

        it('For empty input: Should return an Error string', async () => {


            // LOGIN TO SELLER
            await driver.get(getURL('login'));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(driver, '//input[@id="password"]', LOGIN.password);
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> FACTORING-UNIT TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]")

            // NAVIGATE TO ADD FACTORING-UNIT
            await findByXPathAndClick(driver, '//button[@name="add-factoring"]');

            // FILL THE FORM
            for (let field of Object.keys(ADD_FACTORING_REQUIRED_VALIDATION)) {
                if (ADD_FACTORING_REQUIRED_VALIDATION[field].choose || ['dueDate', 'totalAmount'].includes(field)) {
                    if (ADD_FACTORING_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_FACTORING_REQUIRED_VALIDATION[field].error)
                    }
                }
                else {
                    await findByXPathAndSendKeys(driver, `//input[@id="${field}"]`, ADD_FACTORING_REQUIRED_VALIDATION[field].value);
                    if (ADD_FACTORING_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_FACTORING_REQUIRED_VALIDATION[field].error)
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // WAIT TILL ERRORS LOCATED
            await sleep(1600)

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(driver, "//div[@class='ant-form-item-explain-error']");


            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        })
    })


    describe('ADD_FACTORING_INVALID_VALIDATION', () => {

        it('For invalid input: Should return an Error string', async () => {


            // LOGIN TO SELLER
            await driver.get(getURL('login'));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(driver, '//input[@id="password"]', LOGIN.password);
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> FACTORING-UNIT TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]")

            // NAVIGATE TO ADD FACTORING-UNIT
            await findByXPathAndClick(driver, '//button[@name="add-factoring"]');

            // FILL THE FORM
            for (let field of Object.keys(ADD_FACTORING_INVALID_VALIDATION)) {
                if (ADD_FACTORING_INVALID_VALIDATION[field].choose || ['dueDate', 'totalAmount'].includes(field)) {
                    if (ADD_FACTORING_INVALID_VALIDATION[field].error) {
                        errors.push(ADD_FACTORING_INVALID_VALIDATION[field].error)
                    }
                }
                else {
                    await findByXPathAndSendKeys(driver, `//input[@id="${field}"]`, ADD_FACTORING_INVALID_VALIDATION[field].value);
                    if (ADD_FACTORING_INVALID_VALIDATION[field].error) {
                        errors.push(ADD_FACTORING_INVALID_VALIDATION[field].error)
                    }
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(1600)

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(driver, "//div[@class='ant-form-item-explain-error']");

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        })
    })


    describe('ADD_FACTORING', () => {

        it('For valid input: Should return an Success string', async () => {

            // LOGIN TO SELLER
            await driver.get(getURL('login'));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(driver, '//input[@id="password"]', LOGIN.password);
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> FACTORING-UNIT TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]")

            // NAVIGATE TO ADD FACTORING-UNIT
            await findByXPathAndClick(driver, '//button[@name="add-factoring"]');

            // FILL THE FORM
            for (let field of Object.keys(ADD_FACTORING)) {
                if (ADD_FACTORING[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`)
                    await findByXPathAndClick(driver, `//div[@title="${ADD_FACTORING[field].option}"]`)
                    // WAIT TILL SELLER TO FETCH FROM API
                    if (field === 'buyerName') {
                        await sleep(3200)
                    }
                }
                else {
                    await findByXPathAndSendKeys(driver, `//input[@id="${field}"]`, ADD_FACTORING[field])
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(driver, "//div[@class='ant-notification-notice-message']", message.FACTORING_CREATED)


            // CHECKING FOR SUCCESS
            expect(resposne).toBe('FactoringUnit Created Successfully');
        })
    })



    describe('UPLOAD_FACTORING', () => {

        it('For valid upload input: Should return an Success string', async () => {


            // LOGIN TO SELLER
            await driver.get(getURL('login'));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(driver, '//input[@id="password"]', LOGIN.password);
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> FACTORING-UNIT TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]")

            // CLICK ON UPLOAD FACTORING
            await findByXPathAndWaitForLocatedAndClick(driver, '//button[@name="upload-factoring"]');

            // FILL THE FORM
            for (let field of Object.keys(UPLOAD_FACTORING)) {
                if (UPLOAD_FACTORING[field].choose && ['buyerName', 'sellerName'].includes(field)) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`)
                    await findByXPathAndClick(driver, `//div[@title="${ADD_FACTORING[field].option}"]`)
                    // WAIT TILL SELLER TO FETCH FROM API
                    if (field === 'buyerName') {
                        await sleep(3200)
                    }
                }
                else {
                    console.log(path.resolve(__dirname, UPLOAD_FACTORING[field].option))
                    await findByXPathAndSendKeys(driver, `//input[@id="${field}"]`, path.resolve(__dirname, UPLOAD_FACTORING[field].option));
                }
            }

            // WAIT FOR WHILE
            await sleep(1600);

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(driver, "//div[@class='ant-notification-notice-message']", message.DOCUMENT_UPLOADED)


            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Document Uploaded Successfully");
        })
    })


    describe('UPDATE_FACTORING', () => {

        it('For valid update input: Should return an Success string', async () => {


            // LOGIN TO SELLER
            await driver.get(getURL('login'));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(driver, '//input[@id="password"]', LOGIN.password);
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> FACTORING-UNIT TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]")

            // CLICK ON UPDATE FACTORING -> ANY
            await findByXPathAndWaitForLocatedAndClick(driver, '//button[@name="update-factoring"]');

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_FACTORING)) {
                if (UPDATE_FACTORING[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`)
                    await findByXPathAndClick(driver, `//div[@title="${UPDATE_FACTORING[field].option}"]`)
                    // WAIT TILL SELLER TO FETCH FROM API
                    if (field === 'buyerName') {
                        await sleep(3200)
                    }
                }
                else {
                    await findByXPathClearAndSendKeys(driver, `//input[@id="${field}"]`, UPDATE_FACTORING[field])
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(driver, "//div[@class='ant-notification-notice-message']", message.FACTORING_UPDATED)


            // CHECKING FOR SUCCESS
            expect(resposne).toBe("FactoringUnit Updated Successfully");
        })
    })

    describe('DELETE_FACTORING', () => {

        it('For delete factoring unit: Should return an Success string', async () => {


            // LOGIN TO SELLER
            await driver.get(getURL('login'));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(driver, '//input[@id="password"]', LOGIN.password);
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO SELLER -> FACTORING-UNIT TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]")

            // CLICK ON DELETE FACTORING-UNIT -> ANY
            await findByXPathAndWaitForLocatedAndClick(driver, '//button[@name="delete-factoringUnit"]');

            // PAUSE FOR WHILE
            await sleep(1600)

            // CLICK ON CONFIRM
            await findByXPathAndWaitForLocatedAndClick(driver, '//button[@name="delete"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(driver, "//div[@class='ant-notification-notice-message']", message.FACTORING_DELETED)


            // CHECKING FOR SUCCESS
            expect(resposne).toBe("FactoringUnit Deleted Successfully");
        })
    })
});