const { getURL, getDriver, sleep, sleepEvents } = require("../../../config");
const { message } = require("../../../message");
const {
    ADD_FINANCIER_REQUIRED_VALIDATION,
    ADD_FINANCIER_INVALID_VALIDATION,
    ADD_FINANCIER_PASSWORD_VALIDATION,
    ADD_FINANCIER,
    UPDATE_FINANCIER,
    UPDATE_FINANCIER_STATUS,
    LOGIN,
} = require("./financier.data");
const {
    findByXPathAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findAllByXPathAndWaitForLocated,
    findByXPathAndWaitForLocatedAndClick,
    findByXPathClearAndSendKeys,
} = require("../../../generic-service");

module.exports = describe("Platform Operation Financier Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_FINANCIER_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO PLATFORM ADMIN
            for (let field of Object.keys(LOGIN)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN[field]
                );
            }
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // NAVIGATE TO ADD FINANCIER
            await findByXPathAndClick(driver, '//button[@name="add-financier"]');

            // FILL THE FINANCIER FORM
            for (let key of Object.keys(ADD_FINANCIER_REQUIRED_VALIDATION)) {
                for (let field of Object.keys(ADD_FINANCIER_REQUIRED_VALIDATION[key])) {
                    if (ADD_FINANCIER_REQUIRED_VALIDATION[key][field].choose) {
                        if (ADD_FINANCIER_REQUIRED_VALIDATION[key][field].error) {
                            errors.push(
                                ADD_FINANCIER_REQUIRED_VALIDATION[key][field].error
                            );
                        }
                    } else {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            ADD_FINANCIER_REQUIRED_VALIDATION[key][field].value
                        );
                        if (ADD_FINANCIER_REQUIRED_VALIDATION[key][field].error) {
                            errors.push(
                                ADD_FINANCIER_REQUIRED_VALIDATION[key][field].error
                            );
                        }
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // WAIT FOR A WHILE
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_FINANCIER_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO PLATFORM ADMIN
            for (let field of Object.keys(LOGIN)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN[field]
                );
            }
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // NAVIGATE TO ADD FINANCIER
            await findByXPathAndClick(driver, '//button[@name="add-financier"]');

            // FILL THE FINANCIER FORM
            for (let key of Object.keys(ADD_FINANCIER_INVALID_VALIDATION)) {
                for (let field of Object.keys(ADD_FINANCIER_INVALID_VALIDATION[key])) {
                    if (ADD_FINANCIER_INVALID_VALIDATION[key][field].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${ADD_FINANCIER_INVALID_VALIDATION[key][field].option}"]`
                        );
                    } else {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            ADD_FINANCIER_INVALID_VALIDATION[key][field].value
                        );
                        if (ADD_FINANCIER_INVALID_VALIDATION[key][field].error) {
                            errors.push(
                                ADD_FINANCIER_INVALID_VALIDATION[key][field].error
                            );
                        }
                    }
                }
            }

            // WAIT FOR A WHILE
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_FINANCIER_PASSWORD_VALIDATION", () => {
        it("For invalid password input: Should return an Error string", async () => {
            // LOGIN TO PLATFORM ADMIN
            for (let field of Object.keys(LOGIN)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN[field]
                );
            }
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // NAVIGATE TO ADD FINANCIER
            await findByXPathAndClick(driver, '//button[@name="add-financier"]');

            // FILL THE USER FORM I.E PASSWORDS & REPASSWORD
            await findByXPathAndSendKeys(
                driver,
                `//input[@id="password"]`,
                ADD_FINANCIER_PASSWORD_VALIDATION.password.value
            );
            await findByXPathAndSendKeys(
                driver,
                `//input[@id="repassword"]`,
                ADD_FINANCIER_PASSWORD_VALIDATION.repassword.value
            );

            // FORM ERRORS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-form-item-explain-error']",
                ADD_FINANCIER_PASSWORD_VALIDATION.repassword.error
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Passwords do not match!");
        });
    });

    describe.skip("ADD_FINANCIER", () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO PLATFORM ADMIN
            for (let field of Object.keys(LOGIN)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN[field]
                );
            }
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // NAVIGATE TO ADD FINANCIER
            await findByXPathAndClick(driver, '//button[@name="add-financier"]');

            // FILL THE FINANCIER FORM
            for (let key of Object.keys(ADD_FINANCIER)) {
                for (let field of Object.keys(ADD_FINANCIER[key])) {
                    if (ADD_FINANCIER[key][field].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${ADD_FINANCIER[key][field].option}"]`
                        );
                    } else {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            ADD_FINANCIER[key][field]
                        );
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.FINANCIER_CREATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Financier Created Successfully");
        });
    });

    describe("UPDATE_FINANCIER", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO PLATFORM ADMIN
            for (let field of Object.keys(LOGIN)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN[field]
                );
            }
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // CLICK ON UPDATE FINANCIER
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-financier"]'
            );

            // WAIT FOR A WHILE
            await sleep(sleepEvents.loading);

            // FILL THE FINANCIER FORM
            for (let key of Object.keys(UPDATE_FINANCIER)) {
                for (let field of Object.keys(UPDATE_FINANCIER[key])) {
                    if (UPDATE_FINANCIER[key][field].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${UPDATE_FINANCIER[key][field].option}"]`
                        );
                    } else {
                        await findByXPathClearAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            UPDATE_FINANCIER[key][field]
                        );
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.FINANCIER_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Financier Updated Successfully");
        });
    });

    describe("UPDATE_FINANCIER_STATUS", () => {
        it("For fianncier status update: Should return an Success string", async () => {
            // EXPECTED ACTION TO UPDATE STATUS
            expect(UPDATE_FINANCIER_STATUS.type).toBe("status");

            // LOGIN TO PLATFORM ADMIN
            for (let field of Object.keys(LOGIN)) {
                await findByXPathAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    LOGIN[field]
                );
            }
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");

            // WAIT FOR LOGIN MESSAGE TO DISAPPEAR [NEXT MESSAGE WILL BE APPEAR]
            await sleep(sleepEvents.notificationLoading);

            // DEACTIVATE FINANCIER USER STATUS
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-status"]'
            );

            // DEACTIVATE SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.UPDATE_STATUS
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Status Updated Successfully");

            // WAIT FOR DEACTIVATE MESSAGE TO DISAPPEAR
            await sleep(sleepEvents.notificationLoading);

            // AGAIN ACTIVATE -> BACK TO NORMAL STAGE FINANCIER USER STATUS
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-status"][@class="ant-switch css-dev-only-do-not-override-1lrvbbg"]'
            );

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.UPDATE_STATUS
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Status Updated Successfully");
        });
    });
});
