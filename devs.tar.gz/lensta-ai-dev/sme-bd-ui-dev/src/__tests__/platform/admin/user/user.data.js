const LOGIN = {
    email: "platform.admin@gmail.com",
    password: "platformadmin123",
};

const USER = {
    userType: "Operation Manager",
    name: "operation one",
    dob: new Date().toISOString().slice(0, 10),
    emailId: "operation.one@gmail.com",
    mobileNo: "9856784545",
    password: "operationone123",
    repassword: "operationone123",
};

module.exports = {
    LOGIN: LOGIN,
    ADD_USER_REQUIRED_VALIDATION: {
        userType: {
            choose: true,
            option: null,
            error: "Please select one!",
        },
        name: {
            value: "",
            error: "above field can not be empty!",
        },
        emailId: {
            value: "",
            error: "please enter the email id!",
        },
        mobileNo: {
            value: "",
            error: "please enter the mobile number!",
        },
        password: {
            value: "",
            error: "please enter the password!",
        },
        repassword: {
            value: "",
            error: "Please confirm the password!",
        },
    },
    ADD_USER_INVALID_VALIDATION: {
        userType: {
            choose: true,
            option: USER.userType,
        },
        name: {
            value: "User123",
            error: "only aplhabets required!",
        },
        emailId: {
            value: "123mail.com",
            error: "enter a valid email id!",
        },
        mobileNo: {
            value: "123",
            error: "please enter the valid mobile number!",
        },
        password: {
            value: "123",
            error: "minimum 8 characters required!",
        },
        repassword: {
            value: "123",
            error: "minimum 8 characters required!",
        },
    },
    ADD_USER_PASSWORD_VALIDATION: {
        password: {
            value: "123456789",
            error: "",
        },
        repassword: {
            value: "12345678910",
            error: "Passwords do not match!",
        },
    },
    ADD_USER: {
        ...USER,
        userType: {
            choose: true,
            option: USER.userType,
        },
    },
    UPDATE_USER: {
        dob: new Date().toISOString().slice(0, 10),
        mobileNo: "7845209861",
    },
    UPDATE_USER_STATUS: {
        type: "status",
    },
};
