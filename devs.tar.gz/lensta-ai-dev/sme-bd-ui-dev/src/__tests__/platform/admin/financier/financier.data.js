const LOGIN = {
    email: "platform.admin@gmail.com",
    password: "platformadmin123",
};

const FINANCIER = {
    entityDetails: {
        entityName: "admin financier",
        registrationNumber: "871289129859",
        panNumber: "GREIV9817K",
        gstinNumber: "96YJAKN3985P3Z2",
        udyamNumber: "UDYAM-TN-35-7612082",
        incorporationDate: new Date().toISOString().slice(0, 10),
    },
    adminDetails: {
        adminName: "admin financier",
        mobileNo: "9876543212",
        email: "admin.financier@gmail.com",
        password: "adminfinancier123",
        repassword: "adminfinancier123",
    },
    approvalDetails: {
        expiryDate: new Date().toISOString().slice(0, 10),
        approvalType: "Trial",
    },
};

module.exports = {
    LOGIN: LOGIN,
    ADD_FINANCIER_REQUIRED_VALIDATION: {
        entityDetails: {
            entityName: {
                value: "",
                error: "above field can not be empty!",
            },
            registrationNumber: {
                value: "",
                error: "above field can not be empty!",
            },
            panNumber: {
                value: "",
                error: "please enter the PAN number!",
            },
            incorporationDate: {
                value: "",
                error: "please select the date!",
            },
        },
        adminDetails: {
            adminName: {
                value: "",
                error: "above field can not be empty!",
            },
            mobileNo: {
                value: "",
                error: "please enter the mobile number!",
            },
            email: {
                value: "",
                error: "please enter the email id!",
            },
            password: {
                value: "",
                error: "please enter the password!",
            },
            repassword: {
                value: "",
                error: "Please confirm the password!",
            },
        },
    },
    ADD_FINANCIER_INVALID_VALIDATION: {
        entityDetails: {
            entityName: {
                value: "Entity123",
                error: "only aplhabets required!",
            },
            registrationNumber: {
                value: "regis 123@",
                error: "Please enter a valid input!",
            },
            panNumber: {
                value: "PAN123",
                error: "enter a valid PAN number, must be 10 characters !",
            },
            gstinNumber: {
                value: "GST123",
                error: "please enter a valid gst number!",
            },
            udyamNumber: {
                value: "UDYAM123",
                error: "enter your 19 digit UDYAM registration number (i.e. UDYAM-XX-00-0000000)!",
            },
        },
        adminDetails: {
            adminName: {
                value: "Admin123",
                error: "only aplhabets required!",
            },
            mobileNo: {
                value: "123",
                error: "please enter the valid mobile number!",
            },
            email: {
                value: "123mail.com",
                error: "enter a valid email id!",
            },
            password: {
                value: "123",
                error: "minimum 8 characters required!",
            },
            repassword: {
                value: "123",
                error: "minimum 8 characters required!",
            },
        },
    },
    ADD_FINANCIER_PASSWORD_VALIDATION: {
        password: {
            value: "123456789",
            error: "",
        },
        repassword: {
            value: "12345678910",
            error: "Passwords do not match!",
        },
    },
    ADD_FINANCIER: {
        approvalDetails: {
            ...FINANCIER.approvalDetails,
            approvalType: {
                choose: true,
                option: FINANCIER.approvalDetails.approvalType,
            },
        },
        ...FINANCIER,
    },
    UPDATE_FINANCIER: {
        entityDetails: {
            registrationNumber: "821289129851",
        },
        adminDetails: {
            mobileNo: "7864523987",
        },
    },
    UPDATE_FINANCIER_STATUS: {
        type: "status",
    },
};
