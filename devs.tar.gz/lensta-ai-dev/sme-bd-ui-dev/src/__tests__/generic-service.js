var os = require('os');
const { By, until, Key } = require('selenium-webdriver');
const { sleep } = require('./config');

module.exports.findByXPath = async (driver, pattern) => {
    return await driver.findElement(By.xpath(pattern));
}

module.exports.findByXPathAndGetText = async (driver, pattern) => {
    return await driver.findElement(By.xpath(pattern)).getText();
}

module.exports.findByXPathAndClick = async (driver, pattern) => {
    return await (await driver.findElement(By.xpath(pattern))).click();
}

module.exports.findByXPathAndSendKeys = async (driver, pattern, keys) => {
    return await driver.findElement(By.xpath(pattern)).sendKeys(keys);
}

module.exports.findByXPathClearAndSendKeys = async (driver, pattern, keys) => {
    const element = await driver.findElement(By.xpath(pattern));
    element.sendKeys(Key.HOME, Key.chord(Key.SHIFT, Key.END), keys)
}

module.exports.findByXPathClear = async (driver, pattern) => {
    const element = await driver.findElement(By.xpath(pattern));
    if (os.platform() === 'darwin') {
        element.sendKeys(Key.COMMAND, "a")
        element.sendKeys(Key.DELETE)
    }
    else {
        element.sendKeys(Key.chord(Key.CONTROL, "a", Key.DELETE))
    }
}

module.exports.findByXPathAndWaitForLocated = async (driver, pattern, time = 30000) => {
    return await driver.wait(until.elementLocated(By.xpath(pattern)), time);
}

module.exports.findAllByXPathAndWaitForLocated = async (driver, pattern, time = 30000) => {
    return await driver.wait(until.elementsLocated(By.xpath(pattern)), time);
}

module.exports.findByXPathAndWaitForLocatedAndClick = async (driver, pattern, time = 30000) => {
    return await driver.wait(until.elementLocated(By.xpath(pattern)), time).click();
}

module.exports.findByXPathAndWaitForLocatedAndText = async (driver, pattern) => {
    const element = await (await driver.wait(until.elementLocated(By.xpath(pattern)))).getText();
    console.log(element)
    return element
}

module.exports.findByXPathAndWaitForText = async (driver, pattern, message, time = 30000) => {
    return await driver.wait(until.elementTextIs(driver.wait(until.elementLocated(By.xpath(pattern))), message), time).getText();
}