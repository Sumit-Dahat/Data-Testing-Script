const { Builder } = require('selenium-webdriver');
require('chromedriver');

module.exports.sleepEvents = {
    loading:2500,
    apiLoading:5000,
    optionsLoading: 2500,
    notificationLoading:5000
}

module.exports.getDriver = async () => {
    const driver = await new Builder().forBrowser('chrome').build();
    await driver.manage().window().maximize();
    return driver;
}

module.exports.sleep = ms => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports.getURL = (url) => {
    return "http://localhost:3000/" + url;
} 