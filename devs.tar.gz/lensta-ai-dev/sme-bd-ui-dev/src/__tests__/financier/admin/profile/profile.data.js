const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const UPDATE_PROFILE = {
    entityDetails: {
        entityName: "test profile",
        registrationNumber: "871229829821",
        panNumber: "GRXIV9812K",
        gstinNumber: "29BISVK4165T1ZN",
        udyamNumber: "UDYAM-TN-35-8712781",
        incorporationDate: "2023-01-01",
    },
    adminDetails: {
        mobileNo: "8491673495",
    },
};

module.exports = {
    LOGIN: LOGIN,
    UPDATE_PROFILE_REQUIRED_VALIDATION: {
        entityDetails: {
            registrationNumber: {
                value: "",
                error: "above field can not be empty!",
            },
        },
        adminDetails: {
            adminName: {
                value: "",
                error: "above field can not be empty!",
            },
            mobileNo: {
                value: "",
                error: "please enter the mobile number!",
            },
            email: {
                value: "",
                error: "please enter the email id!",
            },
            password: {
                value: "",
                error: "please enter the password!",
            },
            repassword: {
                value: "",
                error: "Please confirm the password!",
            },
        },
    },
    UPDATE_PROFILE_INVALID_VALIDATION: {
        entityDetails: {
            registrationNumber: {
                value: "regis 123@",
                error: "Please enter a valid input!",
            },
        },
        adminDetails: {
            adminName: {
                value: "test profile 123",
                error: "only aplhabets required!",
            },
            mobileNo: {
                value: "123",
                error: "please enter the valid mobile number!",
            },
            email: {
                value: "123mail.com",
                error: "enter a valid email id!",
            },
            password: {
                value: "123",
                error: "minimum 8 characters required!",
            },
            repassword: {
                value: "123",
                error: "minimum 8 characters required!",
            },
        },
    },
    UPDATE_PROFILE_PASSWORD_VALIDATION: {
        password: {
            value: "123456789",
            error: "",
        },
        repassword: {
            value: "12345678910",
            error: "Passwords do not match!",
        },
    },
    UPDATE_PROFILE: {
        entityDetails: {
            registrationNumber: UPDATE_PROFILE.entityDetails.registrationNumber,
        },
        adminDetails: {
            mobileNo: UPDATE_PROFILE.adminDetails.mobileNo,
        },
    },
};
