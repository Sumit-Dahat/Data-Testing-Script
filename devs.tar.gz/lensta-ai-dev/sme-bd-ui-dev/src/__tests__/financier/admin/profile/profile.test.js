const { getURL, getDriver, sleep, sleepEvents } = require("../../../config");
const { message } = require("../../../message");
const {
    UPDATE_PROFILE_REQUIRED_VALIDATION,
    UPDATE_PROFILE_INVALID_VALIDATION,
    UPDATE_PROFILE_PASSWORD_VALIDATION,
    UPDATE_PROFILE,
    LOGIN,
} = require("./profile.data");
const {
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findAllByXPathAndWaitForLocated,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../../generic-service");

module.exports = describe("Financier Admin Profile Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe.skip("UPDATE_PROFILE_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> PROFILE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_PROFILE_REQUIRED_VALIDATION)) {
                for (let key of Object.keys(UPDATE_PROFILE_REQUIRED_VALIDATION[field])) {
                    if (UPDATE_PROFILE_REQUIRED_VALIDATION[field][key].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${UPDATE_PROFILE_REQUIRED_VALIDATION[field].option}"]`
                        );
                    } else {
                        await findByXPathClearAndSendKeys(
                            driver,
                            `//input[@id="${key}"]`,
                            UPDATE_PROFILE_REQUIRED_VALIDATION[field][key].value
                        );
                        errors.push(UPDATE_PROFILE_REQUIRED_VALIDATION[field][key].error);
                    }
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("UPDATE_PROFILE_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> PROFILE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_PROFILE_INVALID_VALIDATION)) {
                for (let key of Object.keys(UPDATE_PROFILE_INVALID_VALIDATION[field])) {
                    if (UPDATE_PROFILE_INVALID_VALIDATION[field][key].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${UPDATE_PROFILE_INVALID_VALIDATION[field].option}"]`
                        );
                    } else {
                        await findByXPathClearAndSendKeys(
                            driver,
                            `//input[@id="${key}"]`,
                            UPDATE_PROFILE_INVALID_VALIDATION[field][key].value
                        );
                        errors.push(UPDATE_PROFILE_INVALID_VALIDATION[field][key].error);
                    }
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("UPDATE_PROFILE_PASSWORD_VALIDATION", () => {
        it("For invalid password input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> PROFILE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.apiLoading);

            // FILL THE FORM I.E PASSWORDS & REPASSWORD
            await findByXPathClearAndSendKeys(
                driver,
                `//input[@id="password"]`,
                UPDATE_PROFILE_PASSWORD_VALIDATION.password.value
            );
            await findByXPathClearAndSendKeys(
                driver,
                `//input[@id="repassword"]`,
                UPDATE_PROFILE_PASSWORD_VALIDATION.repassword.value
            );

            // FORM ERRORS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-form-item-explain-error']",
                UPDATE_PROFILE_PASSWORD_VALIDATION.repassword.error
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Passwords do not match!");
        });
    });

    describe("UPDATE_PROFILE", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> PROFILE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[5]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_PROFILE)) {
                for (let key of Object.keys(UPDATE_PROFILE[field])) {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//input[@id="${key}"]`,
                        UPDATE_PROFILE[field][key]
                    );
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.PROFILE_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Profile Updated Successfully");
        });
    });
});
