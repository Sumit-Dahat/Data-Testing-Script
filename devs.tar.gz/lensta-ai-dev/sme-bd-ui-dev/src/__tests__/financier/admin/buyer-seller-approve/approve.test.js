const { getURL, getDriver, sleep, sleepEvents } = require("../../../config");
const { message } = require("../../../message");
const {
    APPROVE_BUYER_SELLER_REQUIRED_VALIDATION,
    APPROVE_BUYER_SELLER_INVALID_VALIDATION,
    APPROVE_BUYER_SELLER,
    LOGIN,
} = require("./approve.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../../generic-service");

module.exports = describe("Financier Admin Buyer-Seller Approve Tests", () => {
    let driver,
        response,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("APPROVE_BUYER_SELLER_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[4]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            try {
                // CLICK ON APPROVE ENTITY -> ANY
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    '//button[@name="approve-entity"]',
                    sleepEvents.loading
                );

                // NAVIGATE TO APPROVE BUYER-SELLER TAB
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    "//div[@class='ant-tabs-nav-list']/div[6]"
                );

                // FILL THE FORM
                for (let field of Object.keys(APPROVE_BUYER_SELLER_REQUIRED_VALIDATION)) {
                    try {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            APPROVE_BUYER_SELLER_REQUIRED_VALIDATION[field].value
                        );
                        errors.push(
                            APPROVE_BUYER_SELLER_REQUIRED_VALIDATION[field].error
                        );
                    } catch {
                        await findByXPathAndSendKeys(
                            driver,
                            `//textarea[@id="${field}"]`,
                            APPROVE_BUYER_SELLER_REQUIRED_VALIDATION[field].value
                        );
                        errors.push(
                            APPROVE_BUYER_SELLER_REQUIRED_VALIDATION[field].error
                        );
                    }
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // WAIT TILL ERRORS LOCATED
                await sleep(sleepEvents.loading);

                // FORM ERRORS RESPONSE
                response = await findAllByXPathAndWaitForLocated(
                    driver,
                    "//div[@class='ant-form-item-explain-error']"
                );

                // CHECKING FOR ERROR EXIST
                expect(response).toHaveLength(errors.length);

                for (let index = 0; index < response.length; index++) {
                    error = await response[index].getText();
                    expect(errors).toContain(error);
                    errors.splice(errors.indexOf(error), 1);
                }

                expect(errors).toHaveLength(0);
            } catch {
                console.log(
                    `buyer-seller doesn't exist at financier.approve-buyer-seller.test.js [APPROVE_BUYER_SELLER_REQUIRED_VALIDATION]`
                );
            }
        });
    });

    describe("APPROVE_BUYER_SELLER_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[4]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            try {
                // CLICK ON APPROVE ENTITY -> ANY
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    '//button[@name="approve-entity"]',
                    sleepEvents.loading
                );

                // NAVIGATE TO APPROVE BUYER-SELLER TAB
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    "//div[@class='ant-tabs-nav-list']/div[6]"
                );

                // FILL THE FORM
                for (let field of Object.keys(APPROVE_BUYER_SELLER_INVALID_VALIDATION)) {
                    try {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            APPROVE_BUYER_SELLER_INVALID_VALIDATION[field].value
                        );
                        errors.push(APPROVE_BUYER_SELLER_INVALID_VALIDATION[field].error);
                    } catch {
                        await findByXPathAndSendKeys(
                            driver,
                            `//textarea[@id="${field}"]`,
                            APPROVE_BUYER_SELLER_INVALID_VALIDATION[field].value
                        );
                        errors.push(APPROVE_BUYER_SELLER_INVALID_VALIDATION[field].error);
                    }
                }

                // WAIT TILL ERRORS LOCATED
                await sleep(sleepEvents.loading);

                // FORM ERRORS RESPONSE
                response = await findAllByXPathAndWaitForLocated(
                    driver,
                    "//div[@class='ant-form-item-explain-error']"
                );

                // CHECKING FOR ERROR EXIST
                expect(response).toHaveLength(errors.length);
                error = await response[0].getText();
                expect(error).toBe("must be number!");
            } catch {
                console.log(
                    `buyer-seller doesn't exist at financier.approve-buyer-seller.test.js [APPROVE_BUYER_SELLER_REQUIRED_VALIDATION]`
                );
            }
        });
    });

    describe("APPROVE_BUYER_SELLER", () => {
        it("APPROVE_BUYER_SELLER", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[4]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            try {
                // CLICK ON APPROVE ENTITY -> ANY
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    '//button[@name="approve-entity"]',
                    sleepEvents.loading
                );

                // NAVIGATE TO APPROVE BUYER-SELLER TAB
                await findByXPathAndWaitForLocatedAndClick(
                    driver,
                    "//div[@class='ant-tabs-nav-list']/div[6]"
                );

                // FILL THE FORM
                for (let field of Object.keys(APPROVE_BUYER_SELLER)) {
                    try {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            APPROVE_BUYER_SELLER[field]
                        );
                    } catch {
                        await findByXPathAndSendKeys(
                            driver,
                            `//textarea[@id="${field}"]`,
                            APPROVE_BUYER_SELLER[field]
                        );
                    }
                }

                // WAIT FOR WHILE
                await sleep(sleepEvents.loading);

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // FORM SUCCESS RESPONSE
                response = await findByXPathAndWaitForText(
                    driver,
                    "//div[@class='ant-notification-notice-message']",
                    message.BUYER_SELLER_APPROVED
                );

                // CHECKING FOR SUCCESS
                expect(response).toBe("BuyerSeller Approved Successfully");
            } catch {
                console.log(
                    `buyer-seller doesn't exist at financier.approve-buyer-seller.test.js [APPROVE_BUYER_SELLER_REQUIRED_VALIDATION]`
                );
            }
        });
    });
});
