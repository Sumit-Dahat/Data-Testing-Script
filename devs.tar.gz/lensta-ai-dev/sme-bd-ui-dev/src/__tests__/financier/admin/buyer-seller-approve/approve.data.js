const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const SANCTIONED_LIMIT = {
    sanctionedLimit: 200000,
    remarks: "Approving buyer seller",
};

module.exports = {
    LOGIN: LOGIN,
    APPROVE_BUYER_SELLER_REQUIRED_VALIDATION: {
        sanctionedLimit: {
            value: "",
            error: "above field can not be empty!",
        },
        remarks: {
            value: "",
            error: "above field can not be empty!",
        },
    },
    APPROVE_BUYER_SELLER_INVALID_VALIDATION: {
        sanctionedLimit: {
            value: "Z00000",
            error: "must be a number!",
        },
    },
    APPROVE_BUYER_SELLER: {
        sanctionedLimit: SANCTIONED_LIMIT.sanctionedLimit + 10000,
        remarks: "Approving buyer seller update",
    },
};
