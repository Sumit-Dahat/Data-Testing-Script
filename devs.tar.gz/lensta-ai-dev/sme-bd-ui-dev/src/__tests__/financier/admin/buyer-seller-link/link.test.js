const { getURL, getDriver, sleep, sleepEvents } = require("../../../config");
const { message } = require("../../../message");
const {
    ADD_LINK_REQUIRED_VALIDATION,
    ADD_LINK_INVALID_VALIDATION,
    ADD_LINK_COST_BEARER_VALIDATION,
    ADD_LINK,
    UPDATE_LINK,
    LOGIN,
} = require("./link.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
    findByXPath,
} = require("../../../generic-service");

module.exports = describe("Financier Admin Buyer-Seller Link Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_LINK_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> BUYER-SELLER LINK TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-link"]');

            // FILL THE FORM
            for (let field of Object.keys(ADD_LINK_REQUIRED_VALIDATION)) {
                if (ADD_LINK_REQUIRED_VALIDATION[field].choose) {
                    // await findByXPathAndClick(driver, `//div[@id='${field}']//input[@value="MANUAL"]`)
                    errors.push(ADD_LINK_REQUIRED_VALIDATION[field].error);
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_LINK_REQUIRED_VALIDATION[field].value
                    );
                    errors.push(ADD_LINK_REQUIRED_VALIDATION[field].error);
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_LINK_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> BUYER-SELLER LINK TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-link"]');

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            // FILL THE FORM
            for (let field of Object.keys(ADD_LINK_INVALID_VALIDATION)) {
                if (ADD_LINK_INVALID_VALIDATION[field].choose) {
                    if (field === "buyerName" || field === "sellerName") {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${ADD_LINK_INVALID_VALIDATION[field].option}"]`
                        );
                        // WAIT TILL SELLER TO FETCH FROM API
                        if (field === "buyerName") {
                            await sleep(sleepEvents.optionsLoading);
                        }
                    } else {
                        await findByXPathAndClick(
                            driver,
                            `//div[@id="${field}"]//input[@value="${ADD_LINK_INVALID_VALIDATION[field].option}"]`
                        );
                    }
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_LINK_INVALID_VALIDATION[field].value
                    );
                    errors.push(ADD_LINK_INVALID_VALIDATION[field].error);
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_LINK_COST_BEARER_VALIDATION", () => {
        it("For cost bearer validation", async () => {
            // LOGIN TO FINANCIER ADMIN
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> BUYER-SELLER LINK TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-link"]');

            // FILL THE FORM
            const fieldName = Object.keys(ADD_LINK_COST_BEARER_VALIDATION).find(
                (key) => key === "costBearer"
            );

            if (fieldName === undefined) {
                console.log(
                    `costBearer key error at financier-admin.link.test.js [ADD_LINK_COST_BEARER_VALIDATION]`
                );
                return;
            }

            for (let field of ADD_LINK_COST_BEARER_VALIDATION[fieldName]) {
                await findByXPathAndClick(
                    driver,
                    `//div[@id="${fieldName}"]//input[@value="${field.value}"]`
                );

                // WAIT FOR WHILE
                await sleep(sleepEvents.loading);

                if (field.value === "PERIODIC_SPLIT") {
                    for (let key of field.expecting) {
                        await findByXPath(driver, `//input[@id="${key.inputId}"]`);
                        break;
                    }
                } else {
                    for (let key of field.expecting) {
                        if (key.value === undefined) {
                            await findByXPath(driver, `//input[@id="${key.inputId}"]`);
                        } else {
                            await findByXPath(
                                driver,
                                `//input[@id="${key.inputId}"][@value="${key.value}"]`
                            );
                        }
                    }
                }
            }
        });
    });

    describe.skip("ADD_LINK", () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> BUYER-SELLER LINK TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-link"]');

            // WAIT FOR BUYER NAME TO FETCH FROM API
            await sleep(sleepEvents.optionsLoading);

            // FILL THE FORM
            for (let field of Object.keys(ADD_LINK)) {
                if (ADD_LINK[field].choose) {
                    if (field === "buyerName" || field === "sellerName") {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${ADD_LINK[field].option}"]`
                        );
                        // WAIT TILL SELLER TO FETCH FROM API
                        if (field === "buyerName") {
                            await sleep(sleepEvents.optionsLoading);
                        }
                    } else {
                        await findByXPathAndClick(
                            driver,
                            `//div[@id="${field}"]//input[@value="${ADD_LINK[field].option}"]`
                        );
                    }
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_LINK[field]
                    );
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.BUYER_SELLER_LINK_CREATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("BuyerSellerLink Created Successfully");
        });
    });

    describe("UPDATE_LINK", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> BUYER-SELLER LINK TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // CLICK ON UPDATE LINK -> ANY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-link"]'
            );

            // WAIT FOR BUYER NAME TO FETCH FROM API
            await sleep(sleepEvents.optionsLoading);

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_LINK)) {
                if (UPDATE_LINK[field].choose) {
                    if (field === "buyerName" || field === "sellerName") {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${UPDATE_LINK[field].option}"]`
                        );
                        // WAIT TILL SELLER TO FETCH FROM API
                        if (field === "buyerName") {
                            await sleep(sleepEvents.optionsLoading);
                        }
                    } else {
                        await findByXPathAndClick(
                            driver,
                            `//div[@id="${field}"]//input[@value="${UPDATE_LINK[field].option}"]`
                        );
                    }
                } else {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        UPDATE_LINK[field]
                    );
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.BUYER_SELLER_LINK_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("BuyerSellerLink Updated Successfully");
        });
    });

    describe("DELETE_LINK", () => {
        it("For delete buyer-seller link: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await driver.get(getURL("login"));
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> BUYER-SELLER LINK TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[3]'
            );

            // CLICK ON DELETE BUYER-SELLER LINK -> LATEST WHICH IS NOW ADDED AS WE DON'T WANT TO LOOST FORIGN KEY DATA I.E, EXISTING SEEDERS DATE I.E, FACTORING UNITS , INVOICES AND MANY MORE ETC.
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//tr[@class="ant-table-row ant-table-row-level-0"]//button[@name="delete-buyerSellerLink"]'
            );

            // PAUSE FOR WHILE
            await sleep(sleepEvents.loading);

            // CLICK ON CONFIRM
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete"]'
            );

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.BUYER_SELLER_LINK_DELETED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("BuyerSellerLink Deleted Successfully");
        });
    });
});
