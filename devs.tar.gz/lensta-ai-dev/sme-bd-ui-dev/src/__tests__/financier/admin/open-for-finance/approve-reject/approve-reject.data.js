const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const APPROVE = {
    remarks: "Approving Factoring Unit",
};

module.exports = {
    LOGIN: LOGIN,
    APPROVE_FU_REQUIRED_VALIDATION: {
        remarks: {
            value: "",
            error: "above field can not be empty!",
        },
    },
    APPROVE_FU: {
        ...APPROVE,
    },
};
