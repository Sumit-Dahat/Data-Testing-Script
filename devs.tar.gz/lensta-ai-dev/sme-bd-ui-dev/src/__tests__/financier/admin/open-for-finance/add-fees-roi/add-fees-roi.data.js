const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const FEES_AND_ROI = {
    buyerFees: 1000,
    sellerFees: 1000,
    rateOfInterest: 10,
};

module.exports = {
    LOGIN: LOGIN,
    ADD_FU_FEES_AND_ROI_REQUIRED_VALIDATION: {
        buyerFees: {
            value: "",
            error: "please enter the amount!",
        },
        sellerFees: {
            value: "",
            error: "please enter the amount!",
        },
        rateOfInterest: {
            value: "",
            error: "ROI required!",
        },
    },
    ADD_FU_FEES_AND_ROI_INVALID_VALIDATION: {
        buyerFees: {
            value: "IOOO",
            error: "must be number !",
        },
        sellerFees: {
            value: "IOOO",
            error: "must be number !",
        },
        rateOfInterest: {
            value: "IOOO",
            error: "enter valid ROI!",
        },
    },
    ADD_FU_FEES_AND_ROI: {
        ...FEES_AND_ROI,
    },
};
