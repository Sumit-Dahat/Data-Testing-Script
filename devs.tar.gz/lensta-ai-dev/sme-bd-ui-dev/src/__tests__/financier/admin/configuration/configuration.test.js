const { getURL, getDriver, sleep, sleepEvents } = require("../../../config");
const {
    ADD_CONFIGURATION_REQUIRED_VALIDATION,
    ADD_CONFIGURATION,
    UPDATE_CONFIGURATION,
    LOGIN,
} = require("./configuration.data");
const { before } = require("jest");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../../generic-service");

module.exports = describe("Financier Admin Configurations Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe.only("ADD_CONFIGURATION_REQUIRED_VALIDATION", () => {
        before(function (done) {
            this.timeout(3000); // A very long environment setup.
            setTimeout(done, 2500);
        });

        it("For empty input: Should return an Error string", async (done) => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> CONFIGURATION TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[7]");

            // FILL THE FORM
            let tabIndex = 1;
            for (let field of Object.keys(ADD_CONFIGURATION_REQUIRED_VALIDATION)) {
                findByXPathAndClick(
                    driver,
                    `//div[@class="ant-tabs-nav-list"]/div[${tabIndex}]`
                );

                for (let key of Object.keys(
                    ADD_CONFIGURATION_REQUIRED_VALIDATION[field]
                )) {
                    if (ADD_CONFIGURATION_REQUIRED_VALIDATION[field][key].choose) {
                        if (ADD_CONFIGURATION_REQUIRED_VALIDATION[field][key].error) {
                            errors.push(
                                ADD_CONFIGURATION_REQUIRED_VALIDATION[field][key].error
                            );
                        }
                    } else {
                        // WAIT FOR WHILE
                        await sleep(sleepEvents.loading);

                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${key}"]`,
                            ADD_CONFIGURATION_REQUIRED_VALIDATION[field][key].value
                        );
                        if (ADD_CONFIGURATION_REQUIRED_VALIDATION[field][key].error) {
                            errors.push(
                                ADD_CONFIGURATION_REQUIRED_VALIDATION[field][key].error
                            );
                        }
                    }
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // WAIT TILL ERRORS LOCATED
                await sleep(sleepEvents.loading);

                // FORM ERRORS RESPONSE
                resposne = await findAllByXPathAndWaitForLocated(
                    driver,
                    "//div[@class='ant-form-item-explain-error']"
                );

                // CHECKING FOR ERROR EXIST
                expect(resposne).toHaveLength(errors.length);

                for (let index = 0; index < resposne.length; index++) {
                    error = await resposne[index].getText();
                    expect(errors).toContain(error);
                    errors.splice(errors.indexOf(error), 1);
                }

                expect(errors).toHaveLength(0);

                tabIndex++;

                done();
            }
        });
    });

    describe("ADD_CONFIGURATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> CONFIGURATION TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[7]");

            // FILL THE FORM
            let tabIndex = 1;
            let messages = [
                undefined,
                "Entity Type",
                "Bank Account Type",
                "Promoter Type",
                "Address Type",
                "Business Sector",
                "Industry Sector",
                "Industry Sub Sector",
            ];
            for (let field of Object.keys(ADD_CONFIGURATION)) {
                // WAIT FOR WHILE
                await sleep(sleepEvents.loading);

                findByXPathAndClick(
                    driver,
                    `//div[@class="ant-tabs-nav-list"]/div[${tabIndex}]`
                );

                for (let key of Object.keys(ADD_CONFIGURATION[field])) {
                    if (ADD_CONFIGURATION[field][key].choose) {
                        // WAIT FOR WHILE
                        await sleep(sleepEvents.loading);
                        await findByXPathAndClick(driver, `//input[@id="sector"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${ADD_CONFIGURATION[field][key].option}"]`
                        );
                    } else {
                        // WAIT FOR WHILE
                        await sleep(sleepEvents.loading);
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${key}"]`,
                            ADD_CONFIGURATION[field][key]
                        );
                    }
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // FORM SUCCESS RESPONSE
                resposne = await findByXPathAndWaitForText(
                    driver,
                    "//div[@class='ant-notification-notice-message']",
                    `${messages[tabIndex]} Created Successfully`
                );

                // CHECKING FOR SUCCESS
                const msg = `${messages[tabIndex]} Created Successfully`;
                expect(resposne).toBe(msg);

                tabIndex = tabIndex + 1;
            }
        });
    });

    describe("UPDATE_CONFIGURATION", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> CONFIGURATION TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[7]");

            // FILL THE FORM
            let tabIndex = 1;
            let messages = [
                undefined,
                "Entity Type",
                "Bank Account Type",
                "Promoter Type",
                "Address Type",
                "Business Sector",
                "Industry Sector",
                "Industry Sub Sector",
            ];
            for (let field of Object.keys(UPDATE_CONFIGURATION)) {
                // WAIT FOR WHILE
                await sleep(sleepEvents.loading);

                findByXPathAndClick(
                    driver,
                    `//div[@class="ant-tabs-nav-list"]/div[${tabIndex}]`
                );

                // WAIT FOR WHILE
                await sleep(sleepEvents.loading);

                findByXPathAndClick(driver, `//button[@name="update-configuration"]`);

                for (let key of Object.keys(UPDATE_CONFIGURATION[field])) {
                    if (UPDATE_CONFIGURATION[field][key].choose) {
                        // WAIT FOR WHILE
                        await sleep(sleepEvents.loading);
                        await findByXPathAndClick(driver, `//input[@id="sector"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${UPDATE_CONFIGURATION[field][key].option}"]`
                        );
                    } else {
                        // WAIT FOR WHILE
                        await sleep(sleepEvents.loading);
                        await findByXPathClearAndSendKeys(
                            driver,
                            `//input[@id="${key}"]`,
                            UPDATE_CONFIGURATION[field][key]
                        );
                    }
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@type="submit"]');

                // FORM SUCCESS RESPONSE
                resposne = await findByXPathAndWaitForText(
                    driver,
                    "//div[@class='ant-notification-notice-message']",
                    `${messages[tabIndex]} Updated Successfully`
                );

                // CHECKING FOR SUCCESS
                const msg = `${messages[tabIndex]} Updated Successfully`;
                expect(resposne).toBe(msg);

                tabIndex = tabIndex + 1;
            }
        });
    });
});
