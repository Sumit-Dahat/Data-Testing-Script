const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const CONFIGURATION = {
    entityType: {
        name: "tes949 entity",
    },
    accountType: {
        name: "test49 account",
    },
    addressType: {
        name: "test49 address",
    },
    businessSector: {
        name: "test49 business sector",
    },
    industrySector: {
        sector: "Manufacturing",
        name: "test49 industry sector",
    },
    industrySubSector: {
        sector: "Automobile",
        name: "test49 industry sub sector",
    },
};

module.exports = {
    LOGIN: LOGIN,
    ADD_CONFIGURATION_REQUIRED_VALIDATION: {
        entityType: {
            name: {
                value: "",
                error: "above field can not be empty!",
            },
        },
        accountType: {
            name: {
                value: "",
                error: "above field can not be empty!",
            },
        },
        addressType: {
            name: {
                value: "",
                error: "above field can not be empty!",
            },
        },
        businessSector: {
            name: {
                value: "",
                error: "above field can not be empty!",
            },
        },
        industrySector: {
            name: {
                value: "",
                error: "above field can not be empty!",
            },
            sector: {
                choose: true,
                option: undefined,
                error: "Please select one!",
            },
        },
        industrySubSector: {
            name: {
                value: "",
                error: "above field can not be empty!",
            },
            sector: {
                choose: true,
                option: undefined,
                error: "Please select one!",
            },
        },
    },
    ADD_CONFIGURATION: {
        ...CONFIGURATION,
        industrySector: {
            ...CONFIGURATION.industrySector,
            sector: {
                choose: true,
                option: CONFIGURATION.industrySector.sector,
            },
        },
        industrySubSector: {
            ...CONFIGURATION.industrySubSector,
            sector: {
                choose: true,
                option: CONFIGURATION.industrySubSector.sector,
            },
        },
    },
    UPDATE_CONFIGURATION: {
        entityType: {
            name: "update2 entity type",
        },
        accountType: {
            name: "update2 account type",
        },
        addressType: {
            name: "update2 address type",
        },
        businessSector: {
            name: "update2 business sector",
        },
        industrySector: {
            name: "update2 industry sector",
        },
        industrySubSector: {
            name: "update2 industry sub sector",
        },
    },
};
