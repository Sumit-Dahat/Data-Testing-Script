const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const PROMOTER = {
    promoterType: "Individual",
    nameOrentityName: "test promoter",
    gender: "Male",
    dobOrDateOfIncorporation: "2023-01-01",
    adhaarOrRegistrationNumber: "871289129920",
    dinCin: "871247128725",
    panNumber: "BASIV7612Y",
    shareholding: 50,
    email: "test.promoter@gmail.com",
    contactNo: "8956238734",
    addressLine1: "test address 1",
    addressLine2: "test address 2",
    pinNo: "110033",
};

module.exports = {
    LOGIN: LOGIN,
    ADD_PROMOTER_REQUIRED_VALIDATION: {
        promoterType: {
            choose: true,
            option: null,
            error: "Please select one!",
        },
        nameOrentityName: {
            value: "",
            error: "above field can not be empty!",
        },
        gender: {
            choose: true,
            option: null,
            error: "Please select one!",
        },
        dobOrDateOfIncorporation: {
            value: "",
            error: "please select the date!",
        },
        adhaarOrRegistrationNumber: {
            value: "",
            error: "above field can not be empty!",
        },
        dinCin: {
            value: "",
            error: "above field can not be empty!",
        },
        panNumber: {
            value: "",
            error: "please enter the PAN number!",
        },
        shareholding: {
            value: "",
            error: "above field can not be empty!",
        },
        email: {
            value: "",
            error: "please enter the email id!",
        },
        contactNo: {
            value: "",
            error: "please enter the mobile number!",
        },
        addressLine1: {
            value: "",
            error: "above field can not be empty!",
        },
        pinNo: {
            value: "",
            error: "please enter the 6 digit PIN!",
        },
        state: {
            value: "",
            error: "above field can not be empty!",
        },
        district: {
            value: "",
            error: "above field can not be empty!",
        },
        subDist: {
            value: "",
            error: "above field can not be empty!",
        },
        postOffice: {
            value: "",
            error: "above field can not be empty!",
        },
    },
    ADD_PROMOTER_INVALID_VALIDATION: {
        promoterType: {
            choose: true,
            option: PROMOTER.promoterType,
        },
        nameOrentityName: {
            value: "test promoter 123@",
            error: "only aplhabets required!",
        },
        gender: {
            choose: true,
            option: PROMOTER.gender,
        },
        adhaarOrRegistrationNumber: {
            value: "regis 123@",
            error: "Please enter a valid input!",
        },
        dinCin: {
            value: "DINCIN 123@",
            error: "Please enter a valid input!",
        },
        panNumber: {
            value: "PAN123",
            error: "enter a valid PAN number, must be 10 characters !",
        },
        shareholding: {
            value: "share 123@",
            error: "must be a number!",
        },
        email: {
            value: "123mail.com",
            error: "enter a valid email id!",
        },
        contactNo: {
            value: "123",
            error: "please enter the valid mobile number!",
        },
        addressLine1: {
            value: "test address 1 123@",
            error: "Please enter a valid input!",
        },
        addressLine2: {
            value: "test address 2 123@",
            error: "Please enter a valid input!",
        },
        pinNo: {
            value: "ABCDEF",
            error: "PIN must be a number!",
        },
        state: {
            value: "test state 123@",
            error: "Please enter a valid input!",
        },
        district: {
            value: "test district 123@",
            error: "Please enter a valid input!",
        },
        subDist: {
            value: "test sub-dist 123@",
            error: "Please enter a valid input!",
        },
        postOffice: {
            value: "test post-office 123@",
            error: "Please enter a valid input!",
        },
    },
    ADD_PROMOTER: {
        ...PROMOTER,
        promoterType: {
            choose: true,
            option: PROMOTER.promoterType,
        },
        gender: {
            choose: true,
            option: PROMOTER.gender,
        },
    },
    UPDATE_PROMOTER: {
        shareholding: 64,
        email: "test.update.promoter@gmail.com",
        contactNo: "8956734734",
        addressLine1: "test address update 1",
        addressLine2: "test address udpate 2",
        pinNo: "110009",
    },
    DELETE_PROMOTER: {
        type: "delete",
    },
};
