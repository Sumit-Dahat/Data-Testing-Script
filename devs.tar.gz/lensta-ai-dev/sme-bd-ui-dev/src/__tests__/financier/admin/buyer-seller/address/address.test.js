const { getURL, getDriver, sleep, sleepEvents } = require("../../../../config");
const { message } = require("../../../../message");
const {
    ADD_ADDRESS_REQUIRED_VALIDATION,
    ADD_ADDRESS_INVALID_VALIDATION,
    ADD_ADDRESS,
    UPDATE_ADDRESS,
    LOGIN,
} = require("./address.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../../../generic-service");

module.exports = describe("Financier Admin Buyer-Seller Address Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_ADDRESS_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO ADDRESS TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[2]"
            );

            // FILL THE FORM
            for (let field of Object.keys(ADD_ADDRESS_REQUIRED_VALIDATION)) {
                if (ADD_ADDRESS_REQUIRED_VALIDATION[field].choose) {
                    if (ADD_ADDRESS_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_ADDRESS_REQUIRED_VALIDATION[field].error);
                    }
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_ADDRESS_REQUIRED_VALIDATION[field].value
                    );
                    if (ADD_ADDRESS_REQUIRED_VALIDATION[field].error) {
                        errors.push(ADD_ADDRESS_REQUIRED_VALIDATION[field].error);
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_ADDRESS_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO ADDRESS TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[2]"
            );

            // WAIT FOR OPTION TO BE LOADED
            await sleep(sleepEvents.optionsLoading);

            // FILL THE FORM
            for (let field of Object.keys(ADD_ADDRESS_INVALID_VALIDATION)) {
                if (ADD_ADDRESS_INVALID_VALIDATION[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_ADDRESS_INVALID_VALIDATION[field].option}"]`
                    );
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_ADDRESS_INVALID_VALIDATION[field].value
                    );
                    if (ADD_ADDRESS_INVALID_VALIDATION[field].error) {
                        errors.push(ADD_ADDRESS_INVALID_VALIDATION[field].error);
                    }
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_ADDRESS", () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO ADDRESS TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[2]"
            );

            // WAIT FOR OPTION TO BE LOADED
            await sleep(sleepEvents.optionsLoading);

            // FILL THE FORM
            for (let field of Object.keys(ADD_ADDRESS)) {
                if (ADD_ADDRESS[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_ADDRESS[field].option}"]`
                    );
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_ADDRESS[field]
                    );
                }
            }

            // WAIT FOR WHILE
            await sleep(sleepEvents.apiLoading);

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.ADDRESS_CREATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Address Created Successfully");
        });
    });

    describe("UPDATE_ADDRESS", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO ADDRESS TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[2]"
            );

            // WAIT FOR OPTION TO BE LOADED
            await sleep(sleepEvents.optionsLoading);

            // CLICK ON UPDATE ADDRESS
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-address"]'
            );

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_ADDRESS)) {
                if (UPDATE_ADDRESS[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${UPDATE_ADDRESS[field].option}"]`
                    );
                } else {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        UPDATE_ADDRESS[field]
                    );
                }
            }

            // WAIT FOR WHILE
            await sleep(sleepEvents.apiLoading);

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.ADDRESS_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Address Updated Successfully");
        });
    });

    describe("DELETE_ADDRESS", () => {
        it("For delete address: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO ADDRESS TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[2]"
            );

            // WAIT TILL ADDRESS TYPE FETCH
            await sleep(sleepEvents.optionsLoading);

            // CLICK ON DELETE ADDRESS
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete-address"]'
            );

            // PAUSE FOR WHILE
            await sleep(sleepEvents.loading);

            // CLICK ON CONFIRM
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete"]'
            );

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.ADDRESS_DELETED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Address Deleted Successfully");
        });
    });
});
