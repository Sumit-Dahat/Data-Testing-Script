const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const BANK = {
    ifscCode: "BARB0DBAZAD",
    accountTypeId: "Savings",
    accountTitle: "test account",
    accountNo: "870912760910",
    swiftCode: "BNVLR01267",
};

module.exports = {
    LOGIN: LOGIN,
    ADD_BANK_REQUIRED_VALIDATION: {
        accountTypeId: {
            choose: true,
            option: undefined,
            error: "Please select one!",
        },
        accountNo: {
            value: "",
            error: "please enter the account number!",
        },
        ifscCode: {
            value: "",
            error: "please enter the ifsc code!",
        },
        bankName: {
            value: "",
            error: "above field can not be empty!",
        },
        branchName: {
            value: "",
            error: "above field can not be empty!",
        },
        micrCode: {
            value: "",
            error: "please enter the MICR code!",
        },
    },
    ADD_BANK_INVALID_VALIDATION: {
        accountTypeId: {
            choose: true,
            option: BANK.accountTypeId,
        },
        accountNo: {
            value: "ACCOUNT@",
            error: "only number inputs allowed!",
        },
        ifscCode: {
            value: "VALID@",
            error: "please enter a valid ifsc code!",
        },
        micrCode: {
            value: "MICR@",
            error: "please enter a valid MICR code!",
        },
        swiftCode: {
            value: "SWIFT@",
            error: "please enter a valid SWIFT code!",
        },
    },
    ADD_BANK: {
        ...BANK,
        accountTypeId: {
            choose: true,
            option: BANK.accountTypeId,
        },
    },
    UPDATE_BANK: {
        ifscCode: "BARB0DBAZAD",
        accountTitle: "test account update",
        accountNo: "870000760910",
        swiftCode: "BNXLR01267",
    },
    DELETE_BANK: {
        type: "delete",
    },
};
