const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const ENTITY = {
    entityDetails: {
        buyerSeller: "Seller",
        entityTypeId: "Public",
        startOfOperation: "2023-01-15",
        entityName: "test seller",
        registrationNumber: "871289129821",
        panNumber: "GREIV9812K",
        incorporationDate: "2023-01-10",
        udyamNumber: "UDYAM-TN-35-8712781",
        businessSector: "Trading",
        industrySector: "Gold",
        industrySubsector: "Ornament",
        salesInLastFY: "1000000",
        profitInLastFY: "100000",
        contactNo: "9878671243",
        primaryEmail: "test.seller@gmail.com",
    },
    adminDetails: {
        adminName: "test seller",
        mobileNo: "8753918231",
        email: "test.seller@gmail.com",
        password: "test1234",
        repassword: "test1234",
    },
};

module.exports = {
    LOGIN: LOGIN,
    ADD_ENTITY_REQUIRED_VALIDATION: {
        entityDetails: {
            buyerSeller: {
                choose: true,
                option: undefined,
                error: "Please select one!",
            },
            entityName: {
                value: "",
                error: "above field can not be empty!",
            },
            panNumber: {
                value: "",
                error: "please enter the PAN number!",
            },
            incorporationDate: {
                value: "",
                error: "please select the date!",
            },
            contactNo: {
                value: "",
                error: "please enter the mobile number!",
            },
            primaryEmail: {
                value: "",
                error: "please enter the email id!",
            },
        },
        adminDetails: {
            adminName: {
                value: "",
                error: "above field can not be empty!",
            },
            mobileNo: {
                value: "",
                error: "please enter the mobile number!",
            },
            email: {
                value: "",
                error: "please enter the email id!",
            },
            password: {
                value: "",
                error: "please enter the password!",
            },
            repassword: {
                value: "",
                error: "Please confirm the password!",
            },
        },
    },
    ADD_ENTITY_INVALID_VALIDATION: {
        entityDetails: {
            buyerSeller: {
                choose: true,
                option: ENTITY.entityDetails.buyerSeller,
            },
            entityTypeId: {
                choose: true,
                option: ENTITY.entityDetails.entityTypeId,
            },
            entityName: {
                value: "test seller 123",
                error: "only aplhabets required!",
            },
            registrationNumber: {
                value: "regis 123@",
                error: "Please enter a valid input!",
            },
            panNumber: {
                value: "PAN123",
                error: "enter a valid PAN number, must be 10 characters !",
            },
            udyamNumber: {
                value: "UDYAM123",
                error: "enter your 19 digit UDYAM registration number (i.e. UDYAM-XX-00-0000000)!",
            },
            incorporationDate: {
                value: "DATE 123@",
                error: undefined,
            },
            startOfOperation: {
                value: "DATE 123@",
                error: undefined,
            },
            businessSector: {
                choose: true,
                option: ENTITY.entityDetails.businessSector,
            },
            industrySector: {
                choose: true,
                option: ENTITY.entityDetails.industrySector,
            },
            industrySubsector: {
                choose: true,
                option: ENTITY.entityDetails.industrySubsector,
            },
            salesInLastFY: {
                value: "Iooooo",
                error: "must be number!",
            },
            profitInLastFY: {
                value: "Iooooo",
                error: "must be number!",
            },
            contactNo: {
                value: "123",
                error: "please enter the valid mobile number!",
            },
            primaryEmail: {
                value: "123mail.com",
                error: "enter a valid email id!",
            },
        },
        adminDetails: {
            adminName: {
                value: "test seller 123",
                error: "only aplhabets required!",
            },
            mobileNo: {
                value: "123",
                error: "please enter the valid mobile number!",
            },
            email: {
                value: "123mail.com",
                error: "enter a valid email id!",
            },
            password: {
                value: "123",
                error: "minimum 8 characters required!",
            },
            repassword: {
                value: "123",
                error: "minimum 8 characters required!",
            },
        },
    },
    ADD_ENTITY_PASSWORD_VALIDATION: {
        password: {
            value: "123456789",
            error: "",
        },
        repassword: {
            value: "12345678910",
            error: "Passwords do not match!",
        },
    },
    ADD_ENTITY: {
        entityDetails: {
            ...ENTITY.entityDetails,
            buyerSeller: {
                choose: true,
                option: ENTITY.entityDetails.buyerSeller,
            },
            entityTypeId: {
                choose: true,
                option: ENTITY.entityDetails.entityTypeId,
            },
            businessSector: {
                choose: true,
                option: ENTITY.entityDetails.businessSector,
            },
            industrySector: {
                choose: true,
                option: ENTITY.entityDetails.industrySector,
            },
            industrySubsector: {
                choose: true,
                option: ENTITY.entityDetails.industrySubsector,
            },
        },
        adminDetails: {
            ...ENTITY.adminDetails,
        },
    },
    UPDATE_ENTITY: {
        entityDetails: {
            registrationNumber: "821229129351",
        },
        adminDetails: {
            mobileNo: "7834562198",
        },
    },
};
