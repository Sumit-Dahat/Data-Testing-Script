const { getURL, getDriver, sleep, sleepEvents } = require("../../../../config");
const { message } = require("../../../../message");
const {
    ADD_BANK_REQUIRED_VALIDATION,
    ADD_BANK_INVALID_VALIDATION,
    ADD_BANK,
    UPDATE_BANK,
    LOGIN,
} = require("./bank.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../../../generic-service");

module.exports = describe("Financier Admin Buyer-Seller Bank Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_BANK_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO BANK TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[3]"
            );

            // FILL THE FORM
            for (let field of Object.keys(ADD_BANK_REQUIRED_VALIDATION)) {
                if (ADD_BANK_REQUIRED_VALIDATION[field].choose) {
                    errors.push(ADD_BANK_REQUIRED_VALIDATION[field].error);
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_BANK_REQUIRED_VALIDATION[field].value
                    );
                    errors.push(ADD_BANK_REQUIRED_VALIDATION[field].error);
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_BANK_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO BANK TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[3]"
            );

            // WAIT TILL BANK TYPE LOADING
            await sleep(sleepEvents.optionsLoading);

            // FILL REMAINING THE FORM
            for (let field of Object.keys(ADD_BANK_INVALID_VALIDATION)) {
                if (ADD_BANK_INVALID_VALIDATION[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_BANK_INVALID_VALIDATION[field].option}"]`
                    );
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_BANK_INVALID_VALIDATION[field].value
                    );
                    errors.push(ADD_BANK_INVALID_VALIDATION[field].error);
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_BANK", () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO BANK TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[3]"
            );

            // WAIT TILL BANK TYPE FETCH
            await sleep(sleepEvents.optionsLoading);

            // FILL REMAINING THE FORM
            for (let field of Object.keys(ADD_BANK)) {
                if (ADD_BANK[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${ADD_BANK[field].option}"]`
                    );
                } else {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_BANK[field]
                    );
                    if (field === "ifscCode") {
                        // WAIT TILL IFSC_CODE FETCH
                        await sleep(sleepEvents.apiLoading);
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.BANK_CREATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Bank Created Successfully");
        });
    });

    describe("UPDATE_BANK", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO BANK TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[3]"
            );

            // WAIT TILL BANK TYPE LOADING
            await sleep(sleepEvents.optionsLoading);

            // CLICK ON UPDATE BANK
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-bank"]'
            );

            // FILL REMAINING THE FORM
            for (let field of Object.keys(UPDATE_BANK)) {
                if (UPDATE_BANK[field].choose) {
                    await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                    await findByXPathAndClick(
                        driver,
                        `//div[@title="${UPDATE_BANK[field].option}"]`
                    );
                } else {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        UPDATE_BANK[field]
                    );
                }
            }

            // WAIT TILL IFSC_CODE FETCH
            await sleep(sleepEvents.apiLoading);

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.BANK_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Bank Updated Successfully");
        });
    });

    describe("DELETE_BANK", () => {
        it("For delete address: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO BANK TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[3]"
            );

            // WAIT TILL BANK TYPE FETCH
            await sleep(sleepEvents.optionsLoading);

            // CLICK ON DELETE BANK
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete-bank"]'
            );

            // PAUSE FOR WHILE
            await sleep(sleepEvents.loading);

            // CLICK ON CONFIRM
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="delete"]'
            );

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.BANK_DELETED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Bank Deleted Successfully");
        });
    });
});
