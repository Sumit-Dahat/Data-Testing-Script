const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const DOCUMENT = {
    title: "test doc",
    uploadDocuments: "test.jpg",
};

module.exports = {
    LOGIN: LOGIN,
    ADD_DOCUMENT_REQUIRED_VALIDATION: {
        title: {
            value: "",
            error: "above field can not be empty!",
        },
        uploadDocuments: {
            choose: true,
            option: null,
            error: "please upload the document!",
        },
    },
    ADD_DOCUMENT_INVALID_VALIDATION: {
        type: "skip",
    },
    ADD_DOCUMENT: {
        ...DOCUMENT,
        uploadDocuments: {
            choose: true,
            option: DOCUMENT.uploadDocuments,
        },
    },
    DELETE_DOCUMENT: {
        type: "delete",
    },
};
