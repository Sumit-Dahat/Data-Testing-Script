const { getURL, getDriver, sleep, sleepEvents } = require("../../../../config");
const { message } = require("../../../../message");
const {
    ADD_SANCTIONED_LIMIT_REQUIRED_VALIDATION,
    ADD_SANCTIONED_LIMIT_INVALID_VALIDATION,
    UPDATE_SANCTIONED_LIMIT,
    LOGIN,
} = require("./limit.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../../../generic-service");

module.exports = describe("Financier Admin Buyer-Seller Sanctioned Limit Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe.skip("ADD_SANCTIONED_LIMIT_REQUIRED_VALIDATION", () => {
        expect(ADD_SANCTIONED_LIMIT_REQUIRED_VALIDATION.type).toBe("skip");
    });

    describe("ADD_SANCTIONED_LIMIT_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY -> ANY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO SANCTIONED LIMIT TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[5]"
            );

            // FILL THE FORM
            for (let field of Object.keys(ADD_SANCTIONED_LIMIT_INVALID_VALIDATION)) {
                await findByXPathClearAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    ADD_SANCTIONED_LIMIT_INVALID_VALIDATION[field].value
                );
                errors.push(ADD_SANCTIONED_LIMIT_INVALID_VALIDATION[field].error);
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("UPDATE_SANCTIONED_LIMIT", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY -> ANY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // NAVIGATE TO SANCTIONED LIMIT TAB
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                "//div[@class='ant-tabs-nav-list']/div[5]"
            );

            // FILL THE FORM
            for (let field of Object.keys(UPDATE_SANCTIONED_LIMIT)) {
                await findByXPathClearAndSendKeys(
                    driver,
                    `//input[@id="${field}"]`,
                    UPDATE_SANCTIONED_LIMIT[field]
                );
            }

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.SANCTIONED_LIMIT_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Sanctioned Limit Updated Successfully");
        });
    });
});
