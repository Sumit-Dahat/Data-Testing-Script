const { getURL, getDriver, sleep, sleepEvents } = require("../../../../config");
const { message } = require("../../../../message");
const {
    ADD_ENTITY_REQUIRED_VALIDATION,
    ADD_ENTITY_INVALID_VALIDATION,
    ADD_ENTITY_PASSWORD_VALIDATION,
    ADD_ENTITY,
    UPDATE_ENTITY,
    LOGIN,
} = require("./entity.data");
const {
    findByXPathAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findAllByXPathAndWaitForLocated,
    findByXPathAndWaitForLocatedAndClick,
    findByXPathClearAndSendKeys,
} = require("../../../../generic-service");

module.exports = describe("Financier Admin Buyer-Seller Entity Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_ENTITY_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-entity"]');

            // FILL THE FORM
            for (let key of Object.keys(ADD_ENTITY_REQUIRED_VALIDATION)) {
                for (let field of Object.keys(ADD_ENTITY_REQUIRED_VALIDATION[key])) {
                    if (ADD_ENTITY_REQUIRED_VALIDATION[key][field].choose) {
                        if (ADD_ENTITY_REQUIRED_VALIDATION[key][field].error) {
                            errors.push(ADD_ENTITY_REQUIRED_VALIDATION[key][field].error);
                        }
                    } else {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            ADD_ENTITY_REQUIRED_VALIDATION[key][field].value
                        );
                        if (ADD_ENTITY_REQUIRED_VALIDATION[key][field].error) {
                            errors.push(ADD_ENTITY_REQUIRED_VALIDATION[key][field].error);
                        }
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_ENTITY_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-entity"]');

            // WAIT FOR OPTION TO BE LOADED
            await sleep(sleepEvents.optionsLoading);

            // FILL THE FORM
            for (let key of Object.keys(ADD_ENTITY_INVALID_VALIDATION)) {
                for (let field of Object.keys(ADD_ENTITY_INVALID_VALIDATION[key])) {
                    if (ADD_ENTITY_INVALID_VALIDATION[key][field].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${ADD_ENTITY_INVALID_VALIDATION[key][field].option}"]`
                        );
                    } else {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            ADD_ENTITY_INVALID_VALIDATION[key][field].value
                        );
                        if (ADD_ENTITY_INVALID_VALIDATION[key][field].error) {
                            errors.push(ADD_ENTITY_INVALID_VALIDATION[key][field].error);
                        }
                    }
                }
            }

            // WAIT TILL ERRORS LOCATED
            await sleep(sleepEvents.loading);

            // FORM ERRORS RESPONSE
            resposne = await findAllByXPathAndWaitForLocated(
                driver,
                "//div[@class='ant-form-item-explain-error']"
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toHaveLength(errors.length);

            for (let index = 0; index < resposne.length; index++) {
                error = await resposne[index].getText();
                expect(errors).toContain(error);
                errors.splice(errors.indexOf(error), 1);
            }

            expect(errors).toHaveLength(0);
        });
    });

    describe("ADD_ENTITY_PASSWORD_VALIDATION", () => {
        it("For invalid password input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-entity"]');

            // FILL THE ENTITY FORM I.E PASSWORDS & REPASSWORD
            await findByXPathAndSendKeys(
                driver,
                `//input[@id="password"]`,
                ADD_ENTITY_PASSWORD_VALIDATION.password.value
            );
            await findByXPathAndSendKeys(
                driver,
                `//input[@id="repassword"]`,
                ADD_ENTITY_PASSWORD_VALIDATION.repassword.value
            );

            // FORM ERRORS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-form-item-explain-error']",
                ADD_ENTITY_PASSWORD_VALIDATION.repassword.error
            );

            // CHECKING FOR ERROR EXIST
            expect(resposne).toBe("Passwords do not match!");
        });
    });

    describe.skip("ADD_ENTITY", () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // NAVIGATE TO ADD BUYER-SELLER
            await findByXPathAndClick(driver, '//button[@name="add-entity"]');

            // WAIT FOR OPTION TO BE LOADED
            await sleep(sleepEvents.optionsLoading);

            // FILL THE FORM
            for (let key of Object.keys(ADD_ENTITY)) {
                for (let field of Object.keys(ADD_ENTITY[key])) {
                    if (ADD_ENTITY[key][field].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${ADD_ENTITY[key][field].option}"]`
                        );
                    } else {
                        await findByXPathAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            ADD_ENTITY[key][field]
                        );
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.ENTITY_CREATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Entity Created Successfully");
        });
    });

    describe("UPDATE_ENTITY", () => {
        it("For valid update input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> MANAGE BUYER-SELLER TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[2]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // CLICK ON UPDATE ENTITY
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//button[@name="update-entity"]'
            );

            // WAIT FOR OPTION TO BE LOADED
            await sleep(sleepEvents.optionsLoading);

            // FILL THE FORM
            for (let key of Object.keys(UPDATE_ENTITY)) {
                for (let field of Object.keys(UPDATE_ENTITY[key])) {
                    if (UPDATE_ENTITY[key][field].choose) {
                        await findByXPathAndClick(driver, `//input[@id="${field}"]`);
                        await findByXPathAndClick(
                            driver,
                            `//div[@title="${UPDATE_ENTITY[key][field].option}"]`
                        );
                    } else {
                        await findByXPathClearAndSendKeys(
                            driver,
                            `//input[@id="${field}"]`,
                            UPDATE_ENTITY[key][field]
                        );
                    }
                }
            }

            // SUBMIT FORM
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // FORM SUCCESS RESPONSE
            resposne = await findByXPathAndWaitForText(
                driver,
                "//div[@class='ant-notification-notice-message']",
                message.ENTITY_UPDATED
            );

            // CHECKING FOR SUCCESS
            expect(resposne).toBe("Entity Updated Successfully");
        });
    });
});
