const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const ADDRESS = {
    addressType: "Home",
    addressLine1: "test address 1",
    addressLine2: "test address 2",
    pinNo: "110033",
};

module.exports = {
    LOGIN: LOGIN,
    ADD_ADDRESS_REQUIRED_VALIDATION: {
        addressType: {
            choose: true,
            option: undefined,
            error: "Please select one!",
        },
        addressLine1: {
            value: "",
            error: "above field can not be empty!",
        },
        addressLine2: {
            value: "",
            error: "above field can not be empty!",
        },
        pinNo: {
            value: "",
            error: "please enter the 6 digit PIN!",
        },
        state: {
            value: "",
            error: "above field can not be empty!",
        },
        district: {
            value: "",
            error: "above field can not be empty!",
        },
        subDist: {
            value: "",
            error: "above field can not be empty!",
        },
        postOffice: {
            value: "",
            error: "above field can not be empty!",
        },
    },
    ADD_ADDRESS_INVALID_VALIDATION: {
        addressType: {
            choose: true,
            option: ADDRESS.addressType,
        },
        addressLine1: {
            value: "test address 123@",
            error: "Please enter a valid input!",
        },
        addressLine2: {
            value: "test address 123@",
            error: "Please enter a valid input!",
        },
        pinNo: {
            value: "ABCDEF",
            error: "PIN must be a number!",
        },
        state: {
            value: "test state 123@",
            error: "Please enter a valid input!",
        },
        district: {
            value: "test district 123@",
            error: "Please enter a valid input!",
        },
        subDist: {
            value: "test sub-dist 123@",
            error: "Please enter a valid input!",
        },
        postOffice: {
            value: "test post-office 123@",
            error: "Please enter a valid input!",
        },
    },
    ADD_ADDRESS: {
        ...ADDRESS,
        addressType: {
            choose: true,
            option: ADDRESS.addressType,
        },
    },
    UPDATE_ADDRESS: {
        addressLine1: "test address 1 update",
        addressLine2: "test address 2 update",
        pinNo: "110009",
    },
    DELETE_ADDRESS: {
        type: "delete",
    },
};
