const LOGIN = {
    email: "ellen.doe@gmail.com",
    password: "ellendoe123",
};

const SANCTIONED_LIMIT = {
    sanctionedLimit: 200000,
};

module.exports = {
    LOGIN: LOGIN,
    ADD_SANCTIONED_LIMIT_REQUIRED_VALIDATION: {
        type: "skip",
    },
    ADD_SANCTIONED_LIMIT_INVALID_VALIDATION: {
        sanctionedLimit: {
            value: "Z00000",
            error: "must be number!",
        },
    },
    UPDATE_SANCTIONED_LIMIT: {
        sanctionedLimit: SANCTIONED_LIMIT.sanctionedLimit + 10000,
    },
};
