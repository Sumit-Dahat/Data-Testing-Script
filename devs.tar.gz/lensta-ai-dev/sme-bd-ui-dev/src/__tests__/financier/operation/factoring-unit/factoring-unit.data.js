const LOGIN = {
    email: "financier.operation@gmail.com",
    password: "financieroperation123",
};

const FACTORING_UNIT = {
    buyerName: "Larsen & Toubro Limited",
    sellerName: "JSW Steel Limited",
    invoiceNumber: "INV-377",
    invoiceDate: "2023-01-01",
    invoiceAmount: 100000,
    discountAmount: 100,
    taxAmount: 100,
};

module.exports = {
    LOGIN: LOGIN,
    ADD_FACTORING_REQUIRED_VALIDATION: {
        buyerName: {
            choose: true,
            option: undefined,
            error: "Please select one!",
        },
        sellerName: {
            choose: true,
            option: undefined,
            error: "Please select one!",
        },
        invoiceNumber: {
            value: "",
            error: "please enter the invoice number!",
        },
        invoiceDate: {
            value: "",
            error: "please select the date!",
        },
        dueDate: {
            value: "",
            error: "please select the date!",
        },
        invoiceAmount: {
            value: "",
            error: "please enter the amount!",
        },
        discountAmount: {
            value: "",
            error: "please enter the amount!",
        },
        taxAmount: {
            value: "",
            error: "please enter the amount!",
        },
        totalAmount: {
            value: "",
            error: "please enter the amount!",
        },
    },
    ADD_FACTORING_INVALID_VALIDATION: {
        buyerName: {
            choose: true,
            option: FACTORING_UNIT.buyerName,
        },
        sellerName: {
            choose: true,
            option: FACTORING_UNIT.sellerName,
        },
        invoiceNumber: {
            value: "INV-123@",
            error: "please enter a valid invoice number!",
        },
        invoiceDate: {
            value: "DATE 123@",
            error: undefined,
        },
        invoiceAmount: {
            value: "Z000",
            error: "must be number !",
        },
        discountAmount: {
            value: "Z00",
            error: "must be number !",
        },
        taxAmount: {
            value: "Z00",
            error: "must be number !",
        },
    },
    ADD_FACTORING: {
        ...FACTORING_UNIT,
        buyerName: {
            choose: true,
            option: FACTORING_UNIT.buyerName,
        },
        sellerName: {
            choose: true,
            option: FACTORING_UNIT.sellerName,
        },
    },
    UPLOAD_FACTORING: {
        buyerName: {
            choose: true,
            option: FACTORING_UNIT.buyerName,
        },
        sellerName: {
            choose: true,
            option: FACTORING_UNIT.sellerName,
        },
        uploadDocuments: {
            choose: true,
            option: "test.xlsx",
        },
    },
    UPDATE_FACTORING: {
        invoiceDate: "2023-02-02",
        invoiceAmount: 200000,
        discountAmount: 200,
        taxAmount: 200,
    },
    DELETE_FACTORING: {
        type: "delete",
    },
};
