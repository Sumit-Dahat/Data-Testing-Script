const LOGIN = {
    email: "financier.opperation@gmail.com",
    password: "financieroperation123",
};

const APPROVE = {
    remarks: "Approving Factoring Unit",
};

module.exports = {
    LOGIN: LOGIN,
    APPROVE_FU_REQUIRED_VALIDATION: {
        remarks: {
            value: "",
            error: "above field can not be empty!",
        },
    },
    APPROVE_FU: {
        ...APPROVE,
    },
};
