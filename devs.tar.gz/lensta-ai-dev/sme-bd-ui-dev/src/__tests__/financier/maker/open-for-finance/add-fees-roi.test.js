const path = require("path");
const { getURL, getDriver, sleep, sleepEvents } = require("../../../../config");
const { message } = require("../../../../message");
const {
    ADD_FU_FEES_AND_ROI_REQUIRED_VALIDATION,
    ADD_FU_FEES_AND_ROI_INVALID_VALIDATION,
    ADD_FU_FEES_AND_ROI,
    LOGIN,
} = require("./add-fees-roi.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../../../generic-service");

module.exports = describe("Financier Maker Open-For-Finance Fees & Rate of Interest Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("ADD_FU_FEES_AND_ROI_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> OPEN-FOR-FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            try {
                // CLICK ON ADD BUYER-SELLER FEES & ROI -> ANY
                await findByXPathAndClick(driver, `//button[@name="approve-btn"]`);

                // FILL THE FORM
                for (let field of Object.keys(ADD_FU_FEES_AND_ROI_REQUIRED_VALIDATION)) {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_FU_FEES_AND_ROI_REQUIRED_VALIDATION[field].value
                    );
                    errors.push(ADD_FU_FEES_AND_ROI_REQUIRED_VALIDATION[field].error);
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@name="process"]');

                // WAIT TILL ERRORS LOCATED
                await sleep(sleepEvents.loading);

                // FORM ERRORS RESPONSE
                resposne = await findAllByXPathAndWaitForLocated(
                    driver,
                    "//div[@class='ant-form-item-explain-error']"
                );

                // CHECKING FOR ERROR EXIST
                expect(resposne).toHaveLength(errors.length);

                for (let index = 0; index < resposne.length; index++) {
                    error = await resposne[index].getText();
                    expect(errors).toContain(error);
                    errors.splice(errors.indexOf(error), 1);
                }

                expect(errors).toHaveLength(0);
            } catch (error) {
                console.log(
                    `factoring-unit doesn't exist OR fees & roi already added [ADD_FU_FEES_AND_ROI_REQUIRED_VALIDATION]`
                );
            }
        });
    });

    describe("ADD_FU_FEES_AND_ROI_INVALID_VALIDATION", () => {
        it("For invalid input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> OPEN-FOR-FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            try {
                // CLICK ON ADD BUYER-SELLER FEES & ROI -> ANY
                await findByXPathAndClick(driver, `//button[@name="approve-btn"]`);

                // FILL THE FORM
                for (let field of Object.keys(ADD_FU_FEES_AND_ROI_INVALID_VALIDATION)) {
                    await findByXPathAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_FU_FEES_AND_ROI_INVALID_VALIDATION[field].value
                    );
                    errors.push(ADD_FU_FEES_AND_ROI_INVALID_VALIDATION[field].error);
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@name="process"]');

                // WAIT TILL ERRORS LOCATED
                await sleep(sleepEvents.loading);

                // FORM ERRORS RESPONSE
                resposne = await findAllByXPathAndWaitForLocated(
                    driver,
                    "//div[@class='ant-form-item-explain-error']"
                );

                // CHECKING FOR ERROR EXIST
                expect(resposne).toHaveLength(errors.length);

                for (let index = 0; index < resposne.length; index++) {
                    error = await resposne[index].getText();
                    expect(errors).toContain(error);
                    errors.splice(errors.indexOf(error), 1);
                }

                expect(errors).toHaveLength(0);
            } catch (error) {
                console.log(
                    `factoring-unit doesn't exist OR fees & roi already added [ADD_FU_FEES_AND_ROI_INVALID_VALIDATION]`
                );
            }
        });
    });

    describe("ADD_FU_FEES_AND_ROI", () => {
        it("For valid input: Should return an Success string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> OPEN-FOR-FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            try {
                // CLICK ON ADD BUYER-SELLER FEES & ROI -> ANY
                await findByXPathAndClick(driver, `//button[@name="approve-btn"]`);

                // FILL THE FORM
                for (let field of Object.keys(ADD_FU_FEES_AND_ROI)) {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//input[@id="${field}"]`,
                        ADD_FU_FEES_AND_ROI[field]
                    );
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@name="process"]');

                // FORM SUCCESS RESPONSE
                resposne = await findByXPathAndWaitForText(
                    driver,
                    "//div[@class='ant-notification-notice-message']",
                    message.FEE_AND_ROI_ADDED
                );

                // CHECKING FOR SUCCESS
                expect(resposne).toBe("Fees & ROI Added Successfully");
            } catch (error) {
                console.log(
                    `factoring-unit doesn't exist OR fees & roi already added [ADD_FU_FEES_AND_ROI]`
                );
            }
        });
    });
});
