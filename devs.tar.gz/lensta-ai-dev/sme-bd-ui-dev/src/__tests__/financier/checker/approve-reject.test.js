const { getURL, getDriver, sleep, sleepEvents } = require("../../config");
const { message } = require("../../message");
const {
    APPROVE_FU_REQUIRED_VALIDATION,
    APPROVE_FU,
    LOGIN,
} = require("./approve-reject.data");
const {
    findAllByXPathAndWaitForLocated,
    findByXPathAndSendKeys,
    findByXPathClearAndSendKeys,
    findByXPathAndClick,
    findByXPathAndWaitForText,
    findByXPathAndWaitForLocatedAndClick,
} = require("../../generic-service");

module.exports = describe("Financier Checker Open-For-Finance Approve Reject Tests", () => {
    let driver,
        resposne,
        error,
        errors = [];

    beforeEach(async () => {
        driver = await getDriver();
        await driver.get(getURL("login"));
    });

    afterEach(async () => {
        await driver.quit();
    });

    describe("APPROVE_FU_REQUIRED_VALIDATION", () => {
        it("For empty input: Should return an Error string", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> OPEN-FOR-FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            try {
                // CLICK ON ADD BUYER-SELLER FEES & ROI -> ANY
                await findByXPathAndClick(driver, `//button[@name="approve-btn"]`);

                // FILL THE FORM
                for (let field of Object.keys(APPROVE_FU_REQUIRED_VALIDATION)) {
                    await findByXPathAndSendKeys(
                        driver,
                        `//textarea[@id="${field}"]`,
                        APPROVE_FU_REQUIRED_VALIDATION[field].value
                    );
                    errors.push(APPROVE_FU_REQUIRED_VALIDATION[field].error);
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@name="approve"]');

                // WAIT TILL ERRORS LOCATED
                await sleep(sleepEvents.loading);

                // FORM ERRORS RESPONSE
                resposne = await findAllByXPathAndWaitForLocated(
                    driver,
                    "//div[@class='ant-form-item-explain-error']"
                );

                // CHECKING FOR ERROR EXIST
                expect(resposne).toHaveLength(errors.length);

                for (let index = 0; index < resposne.length; index++) {
                    error = await resposne[index].getText();
                    expect(errors).toContain(error);
                    errors.splice(errors.indexOf(error), 1);
                }

                expect(errors).toHaveLength(0);
            } catch (error) {
                console.log(
                    `factoring-unit doesn't exits OR first add roi & fees. [APPROVE_FU_REQUIRED_VALIDATION]`
                );
            }
        });
    });

    describe("APPROVE_FU", () => {
        it("APPROVE_FU", async () => {
            // LOGIN TO FINANCIER ADMIN
            await findByXPathAndSendKeys(driver, '//input[@id="email"]', LOGIN.email);
            await findByXPathAndSendKeys(
                driver,
                '//input[@id="password"]',
                LOGIN.password
            );
            await findByXPathAndClick(driver, '//button[@type="submit"]');

            // NAVIGATE TO FINANCIER -> OPEN-FOR-FINANCE TAB
            await findByXPathAndWaitForLocatedAndClick(driver, "//ul/li[3]");
            await findByXPathAndWaitForLocatedAndClick(
                driver,
                '//ul[@class="ant-menu ant-menu-sub ant-menu-vertical"]/li[1]'
            );

            // WAIT FOR WHILE
            await sleep(sleepEvents.loading);

            try {
                // CLICK ON ADD BUYER-SELLER FEES & ROI -> ANY
                await findByXPathAndClick(driver, `//button[@name="approve-btn"]`);

                // FILL THE FORM
                for (let field of Object.keys(APPROVE_FU)) {
                    await findByXPathClearAndSendKeys(
                        driver,
                        `//textarea[@id="${field}"]`,
                        APPROVE_FU[field]
                    );
                }

                // SUBMIT FORM
                await findByXPathAndClick(driver, '//button[@name="approve"]');

                // FORM SUCCESS RESPONSE
                resposne = await findByXPathAndWaitForText(
                    driver,
                    "//div[@class='ant-notification-notice-message']",
                    message.OPEN_FOR_FINANCE_APPROVED
                );

                // CHECKING FOR SUCCESS
                expect(resposne).toBe("Factoring Unit Sent For Finance Successfully");
            } catch (error) {
                console.log(
                    `factoring-unit doesn't exits OR first add roi & fees. [APPROVE_FU]`
                );
            }
        });
    });
});
