import { userTypes } from "./types";

const reducer = (state = [], action) => {
    switch (action.type) {
        case userTypes.GET_USER_LOADING:
            return {
                ...state,
                loadingUser: true,
                users: {},
            };
        /* falls through */

        case userTypes.GET_USER_SUCCESS: {
            const users = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });

            return {
                ...state,
                loadingUser: false,
                users: {
                    data: users,
                    count: action?.payload?.count,
                },
            };
            /* falls through */
        }

        case userTypes.GET_USER_FAILURE:
            return {
                ...state,
                loadingUser: false,
                users: {},
            };
        /* falls through */

        case userTypes.GET_USER_BY_ENTITY_LOADING:
            return {
                ...state,
                loadingCheckerLevelUser: true,
                checkerLevelUser: [],
            };
        /* falls through */

        case userTypes.GET_USER_BY_ENTITY_SUCCESS: {
            return {
                ...state,
                loadingCheckerLevelUser: false,
                checkerLevelUser: action.payload,
            };
            /* falls through */
        }

        case userTypes.GET_USER_BY_ENTITY_FAILURE:
            return {
                ...state,
                loadingCheckerLevelUser: false,
                checkerLevelUser: [],
            };
        /* falls through */

        case userTypes.GET_PROFILE_LOADING:
            return {
                ...state,
                loadingProfile: true,
                profile: undefined,
            };
        /* falls through */

        case userTypes.GET_PROFILE_SUCCESS: {
            return {
                ...state,
                loadingProfile: false,
                profile: action.payload,
            };
            /* falls through */
        }

        case userTypes.GET_PROFILE_FAILURE:
            return {
                ...state,
                loadingProfile: false,
                profile: undefined,
            };
        /* falls through */

        case userTypes.EDIT_USER:
            return {
                ...state,
                editUser: action.payload,
            };
        /* falls through */

        case userTypes.PLATFORM_USER_FILTER_QUERY: {
            return {
                ...state,
                platformUserQuery: action.payload,
            };
            /* falls through */
        }
        default:
            return state;
        /* falls through */
    }
};

export default reducer;
