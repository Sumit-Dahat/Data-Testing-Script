import { store } from "../index";
import { userTypes } from "./types";

export const editUser = (openEdit, data) => {
    store.dispatch({
        type: userTypes.EDIT_USER,
        payload: { data, openEdit },
    });
};

export const setUserFilterQuery = (query) => {
    store.dispatch({
        type: userTypes.PLATFORM_USER_FILTER_QUERY,
        payload: query,
    });
};
