import {
    openForFinanceTypes,
    factoredUnitTypes,
    notFactoredUnitTypes,
    transactionHistoryTypes,
    factoringUnitTypes,
    invoiceDocumentTypes,
    factoringUnitByIdTypes,
    checkerLevelTypes,
    acceptBankFinance,
    paymentTypes,
} from "./types";

const reducer = (state = {}, action) => {
    switch (action.type) {
        case factoringUnitByIdTypes.GET_FACTORING_UNIT_BY_ID_LOADING:
            return {
                ...state,
                loadingFactoringUnitById: true,
                factoringUnitById: [],
            };
        /* falls through */

        case factoringUnitByIdTypes.GET_FACTORING_UNIT_BY_ID_FAILURE:
            return {
                ...state,
                loadingFactoringUnitById: false,
                factoringUnitById: [],
            };
        /* falls through */

        case factoringUnitByIdTypes.GET_FACTORING_UNIT_BY_ID_SUCCESS:
            return {
                ...state,
                loadingFactoringUnitById: false,
                factoringUnitById: action.payload,
            };
        /* falls through */

        case factoringUnitTypes.GET_FACTORING_UNIT_FAILURE:
            return {
                ...state,
                loadingFactoringUnit: false,
                factoringUnit: {},
            };
        /* falls through */

        case factoringUnitTypes.GET_FACTORING_UNIT_LOADING:
            return {
                ...state,
                loadingFactoringUnit: true,
                factoringUnit: {},
            };
        /* falls through */

        case factoringUnitTypes.GET_FACTORING_UNIT_SUCCESS:
            const factoringUnit = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingFactoringUnit: false,
                factoringUnit: {
                    data: factoringUnit,
                    count: action?.payload?.count,
                },
            };

        case acceptBankFinance.GET_ACCEPT_BANK_FINANCE_FAILURE:
            return {
                ...state,
                loadingacceptBankFinance: false,
                acceptBankFinance: {},
            };
        /* falls through */

        case acceptBankFinance.GET_ACCEPT_BANK_FINANCE_LOADING:
            return {
                ...state,
                loadingacceptBankFinance: true,
                acceptBankFinance: {},
            };
        /* falls through */

        case acceptBankFinance.GET_ACCEPT_BANK_FINANCE_SUCCESS:
            const acceptBankFinanceData = action?.payload?.data?.map(
                (item, index) => {
                    item["key"] = index;
                    return item;
                }
            );
            return {
                ...state,
                loadingacceptBankFinance: false,
                acceptBankFinance: {
                    data: acceptBankFinanceData,
                    count: action?.payload?.count,
                },
            };
        /* falls through */

        case checkerLevelTypes.GET_CHECKER_LEVEL_FAILURE:
            return {
                ...state,
                loadingCheckerLevel: false,
                checkerLevel: {},
            };
        /* falls through */

        case checkerLevelTypes.GET_CHECKER_LEVEL_LOADING:
            return {
                ...state,
                loadingCheckerLevel: true,
                checkerLevel: {},
            };
        /* falls through */

        case checkerLevelTypes.GET_CHECKER_LEVEL_SUCCESS:
            const checkerLevelData = action?.payload?.data?.map(
                (item, index) => {
                    item["key"] = index;
                    return item;
                }
            );
            return {
                ...state,
                loadingCheckerLevel: false,
                checkerLevel: {
                    data: checkerLevelData,
                    count: action?.payload?.count,
                },
            };
        /* falls through */

        case checkerLevelTypes.EDIT_CHECKER_LEVEL:
            return {
                ...state,
                editCheckerLevel: action.payload,
            };
        /* falls through */

        case factoringUnitTypes.EDIT_FACTORING_UNIT:
            return {
                ...state,
                editFactoringUnit: action.payload,
            };
        /* falls through */

        case openForFinanceTypes.GET_OPEN_FOR_FINANCE_FAILURE:
            return {
                ...state,
                loadingOpenForFinance: false,
                openForFinance: {},
            };
        /* falls through */
        case openForFinanceTypes.GET_OPEN_FOR_FINANCE_SUCCESS:
            const openForFinance = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingOpenForFinance: false,
                openForFinance: {
                    data: openForFinance,
                    count: action?.payload?.count,
                },
            };
        /* falls through */

        case openForFinanceTypes.GET_OPEN_FOR_FINANCE_LOADING:
            return {
                ...state,
                loadingOpenForFinance: true,
                openForFinance: {},
            };
        /* falls through */

        case factoredUnitTypes.GET_FACTORED_UNIT_FAILURE:
            return {
                ...state,
                loadingFactoredUnit: false,
                factoredUnit: {},
            };
        /* falls through */

        case factoredUnitTypes.GET_FACTORED_UNIT_SUCCESS:
            const factoredUnit = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingFactoredUnit: false,
                factoredUnit: {
                    data: factoredUnit,
                    count: action?.payload?.count,
                },
            };
        /* falls through */

        case factoredUnitTypes.GET_FACTORED_UNIT_LOADING:
            return {
                ...state,
                loadingFactoredUnit: true,
                factoredUnit: {},
            };
        /* falls through */
        case notFactoredUnitTypes.GET_NOT_FACTORED_UNIT_FAILURE:
            return {
                ...state,
                loadingNotFactoredUnit: false,
                notFactoredUnit: {},
            };
        /* falls through */
        case notFactoredUnitTypes.GET_NOT_FACTORED_UNIT_SUCCESS:
            const notFactoredUnit = action?.payload?.data?.map(
                (item, index) => {
                    item["key"] = index;
                    return item;
                }
            );
            return {
                ...state,
                loadingNotFactoredUnit: false,
                notFactoredUnit: {
                    data: notFactoredUnit,
                    count: action?.payload?.count,
                },
            };
        /* falls through */

        case notFactoredUnitTypes.GET_NOT_FACTORED_UNIT_LOADING:
            return {
                ...state,
                loadingNotFactoredUnit: true,
                notFactoredUnit: {},
            };
        /* falls through */
        case paymentTypes.GET_PAYMENTS_FAILURE:
            return {
                ...state,
                loadingFUPayment: false,
                fUPayment: {},
            };
        /* falls through */
        case paymentTypes.GET_PAYMENTS_SUCCESS:
            console.log(action.payload)
            const paymentData = action?.payload?.data?.data?.map(
                (item, index) => {
                    item["key"] = index;
                    return item;
                }
            );
            console.log("COMIFDSF")
            return {
                ...state,
                loadingFUPayment: false,
                fUPayment: {
                    data: paymentData,
                    count: action?.payload?.count,
                    totalPaymentAmount: action?.payload?.data?.totalPaymentAmount
                },
            };
        /* falls through */
        case paymentTypes.GET_PAYMENTS_LOADING:
            return {
                ...state,
                loadingFUPayment: true,
                fUPayment: {},
            };
        /* falls through */
        case transactionHistoryTypes.GET_TRANSACTION_HISTORY_FAILURE:
            return {
                ...state,
                loadingTransactionHistory: false,
                transactionHistory: {},
            };
        /* falls through */
        case transactionHistoryTypes.GET_TRANSACTION_HISTORY_SUCCESS:
            const transactionHistory = action?.payload?.data?.data?.map(
                (item, index) => {
                    item["key"] = index;
                    return item;
                }
            );
            return {
                ...state,
                loadingTransactionHistory: false,
                transactionHistory: {
                    data: transactionHistory,
                    count: action?.payload?.count,
                    totalTransactionAmount: action?.payload?.data?.totalTransactionAmount
                },
            };
        /* falls through */

        case transactionHistoryTypes.GET_TRANSACTION_HISTORY_LOADING:
            return {
                ...state,
                loadingTransactionHistory: true,
                transactionHistory: {},
            };
        /* falls through */

        case factoringUnitTypes.FACTORING_UNIT_FILTER_QUERY:
            return {
                ...state,
                factoringUnitQuery: action.payload,
            };
        /* falls through */

        case factoredUnitTypes.FACTORED_UNIT_FILTER_QUERY:
            return {
                ...state,
                factoredUnitQuery: action.payload,
            };
        /* falls through */

        case openForFinanceTypes.OPEN_FOR_FINANCE_FILTER_QUERY:
            return {
                ...state,
                openForFinanceQuery: action.payload,
            };
        /* falls through */

        case notFactoredUnitTypes.NOT_FACTORED_UNIT_FILTER_QUERY:
            return {
                ...state,
                notFactoredUnitQuery: action.payload,
            };
        /* falls through */

        case invoiceDocumentTypes.GET_INVOICE_DOCUMENT_FAILURE:
            return {
                ...state,
                loadingInvoiceDocument: false,
                invoiceDocument: [],
            };
        /* falls through */
        case invoiceDocumentTypes.GET_INVOICE_DOCUMENT_SUCCESS:
            const invoiceDocument = action?.payload?.data?.map(
                (item, index) => {
                    item["key"] = index;
                    return item;
                }
            );

            return {
                ...state,
                loadingInvoiceDocument: false,
                invoiceDocument: {
                    data: invoiceDocument,
                    count: action?.payload?.count,
                },
            };
        /* falls through */

        case invoiceDocumentTypes.GET_INVOICE_DOCUMENT_LOADING:
            return {
                ...state,
                loadingInvoiceDocument: true,
                invoiceDocument: [],
            };
        /* falls through */
        default:
            return state;
        /* falls through */
    }
};

export default reducer;
