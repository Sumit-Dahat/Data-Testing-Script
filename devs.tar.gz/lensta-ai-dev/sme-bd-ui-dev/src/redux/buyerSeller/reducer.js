import { buyerSellerTypes } from "./types";

const reducer = (state = {}, action) => {
    switch (action.type) {
        case buyerSellerTypes.GET_BUYER_SELLER_FAILURE:
            return {
                ...state,
                loadingBuyerSeller: false,
                buyerSeller: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_SUCCESS: {
            const buyerSeller = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingBuyerSeller: false,
                buyerSeller: {
                    data: buyerSeller,
                    count: action?.payload?.count,
                },
            };
            /* falls through */
        }
        case buyerSellerTypes.GET_BUYER_SELLER_LOADING:
            return {
                ...state,
                loadingBuyerSeller: true,
                buyerSeller: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_BUYER_SELLER_PROFILE_FAILURE:
            return {
                ...state,
                loadingBuyerSellerProfile: false,
                buyerSellerProfile: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_PROFILE_LOADING: {
            return {
                ...state,
                loadingBuyerSellerProfile: true,
                buyerSellerProfile: {},
            };
            /* falls through */
        }
        case buyerSellerTypes.GET_BUYER_SELLER_PROFILE_SUCCESS:
            return {
                ...state,
                loadingBuyerSellerProfile: false,
                buyerSellerProfile: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.GET_ADDRESS_FAILURE:
            return {
                ...state,
                loadingAddress: false,
                address: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_ADDRESS_LOADING:
            return {
                ...state,
                loadingAddress: true,
                address: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_ADDRESS_SUCCESS: {
            const address = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingAddress: false,
                address: {
                    data: address,
                    count: action.payload.count,
                },
            };
            /* falls through */
        }
        case buyerSellerTypes.GET_BANKS_SUCCESS: {
            const banks = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingBank: false,
                bank: {
                    data: banks,
                    count: action.payload.count,
                },
            };
            /* falls through */
        }

        case buyerSellerTypes.GET_BANKS_LOADING:
            return {
                ...state,
                loadingBank: true,
                bank: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_BANKS_FAILURE:
            return {
                ...state,
                loadingBank: false,
                bank: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_PROMOTER_SUCCESS: {
            const promoters = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingPromoters: false,
                promoters: {
                    data: promoters,
                    count: action.payload.count,
                },
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_PROMOTER_LOADING:
            return {
                ...state,
                loadingPromoters: true,
                promoters: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_PROMOTER_FAILURE:
            return {
                ...state,
                loadingPromoters: false,
                promoters: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_DOCUMENT_SUCCESS: {
            const documents = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingDocument: false,
                documents: {
                    data: documents.filter(document => document.title !== "Bank-Statement XLXS Reports"),
                    count: action.payload.count,
                },
            };
            /* falls through */
        }

        case buyerSellerTypes.GET_DOCUMENT_LOADING:
            return {
                ...state,
                loadingDocument: true,
                documents: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_DOCUMENT_FAILURE:
            return {
                ...state,
                loadingDocument: false,
                documents: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_LINK_FAILURE:
            return {
                ...state,
                loadingBsLink: false,
                buyerSellerLink: [],
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_LINK_LOADING:
            return {
                ...state,
                loadingBsLink: true,
                buyerSellerLink: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_LINK_SUCCESS:
            const buyerSellerLink = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });

            return {
                ...state,
                loadingBsLink: false,
                buyerSellerLink: {
                    data: buyerSellerLink,
                    count: action?.payload?.count,
                },
            };

        /* falls through */
        case buyerSellerTypes.GET_LINKED_GST_FAILURE:
            return {
                ...state,
                loadingLinkedGst: false,
                linkedGst: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_LINKED_GST_LOADING:
            return {
                ...state,
                loadingLinkedGst: true,
                linkedGst: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_LINKED_GST_SUCCESS:
            const linkedGst = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });

            return {
                ...state,
                loadingLinkedGst: false,
                linkedGst: {
                    data: linkedGst,
                    count: action?.payload?.count,
                },
            };
        /* falls through */

        case buyerSellerTypes.GET_IFSC_DETAILS_FAILURE:
            return {
                ...state,
                loadingifscData: false,
                ifscData: [],
            };
        /* falls through */

        case buyerSellerTypes.GET_IFSC_DETAILS_LOADING:
            return {
                ...state,
                loadingifscData: true,
                ifscData: [],
            };
        /* falls through */

        case buyerSellerTypes.GET_IFSC_DETAILS_SUCCESS:
            return {
                ...state,
                loadingifscData: false,
                ifscData: action.payload,
            };
        /* falls through */

        case buyerSellerTypes.GET_PIN_CODE_DETAILS_FAILURE:
            return {
                ...state,
                loadingpinCodeData: false,
                pinData: [],
            };
        /* falls through */

        case buyerSellerTypes.GET_PIN_CODE_DETAILS_LOADING:
            return {
                ...state,
                loadingpinCodeData: true,
                pinData: [],
            };
        /* falls through */
        case buyerSellerTypes.GET_PIN_CODE_DETAILS_SUCCESS:
            return {
                ...state,
                loadingpinCodeData: false,
                pinData: action.payload,
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_INVOICE_FAILURE:
            return {
                ...state,
                loadingInvoiceData: false,
                invoiceData: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_INVOICE_LOADING:
            return {
                ...state,
                loadingInvoiceData: true,
                invoiceData: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_BUYER_SELLER_INVOICE_SUCCESS:
            const invoiceData = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });

            return {
                ...state,
                loadingInvoiceData: false,
                invoiceData: {
                    data: invoiceData,
                    count: action?.payload?.count,
                },
            };

        case buyerSellerTypes.GET_BUYER_SELLER_INVOICE_FAILURE_BY_ID:
            return {
                ...state,
                loadingInvoiceById: false,
                invoiceById: {},
            };
        /* falls through */

        case buyerSellerTypes.GET_BUYER_SELLER_INVOICE_LOADING_BY_ID:
            return {
                ...state,
                loadingInvoiceById: true,
                invoiceById: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_BUYER_SELLER_INVOICE_SUCCESS_BY_ID:
            return {
                ...state,
                loadingInvoiceById: false,
                invoiceById: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.EDIT_BUYER_SELLER:
            return {
                ...state,
                editBuyerSeller: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.EDIT_INVOICE:
            return {
                ...state,
                editInvoice: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.EDIT_ADDRESS:
            return {
                ...state,
                editAddress: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.EDIT_BANK:
            return {
                ...state,
                editBank: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.EDIT_PROMOTER:
            return {
                ...state,
                editPromter: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.EDIT_BUYER_SELLER_LINK:
            return {
                ...state,
                editBuyerSellerLink: action.payload,
            };
        /* falls through */

        case buyerSellerTypes.BUYER_SELLER_FILTER_QUERY:
            return {
                ...state,
                buyerSellerQuery: action.payload,
            };
        /* falls through */
        case buyerSellerTypes.USER_FILTER_QUERY:
            return {
                ...state,
                financierUserFilterQuery: action.payload,
            };
        case buyerSellerTypes.GET_PAN_KYC_FAILURE:
            return {
                ...state,
                loadingPanKycDetails: false,
                panKycDetails: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_PAN_KYC_LOADING: {
            return {
                ...state,
                loadingPanKycDetails: true,
                panKycDetails: {},
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_PAN_KYC_SUCCESS:
            return {
                ...state,
                loadingPanKycDetails: false,
                panKycDetails: action.payload.data,
            };
        /* falls through */
        case buyerSellerTypes.GET_GST_KYC_FAILURE:
            return {
                ...state,
                loadingGstKycDetails: false,
                gstKycDetails: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_GST_KYC_LOAING: {
            return {
                ...state,
                loadingGstKycDetails: true,
                gstKycDetails: {},
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_GST_KYC_SUCCESS:
            return {
                ...state,
                loadingGstKycDetails: false,
                gstKycDetails: action.payload.data,
            };
        /* falls through */
        case buyerSellerTypes.GET_GST_ITR_KYC_FAILURE:
            return {
                ...state,
                loadingGstItrDetails: false,
                gstItrDetails: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_GST_ITR_KYC_LOAING: {
            return {
                ...state,
                loadingGstItrDetails: true,
                gstItrDetails: {},
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_GST_ITR_KYC_SUCCESS:
            return {
                ...state,
                loadingGstItrDetails: false,
                gstItrDetails: action.payload.data,
            };
        /* falls through */
        case buyerSellerTypes.GET_UDYAM_KYC_FAILURE:
            return {
                ...state,
                loadingUdyamKycDetails: false,
                udyamKycDetails: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_UDYAM_KYC_LOADING: {
            return {
                ...state,
                loadingUdyamKycDetails: true,
                udyamKycDetails: {},
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_UDYAM_KYC_SUCCESS:
            return {
                ...state,
                loadingUdyamKycDetails: false,
                udyamKycDetails: action.payload.data,
            };
        /* falls through */
        case buyerSellerTypes.GET_BANK_KYC_FAILURE:
            return {
                ...state,
                loadingBankKycDetails: false,
                bankKycDetails: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_BANK_KYC_LOADING: {
            return {
                ...state,
                loadingBankKycDetails: true,
                bankKycDetails: {},
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_BANK_KYC_SUCCESS:
            return {
                ...state,
                loadingBankKycDetails: false,
                bankKycDetails: action.payload.data,
            };
        /* falls through */
        case buyerSellerTypes.GET_BANK_STMT_FAILURE:
            return {
                ...state,
                loadingBankStmtDetails: false,
                bankStmtDetails: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_BANK_STMT_LOADING: {
            return {
                ...state,
                loadingBankStmtDetails: true,
                bankStmtDetails: {},
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_BANK_STMT_SUCCESS:
            return {
                ...state,
                loadingBankStmtDetails: false,
                bankStmtDetails: action.payload.data,
            };
        /* falls through */
        case buyerSellerTypes.GET_AADHAAR_KYC_FAILURE:
            return {
                ...state,
                loadingAadhaarKycDetails: false,
                aadhaarKycDetails: {},
            };
        /* falls through */
        case buyerSellerTypes.GET_AADHAAR_KYC_LOADING: {
            return {
                ...state,
                loadingAadhaarKycDetails: true,
                aadhaarKycDetails: {},
            };
        }
        /* falls through */
        case buyerSellerTypes.GET_AADHAAR_KYC_SUCCESS:
            return {
                ...state,
                loadingAadhaarKycDetails: false,
                aadhaarKycDetails: action.payload.data,
            };
        /* falls through */
        default:
            return state;
        /* falls through */
    }
};

export default reducer;
