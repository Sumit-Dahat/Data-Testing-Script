import { store } from "../index";
import { financierTypes } from "./types";

export const editFinancier = (openEdit, data) => {
    store.dispatch({
        type: financierTypes.EDIT_FINANCIER,
        payload: { data, openEdit },
    });
};

export const editFinancierBank = (openEdit, data) => {
    store.dispatch({
        type: financierTypes.EDIT_FINANCIER_BANK,
        payload: { data, openEdit },
    });
};

export const setFinancierFilterQuery = (query) => {
    store.dispatch({
        type: financierTypes.FINANCIER_FILTER_QUERY,
        payload: query,
    });
};
