import { financierTypes } from "./types";

const reducer = (state = {}, action) => {
    switch (action.type) {
        case financierTypes.GET_FINANCIER_LOADING:
            return {
                ...state,
                loadingFinancier: true,
                financiers: {},
            };
        /* falls through */

        case financierTypes.GET_FINANCIER_SUCCESS: {
            const financiers = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingFinancier: false,
                financiers: {
                    data: financiers,
                    count: action?.payload?.count,
                },
            };
            /* falls through */
        }

        case financierTypes.GET_FINANCIER_PROFILE_LOADING:
            return {
                ...state,
                loadingFinancierProfile: true,
                financierProfile: {},
            };
        /* falls through */

        case financierTypes.GET_FINANCIER_PROFILE_SUCCESS: {
            return {
                ...state,
                loadingFinancierProfile: false,
                financierProfile: action.payload,
            };
            /* falls through */
        }

        case financierTypes.GET_FINANCIER_PROFILE_FAILURE:
            return {
                ...state,
                loadingFinancierProfile: false,
                financierProfile: {},
            };
        /* falls through */

        case financierTypes.GET_FINANCIER_FAILURE:
            return {
                ...state,
                loadingFinancier: false,
                financiers: {},
            };

        case financierTypes.GET_FINANCIER_BANKS_SUCCESS: {
            const banks = action?.payload?.data?.map((item, index) => {
                item["key"] = index;
                return item;
            });
            return {
                ...state,
                loadingFinancierBank: false,
                financierBank: {
                    data: banks,
                    count: action.payload.count,
                },
            };
            /* falls through */
        }

        case financierTypes.GET_FINANCIER_BANKS_LOADING:
            return {
                ...state,
                loadingFinancierBank: true,
                financierBank: {},
            };
        /* falls through */

        case financierTypes.GET_FINANCIER_BANKS_FAILURE:
            return {
                ...state,
                loadingFinancierBank: false,
                financierBank: {},
            };

        /* falls through */
        case financierTypes.EDIT_FINANCIER:
            return {
                ...state,
                editFinancier: action.payload,
            };

        case financierTypes.EDIT_FINANCIER_BANK:
            return {
                ...state,
                editFinancierBank: action.payload,
            };

        case financierTypes.FINANCIER_FILTER_QUERY: {
            return {
                ...state,
                financierQuery: action.payload,
            };
            /* falls through */
        }

        default:
            return state;
        /* falls through */
    }
};

export default reducer;
