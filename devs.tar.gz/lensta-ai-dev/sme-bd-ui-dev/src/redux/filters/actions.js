import { store } from "../index";
import { filterTypes } from "./types";

export const setFilterQuery = (query) => {
    store.dispatch({
        type: filterTypes.FILTER_QUERY,
        payload: query,
    });
};

export const setDocFilterQuery = (query) => {
    store.dispatch({
        type: filterTypes.DOC_QUERY,
        payload: query,
    });
};

export const setFilter = (query) => {
    store.dispatch({
        type: filterTypes.SET_FILTER,
        payload: query,
    });
}