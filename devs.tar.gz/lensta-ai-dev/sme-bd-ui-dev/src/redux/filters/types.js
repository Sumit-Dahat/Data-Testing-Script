export const filterTypes = {
    FILTER_QUERY: "FILTER_QUERY",
    DOC_QUERY: "DOC_QUERY",
    SET_FILTER:"SET_FILTER"
};
