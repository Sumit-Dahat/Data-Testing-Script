import { filterTypes } from "./types";

const reducer = (state = {}, action) => {
    switch (action.type) {
        case filterTypes.FILTER_QUERY:
            return {
                ...state,
                query: action.payload,
            };
        /* falls through */
        case filterTypes.DOC_QUERY:
            return {
                ...state,
                docquery: action.payload,
            };
        /* falls through */
        case filterTypes.SET_FILTER:
            return {
                ...state,
                filter: action.payload,
            };
        default:
            return state;
        /* falls through */
    }
};

export default reducer;
