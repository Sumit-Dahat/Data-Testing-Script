#!/bin/bash

for folder in "$@"
do
	#  Stop running background process
	pm2 stop $folder

	# Go to project directory
	cd $folder

	# Checkout & pull latest 'Test' branch changes
	git checkout Test
	git pull origin Test

	# Re-install Node modules
	rm -rf node_modules
	npm i

	# Excluding 'sme-bd-notifications' micro-service from DB reset
	if [[ $folder != *"notification"* ]]; then
		# Reset DB
        	echo -e "\nEnter password to drop DB"
        	dropdb -e $folder -U postgres -p 5432

        	echo -e "\nEnter password to create DB"
	        createdb -e $folder -U postgres -p 5432
	fi

	# Restart background process
	pm2 restart $folder
	cd ..
done