const { StatusCodes } = require("http-status-codes");
const FUTxnHelpers = require('../../helpers/financier').FUTxn;
const FUHelpers = require('../../helpers/financier').factoringUnit;
const { applyLimitAndOffsetParams } = require("../../services/generic-query.service");
const sequelize = require("sequelize")

const createAnFUTxnCntrl = async (req, res, next) => {
    try {
        req.body.factoringUnitNo = req.params.factoringUnitNo;

        const FUTxn = await FUTxnHelpers.createAnFUTxn(req.body);

        if (FUTxn.error) {
            return next(FUTxn.error);
        }

        let FUTxns = await FUTxnHelpers.getAllFUTxns({
            where: {
                factoringUnitNo: req.params.factoringUnitNo
            },
            attributes: [
                [sequelize.fn('SUM', sequelize.col('transactionAmount')), 'totalTransactionAmount'],
            ],
        });

        const factoringUnit = await FUHelpers.getAnFUByFUNo(req.params.factoringUnitNo, {
            include: ['invoices'],
            attributes: {
                exclude: ['buyerSellerLinkId', 'nextCheckerUserId']
            }
        });

        if (
            FUTxns.data[0].dataValues.totalTransactionAmount >=  (
                factoringUnit.data.factoringAmount + 
                factoringUnit.data.buyerFees + 
                factoringUnit.data.buyerInterest
            ))  
        {
            const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, { status: "PAYMENT_CLOSED" });

            if (updatedFU.error) {
                return next(updatedFU.error);
            }
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Transaction added successfully.',
            data: FUTxn.data
        });

    } catch (error) {
        next(error);
    }
}
const getFUTxnsByFUNoCntrl = async (req, res, next) => {
    try {

        let FUTxns = await FUTxnHelpers.getAllFUTxns({
            where: [req.query, {
                factoringUnitNo: req.params.factoringUnitNo
            }]
        });

        if (FUTxns.error) {
            return next(FUTxns.error);
        }

        const resultLength = FUTxns.data.length;

        FUTxns.totalTransactionAmount = FUTxns.data.reduce((prevTxns, currTxns) => prevTxns + currTxns.transactionAmount, 0);

        FUTxns.data = [...applyLimitAndOffsetParams(
            FUTxns.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: {
                data: FUTxns.data,
                totalTransactionAmount: FUTxns.totalTransactionAmount
            }
        });

    } catch (error) {
        next(error);
    }
}
const getAnFUTxnByTxnIdCntrl = async (req, res, next) => {
    try {
        const FUTxn = await FUTxnHelpers.getAnFUTxnByTxnId(req.params.transactionId);

        if (FUTxn.error) {
            return next(FUTxn.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: FUTxn.data
        });

    } catch (error) {
        next(error);
    }
}
const updateAnFUTxnByTxnIdCntrl = async (req, res, next) => {
    try {

        req.body.factoringUnitNo = req.params.factoringUnitNo;

        const updatedFUTxn = await FUTxnHelpers.updateAnFUTxnByTxnId(req.params.transactionId, req.body);

        if (updatedFUTxn.error) {
            return next(updatedFUTxn.error);
        }

        let FUTxns = await FUTxnHelpers.getAllFUTxns({
            where: {
                factoringUnitNo: req.params.factoringUnitNo
            },
            attributes: [
                [sequelize.fn('SUM', sequelize.col('transactionAmount')), 'totalTransactionAmount'],
            ],
        });

        const factoringUnit = await FUHelpers.getAnFUByFUNo(req.params.factoringUnitNo, {
            include: ['invoices'],
            attributes: {
                exclude: ['buyerSellerLinkId', 'nextCheckerUserId']
            }
        });

        if (FUTxns.data.totalTransactionAmount >= factoringUnit.data.factoringAmount) {

            const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, { status: "PAYMENT_CLOSED" });

            if (updatedFU.error) {
                return next(updatedFU.error);
            }
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Transaction updated successfully.',
            data: updatedFUTxn.data
        });

    } catch (error) {
        next(error);
    }
}

const deleteAnFUTxnByTxnIdCntrl = async (req, res, next) => {
    try {
        const deletedFUTxn = await FUTxnHelpers.deleteAnFUTxnByTxnId(req.params.transactionId);

        if (deletedFUTxn.error) {
            return next(deletedFUTxn.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Transaction deleted successfully.'
        });

    } catch (error) {
        next(error);
    }
}
module.exports = {
    createAnFUTxnCntrl,

    getFUTxnsByFUNoCntrl,
    getAnFUTxnByTxnIdCntrl,

    updateAnFUTxnByTxnIdCntrl,

    deleteAnFUTxnByTxnIdCntrl
}