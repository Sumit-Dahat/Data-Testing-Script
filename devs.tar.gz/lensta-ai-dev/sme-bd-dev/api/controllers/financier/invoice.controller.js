const nodeXLSX = require('node-xlsx');
const axios = require('axios');
const uuid = require('uuid');
const { APIError } = require("../../error");
const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services//generic-query.service");
const { appendFileMetadata } = require("../../services//generic.service");
const userHelpers = require('../../helpers/platform').user;
const invoiceHelpers = require('../../helpers/financier').invoice;
const invActionHelpers = require('../../helpers/financier').invoiceActionHistory;
const FUActionHelpers = require('../../helpers/financier').FUActionHistory;
const BSLinkHelpers = require('../../helpers/buyer-seller').buyerSellerLink;
const checkerLvlHelpers = require('../../helpers/platform/checker-level.helper');
const FUHelpers = require('../../helpers/financier/factoring-unit.helper');

const invInitialCheckerConfigCntrl = async (req, res, next) => {
    try {
        // Check if Buyer / Seller are linked or not
        const BSLinks = await BSLinkHelpers.getAllBSLinks({
            where: {
                buyerId: req.body.buyerId,
                sellerId: req.body.sellerId,
            },
            attributes: ['id', 'buyerId', 'sellerId']
        });

        if (BSLinks.error) {
            return next(BSLinks.error);
        }

        req.body = {
            ...req.body,
            approved: 0,
            nextCheckerUserId: null,
            buyerSellerLinkId: BSLinks.data[0].id
        };

        delete req.body.buyerId;
        delete req.body.sellerId;

        // Get Seller Checker Levels
        const sellerCheckerLvls = await checkerLvlHelpers.getAllCheckerLevels({
            where: [{
                '$user.entityId$': BSLinks.data[0].sellerId
            }],
            include: [
                {
                    model: db['Users'],
                    as: 'user',
                    attributes: ['id']
                }
            ],
            attributes: {
                exclude: ['userId']
            }
        });

        if (sellerCheckerLvls.error) {
            return next(sellerCheckerLvls.error);
        }

        // Set next checker user ID if Seller Checker Levels are present
        if (sellerCheckerLvls.data.length > 0) {
            req.body.nextCheckerUserId = sellerCheckerLvls.data[0].user.id;
            
        } else {
            // As Seller Checker Levels are absent, if set next checker user ID to Buyer Checker Levels if present else to Buyer Admin

            switch(req.user.userType) {
                case 'ADMIN': {
                    // Get Buyer Checker Levels
                    const buyerChckrLvls = await checkerLvlHelpers.getAllCheckerLevels({
                        where: [{
                            '$user.entityId$': BSLinks.data[0].buyerId
                        }],
                        include: [
                            {
                                model: db['Users'],
                                as: 'user',
                                attributes: ['id']
                            }
                        ],
                        attributes: {
                            exclude: ['userId']
                        }
                    });
            
                    if (buyerChckrLvls.error) {
                        return next(buyerChckrLvls.error);
                    }

                    // If Buyer Checker Levels are present, set next checker to Buyer Checker else set to Buyer Admin user ID
                    if (buyerChckrLvls.data.length > 0) {
                        req.body.nextCheckerUserId = buyerChckrLvls.data[0].user.id;

                    } else {
                        const buyerAdmin = await userHelpers.getAnUser({
                            where: {
                                entityId: BSLinks.data[0].buyerId,
                                userType: 'ADMIN'
                            },
                            attributes: ['id']
                        });

                        if (buyerAdmin.error) {
                            return next(buyerAdmin.error);
                        }

                        req.body.nextCheckerUserId = buyerAdmin.data.id;
                    }
                    
                    break;
                }

                case 'MAKER': {
                    const sellerAdmin = await userHelpers.getAnUser({
                        where: {
                            entityId: BSLinks.data[0].sellerId,
                            userType: 'ADMIN'
                        },
                        attributes: ['id']
                    });

                    if (sellerAdmin.error) {
                        return next(sellerAdmin.error);
                    }

                    req.body.nextCheckerUserId = sellerAdmin.data.id;

                    break;
                }

                default: {
                    break;
                }
            }

        }

    } catch(error) {
        next(error);
    }
};

const createAnInvFromJSONCntrl = async (req, res, next) => {
    try {
        await invInitialCheckerConfigCntrl(req, res, next);

        const createAnInvoiceTxn = await db.sequelize.transaction();

        /* Create an invoice */
        const invoice = await invoiceHelpers.createAnInvoice(req.body, {
            transaction: createAnInvoiceTxn
        });

        if (invoice.error) {
            await createAnInvoiceTxn.rollback();
            return next(invoice.error);
        }

        /* Create multiple Invoice Actions */
        const invoiceActions = await invActionHelpers.createMultipleInvActions([
            {
                invoiceId: invoice.data.id,
                action: 'CREATE',
                actionByUserId: invoice.data.createdByUserId,
                remarks: `Invoice created.`
            }
        ], {
            transaction: createAnInvoiceTxn
        });

        if (invoiceActions.error) {
            await createAnInvoiceTxn.rollback();
            return next(invoiceActions.error);
        }

        await createAnInvoiceTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Invoice added successfully.',
            data: invoice.data
        });

    } catch(error) {
        next(error);
    }
};

const createAnInvFromFileCntrl = async (req, res, next) => {
    try {
        if (
            !req.files ||
            (Object.keys(req.files).length == 0)
        ) {
            return next(new APIError('0129', StatusCodes.NOT_FOUND));
        }

        const sheets = nodeXLSX.parse(req.files.file.filepath, {
            defval: ''
        });

        let headerFields = [
            'Invoice No.',
            'Invoice Date (YYYY-MM-DD)',
            'Invoice Due Date (YYYY-MM-DD)',
            'Invoice Amount',
            'Discount Amount',
            'Tax Amount'
        ];

        if (sheets.length == 0) {
            return next(new APIError("0108", StatusCodes.BAD_REQUEST));
        }

        await invInitialCheckerConfigCntrl(req, res, next);

        let dateFormatRegEx = new RegExp(/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/);

        const tests = {
            hasValidHeaders: (row) => {
                return (
                    row.length == 6 &&
                    row.every((cell) => headerFields.indexOf(cell) >= 0)
                );
            },
            allRowsHaveNonNullValues: (sheetData) => {
                return (
                    sheetData.every(
                        (row) => (
                            row.length == 6 &&
                            row.every((cell) => Boolean(cell))
                        )
                    ) && sheetData.length > 1
                );
            },
            allRowsHaveValidDates: (sheetData) => {
                return (
                    sheetData.slice(1, sheetData.length).every(
                        (row) => (
                            (dateFormatRegEx.test(row[1])) &&
                            (dateFormatRegEx.test(row[2])) &&
                            (
                                new Date(row[1]).getTime() <= new Date(row[2]).getTime()
                            )
                        )
                    )
                )
            }
        };

        let lists = {
            invoices: [],
            invActions: []
        };

        sheets.forEach(async (sheet, sheetIdx) => {
            sheet.data = [...sheet.data.filter((subArray) => subArray.join('').length > 0).map((row) => {
                let values = [];

                row.forEach((elem) => {
                    values.push(
                        (typeof elem == 'string') ? elem.trim() : elem
                    );
                });

                return values;
            })];

            if (
                !tests.hasValidHeaders(sheet.data[0]) ||
                
                !tests.allRowsHaveNonNullValues(sheet.data) ||
                
                !tests.allRowsHaveValidDates(sheet.data) ||
                
                (sheet.data.length <= 1)
            ) {
                return next(new APIError("0108", StatusCodes.BAD_REQUEST));
            }

            if (sheetIdx > 0) {
                if (typeof sheet.data[0] == 'number') {
                    sheet.data[0] = sheet.data[0].toFixed(2);
                }
            }

            sheet.data.slice(1, sheet.data.length).forEach((row) => {
                const invoiceId = uuid.v4();

                // Add Invoice to list
                lists.invoices.push({
                    id: invoiceId,

                    invoiceNo: row[0],

                    invoiceDate: row[1],

                    invoiceDueDate: row[2],

                    invoiceAmount: row[3],

                    discountAmount: row[4],

                    taxAmount: row[5],

                    buyerSellerLinkId: req.body.buyerSellerLinkId,

                    approved: req.body.approved,

                    nextCheckerUserId: req.body.nextCheckerUserId,

                    createdByUserId: req.body.createdByUserId
                });

                // Add Invoice Action to list
                lists.invActions.push({
                    invoiceId: invoiceId,
                    action: 'CREATE',
                    actionByUserId: req.body.createdByUserId,
                    remarks: 'Invoice created.'
                });
            });
        });

        const createMultipleInvTxn = await db.sequelize.transaction();

        // Create multiple Invoices
        const invoices = await invoiceHelpers.createMultipleInvoices(lists.invoices, {
            transaction: createMultipleInvTxn
        });

        if (invoices.error) {
            await createMultipleInvTxn.rollback();
            return next(invoices.error);
        }

        // Create multiple Invoice Actions
        const invoiceActions = await invActionHelpers.createMultipleInvActions(lists.invActions, {
            transaction: createMultipleInvTxn
        });

        if (invoiceActions.error) {
            await createMultipleInvTxn.rollback();
            return next(invoiceActions.error);
        }

        await createMultipleInvTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Invoice(s) added successfully.'
        });

    } catch(error) {
        next(error);
    }
};

const getAnInvoiceByIdCntrl = async (req, res, next) => {
    try {
        const invoice = await invoiceHelpers.getAnInvoiceById(req.params.invoiceId, {
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                },
                {
                    model: db['Users'],
                    as: 'nextCheckerUser',
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                },
                {
                    model: db['InvoiceActionHistory'],
                    as: 'actionHistory',
                    include: [
                        {
                            model: db['Users'],
                            as: 'actionByUser',
                            attributes: {
                                exclude: ['password', 'encPassword']
                            }
                        }
                    ],
                    attributes: {
                        exclude: ['actionByUserId']
                    }
                },
                'documents'
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'nextCheckerUserId']
            }
        });

        if (invoice.error) {
            return next(invoice.error);
        }

        let invoiceDocIds = [...invoice.data.documents.map((doc) => doc.documentId)];

        let invoiceDetails = invoice.data.toJSON();

        if (invoiceDocIds.length > 0) {
            const invoiceDocs = await invoiceHelpers.getInvoiceDocsByIds(req.headers.authorization, invoiceDocIds);

            if (invoiceDocs.error) {
                return next(invoiceDocs.error);
            }

            invoiceDetails['documents'] = invoiceDocs.data.data;

        } else {
            invoiceDetails['documents'] = invoiceDocIds;
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: invoiceDetails
        });

    } catch(error) {
        next(error);
    }
};

const getAllInvoicesCntrl = async (req, res, next) => {
    try {
        let invoices = await invoiceHelpers.getAllInvoices({
            where: [req.query],
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                },
                {
                    model: db['Users'],
                    as: 'nextCheckerUser',
                    include: ['entity'],
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'nextCheckerUserId']
            }
        });

        if (invoices.error) {
            return next(invoices.error);
        }

        const resultLength = invoices.data.length;

        invoices.data = [...applyLimitAndOffsetParams(
            invoices.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: invoices.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllInvoiceDocumentsCntrl = async (req, res, next) => {
    try {
        const invoice = await invoiceHelpers.getAnInvoiceById(req.params.invoiceId, {
            include: ['documents']
        });

        if (invoice.error) {
            return next(invoice.error);
        }

        let invoiceDocIds = [...invoice.data.documents.map((doc) => doc.documentId)];

        let result;

        if (invoiceDocIds.length > 0) {
            const fetchedInvDocs = await invoiceHelpers.getInvoiceDocsByIds(req.headers.authorization, invoiceDocIds, req.query);

            if (fetchedInvDocs.error) {
                return next(fetchedInvDocs.error);
            }

            result = fetchedInvDocs.data;

        } else {
            result = {
                count: invoiceDocIds.length,
                data: invoiceDocIds
            };
        }

        res.status(StatusCodes.OK).json({
            error: null,
            ...result
        });

    } catch(error) {
        next(error);
    }
};

const getInvDocSignedURLCntrl = async (req, res, next) => {
    try {
        const docURL = await axios.get(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads/${req.params.documentId}/signed-url`, {
            headers: {
                Authorization: req.headers.authorization
            },
            params: {
                action: req.query.action,
                expiresIn: req.query.expiresIn
            }
        });

        if (docURL.status != 200) {
            return next(new APIError('0000', StatusCodes.BAD_REQUEST));
        }

        res.status(docURL.status).json(docURL.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0000',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const addDocumentForInvoiceCntrl = async (req, res, next) => {
    try {
        let formData = appendFileMetadata(req.body, req.files['document']);

        formData.append('createdById', req.user.id);
        formData.append('updatedById', req.user.id);

        const newDocUpload = await axios.post(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads`, formData, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (newDocUpload.status != 200) {
            return next(new APIError('0095', StatusCodes.BAD_REQUEST));
        }

        const invoiceDoc = newDocUpload.data.data;

        const invoiceDocRef = await invoiceHelpers.createAnInvoiceDocumentRef(req.params.invoiceId, invoiceDoc.id);

        if (invoiceDocRef.error) {
            return next(new APIError('0096', StatusCodes.BAD_REQUEST));
        }

        res.status(StatusCodes.OK).json(newDocUpload.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0095',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const approveOrRejectAnInvoiceCntrl = async (req, res, next) => {
    try {
        /* Get Invoice details */
        const invoice = await invoiceHelpers.getAnInvoiceById(req.params.invoiceId, {
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: [
                        {
                            model: db.EntityDetails,
                            as: 'buyer',
                            include: [
                                {
                                    model: db['Users'],
                                    as: 'users',
                                    where: {
                                        userType: 'ADMIN'
                                    },
                                    attributes: ['id']
                                }
                            ]
                        },
                        {
                            model: db.EntityDetails,
                            as: 'seller',
                            attributes: ['id']
                        }
                    ]
                }
            ],
            attributes: {
                exclude: ['buyerSellerLinkId']
            }
        });

        if (invoice.error) {
            return next(!invoice.error);
        }

        if (invoice.data.nextCheckerUserId == null) {
            return next(new APIError('0110', StatusCodes.BAD_REQUEST));
        }

        let lists = {
            invoiceActions: [],
            FUActions: []
        };

        const isInvApproved = req.body.approved;

        const approveOrRejectAnInvoiceTxn = await db.sequelize.transaction();

        // If invoice is approved
        if (req.body.approved == 1) {
            
            // Check if invoice is already approved or not
            const invApprovalHistory = await invActionHelpers.getLatestInvApprovalHistory(req.params.invoiceId);

            if (invApprovalHistory.error) {
                return next(invApprovalHistory.error);
            }

            if (
                invApprovalHistory.data.map((invAction) => invAction.actionByUserId).indexOf(req.user.id) >= 0
            ) {
                return next(new APIError('0109', StatusCodes.BAD_REQUEST));
            }

            // Create Invoice Approval Action
            lists.invoiceActions.push({
                invoiceId: req.params.invoiceId,
                action: 'APPROVE',
                actionByUserId: req.user.id,
                remarks: req.body.remarks
            });

            if (
                (req.user.userType == 'CHECKER') ||
                (
                    req.user.userType == 'ADMIN' &&
                    invoice.data.nextCheckerUserId == req.user.id
                )
            ) {
                if (
                    (req.user.userType == 'CHECKER') &&
                    (invoice.data.nextCheckerUserId != req.user.id)
                ) {
                    return next(new APIError('0110', StatusCodes.BAD_REQUEST));
                }

                const checkerData = await invoiceHelpers.getNextCheckerLevel({
                    userId: req.user.id,
                    
                    entityCategory: req.user.entityCategory,
                    
                    buyerId: invoice.data.buyerSellerLink.buyer.id,

                    ...(req.user.entityCategory == 'SELLER') ? {
                        sellerId: invoice.data.buyerSellerLink.seller.id
                    } : {}
                });

                if (checkerData.error) {
                    return next(checkerData.error);
                }

                req.body.nextCheckerUserId = checkerData.data.nextCheckerUserId;

                req.body = {
                    ...req.body,

                    ...(req.user.entityCategory == 'BUYER') ? {
                        convertToFU: checkerData.data.convertToFU,
                    
                        buyerCheckerLevelsPresent: checkerData.data.buyerCheckerLevelsPresent
                    } : {}
                };

                req.body.approved = (req.user.entityCategory == 'BUYER') ? (
                    (req.body.convertToFU) ? 1 : 0
                ) : 0;
                

            } else if (
                req.user.userType == 'ADMIN' &&
                invoice.data.nextCheckerUserId != req.user.id
            ) {
                req.body.approved = 0;
            }

            // If invoice is approved and converted to FU
            if (req.body.convertToFU) {
                const factoringUnit = await FUHelpers.createAnFactoringUnit({
                    buyerSellerLinkId: invoice.data.buyerSellerLink.id,
                    status: (
                        (invoice.data.buyerSellerLink.sendForFinance == 'AUTO')
                    ) ? 'OPEN_FOR_FINANCE' : (
                        (req.body.buyerCheckerLevelsPresent) ? 'PENDING' : 'OPEN_FOR_FINANCE'
                    ),
                    createdByUserId: invoice.data.buyerSellerLink.buyer.users[0].id
                }, {
                    transaction: approveOrRejectAnInvoiceTxn
                });

                if (factoringUnit.error) {
                    await approveOrRejectAnInvoiceTxn.rollback();
                    return next(factoringUnit.error);
                }

                lists.FUActions.push({
                    factoringUnitNo: factoringUnit.data.factoringUnitNo,

                    action: 'CREATE',
                    
                    status: 'PENDING',
                    
                    actionByUserId: factoringUnit.data.createdByUserId,
                    
                    remarks: 'Factoring Unit created.'
                });

                if (
                    (invoice.data.buyerSellerLink.sendForFinance == 'AUTO') ||
                    !req.body['buyerCheckerLevelsPresent']
                ) {
                    lists.FUActions.push({
                        factoringUnitNo: factoringUnit.data.factoringUnitNo,
                        
                        action: 'APPROVE',
                        
                        status: 'PENDING',
                        
                        actionByUserId: factoringUnit.data.createdByUserId,
                        
                        remarks: 'Factoring Unit approved and sent to Request for Finance.'
                    });
                }

                req.body.factoringUnitNo = factoringUnit.data.factoringUnitNo;

                req.body.buyerAdminId = invoice.data.buyerSellerLink.buyer.users[0].id;
            }

            lists.invoiceActions.push({
                invoiceId: req.params.invoiceId,
                action: 'APPROVE',
                actionByUserId: req.user.id,
                remarks: (req.body.remarks) ? req.body.remarks : (
                    (req.body.convertToFU) ? `Invoice auto-approved to Factoring Unit No. ${req.body.factoringUnitNo}.` : `Invoice approved successfully.`
                )
            });

        } else {
            // If invoice is rejected
            req.body.nextCheckerUserId = null;

            lists.invoiceActions.push({
                invoiceId: req.params.invoiceId,
                action: 'REJECT',
                actionByUserId: req.user.id,
                remarks: (req.body.remarks) ? req.body.remarks : `Invoice rejected.`
            }); 
        }

        // Create multiple Invoice Actions
        const invoiceActions = await invActionHelpers.createMultipleInvActions(lists.invoiceActions, {
            transaction: approveOrRejectAnInvoiceTxn
        });

        if (invoiceActions.error) {
            await approveOrRejectAnInvoiceTxn.rollback();
            return next(invoiceActions.error);
        }

        /* Create multiple FU Actions if present */
        if (lists.FUActions.length > 0) {
            const FUActions = await FUActionHelpers.createMultipleFUActions(lists.FUActions, {
                transaction: approveOrRejectAnInvoiceTxn
            });

            if (FUActions.error) {
                await approveOrRejectAnInvoiceTxn.rollback();
                return next(FUActions.error);
            }
        }

        /* Update the invoice */
        const updatedInv = await invoiceHelpers.updateAnInvoiceById(req.params.invoiceId, {
            nextCheckerUserId: req.body.nextCheckerUserId,
            approved: req.body.approved,
            ...(req.body.factoringUnitNo) ? {
                factoringUnitNo: req.body.factoringUnitNo
            } : {}
        }, {
            transaction: approveOrRejectAnInvoiceTxn
        });

        if (updatedInv.error) {
            await approveOrRejectAnInvoiceTxn.rollback();
            return next(updatedInv.error);
        }

        await approveOrRejectAnInvoiceTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: (
                (isInvApproved == 1) ? (
                    (req.body.convertToFU) ? 
                    `Invoice approved and converted to Factoring Unit No. ${req.body.factoringUnitNo}` : 
                    `Invoice approved successfully.`
                ) : `Invoice rejected successfully.`
            )
        });

    } catch(error) {
        next(error);
    }
};

const updateAnInvoiceByIdCntrl = async (req, res, next) => {
    try {
        const invoice = await invoiceHelpers.getAnInvoiceById(req.params.invoiceId, {
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    attributes: ['id', 'buyerId', 'sellerId']
                }
            ],
            attributes: {
                exclude: ['buyerSellerLinkId']
            }
        });

        if (invoice.error) {
            return next(invoice.error);
        }

        req.body.buyerId = (req.body.buyerId) ? req.body.buyerId : invoice.data.buyerSellerLink.buyerId;

        req.body.sellerId = (req.body.sellerId) ? req.body.sellerId : invoice.data.buyerSellerLink.sellerId;

        await invInitialCheckerConfigCntrl(req, res, next);

        const invActionsList = [
            {
                invoiceId: invoice.data.id,
                action: 'UPDATE',
                actionByUserId: req.user.id,
                remarks: `Invoice updated.`
            }
        ];

        const updateAnInvoiceTxn = await db.sequelize.transaction();

        /* Create an Update Invoice Action  */
        const invActions = await invActionHelpers.createMultipleInvActions(invActionsList, {
            transaction: updateAnInvoiceTxn
        });

        if (invActions.error) {
            await updateAnInvoiceTxn.rollback();
            return next(invActions.error);
        }

        /* Update the invoice */
        const updatedInvoice = await invoiceHelpers.updateAnInvoiceById(req.params.invoiceId, req.body, {
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                }
            ],
            transaction: updateAnInvoiceTxn
        });

        if (updatedInvoice.error) {
            await updateAnInvoiceTxn.rollback();
            return next(updatedInvoice.error);
        }

        await updateAnInvoiceTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Invoice updated successfully.',
            data: updatedInvoice.data
        });

    } catch(error) {
        next(error);
    }
};

const deleteAnInvoiceByIdCntrl = async (req, res, next) => {
    try {
        const invoice = await invoiceHelpers.getAnInvoiceById(req.params.invoiceId, {
            include: ['documents']
        });

        if (invoice.error) {
            return next(invoice.error);
        }

        const deleteInvTxn = await db.sequelize.transaction();

        // If invoice has documents
        if (invoice.data.documents.length > 0) {

            // Delete Invoice Documents
            let invoiceDocIds = [...invoice.data.documents.map((doc) => doc.documentId)];

            const invoiceDocs = await invoiceHelpers.deleteInvoiceDocsByDocIds(req.headers.authorization, invoiceDocIds);

            if (invoiceDocs.error) {
                await deleteInvTxn.rollback();
                return next(invoiceDocs.error);
            }
        }

        // Delete Invoice
        const deletedInvoice = await invoiceHelpers.deleteAnInvoiceById(req.params.invoiceId, {
            transaction: deleteInvTxn
        });

        if (deletedInvoice.error) {
            await deleteInvTxn.rollback();
            return next(deletedInvoice.error);
        }

        await deleteInvTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: "Invoice deleted successfully."
        });

    } catch(error) {
        next(error);
    }
};

const deleteAnInvoiceDocumentByIdCntrl = async (req, res, next) => {
    try {
        const docUpload = await axios.delete(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads/${req.params.documentId}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (docUpload.status != 200) {
            return next(new APIError('0098', StatusCodes.BAD_REQUEST));
        }

        const invDocRef = await invoiceHelpers.deleteAnInvoiceDocumentRef(req.params.documentId);

        if (invDocRef.error) {
            return next(invDocRef.error);
        }

        res.status(StatusCodes.OK).json(docUpload.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0098',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

module.exports = {
    createAnInvFromJSONCntrl,
    createAnInvFromFileCntrl,

    getAnInvoiceByIdCntrl,
    getAllInvoicesCntrl,
    getAllInvoiceDocumentsCntrl,

    getInvDocSignedURLCntrl,
    addDocumentForInvoiceCntrl,
    approveOrRejectAnInvoiceCntrl,
    updateAnInvoiceByIdCntrl,

    deleteAnInvoiceByIdCntrl,
    deleteAnInvoiceDocumentByIdCntrl
}