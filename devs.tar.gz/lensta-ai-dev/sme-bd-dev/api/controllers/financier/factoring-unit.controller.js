const nodeXLSX = require('node-xlsx');
const uuid = require('uuid');
const { APIError } = require("../../error");
const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services//generic-query.service");
const { generateCustomNanoId } = require('../../services//generic.service');
const FUHelpers = require('../../helpers/financier').factoringUnit;
const FUActionHelpers = require('../../helpers/financier').FUActionHistory;
const invoiceHelpers = require('../../helpers/financier').invoice;
const BSLinkHelpers = require('../../helpers/buyer-seller').buyerSellerLink;
const invActionHelpers = require('../../helpers/financier').invoiceActionHistory;
const checkerLvlHelpers = require('../../helpers/platform').checkerLevel;
const userHelpers = require('../../helpers/platform').user;
const entDetHelpers = require('../../helpers/buyer-seller').entDetails;

const FUInitialCheckerConfigCntrl = async (req, res, next) => {
    try {
        /* Check if Buyer / Seller are linked or not */
        const BSLinks = await BSLinkHelpers.getAllBSLinks({
            where: {
                buyerId: req.body.buyerId,
                sellerId: req.body.sellerId,
            },
            attributes: ['id', 'buyerId', 'sellerId', 'sendForFinance', 'acceptPayment']
        });

        if (BSLinks.error) {
            return next(BSLinks.error);
        }

        delete req.body.buyerId;
        delete req.body.sellerId;

        req.body = {
            ...req.body,
            status: (
                (BSLinks.sendForFinance == 'AUTO') ? 'OPEN_FOR_FINANCE' : 'PENDING'
            ),
            fuListedDate: (
                (BSLinks.sendForFinance == 'AUTO') ? new Date() : null
            ),
            nextCheckerUserId: null,
            createdByUserId: (
                req.body.createdByUserId ? req.body.createdByUserId : req.user.id
            ),
            buyerSellerLinkId: BSLinks.data[0].id
        };

        if (req.body.status == 'PENDING') {
            /* Get Buyer Checker Levels */
            const buyerChkrLvls = await checkerLvlHelpers.getAllCheckerLevels({
                where: [{
                    '$user.entityId$': BSLinks.data[0].buyerId
                }],
                include: [
                    {
                        model: db['Users'],
                        as: 'user',
                        attributes: ['id']
                    }
                ],
                attributes: {
                    exclude: ['userId']
                }
            });

            if (buyerChkrLvls.error) {
                return next(buyerChkrLvls.error);
            }

            /* Set next checker user ID to Buyer Checker if Buyer Checker Levels are available */
            if (buyerChkrLvls.data.length > 0) {
                req.body.nextCheckerUserId = buyerChkrLvls.data[0].user.id;

            } else {
                /* Get Buyer Admin */
                const buyerAdmin = await userHelpers.getAnUser({
                    where: {
                        entityId: BSLinks.data[0].buyerId,
                        userType: 'ADMIN'
                    },
                    attributes: ['id']
                });

                if (buyerAdmin.error) {
                    return next(buyerAdmin.error);
                }

                /* Set next checker as Buyer Admin if Buyer Admin is not creating the FU  */
                req.body.nextCheckerUserId = (
                    (req.user.id != buyerAdmin.data.id) ? buyerAdmin.data.id : null
                );

                /* Set status to 'PENDING' if Buyer Admin is not creating the FU  */
                req.body.status = (
                    (req.body.nextCheckerUserId) ? 'PENDING' : 'OPEN_FOR_FINANCE'
                );

                /* Don't set FU Listed Date if Buyer Admin is not creating the FU  */
                req.body.fuListedDate = (
                    (req.body.status == 'OPEN_FOR_FINANCE') ? new Date() : null
                );
            }
        }

    } catch (error) {
        next(error);
    }
};

const createAnFUFromJSONCntrl = async (req, res, next) => {
    try {
        await FUInitialCheckerConfigCntrl(req, res, next);

        let invoiceDetails = req.body.invoiceDetails;
        delete req.body.invoiceDetails;

        const createAnFUTxn = await db.sequelize.transaction();

        /* Create an Factoring Unit */
        const factoringUnit = await FUHelpers.createAnFactoringUnit(req.body, {
            transaction: createAnFUTxn
        });

        if (factoringUnit.error) {
            await createAnFUTxn.rollback();
            return next(factoringUnit.error);
        }

        /* Create multiple FU Actions */
        let FUActionsList = [
            {
                factoringUnitNo: factoringUnit.data.factoringUnitNo,

                action: 'CREATE',

                status: 'PENDING',

                actionByUserId: factoringUnit.data.createdByUserId,

                remarks: 'Factoring Unit created.'
            }
        ];

        /* Create an FU Approve Action if it's auto-approved to 'OPEN_FOR_FINANCE' */
        if (req.body.status == 'OPEN_FOR_FINANCE') {
            FUActionsList.push({
                factoringUnitNo: factoringUnit.data.factoringUnitNo,

                action: 'APPROVE',

                status: 'PENDING',

                actionByUserId: factoringUnit.data.createdByUserId,

                remarks: 'Factoring Unit approved and sent to Request for Finance.'
            });
        }

        /* Create multiple FU Actions */
        const FUActions = await FUActionHelpers.createMultipleFUActions(FUActionsList, {
            transaction: createAnFUTxn
        });

        if (FUActions.error) {
            await createAnFUTxn.rollback();
            return next(FUActions.error);
        }

        invoiceDetails = {
            ...invoiceDetails,

            buyerSellerLinkId: factoringUnit.data.buyerSellerLinkId,

            factoringUnitNo: factoringUnit.data.factoringUnitNo,

            approved: 1,

            createdByUserId: req.body.createdByUserId
        };

        /* Create an Invoice */
        const invoice = await invoiceHelpers.createAnInvoice(invoiceDetails, {
            transaction: createAnFUTxn
        });

        if (invoice.error) {
            await createAnFUTxn.rollback();
            return next(invoice.error);
        }

        /* Create an Invoice Actions */
        const invActionsList = [
            {
                invoiceId: invoice.data.id,
                action: 'CREATE',
                actionByUserId: req.body.createdByUserId,
                remarks: 'Invoice created.'
            },
            {
                invoiceId: invoice.data.id,
                action: 'APPROVE',
                actionByUserId: req.body.createdByUserId,
                remarks: 'Invoice approved.'
            }
        ];

        /* Create multiple Invoice Actions */
        const invoiceActions = await invActionHelpers.createMultipleInvActions(invActionsList, {
            transaction: createAnFUTxn
        });

        if (invoiceActions.error) {
            await createAnFUTxn.rollback();
            return next(invoiceActions.error);
        }

        await createAnFUTxn.commit();

        const FU = await FUHelpers.getAnFUByFUNo(factoringUnit.data.factoringUnitNo, {
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                },
                'invoices'
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'factoredUnitBreakup', 'sumOfInvoiceAmounts']
            }
        });

        if (FU.error) {
            return next(FU.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Factoring Unit added successfully.',
            data: FU.data
        });

    } catch (error) {
        next(error);
    }
};

const createAnFUFromFileCntrl = async (req, res, next) => {
    try {
        if (
            !req.files ||
            (Object.keys(req.files).length == 0)
        ) {
            return next(new APIError('0129', StatusCodes.NOT_FOUND));
        }

        const sheets = nodeXLSX.parse(req.files.file.filepath, {
            defval: ''
        });

        let headerFields = [
            'Invoice No.',
            'Invoice Date (YYYY-MM-DD)',
            'Invoice Due Date (YYYY-MM-DD)',
            'Invoice Amount',
            'Discount Amount',
            'Tax Amount'
        ];

        if (sheets.length == 0) {
            return next(new APIError('0101', StatusCodes.BAD_REQUEST));
        }

        await FUInitialCheckerConfigCntrl(req, res, next);

        /* Date Regex */
        let dateFormatRegEx = new RegExp(/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/);

        const tests = {
            hasValidHeaders: (row) => {
                return (
                    row.length == 6 &&
                    row.every((cell) => headerFields.indexOf(cell) >= 0)
                );
            },
            allRowsHaveNonNullValues: (sheetData) => {
                return (
                    sheetData.every(
                        (row) => (
                            row.length == 6 &&
                            row.every((cell) => Boolean(cell))
                        )
                    ) && sheetData.length > 1
                );
            },
            rowOneHasValidDates: (sheetData) => {
                return (
                    dateFormatRegEx.test(sheetData[1][1]) &&

                    dateFormatRegEx.test(sheetData[1][2]) &&

                    new Date(sheetData[1][1]).getTime() <= new Date(sheetData[1][2]).getTime()
                )
            },
            allRowsHaveRowOneDates: (sheetData) => {
                return (
                    sheetData.slice(2, sheetData.length).every(
                        (row) => (
                            sheetData[1][1] == row[1] &&
                            sheetData[1][2] == row[2]
                        )
                    )
                );
            },
            allRowsHaveValidDates: (sheetData) => {
                return (
                    sheetData.slice(1, sheetData.length).every(
                        (row) => (
                            (dateFormatRegEx.test(row[1])) &&
                            (dateFormatRegEx.test(row[2])) &&
                            (
                                new Date(row[1]).getTime() <= new Date(row[2]).getTime()
                            )
                        )
                    )
                )
            }
        };

        let lists = {
            FUInvoices: [],
            FUInvActions: [],
            factoringUnits: [],
            FUActions: []
        };

        sheets.forEach(async (sheet, sheetIdx) => {
            sheet.data = [...sheet.data.filter((subArray) => subArray.join('').length > 0).map((subArray) => {
                let values = [];

                subArray.forEach((elem) => {
                    values.push(
                        (typeof elem == 'string') ? elem.trim() : elem
                    );
                });

                return values;
            })];

            if (
                !tests.hasValidHeaders(sheet.data[0]) ||

                !tests.allRowsHaveNonNullValues(sheet.data) ||

                !tests.rowOneHasValidDates(sheet.data) ||

                !tests.allRowsHaveValidDates(sheet.data) ||

                (sheet.data.length <= 1)
            ) {
                return next(new APIError('0101', StatusCodes.BAD_REQUEST));
            }

            if (sheetIdx > 0) {
                if (typeof sheet.data[0] == 'number') {
                    sheet.data[0] = sheet.data[0].toFixed(2);
                }
            }

            if (
                (sheet.data.length > 2) &&
                !tests.allRowsHaveRowOneDates(sheet.data)
            ) {
                return next(new APIError('0101', StatusCodes.BAD_REQUEST));
            }

            /* Custom FU No. */
            req.body.factoringUnitNo = `FU-${generateCustomNanoId(8)}`;

            /* Add a new FU to the FU list */
            lists.factoringUnits.push({ ...req.body });

            /* Add FU Actions to FU Actions List */
            lists.FUActions.push({
                factoringUnitNo: req.body.factoringUnitNo,

                action: 'CREATE',

                status: 'PENDING',

                actionByUserId: req.body.createdByUserId,

                remarks: 'Factoring Unit created.'
            });

            /* If FU is auto-approved to 'OPEN_FOR_FINANCE' */
            if (req.body.status == 'OPEN_FOR_FINANCE') {
                lists.FUActions.push({
                    factoringUnitNo: req.body.factoringUnitNo,

                    action: 'APPROVE',

                    status: 'PENDING',

                    actionByUserId: req.body.createdByUserId,

                    remarks: 'Factoring Unit approved and sent to Request for Finance.'
                });
            }

            sheet.data.slice(1, sheet.data.length).forEach((row) => {
                const newInvId = uuid.v4();

                /* Create an Invoices to FU Invoice List */
                lists.FUInvoices.push({
                    factoringUnitNo: req.body.factoringUnitNo,

                    buyerSellerLinkId: req.body.buyerSellerLinkId,

                    id: newInvId,

                    invoiceNo: row[0],

                    invoiceDate: row[1],

                    invoiceDueDate: row[2],

                    invoiceAmount: row[3],

                    discountAmount: row[4],

                    taxAmount: row[5],

                    approved: 1,

                    createdByUserId: req.body.createdByUserId
                });

                lists.FUInvActions.push(...[
                    {
                        invoiceId: newInvId,
                        action: 'CREATE',
                        actionByUserId: req.body.createdByUserId,
                        remarks: 'Invoice created.'
                    },
                    {
                        invoiceId: newInvId,
                        action: 'APPROVE',
                        actionByUserId: req.body.createdByUserId,
                        remarks: 'Invoice approved.'
                    }
                ]);
            });
        });

        const createAnFUTxn = await db.sequelize.transaction();

        /* Create multiple FUs */
        const factoringUnits = await FUHelpers.createMultipleFUs(lists.factoringUnits, {
            transaction: createAnFUTxn
        });

        if (factoringUnits.error) {
            await createAnFUTxn.rollback();
            return next(factoringUnits.error);
        }

        /* Create multiple FU Actions */
        const FUActions = await FUActionHelpers.createMultipleFUActions(lists.FUActions, {
            transaction: createAnFUTxn
        });

        if (FUActions.error) {
            await createAnFUTxn.rollback();
            return next(FUActions.error);
        }

        /* Create multiple Invoices */
        const FUInvoices = await invoiceHelpers.createMultipleInvoices(lists.FUInvoices, {
            transaction: createAnFUTxn
        });

        if (FUInvoices.error) {
            await createAnFUTxn.rollback();
            return next(FUInvoices.error);
        }

        /* Create multiple Invoice Actions */
        const invActions = await invActionHelpers.createMultipleInvActions(lists.FUInvActions, {
            transaction: createAnFUTxn
        });

        if (invActions.error) {
            await createAnFUTxn.rollback();
            return next(invActions.error);
        }

        await createAnFUTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Factoring Unit(s) added successfully.'
        });

    } catch (error) {
        next(error);
    }
};

const getAnFUByFUNoCntrl = async (req, res, next) => {
    try {
        const factoringUnit = await FUHelpers.getAnFUByFUNo(req.params.factoringUnitNo, {
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                },
                {
                    model: db['Users'],
                    as: 'nextCheckerUser',
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                },
                'invoices',
                {
                    model: db['FUActionHistory'],
                    as: 'actionHistory',
                    include: [
                        {
                            model: db['Users'],
                            as: 'actionByUser',
                            attributes: {
                                exclude: ['password', 'encPassword']
                            }
                        }
                    ],
                    attributes: {
                        exclude: ['actionByUserId']
                    }
                }
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'nextCheckerUserId']
            }
        });

        if (factoringUnit.error) {
            return next(factoringUnit.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: factoringUnit.data
        });

    } catch (error) {
        next(error);
    }
};

const getAllFactoringUnitsCntrl = async (req, res, next) => {
    try {
        let factoringUnits = await FUHelpers.getAllFactoringUnits({
            where: [req.query],
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: [
                        {
                            model: db.EntityDetails,
                            as: 'buyer',
                            include: ['createdByFinancier'],
                            attributes: {
                                exclude: ['createdByFinancierId']
                            }
                        },
                        {
                            model: db.EntityDetails,
                            as: 'seller',
                            include: ['createdByFinancier'],
                            attributes: {
                                exclude: ['createdByFinancierId']
                            }
                        }
                    ],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                },
                {
                    model: db['Users'],
                    as: 'nextCheckerUser',
                    include: ['entity'],
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                },
                'invoices',
                'payment'
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'nextCheckerUserId', 'factoredUnitBreakup']
            }
        });

        if (factoringUnits.error) {
            return next(factoringUnits.error);
        }

        let queryFactAmt = (req.query.factoringAmount) ? parseFloat(req.query.factoringAmount) : -1.00;

        if (queryFactAmt && queryFactAmt >= 0) {
            factoringUnits.data = [...factoringUnits.data.filter((fu) => {
                return (fu.factoringAmount == queryFactAmt);
            })];
        }

        const resultLength = factoringUnits.data.length;

        factoringUnits.data = [...applyLimitAndOffsetParams(
            factoringUnits.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: factoringUnits.data
        });

    } catch (error) {
        next(error);
    }
};

const combineTwoFUsCntrl = async (req, res, next) => {
    try {
        const factUnits = await FUHelpers.getAllFactoringUnits({
            where: {
                factoringUnitNo: {
                    [db.Sequelize.Op.in]: [
                        req.body.factoringUnit1No,
                        req.body.factoringUnit2No
                    ]
                }
            },
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller']
                },
                'invoices'
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'factoredUnitBreakup', 'sumOfInvoiceAmounts']
            }
        });

        if (
            factUnits.error ||
            (factUnits.data.length < 2)
        ) {
            return next(new APIError('0089', StatusCodes.NOT_FOUND));
        }

        /* If Buyer / Seller ID of any of the FUs is different */
        if (
            (factUnits.data[0].buyerSellerLink.buyerId != factUnits.data[1].buyerSellerLink.buyerId) ||

            (factUnits.data[0].buyerSellerLink.sellerId != factUnits.data[1].buyerSellerLink.sellerId)
        ) {
            return next(new APIError('0100', StatusCodes.BAD_REQUEST));
        }

        let fu2Index = factUnits.data.map((fu) => fu.factoringUnitNo).indexOf(req.body.factoringUnit2No);

        let fu1Index = (fu2Index == 0) ? 1 : 0;

        let dates = {
            fu1InvDates: Array.from(
                new Set(factUnits.data[fu1Index].invoices.map((invoice) => new Date(invoice.invoiceDate).toISOString().split('T')[0]))
            ),

            fu1InvDueDates: Array.from(
                new Set(factUnits.data[fu1Index].invoices.map((invoice) => new Date(invoice.invoiceDueDate).toISOString().split('T')[0]))
            ),

            fu2InvDates: Array.from(
                new Set(factUnits.data[fu2Index].invoices.map((invoice) => new Date(invoice.invoiceDate).toISOString().split('T')[0]))
            ),

            fu2InvDueDates: Array.from(
                new Set(factUnits.data[fu2Index].invoices.map((invoice) => new Date(invoice.invoiceDueDate).toISOString().split('T')[0]))
            ),
        };

        /* If all FU-1 Invoices don't have common Invoice Date & Due Dates */
        if (
            (dates.fu1InvDates.length != 1) ||
            (dates.fu1InvDueDates.length != 1)
        ) {
            return next(new APIError('0100', StatusCodes.BAD_REQUEST));
        }

        /* If all FU-2 Invoices don't have common Invoice Date & Due Dates */
        if (
            (dates.fu2InvDates.length != 1) ||
            (dates.fu2InvDueDates.length != 1)
        ) {
            return next(new APIError('0100', StatusCodes.BAD_REQUEST));
        }

        /* Combine both FUs, if both have same Buyer & Seller and have same Invoice Date & Due Dates */
        if (
            (dates.fu1InvDates[0] != dates.fu2InvDates[0]) ||

            (dates.fu1InvDueDates[0] != dates.fu2InvDueDates[0]) ||

            (factUnits.data[fu1Index].status != 'PENDING') ||

            (factUnits.data[fu2Index].status != 'PENDING')
        ) {
            return next(new APIError('0100', StatusCodes.BAD_REQUEST));
        }

        delete dates.fu1InvDates;
        delete dates.fu1InvDueDates;
        delete dates.fu2InvDates;
        delete dates.fu2InvDueDates;

        const combineTwoFUsTxn = await db.sequelize.transaction();

        /* Set FU No. of FU-2's invoices to FU No. of FU-1 */
        const updatedInvoices = await invoiceHelpers.updateInvoicesByFUNo(
            req.body.factoringUnit2No,
            {
                factoringUnitNo: req.body.factoringUnit1No
            },
            { transaction: combineTwoFUsTxn }
        );

        if (updatedInvoices.error) {
            await combineTwoFUsTxn.rollback();
            return next(updatedInvoices.error);
        }

        /* Delete FU-2 */
        const deletedFU = await FUHelpers.deleteAllFactoringUnits({
            where: {
                factoringUnitNo: req.body.factoringUnit2No
            },
            transaction: combineTwoFUsTxn
        });

        if (deletedFU.error) {
            await combineTwoFUsTxn.rollback();
            return next(deletedFU.error);
        }

        req.body.buyerId = factUnits.data[fu1Index].buyerSellerLink.buyer.id;

        req.body.sellerId = factUnits.data[fu1Index].buyerSellerLink.seller.id;

        await FUInitialCheckerConfigCntrl(req, res, next);

        const updatedFU = await FUHelpers.updateAnFUByFUNo(req.body.factoringUnit1No, {
            status: req.body.status,
            nextCheckerUserId: req.body.nextCheckerUserId
        }, {
            transaction: combineTwoFUsTxn,
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                },
                'invoices'
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'factoredUnitBreakup']
            }
        });

        if (updatedFU.error) {
            await combineTwoFUsTxn.rollback();
            return next(updatedFU.error);
        }

        await combineTwoFUsTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: `FU No. '${req.body.factoringUnit2No}' combined into FU No. '${req.body.factoringUnit1No}' successfully.`,
            data: updatedFU.data
        });

    } catch (error) {
        next(error);
    }
};

const updateAnFUByFUNoCntrl = async (req, res, next) => {
    try {
        /* Get Factoring Unit */
        const factoringUnit = await FUHelpers.getAnFUByFUNo(req.params.factoringUnitNo, {
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                }
            ],
            attributes: {
                exclude: ['buyerSellerLinkId']
            }
        });

        if (factoringUnit.error) {
            return next(factoringUnit.error);
        }

        let FUActionList = [];

        const updateAnFUTxn = await db.sequelize.transaction();

        /* Update FU according to it's status */
        switch (factoringUnit.data.status) {
            case 'PENDING': {
                /* Update Invoice details if present */
                if (req.body.invoiceDetails) {
                    const updatedInv = await invoiceHelpers.updateAnInvoiceByFUNo(req.params.factoringUnitNo, req.body.invoiceDetails, {
                        transaction: updateAnFUTxn
                    });

                    if (updatedInv.error) {
                        await updateAnFUTxn.rollback();
                        return next(updatedInv.error);
                    }
                }

                req.body.buyerId = (req.body.buyerId) ? req.body.buyerId : factoringUnit.data.buyerSellerLink.buyer.id;

                req.body.sellerId = (req.body.sellerId) ? req.body.sellerId : factoringUnit.data.buyerSellerLink.seller.id;

                await FUInitialCheckerConfigCntrl(req, res, next);

                delete req.body.createdByUserId;
                delete req.body.invoiceDetails;
                delete req.body.buyerId;
                delete req.body.sellerId;

                break;
            }

            case 'OPEN_FOR_FINANCE': {
                /* Get available limit of Buyer */
                const buyerAvlLimit = await entDetHelpers.getAvlLimitOfAnEntityById(factoringUnit.data.buyerSellerLink.buyer.id);

                if (buyerAvlLimit.error) {
                    return next(buyerAvlLimit.error);
                }

                /* Get available limit of Seller */
                const sellerAvlLimit = await entDetHelpers.getAvlLimitOfAnEntityById(factoringUnit.data.buyerSellerLink.seller.id);

                if (sellerAvlLimit.error) {
                    return next(sellerAvlLimit.error);
                }

                if (
                    (buyerAvlLimit.data < factoringUnit.data.factoringAmount) ||
                    (sellerAvlLimit.data < factoringUnit.data.factoringAmount)
                ) {
                    return next(new APIError('0134', StatusCodes.BAD_REQUEST));
                }

                /* Proceed for updating interest and fees if limit is available */
                const feesAndInterest = FUHelpers.getInterestAndFees(
                    factoringUnit.data.factoringAmount,
                    req.body.rateOfInterest,
                    factoringUnit.data.buyerSellerLink
                );

                if (feesAndInterest.error) {
                    return next(feesAndInterest.error);
                }

                req.body = {
                    fuListedDate: new Date(),
                    ...req.body,
                    ...feesAndInterest.data
                };

                const checkerData = await invoiceHelpers.getNextCheckerLevel({
                    userId: req.user.id,

                    entityCategory: 'FINANCIER',

                    financierId: factoringUnit.data.buyerSellerLink.buyer.createdByFinancierId
                });

                if (checkerData.error) {
                    return next(checkerData.error);
                }

                req.body.nextCheckerUserId = checkerData.data.nextCheckerUserId;

                if (checkerData.data.isLastFinancierChecker) {

                    if (factoringUnit.data.buyerSellerLink.acceptPayment == 'AUTO') {

                        req.body.status = 'AMT_DISBURSED';

                        req.body.factoredDate = new Date();

                        req.body.nextCheckerUserId = null;

                        FUActionList.push(...[
                            {
                                factoringUnitNo: req.params.factoringUnitNo,

                                action: 'APPROVE',

                                status: 'OPEN_FOR_FINANCE',

                                actionByUserId: req.user.id,

                                remarks: 'Factoring Unit approved and sent to Request for Finance.'
                            },
                            {
                                factoringUnitNo: req.params.factoringUnitNo,

                                action: 'APPROVE',

                                status: 'ROI_ADDED',

                                actionByUserId: req.user.id,

                                remarks: 'Factoring Unit approved and financed.'
                            }
                        ]);
                    }
                    else {
                        req.body.status = 'ROI_ADDED';

                        req.body.nextCheckerUserId = null;

                        FUActionList.push(...[
                            {
                                factoringUnitNo: req.params.factoringUnitNo,

                                action: 'APPROVE',

                                status: 'OPEN_FOR_FINANCE',

                                actionByUserId: req.user.id,

                                remarks: 'Factoring Unit approved and sent to Request for Finance.'
                            }
                        ]);
                    }
                }

                break;
            }

            default: { }
        }

        /* Create FU Actions if present */
        if (FUActionList.length > 0) {
            const FUActions = await FUActionHelpers.createMultipleFUActions(FUActionList, {
                transaction: updateAnFUTxn
            });

            if (FUActions.error) {
                await updateAnFUTxn.rollback();
                return next(FUActions.error);
            }
        }

        /* Update FU */
        const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, req.body, {
            transaction: updateAnFUTxn,
            include: [
                {
                    model: db['EntityLinks'],
                    as: 'buyerSellerLink',
                    include: ['buyer', 'seller'],
                    attributes: {
                        exclude: ['buyerId', 'sellerId']
                    }
                },
                'invoices'
            ],
            attributes: {
                exclude: ['buyerSellerLinkId', 'factoredUnitBreakup', 'sumOfInvoiceAmounts']
            }
        });

        if (updatedFU.error) {
            await updateAnFUTxn.rollback();
            return next(updatedFU.error);
        }

        await updateAnFUTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: (updatedFU.data.status == 'AMT_DISBURSED') ? 'Factoring Unit updated, auto-approved and financed.' : `Factoring Unit updated successfully.`,
            data: updatedFU.data
        });

    } catch (error) {
        next(error);
    }
};

const sendFUForFinanceCntrl = async (req, res, next) => {
    try {
        let FUActionList = [];
        const approved = req.body.approved;

        req.body.nextCheckerUserId = null;

        req.body = {
            ...req.body,
            fuListedDate: null
        };

        /* If FU is approved */
        if (approved == 1) {
            FUActionList.push({
                factoringUnitNo: req.params.factoringUnitNo,
                action: 'APPROVE',
                status: 'PENDING',
                actionByUserId: req.user.id,
                remarks: req.body.remarks
            });

            /* Check if FU is already approved or not */
            const FUApprovalHistory = await FUActionHelpers.getLatestFUApprovalHistory(req.params.factoringUnitNo);

            if (FUApprovalHistory.error) {
                return next(FUApprovalHistory.error);
            }

            if (
                FUApprovalHistory.data.map((FUAction) => FUAction.actionByUserId).indexOf(req.user.id) >= 0
            ) {
                return next(new APIError('0127', StatusCodes.BAD_REQUEST));
            }

            const factoringUnit = await FUHelpers.getAnFUByFUNo(req.params.factoringUnitNo, {
                include: [
                    {
                        model: db['EntityLinks'],
                        as: 'buyerSellerLink',
                        attributes: ['id', 'buyerId', 'sellerId', 'sendForFinance']
                    }
                ]
            });

            if (factoringUnit.error) {
                return next(factoringUnit.error);
            }

            if (factoringUnit.data.buyerSellerLink.sendForFinance == 'AUTO') {
                req.body = {
                    status: 'OPEN_FOR_FINANCE',
                    fuListedDate: new Date(),
                    nextCheckerUserId: null
                };

            } else {
                if (
                    (req.user.userType == 'CHECKER') ||
                    (
                        req.user.userType == 'ADMIN' &&
                        factoringUnit.data.nextCheckerUserId == req.user.id
                    )
                ) {
                    if (
                        (req.user.userType == 'CHECKER') &&
                        (factoringUnit.data.nextCheckerUserId != req.user.id)
                    ) {
                        return next(new APIError('0128', StatusCodes.BAD_REQUEST));
                    }

                    const checkerData = await invoiceHelpers.getNextCheckerLevel({
                        userId: req.user.id,

                        entityCategory: 'BUYER',

                        buyerId: factoringUnit.data.buyerSellerLink.buyerId
                    });

                    if (checkerData.error) {
                        return next(checkerData.error);
                    }

                    req.body.nextCheckerUserId = checkerData.data.nextCheckerUserId;

                    req.body.lastBuyerChecker = checkerData.data.convertToFU;

                    req.body.status = (req.body.lastBuyerChecker) ? 'OPEN_FOR_FINANCE' : 'PENDING';

                    req.body.fuListedDate = (req.body.lastBuyerChecker) ? new Date() : null;

                    delete req.body.lastBuyerChecker;

                } else {
                    req.body.status = 'PENDING';
                }
            }

        } else {
            /* If FU is rejected */
            req.body = {
                nextCheckerUserId: null
            };

            FUActionList.push({
                factoringUnitNo: req.params.factoringUnitNo,
                action: 'REJECT',
                status: 'PENDING',
                actionByUserId: req.user.id,
                remarks: (req.body.remarks) ? req.body.remarks : 'Factoring Unit rejected.'
            });
        }

        const sendForFinanceTxn = await db.sequelize.transaction();

        /* Create FU Action */
        const FUActions = await FUActionHelpers.createMultipleFUActions(FUActionList, {
            transaction: sendForFinanceTxn
        });

        if (FUActions.error) {
            await sendForFinanceTxn.rollback();
            return next(FUActions.error);
        }

        /* Update FU */
        const updateBody = {
            status: req.body.status,

            fuListedDate: req.body.fuListedDate,

            nextCheckerUserId: req.body.nextCheckerUserId
        };

        const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, updateBody, {
            transaction: sendForFinanceTxn
        });

        if (updatedFU.error) {
            await sendForFinanceTxn.rollback();
            return next(updatedFU.error);
        }

        await sendForFinanceTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: (
                (approved == 1) ? (
                    (req.body.status == 'OPEN_FOR_FINANCE') ? `Factoring Unit sent to Request for Finance.` : 'Factoring Unit approved successfully.'
                ) : 'Factoring Unit rejected successfully.'
            )
        });

    } catch (error) {
        next(error);
    }
};

const validateROICntrl = async (req, res, next) => {
    try {
        let FUActionList = [];

        if (req.body.approved == 1) {

            /* Check if FU is already approved or not */
            const FUApprovalHistory = await FUActionHelpers.getLatestFUApprovalHistory(req.params.factoringUnitNo);

            if (FUApprovalHistory.error) {
                return next(FUApprovalHistory.error);
            }

            if (
                FUApprovalHistory.data.map((FUAction) => FUAction.actionByUserId).indexOf(req.user.id) >= 0
            ) {
                return next(new APIError('0127', StatusCodes.BAD_REQUEST));
            }

            /* Get FU details */
            const factoringUnit = await FUHelpers.getAnFUByFUNo(req.params.factoringUnitNo, {
                include: [
                    {
                        model: db['EntityLinks'],
                        as: 'buyerSellerLink',
                        include: ['buyer', 'seller']
                    },
                    'invoices'
                ]
            });

            if (factoringUnit.error) {
                return next(factoringUnit.error);
            }

            if (
                (req.user.userType == 'CHECKER') ||
                (
                    req.user.userType == 'ADMIN' &&
                    factoringUnit.data.nextCheckerUserId == req.user.id
                )
            ) {
                if (
                    (req.user.userType == 'CHECKER') &&
                    (factoringUnit.data.nextCheckerUserId != req.user.id)
                ) {
                    return next(new APIError('0128', StatusCodes.BAD_REQUEST));
                }

                const checkerData = await invoiceHelpers.getNextCheckerLevel({
                    userId: req.user.id,

                    entityCategory: 'FINANCIER',

                    financierId: factoringUnit.data.buyerSellerLink.buyer.createdByFinancierId
                });

                if (checkerData.error) {
                    return next(checkerData.error);
                }

                req.body.nextCheckerUserId = checkerData.data.nextCheckerUserId;

                /* If approval is done by last Financier Checker Level */
                if (checkerData.data.isLastFinancierChecker) {
                    req.body.status = 'ROI_ADDED';
                }
            }

            FUActionList.push({
                factoringUnitNo: req.params.factoringUnitNo,
                action: 'APPROVE',
                status: 'OPEN_FOR_FINANCE',
                actionByUserId: req.user.id,
                remarks: (req.body.remarks) ? req.body.remarks : 'Factoring Unit approved.'
            });

            /* If Accept Payment option is set to AUTO */
            if (factoringUnit.data.buyerSellerLink.acceptPayment == 'AUTO') {

                req.body.status = 'AMT_DISBURSED';
                req.body.factoredDate = new Date();
                req.body.nextCheckerUserId = null;

                FUActionList.push({
                    factoringUnitNo: req.params.factoringUnitNo,

                    action: 'APPROVE',

                    status: 'ROI_ADDED',

                    actionByUserId: req.user.id,

                    remarks: (req.body.remarks) ? req.body.remarks : 'Factoring Unit approved and financed.'
                });
            }

        } else {
            req.body = {
                buyerFees: null,
                sellerFees: null,
                rateOfInterest: null,
                advanceTax: null,
                interest: null,
                buyerInterest: null,
                sellerInterest: null,
                nextCheckerUserId: null
            };

            FUActionList.push({
                factoringUnitNo: req.params.factoringUnitNo,
                action: 'REJECT',
                status: 'OPEN_FOR_FINANCE',
                actionByUserId: req.user.id,
                remarks: (req.body.remarks) ? req.body.remarks : 'Factoring Unit rejected.'
            });
        }

        const approved = req.body.approved;
        delete req.body.approved;
        delete req.body.remarks;

        const validateROITxn = await db.sequelize.transaction();

        /* Create multiple FU Actions */
        const FUActions = await FUActionHelpers.createMultipleFUActions(FUActionList, {
            transaction: validateROITxn
        });

        if (FUActions.error) {
            await validateROITxn.rollback();
            return next(FUActions.error);
        }

        /* Update FU */
        const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, req.body, {
            transaction: validateROITxn
        });

        if (updatedFU.error) {
            await validateROITxn.rollback();
            return next(updatedFU.error);
        }

        await validateROITxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: (
                (approved == 1) ? (
                    (req.body.status == 'AMT_DISBURSED') ? `Factoring Unit approved and financed.` : 'Factoring Unit approved successfully.'
                ) : 'Factoring Unit rejected successfully.'
            )
        });

    } catch (error) {
        next(error);
    }
};

const disburseAmtCntrl = async (req, res, next) => {
    try {
        req.body.status = (req.body.approved == 1) ? 'AMT_DISBURSED' : 'REJECTED';

        req.body.factoredDate = (req.body.approved == 1) ? new Date() : null;

        const disburseAmtTxn = await db.sequelize.transaction();

        /* Create an FU Action */
        const FUActions = await FUActionHelpers.createMultipleFUActions([
            {
                factoringUnitNo: req.params.factoringUnitNo,

                action: (req.body.approved == 1) ? 'APPROVE' : 'REJECT',

                status: 'ROI_ADDED',

                actionByUserId: req.user.id,

                remarks: req.body.remarks
            }
        ], {
            transaction: disburseAmtTxn
        });

        if (FUActions.error) {
            await disburseAmtTxn.rollback();
            return next(FUActions.error);
        }

        /* Update FU */
        const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, {
            status: req.body.status,
            factoredDate: req.body.factoredDate
        }, {
            ...(req.body.approved == 1) ? {
                include: [
                    {
                        model: db['EntityLinks'],
                        as: 'buyerSellerLink',
                        include: [
                            {
                                model: db.EntityDetails,
                                as: 'buyer',
                                attributes: ['id']
                            },
                            {
                                model: db.EntityDetails,
                                as: 'seller',
                                include: [
                                    {
                                        model: db['EntityBankDetails'],
                                        as: 'bankDetails',
                                        where: {
                                            isDefault: 1
                                        },
                                        attributes: ['id']
                                    },
                                    {
                                        model: db.EntityDetails,
                                        as: 'createdByFinancier',
                                        include: [
                                            {
                                                model: db['EntityBankDetails'],
                                                as: 'bankDetails',
                                                where: {
                                                    isDefault: 1
                                                },
                                                attributes: ['id']
                                            }
                                        ]
                                    }
                                ],
                                attributes: {
                                    exclude: ['createdByFinancierId']
                                }
                            }
                        ],
                        attributes: {
                            exclude: ['buyerId', 'sellerId']
                        }
                    },
                    'invoices'
                ],
                attributes: {
                    exclude: ['buyerSellerLinkId']
                }
            } : {},
            transaction: disburseAmtTxn
        });

        if (updatedFU.error) {
            await disburseAmtTxn.rollback();
            return next(updatedFU.error);
        }

        await disburseAmtTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Factoring Unit ${(
                (req.body.approved == 1) ? 'approved for finance' : 'rejected'
            )} successfully.`
        });

    } catch (error) {
        next(error);
    }
}

const deleteAnFUByFUNoCntrl = async (req, res, next) => {
    try {
        const deletedFU = await FUHelpers.deleteAllFactoringUnits({
            where: {
                factoringUnitNo: req.params.factoringUnitNo
            }
        });

        if (deletedFU.error) {
            return next(deletedFU.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Factoring Unit deleted successfully.`
        });

    } catch (error) {
        next(error);
    }
};

module.exports = {
    FUInitialCheckerConfigCntrl,
    createAnFUFromJSONCntrl,
    createAnFUFromFileCntrl,

    getAnFUByFUNoCntrl,
    getAllFactoringUnitsCntrl,

    combineTwoFUsCntrl,

    updateAnFUByFUNoCntrl,
    sendFUForFinanceCntrl,
    validateROICntrl,
    disburseAmtCntrl,

    deleteAnFUByFUNoCntrl
}