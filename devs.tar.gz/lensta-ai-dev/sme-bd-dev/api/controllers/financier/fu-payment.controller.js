const { StatusCodes } = require("http-status-codes");
const FUPymtHelpers = require('../../helpers/financier').FUPymt;
const { applyLimitAndOffsetParams } = require("../../services/generic-query.service");
const FUHelpers = require('../../helpers/financier').factoringUnit;
const sequelize = require("sequelize")

const createAnFUPymtCntrl = async (req, res, next) => {
    try {
        req.body.factoringUnitNo = req.params.factoringUnitNo;

        const FUPymt = await FUPymtHelpers.createAnFUPymt(req.body);

        if (FUPymt.error) {
            return next(FUPymt.error);
        }

        let FUPymts = await FUPymtHelpers.getAllFUPymts({
            where: {
                factoringUnitNo: req.params.factoringUnitNo,
                status: 'SUCCESSFUL'
            },
            attributes: [
                [sequelize.fn('SUM', sequelize.col('paymentAmount')), 'totalPaymentAmount'],
            ],
        });

        const factoringUnit = await FUHelpers.getAnFUByFUNo(req.params.factoringUnitNo, {
            include: ['invoices'],
            attributes: {
                exclude: ['buyerSellerLinkId', 'nextCheckerUserId']
            }
        });

        // Send FU for Active/Overdue Disbursement in-case (sum of successful payment-amount) is greater than the (disbursement amount).
        if (FUPymts.data[0].dataValues.totalPaymentAmount >= (factoringUnit.data.factoringAmount - (factoringUnit.data.sellerFees + factoringUnit.data.sellerInterest))) {

            let currDate = new Date();
            currDate.setHours(0, 0, 0, 0);

            let dueDate = new Date(factoringUnit.data.invoices[0].invoiceDueDate);
            dueDate.setHours(0, 0, 0, 0);

            let status = currDate > dueDate ? "OVERDUE_DISBURSEMENT" : "ACTIVE_DISBURSEMENT";

            const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, { status });

            if (updatedFU.error) {
                return next(updatedFU.error);
            }
        }

        if (req.body.status === 'CANCELLED') {
            const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, { status: "REJECTED" });

            if (updatedFU.error) {
                return next(updatedFU.error);
            }
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Payment added successfully.',
            data: FUPymt.data
        });

    } catch (error) {
        next(error);
    }
}

const getFUPymtByFUNoCntrl = async (req, res, next) => {
    try {
        let FUPymts = await FUPymtHelpers.getAllFUPymts({
            where: [req.query, {
                factoringUnitNo: req.params.factoringUnitNo
            }]
        });

        if (FUPymts.error) {
            return next(FUPymts.error);
        }

        const resultLength = FUPymts.data.length;

        FUPymts.totalPaymentAmount = FUPymts.data.reduce((prevPymt, currPymt) => currPymt.status === 'SUCCESSFUL' ? prevPymt + currPymt.paymentAmount : prevPymt, 0);

        FUPymts.data = [...applyLimitAndOffsetParams(
            FUPymts.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: {
                data: FUPymts.data,
                totalPaymentAmount: FUPymts.totalPaymentAmount
            }
        });

    } catch (error) {
        next(error);
    }
}
const getAnFUPymtByPymtIdCntrl = async (req, res, next) => {
    try {
        const FUPymt = await FUPymtHelpers.getAnFUPymtByPymtId(req.params.paymentId);

        if (FUPymt.error) {
            return next(FUPymt.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: FUPymt.data
        });

    } catch (error) {
        next(error);
    }
}

const updateAnFUPymtByPymtIdCntrl = async (req, res, next) => {
    try {
        req.body.factoringUnitNo = req.params.factoringUnitNo;

        const updatedFUPymt = await FUPymtHelpers.updateAnFUPymtByPymtId(req.params.paymentId, req.body);

        if (updatedFUPymt.error) {
            return next(updatedFUPymt.error);
        }

        // Send FU for Active/Overdue Disbursement in-case (sum of successful payment-amount) is greater than the (disbursement amount).
        if (FUPymts.data[0].dataValues.totalPaymentAmount >= (factoringUnit.data.factoringAmount - (factoringUnit.data.sellerFees + factoringUnit.data.sellerInterest))) {

            let currDate = new Date();
            currDate.setHours(0, 0, 0, 0);

            let dueDate = new Date(factoringUnit.data.invoices[0].invoiceDueDate);
            dueDate.setHours(0, 0, 0, 0);

            let status = currDate > dueDate ? "OVERDUE_DISBURSEMENT" : "ACTIVE_DISBURSEMENT";

            const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, { status });

            if (updatedFU.error) {
                return next(updatedFU.error);
            }
        }

        if (req.body.status === 'CANCELLED') {
            const updatedFU = await FUHelpers.updateAnFUByFUNo(req.params.factoringUnitNo, { status: "REJECTED" });

            if (updatedFU.error) {
                return next(updatedFU.error);
            }
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Payment updated successfully.',
            data: updatedFUPymt.data
        });

    } catch (error) {
        next(error);
    }
}

const deleteAnFUPymtByPymtIdCntrl = async (req, res, next) => {
    try {
        const deletedFUPymt = await FUPymtHelpers.deleteAnFUPymtByPymtId(req.params.paymentId);

        if (deletedFUPymt.error) {
            return next(deletedFUPymt.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Payment deleted successfully.'
        });

    } catch (error) {
        next(error);
    }
}

module.exports = {
    createAnFUPymtCntrl,

    getFUPymtByFUNoCntrl,
    getAnFUPymtByPymtIdCntrl,

    updateAnFUPymtByPymtIdCntrl,

    deleteAnFUPymtByPymtIdCntrl
}