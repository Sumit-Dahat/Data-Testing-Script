module.exports = {

    factoringUnit: require('./factoring-unit.controller'),

    FUTxn: require('./fu-transaction.controller'),

    FUPymt: require('./fu-payment.controller'),

    invoice: require('./invoice.controller')
};