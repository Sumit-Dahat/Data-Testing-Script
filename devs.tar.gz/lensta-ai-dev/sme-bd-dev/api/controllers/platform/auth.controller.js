const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const userHelpers = require('../../helpers/platform').user;
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../error');
const { default: axios } = require('axios');

const loginCntrl = async (req, res, next) => {
    try {
        const user = await userHelpers.getAnUser({
            where: (
                (req.body.emailId) ? {
                    emailId : req.body.emailId
                } : {
                    mobileNo : req.body.mobileNo
                }
            ),
            include: [
                {
                    model: db.EntityDetails,
                    as: 'entity',
                    include: [
                        'approvalDetails',
                        {
                            model: db.EntityDetails,
                            as: 'createdByFinancier',
                            attributes: ['finLogoDocId','active']
                        }
                    ],
                    attributes: {
                        exclude: ['createdByFinancierId']
                    }
                }
            ],
            attributes: {
                exclude: ['entityId', 'encPassword'],
            }
        });



        if (user.error || !user.data) 
        {
            return next(new APIError("0001", StatusCodes.UNAUTHORIZED));

            return res.status(200).json({message:"jsdfjdl"})
            return next(new APIError("0001", StatusCodes.UNAUTHORIZED));
        }

        /* Check if user is active */
        if (!user.data.active) {
            return next(new APIError("0029", StatusCodes.FORBIDDEN));
        }

        /* Check if Financier is active (for Buyer / Seller) */
        if (
            user.data.entity &&
            ['BUYER','SELLER'].includes(user.data.entity.entityCategory) &&
            (user.data.entity.createdByFinancier) &&
            (!user.data.entity.createdByFinancier.active)
        ) {
            return next(new APIError('0030', StatusCodes.FORBIDDEN));
        }

        /* Check if Entity is active */
        if (
            user.data.entity &&
            !user.data.entity.active
        ) {
            return next(new APIError("0031", StatusCodes.FORBIDDEN)); 
        }


        /* Check if subscription package is expired */
        if(user.data.entity){
            const approvalDetails = ['BUYER','SELLER'].includes(user.data.entity.entityCategory) ? user.data.entity.createdByFinancier.approvalDetails : ['FINANCIER'].includes(user.data.entity.entityCategory) ? (user.data.entity.approvalDetails) : null; 

            if(approvalDetails && new Date(approvalDetails.dateOfExpiry) <= new Date()){
                return next(new APIError("0179", StatusCodes.UNAUTHORIZED));
            }
        }
         
        const isValidPassword = bcrypt.compareSync(
            req.body.password,
            (user.data.password) ? user.data.password : ''
        );

        if (!isValidPassword) {
            return next(new APIError("0002", StatusCodes.UNAUTHORIZED));
        }

        const token_payload = {
            id: user.data.id,

            firstName: user.data.firstName,
            
            lastName: user.data.lastName,
            
            emailId: user.data.emailId,
            
            mobileNo: user.data.mobileNo,
            
            userType: user.data.userType,
            
            active: user.data.active,
            
            entityId: (user.data.entity) ? user.data.entity.id : null,
            
            entityCategory: (user.data.entity) ? user.data.entity.entityCategory : null,

            finLogoDocId: (
                (user.data.entity) ? (
                    (user.data.entity.entityCategory == 'FINANCIER') ? user.data.entity.finLogoDocId : user.data.entity.createdByFinancier.finLogoDocId
                ) : null
            )
        };

        const token = await jwt.sign(
            { token_payload },
            envConfig.JWT_SECRET_KEY
        );

        res.status(StatusCodes.OK).json({
            error: null,
            message:'User logged in successfully.',
            token,
            data: token_payload
        });

    } catch(error) {
        next(error);
    }
};

const sendResetPasswordLink = async (req, res, next) => {
    const user = await userHelpers.getAnUser({
        where: (
            (req.body.emailId) ? {
                emailId : req.body.emailId
            } : {
                mobileNo : req.body.mobileNo
            }
        )
    });

    if (user.error || !user.data) {
        return next(new APIError("0001", StatusCodes.UNAUTHORIZED));
    }

    /* Check if user is active */
    if (!user.data.active) {
        return next(new APIError("0029", StatusCodes.FORBIDDEN));
    }

    const token = jwt.sign({ userId: user.data.id }, user.data.id + envConfig.JWT_SECRET_KEY , { expiresIn: '15m' });
    
    let data = {};
    
    data[req.body.emailId ? "emailId" : "mobileNo"] = req.body.emailId ? req.body.emailId : req.body.mobileNo;
    
    data.body =  `Hi ${user.data.firstName},\nForget your password ? We received a request to reset the password for your account.\nClick on the link to reset your password.\n\n${`${envConfig.API_BASE_URL}/reset-password/${user.data.id}/${token}`}`;
    
    if(req.body.emailId){
        data.subject = "Reset Password";
    }
    
    const sendEmail = await axios.post(`${envConfig.NOTIFICATION_SERVICE_API_BASE_URL}/notifications/${req.body.emailId ? "email" : "sms"}`, data);

    if (sendEmail.status != 200) {
        return next(new APIError('0154', StatusCodes.BAD_REQUEST));
    }

    const updatedUser = await userHelpers.updateAnUserById(user.data.id, { resetPassword : token }); // set-reset password for one-time.

    if (updatedUser.error) {
        return next(updatedUser.error);
    }
   
    res.status(StatusCodes.OK).json({
        error: null,
        message: `Password reset link sent successfully. Please check your ${req.body.emailId ? "emailId." : "mobileNo."}`,
        data: null
    });
}

const resetPassword = async (req, res, next) => {
    try {
        const user = await userHelpers.getAnUser({
            where:{
                id: req.params.userId
            }
        });
    
        if (user.error || !user.data) {
            return next(new APIError("0001", StatusCodes.UNAUTHORIZED));
        }
    
        /* Check if user is active */
        if (!user.data.active) {
            return next(new APIError("0029", StatusCodes.FORBIDDEN));
        }

        /* Check if reset-password flag is true. In-case user try to update password on clicking the reset-password link second-time. reset-flag will be false. */
        if(!user.data.resetPassword || user.data.resetPassword != req.params.token){
            return next(new APIError("0180", StatusCodes.BAD_REQUEST));
        }

        const newToken = user.data.id + envConfig.JWT_SECRET_KEY;

        const verifiedJWT = jwt.verify(req.params.token, newToken);

        if(verifiedJWT && req.body.password){
            const updatedUser = await userHelpers.updateAnUserById(req.params.userId, { ...req.body, resetPassword: null });

            if (updatedUser.error) {
                return next(updatedUser.error);
            }

            res.status(StatusCodes.OK).json({
                error: null,
                message: 'Password reset successfully.',
                data: null
            });
        }

    } catch (error) {
        next(error);
    }
}

module.exports = {
    loginCntrl,
    sendResetPasswordLink,
    resetPassword
};