const entBankDetailsCntrls = require('../buyer-seller/index').entBankDetails;
const userCntrls = require('./user.controller');
const financierCntrls = require('./financier.controller');

const getFinancierProfileCntrl = async (req, res, next) => {
    try {
        req.params.financierId = req.user.entityId;
        financierCntrls.getAnFinancierByIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const createAnFinancierBankDetailCntrl = async (req, res, next) => {
    try {
        entBankDetailsCntrls.createAnEntBankDetCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const createAnFinancierUserCntrl = async (req, res, next) => {
    try {
        userCntrls.createAnUserCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const getAnFinBankDetailByIdCntrl = async (req, res, next) => {
    try {
        entBankDetailsCntrls.getAnEntBankDetailByIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const getAnFinancierUserByIdCntrl = async (req, res, next) => {
    try {
        userCntrls.getAnUserByIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};


const getFinBankDetailsByFinIdCntrl = async (req, res, next) => {
    try {
        entBankDetailsCntrls.getEntBankDetlsByEntityIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const getFinancierUsersCntrl = async (req, res, next) => {
    try {
        userCntrls.getAllUsersByEntityIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const updateAnFinBankDetailByIdCntrl = async (req, res, next) => {
    try {
        entBankDetailsCntrls.updateAnEntBankDetByIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const updateAnFinancierUserByIdCntrl = async (req, res, next) => {
    try {
        userCntrls.updateAnUserByIdCntrl(req, res, next);

    } catch(error) {
        next(error);
    }
};

const updateFinancierProfileCntrl = async (req, res, next) => {
    try {
        financierCntrls.updateAnFinancierByIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const deleteAnFinBankDetailByIdCntrl = async (req, res, next) => {
    try {
        entBankDetailsCntrls.deleteAnEntBankDetByIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const deleteAnFinancierUserByIdCntrl = async (req, res, next) => {
    try {
        userCntrls.deleteAnUserByIdCntrl(req, res, next);

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnFinancierBankDetailCntrl,
    createAnFinancierUserCntrl,
    
    getAnFinBankDetailByIdCntrl,
    getAnFinancierUserByIdCntrl,
    getFinancierProfileCntrl,
    getFinBankDetailsByFinIdCntrl,
    getFinancierUsersCntrl,

    updateAnFinBankDetailByIdCntrl,
    updateAnFinancierUserByIdCntrl,
    updateFinancierProfileCntrl,
    
    deleteAnFinBankDetailByIdCntrl,
    deleteAnFinancierUserByIdCntrl
}