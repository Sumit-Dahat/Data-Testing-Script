const checkerLevelHelpers = require('../../helpers/platform').checkerLevel;
const { APIError } = require("../../error");
const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services//generic-query.service");

const createAnCheckerLevelCntrl = async (req, res, next) => {
    try {
        const checkerLevel = await checkerLevelHelpers.createAnCheckerLevel(req.body, {
            include: [
                {
                    model: db['Users'],
                    as: 'user',
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ]
        });

        if (checkerLevel.error) {
            return next(checkerLevel.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Checker Level added successfully.`,
            data: checkerLevel.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnCheckerLevelByIdCntrl = async (req, res, next) => {
    try {
        const checkerLevel = await checkerLevelHelpers.getAnCheckerLevelById(req.params.checkerLevelId, {
            include: [
                {
                    model: db['Users'],
                    as: 'user',
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ],
            attributes: {
                exclude: ['userId']
            }
        });

        if (checkerLevel.error) {
            return next(checkerLevel.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: checkerLevel.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllEntityCheckerLevelsCntrl = async (req, res, next) => {
    try {
        let checkerLevels = await checkerLevelHelpers.getAllCheckerLevels({
            where: [req.query],
            include: [
                {
                    model: db['Users'],
                    as: 'user',
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ],
            attributes: {
                exclude: ['userId']
            }
        });

        if (checkerLevels.error) {
            return next(checkerLevels.error);
        }

        const resultLength = checkerLevels.data.length;

        checkerLevels.data = [...applyLimitAndOffsetParams(
            checkerLevels.data,
            req.pagination.limit,
            req.pagination.offset
        )];
        
        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: checkerLevels.data
        });

    } catch(error) {
        next(error);
    }
};

const updateAnCheckerLevelByIdCntrl = async (req, res, next) => {
    try {
        const updatedChkrLvl = await checkerLevelHelpers.updateAnCheckerLevelById(req.params.checkerLevelId, req.body, {
            include: [
                {
                    model: db['Users'],
                    as: 'user',
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ],
            attributes: {
                exclude: ['userId']
            }
        });

        if (updatedChkrLvl.error) {
            return next(updatedChkrLvl.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Checker Level updated successfully.`,
            data: updatedChkrLvl.data
        });

    } catch(error) {
        next(error);
    }
};

const deleteAnCheckerLevelByIdCntrl = async (req, res, next) => {
    try {
        const deletedChkrLvl = await checkerLevelHelpers.deleteAnCheckerLevelById(req.params.checkerLevelId);

        if (deletedChkrLvl.error) {
            return next(deletedChkrLvl.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Checker Level deleted successfully.`
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnCheckerLevelCntrl,
    getAnCheckerLevelByIdCntrl,
    getAllEntityCheckerLevelsCntrl,
    updateAnCheckerLevelByIdCntrl,
    deleteAnCheckerLevelByIdCntrl
};