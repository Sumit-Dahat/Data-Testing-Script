const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services/generic-query.service");
const entityTypeHelpers = require('../../helpers/platform').entityType;

const createAnEntityTypeCntrl = async (req, res, next) => {
    try {
        const entityType = await entityTypeHelpers.createAnEntityType(req.body);

        if (entityType.error) {
            return next(entityType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Type added successfully.',
            data: entityType.data
        });

    } catch (error) {
        next(error);
    }
};

const getAnEntityTypeByIdCntrl = async (req, res, next) => {
    try {
        const entityType = await entityTypeHelpers.getAnEntityTypeById(req.params.entityTypeId);

        if (entityType.error) {
            return next(entityType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: entityType.data
        });

    } catch (error) {
        next(error);
    }
};

const getAllEntityTypesCntrl = async (req, res, next) => {
    try {
        let entityTypes = await entityTypeHelpers.getAllEntityTypes({
            where: [req.query]
        });

        if (entityTypes.error) {
            return next(entityTypes.data)
        }

        const resultLength = entityTypes.data.length;

        entityTypes.data = [...applyLimitAndOffsetParams(
            entityTypes.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: entityTypes.data
        });

    } catch (error) {
        next(error);
    }
};

const updateAnEntityTypeByIdCntrl = async (req, res, next) => {
    try {
        const updatedEntityType = await entityTypeHelpers.updateAnEntityTypeById(req.params.entityTypeId, req.body);

        if (updatedEntityType.error) {
            return next(updatedEntityType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Entity Type updated successfully.`,
            data: updatedEntityType.data[1][0]
        });

    } catch (error) {
        next(error);
    }
};

module.exports = {
    createAnEntityTypeCntrl,
    getAnEntityTypeByIdCntrl,
    getAllEntityTypesCntrl,
    updateAnEntityTypeByIdCntrl
};