const financierHelpers = require('../../helpers/platform').financier;
const userHelpers = require('../../helpers/platform').user;
const entDocsCntrls = require('../../controllers/buyer-seller/index').entDocuments;
const { APIError } = require('../../error');
const { StatusCodes } = require('http-status-codes');
const { applyLimitAndOffsetParams } = require('../../services//generic-query.service');

const createAnFinancierCntrl = async (req, res, next) => {
    try {
        
        // Upload Financier logo if available
        if (req.files && req.files.entityLogo) {
            const finLogoUpload = await financierHelpers.addOrUpdateFinLogo(
                req.files.entityLogo,
                req.user,
                req.headers.authorization
            );

            if (finLogoUpload.error) {
                return next(finLogoUpload.error);
            }
            req.body.entityDetails.finLogoDocId = finLogoUpload.data.id;
        }

        /* Start DB transaction */
        const createAnFinTxn = await db.sequelize.transaction();

        /* Create an Financier */
        const finEntDetails = await financierHelpers.createAnFinancier(req.body.entityDetails, {
            transaction: createAnFinTxn
        });

        if (finEntDetails.error) {
            await createAnFinTxn.rollback();
            return next(finEntDetails.error);
        }

        /* Create an Financier Admin */
        req.body.adminDetails.entityId = finEntDetails.data.id;
        
        req.body.adminDetails.entityCategory = finEntDetails.data.entityCategory;

        const finAdmin = await userHelpers.createAnUser(req.body.adminDetails, {
            transaction: createAnFinTxn,
            attributes: {
                exclude: ['password', 'encPassword']
            }
        });

        if (finAdmin.error) {
            await createAnFinTxn.rollback();
            return next(finAdmin.error);
        }

        /* Create Financier Approval Details */
        req.body.approvalDetails.financierId = finEntDetails.data.id;

        const finApproval = await financierHelpers.createAnFinancierApproval(req.body.approvalDetails, {
            transaction: createAnFinTxn
        });

        if (finApproval.error) {
            await createAnFinTxn.rollback();
            return next(finApproval.error);
        }

        await createAnFinTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Financier added successfully.',
            data: {
                entityDetails: finEntDetails.data,
                adminDetails: finAdmin.data,
                approvalDetails: finApproval.data
            }
        });

    } catch(error) {
        next(error);
    }
};

const getFinLogoSignedURLCntrl = async (req, res, next) => {
    try {
        req.params.documentId = req.params.logoDocumentId;

        entDocsCntrls.getEntityDocSignedURLCntrl(req, res, next);

    } catch(error) {
        return next(new APIError('0132', StatusCodes.BAD_REQUEST));
    }
}

const getAnFinancierByIdCntrl = async (req, res, next) => {
    try {
        let finEntDetails = await financierHelpers.getAnFinancierById(req.params.financierId, {
            include: [
                'approvalDetails',
                {
                    model: db['Users'],
                    as: 'users',
                    where: {
                        userType: 'ADMIN'
                    },
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ]
        });

        if (finEntDetails.error) {
            return next(finEntDetails.error);
        }

        delete finEntDetails.data.dataValues.users;
        delete finEntDetails.data.dataValues.approvalDetails;

        res.status(StatusCodes.OK).json({
            error: null,
            data: {
                entityDetails: finEntDetails.data,
                adminDetails: finEntDetails.data.users[0],
                approvalDetails: finEntDetails.data.approvalDetails
            }
        });

    } catch(error) {
        next(error);
    }
};

const getAllFinanciersCntrl = async (req, res, next) => {
    try {
        const financiers = await financierHelpers.getAllFinanciers({
            where: [req.query],
            include: [
                'approvalDetails',
                {
                    model: db['Users'],
                    as: 'users',
                    where: {
                        userType: 'ADMIN'
                    },
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ] 
        });

        if (financiers.error) {
            return next(financiers.error);
        }

        let financierDetails = [...financiers.data.map((financier) => {
            const finApprovalDetails = financier.approvalDetails;
            const finAdmin = financier.users[0];
            
            delete financier.dataValues.approvalDetails;
            delete financier.dataValues.users;
            
            return {
                entityDetails: financier,
                adminDetails: finAdmin,
                approvalDetails: finApprovalDetails
            }
        })];

        const resultLength = financierDetails.length;

        financierDetails = applyLimitAndOffsetParams(
            financierDetails,
            req.pagination.limit,
            req.pagination.offset
        );
        
        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: financierDetails
        });

    } catch(error) {
        next(error);
    }
};

const updateAnFinancierByIdCntrl = async (req, res, next) => {
    try {
        const finToUpdate = await financierHelpers.getAnFinancierById(req.params.financierId);

        if (finToUpdate.error) {
            return next(finToUpdate.error);
        }

        /* Add or update Financier Logo */
        if (req.files && req.files.entityLogo) {
            const finLogoUpload = await financierHelpers.addOrUpdateFinLogo(
                req.files.entityLogo,
                req.user,
                req.headers.authorization,
                finToUpdate.data.finLogoDocId
            )

            if (finLogoUpload.error) {
                return next(finLogoUpload.error);
            }

            if (finLogoUpload.data.id) {
                req.body.entityDetails = (req.body.entityDetails) ? req.body.entityDetails : {};
                
                req.body.entityDetails.finLogoDocId = finLogoUpload.data.id;
            }
        }

        /* Start Financier update DB transaction */
        const updateAnFinTxn = await db.sequelize.transaction();
        
        const finDetails = {...req.body};
        let updateFinResult = {};

        // Update Financier Entity Details if present
        if (
            finDetails.entityDetails && 
            Object.keys(finDetails.entityDetails).length > 0
        ) {
            const updatedFinEntDetls = await financierHelpers.updateAnFinancierById(req.params.financierId, finDetails.entityDetails, {
                transaction: updateAnFinTxn
            });

            if (updatedFinEntDetls.error) {
                await updateAnFinTxn.rollback();
                return next(updatedFinEntDetls.error);
            }

            updateFinResult.entityDetails = updatedFinEntDetls.data;
        }

        // Update Financier Admin Details if present
        if (
            finDetails.adminDetails && 
            Object.keys(finDetails.adminDetails).length > 0
        ) {
            if (!finDetails.adminDetails.id) {
                await updateAnFinTxn.rollback();
                return next(new APIError('0012', StatusCodes.NOT_FOUND));
            }

            const updatedFinAdmin = await userHelpers.updateAnUserById(finDetails.adminDetails.id, finDetails.adminDetails, {
                include: ['entity'],
                attributes: {
                    exclude: ['entityId', 'password', 'encPassword']
                },
                transaction: updateAnFinTxn
            });

            if (updatedFinAdmin.error) {
                await updateAnFinTxn.rollback();
                return next(updatedFinAdmin.error);
            }

            updateFinResult.adminDetails = updatedFinAdmin.data;
        }

        // Update Financier Approval Details if present
        if (
            finDetails.approvalDetails && 
            Object.keys(finDetails.approvalDetails).length > 0
        ) {
            const updatedFinApprvl = await financierHelpers.updateAnFinApprovalByFinancierId(
                req.params.financierId, 
                finDetails.approvalDetails, 
                {
                    where: {
                        financierId: req.params.financierId
                    },
                    include: 'financier',
                    attributes: {
                        exclude: ['financierId']
                    },
                    transaction: updateAnFinTxn
            });

            if (updatedFinApprvl.error) {
                await updateAnFinTxn.rollback();
                return next(updatedFinApprvl.error);
            }

            updateFinResult.approvalDetails = updatedFinApprvl.data;
        }

        // Commit Financier Update DB transaction and send response
        await updateAnFinTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Financier Details updated successfully.',
            data: updateFinResult
        });

    } catch(error) {
        next(error);
    }
};

const deleteAnFinancierByIdCntrl = async (req, res, next) => {
    try {
        const deletedFinancier = await financierHelpers.deleteAllFinanciers({
            where: {
                id: req.params.financierId,
            }
        });

        if (deletedFinancier.error) {
            return next(deletedFinancier.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Financier deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

const deleteAllFinanciersCntrl = async (req, res, next) => {
    try {
        const deletedFinanciers = await financierHelpers.deleteAllFinanciers({
            where: {
                entityCategory: 'FINANCIER'
            }
        });

        if (deletedFinanciers.error) {
            return next(deletedFinanciers.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Financier(s) deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnFinancierCntrl,
    
    getFinLogoSignedURLCntrl,
    getAnFinancierByIdCntrl,
    getAllFinanciersCntrl,
    
    updateAnFinancierByIdCntrl,
    
    deleteAnFinancierByIdCntrl,
    deleteAllFinanciersCntrl
}