const userHelpers = require('../../helpers/platform').user;
const { StatusCodes } = require('http-status-codes');
const { getDecryptedString } = require('../../services/crypto.service');
const { applyLimitAndOffsetParams } = require('../../services//generic-query.service');

const createAnUserCntrl = async (req, res, next) => {
    try {
        const user = await userHelpers.createAnUser(req.body, {
            attributes: {
                exclude: ['password', 'encPassword']
            }
        });

        if (user.error) {
            return next(user.error);
        }

        res.status(StatusCodes.OK).json({
            status: (200),
            message: 'User added successfully.',
            data: user.data
        });

    } catch(error) {
        next(error);
    }
};

const getUserProfileCntrl = async (req, res, next) => {
    try {
        req.params.userId = req.user.id;
        getAnUserByIdCntrl(req, res, next);

    } catch(error) {
        next(error);
    }
};

const getUserPasswordCntrl = async (req, res, next) => {
    try {
        const user = await userHelpers.getAnUserById(req.params.userId);

        if (user.error) {
            return next(user.error);
        }

        const decryptedPassword = getDecryptedString(user.data.encPassword);

        res.status(StatusCodes.OK).json({
            error: null,
            data: {
                password: decryptedPassword
            }
        });

    } catch(error) {
        next(error);
    }
};

const getAnUserByIdCntrl = async (req, res, next) => {
    try {
        const user = await userHelpers.getAnUserById(req.params.userId, {
            include: [
                {
                    model: db.EntityDetails,
                    as: 'entity',
                    include: ['createdByFinancier'],
                    attributes: {
                        exclude: ['createdByFinancierId']
                    }
                }
            ],
            attributes: {
                exclude: ['entityId', 'password', 'encPassword']
            }
        });

        if (user.error) {
            return next(user.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: user.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllUsersByEntityIdCntrl = async (req, res, next) => {
    try {
        let entityUsers = await userHelpers.getAllUsers({
            where: [req.query, {
                id: {
                    [db.Sequelize.Op.ne]: req.user.id
                },
                entityId: req.params.entityId
            }],
            include: ['entity'],
            attributes: {
                exclude: ['entityId', 'password', 'encPassword']
            }
        });

        if (entityUsers.error) {
            return next(entityUsers.error);
        }

        const resultLength = entityUsers.data.length;

        entityUsers.data = [...applyLimitAndOffsetParams(
            entityUsers.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: entityUsers.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllPlatformUsersCntrl = async (req, res, next) => {
    try {
        let platformUsers = await userHelpers.getAllUsers({
            where: [req.query, {
                id: {
                    [db.Sequelize.Op.ne]: req.user.id
                },
                entityId: null,
                [db.Sequelize.Op.or]: [
                    { userType: 'ADMIN' },
                    { userType: 'OPERATION_MANAGER' }
                ]
            }],
            include: ['entity'],
            attributes: {
                exclude: ['entityId', 'password', 'encPassword'],
            }
        });

        if (platformUsers.error) {
            return next(platformUsers.error);
        }

        const resultLength = platformUsers.data.length;

        platformUsers.data = [...applyLimitAndOffsetParams(
            platformUsers.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: platformUsers.data
        });

    } catch(error) {
        next(error);
    }
};

const updateUserProfileCntrl = async (req, res, next) => {
    try {   
        updateAnUserByIdCntrl(req, res, next);
    } catch(error) {
        next(error);
    }
};

const updateAnUserByIdCntrl = async (req, res, next) => {
    try {
        const updatedUser = await userHelpers.updateAnUserById(req.params.userId, req.body, {
            include: ['entity'],
            attributes: {
                exclude: ['entityId', 'password', 'encPassword'],
            }
        });

        if (updatedUser.error) {
            return next(updatedUser.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'User Details updated successfully.',
            data: updatedUser.data
        });

    } catch(error) {
        next(error);
    }
};

const deleteAnUserByIdCntrl = async (req, res, next) => {
    try {
        const deletedUser = await userHelpers.deleteAllUsers({
            where: {
                id: req.params.userId
            }
        });

        if (deletedUser.error) {
            return next(deletedUser.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'User deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

const deleteAllUsersCntrl = async (req, res, next) => {
    try {
        const deletedUsers = await userHelpers.deleteAllUsers({
            where: {
                userType: {
                    [db.Sequelize.Op.ne]: 'ADMIN'
                }
            }
        });

        if (deletedUsers.error) {
            return next(deletedUsers.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'User(s) deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
}

module.exports = {
    createAnUserCntrl,

    getUserProfileCntrl,
    getUserPasswordCntrl,
    getAnUserByIdCntrl,
    getAllUsersByEntityIdCntrl,
    getAllPlatformUsersCntrl,

    updateUserProfileCntrl,
    updateAnUserByIdCntrl,

    deleteAnUserByIdCntrl,
    deleteAllUsersCntrl
};