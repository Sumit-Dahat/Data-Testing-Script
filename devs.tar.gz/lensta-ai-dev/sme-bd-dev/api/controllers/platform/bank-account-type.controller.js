const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services//generic-query.service");
const bankAccTypeHelpers = require('../../helpers/platform').bankAccountType;

const createAnBankAccountTypeCntrl = async (req, res, next) => {
    try {
        const bankAccountType = await bankAccTypeHelpers.createAnBankAccountType(req.body);

        if (bankAccountType.error) {
            return next(bankAccountType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Bank Account Type added successfully.',
            data: bankAccountType.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnBankAccountTypeByIdCntrl = async (req, res, next) => {
    try {
        const bankAccountType = await bankAccTypeHelpers.getAnBankAccountTypeById(req.params.bankAccountTypeId);

        if (bankAccountType.error) {
            return next(bankAccountType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: bankAccountType.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllBankAccountTypesCntrl = async (req, res, next) => {
    try {
        let bankAccountTypes = await bankAccTypeHelpers.getAllBankAccountTypes({
            where: [req.query]
        });

        if (bankAccountTypes.error) {
            return next(bankAccountTypes.error);
        }

        const resultLength = bankAccountTypes.data.length;

        bankAccountTypes.data = [...applyLimitAndOffsetParams(
            bankAccountTypes.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: bankAccountTypes.data
        });
        
    } catch(error) {
        next(error);
    }
};

const updateAnBankAccountTypeByIdCntrl = async (req, res, next) => {
    try {
        const updatedBankAccType = await bankAccTypeHelpers.updateAnBankAccountTypeById(req.params.bankAccountTypeId, req.body);

        if (updatedBankAccType.error) {
            return next(updatedBankAccType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Bank Account Type updated successfully.`,
            data: updatedBankAccType.data[1][0]
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnBankAccountTypeCntrl,
    getAnBankAccountTypeByIdCntrl,
    getAllBankAccountTypesCntrl,
    updateAnBankAccountTypeByIdCntrl
};