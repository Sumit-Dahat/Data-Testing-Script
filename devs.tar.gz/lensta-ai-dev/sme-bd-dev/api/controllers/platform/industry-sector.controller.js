const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services//generic-query.service");
const industrySectorHelpers = require('../../helpers/platform').industrySector;

const createAnIndustrySectorCntrl = async (req, res, next) => {
    try {
        const industrySector = await industrySectorHelpers.createAnIndustrySector(req.body);

        if (industrySector.error) {
            return next(industrySector.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Industry Sector added successfully.',
            data: industrySector.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnIndustrySectorByIdCntrl = async (req, res, next) => {
    try {
        const industrySector = await industrySectorHelpers.getAnIndustrySectorById(req.params.industrySectorId, {
            include: ['businessSector'],
            attributes: {
                exclude: ['businessSectorId']
            }
        });

        if (industrySector.error) {
            return next(industrySector.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: industrySector.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllIndustrySectorsCntrl = async (req, res, next) => {
    try {
        let industrySectors = await industrySectorHelpers.getAllIndustrySectors({
            where: [req.query],
            include: ['businessSector'],
            attributes: {
                exclude: ['businessSectorId']
            }
        });

        if (industrySectors.error) {
            return next(industrySectors.error);
        }

        const resultLength = industrySectors.data.length;

        industrySectors.data = [...applyLimitAndOffsetParams(
            industrySectors.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: industrySectors.data
        });

    } catch(error) {
        next(error);
    }
};

const updateAnIndustrySectorByIdCntrl = async (req, res, next) => {
    try {
        const updatedIndSect = await industrySectorHelpers.updateAnIndustrySectorById(req.params.industrySectorId, req.body);

        if (updatedIndSect.error) {
            return next(updatedIndSect.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Industry Sector updated successfully.`,
            data: updatedIndSect.data[1][0]
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnIndustrySectorCntrl,
    getAnIndustrySectorByIdCntrl,
    getAllIndustrySectorsCntrl,
    updateAnIndustrySectorByIdCntrl
};