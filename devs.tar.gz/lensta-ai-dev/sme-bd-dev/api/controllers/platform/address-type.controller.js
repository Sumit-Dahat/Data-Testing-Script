const { StatusCodes } = require("http-status-codes");
const addrTypeHelpers = require('../../helpers/platform').addressType;
const { APIError } = require("../../error");
const { applyLimitAndOffsetParams } = require("../../services/generic-query.service");

const createAnAddressTypeCntrl = async (req, res, next) => {
    try {
        const addressType = await addrTypeHelpers.createAnAddressType(req.body);

        if (addressType.error) {
            return next(addressType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Address Type added successfully.',
            data: addressType.data
        });

    } catch (error) {
        next(error);
    }
};

const getAnAddressTypeByIdCntrl = async (req, res, next) => {
    try {
        const addressType = await addrTypeHelpers.getAnAddressTypeById(req.params.addressTypeId);

        if (addressType.error) {
            return next(addressType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: addressType.data
        });

    } catch (error) {
        next(error);
    }
};

const getAllAddressTypesCntrl = async (req, res, next) => {
    try {
        let addressTypes = await addrTypeHelpers.getAllAddressTypes({
            where: [req.query]
        });

        if (addressTypes.error) {
            return next(addressTypes.error);
        }

        const resultLength = addressTypes.data.length;

        addressTypes.data = [...applyLimitAndOffsetParams(
            addressTypes.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: addressTypes.data
        });

    } catch (error) {
        next(error);
    }
};

const updateAnAddressTypeByIdCntrl = async (req, res, next) => {
    try {
        const updatedAddressType = await addrTypeHelpers.updateAnAddressTypeById(req.params.addressTypeId, req.body);

        if (updatedAddressType.error) {
            return next(updatedAddressType.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Address Type updated successfully.`,
            data: updatedAddressType.data[1][0]
        });

    } catch (error) {
        next(error);
    }
};

module.exports = {
    createAnAddressTypeCntrl,
    getAnAddressTypeByIdCntrl,
    getAllAddressTypesCntrl,
    updateAnAddressTypeByIdCntrl
};