module.exports = {
    financier: require('../platform/financier.controller'),

    financierProfile: require('./financier-profile.controller'),

    auth: require('./auth.controller'),

    user: require('./user.controller'),

    checkerLevel: require('./checker-level.controller'),

    kyc: require('./kyc'),

    addressType: require('../platform/address-type.controller'),

    bankAccountType: require('./bank-account-type.controller'),

    businessSector: require('./business-sector.controller'),

    industrySector: require('./industry-sector.controller'),

    industrySubSector: require('./industry-sub-sector.controller'),

    entityType: require('./entity-type.controller'),
};