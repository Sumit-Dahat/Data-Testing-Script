const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services/generic-query.service");
const businessSectorHelpers = require('../../helpers/platform').businessSector;

const createAnBusinessSectorCntrl = async (req, res, next) => {
    try {
        const businessSector = await businessSectorHelpers.createAnBusinessSector(req.body);

        if (businessSector.error) {
            return next(businessSector.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Business Sector added successfully.',
            data: businessSector.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnBusinessSectorByIdCntrl = async (req, res, next) => {
    try {
        const businessSector = await businessSectorHelpers.getAnBusinessSectorById(req.params.businessSectorId);

        if (businessSector.error) {
            return next(businessSector.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: businessSector.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllBusinessSectorsCntrl = async (req, res, next) => {
    try {
        let businessSectors = await businessSectorHelpers.getAllBusinessSectors({
            where: [req.query]
        });

        if (businessSectors.error) {
            return next(businessSectors.error);
        }

        const resultLength = businessSectors.data.length;

        businessSectors.data = [...applyLimitAndOffsetParams(
            businessSectors.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: businessSectors.data
        });

    } catch(error) {
        next(error);
    }
};

const updateAnBusinessSectorByIdCntrl = async (req, res, next) => {
    try {
        const updatedBusnSect = await businessSectorHelpers.updateAnBusinessSectorById(req.params.businessSectorId, req.body);

        if (updatedBusnSect.error) {
            return next(updatedBusnSect.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Business Sector updated successfully.`,
            data: updatedBusnSect.data[1][0]
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnBusinessSectorCntrl,
    getAnBusinessSectorByIdCntrl,
    getAllBusinessSectorsCntrl,
    updateAnBusinessSectorByIdCntrl
};