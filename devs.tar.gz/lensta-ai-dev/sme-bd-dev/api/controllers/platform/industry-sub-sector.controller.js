const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require("../../services/generic-query.service");
const industrySubSectorHelpers = require('../../helpers/platform').industrySubSector;

const createAnIndustrySubSectorCntrl = async (req, res, next) => {
    try {
        const industrySubSector = await industrySubSectorHelpers.createAnIndustrySubSector(req.body);

        if (industrySubSector.error) {
            return next(industrySubSector.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Industry Sub-Sector added successfully.',
            data: industrySubSector.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnIndustrySubSectorByIdCntrl = async (req, res, next) => {
    try {
        const industrySubSector = await industrySubSectorHelpers.getAnIndustrySubSectorById(req.params.industrySubSectorId, {
            include: ['industrySector'],
            attributes: {
                exclude: ['industrySectorId']
            }
        });

        if (industrySubSector.error) {
            return next(industrySubSector.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: industrySubSector.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllIndustrySubSectorsCntrl = async (req, res, next) => {
    try {
        let industrySubSectors = await industrySubSectorHelpers.getAllIndustrySubSectors({
            where: [req.query],
            include: ['industrySector'],
            attributes: {
                exclude: ['industrySectorId']
            }
        });

        if (industrySubSectors.error) {
            return next(industrySubSectors.error);
        }

        const resultLength = industrySubSectors.data.length;

        industrySubSectors.data = [...applyLimitAndOffsetParams(
            industrySubSectors.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: industrySubSectors.data
        });

    } catch(error) {
        next(error);
    }
};

const updateAnIndustrySubSectorByIdCntrl = async (req, res, next) => {
    try {
        const updatedIndSubSect = await industrySubSectorHelpers.updateAnIndustrySubSectorById(req.params.industrySubSectorId, req.body);

        if (updatedIndSubSect.error) {
            return next(updatedIndSubSect.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Industry Sub-Sector updated successfully.`,
            data: updatedIndSubSect.data[1][0]
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnIndustrySubSectorCntrl,
    getAnIndustrySubSectorByIdCntrl,
    getAllIndustrySubSectorsCntrl,
    updateAnIndustrySubSectorByIdCntrl
};