const kyc = {
    finbox: require("./finbox"),
    karza: require("./karza"),
    gridlines: require("./gridlines"),
};

module.exports = kyc;
