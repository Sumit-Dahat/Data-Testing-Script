const axios = require('axios');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../../../error');
const { appendFileMetadata } = require('../../../../services/generic.service');

const addBankAccStmtDetailsCntrl = async (req, res, next) => {
    try {
        let formData =  appendFileMetadata(req.body, req.files['document']);
        const bankAccStmtApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/finbox/stmt/bank-account`, formData, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (bankAccStmtApi.status != 200) {
            return next(new APIError('0154', StatusCodes.BAD_REQUEST));
        }

        res.status(bankAccStmtApi.status).json(bankAccStmtApi.data);
    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0154',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    } 
}

const getBankAccStmtByAccNoCntrl = async (req, res, next) => {
    try {
        const bankAccStmtApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/finbox/stmt/bank-account/${req.params.accountNumber}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (bankAccStmtApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(bankAccStmtApi.status).json(bankAccStmtApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

module.exports = {
    addBankAccStmtDetailsCntrl,
    getBankAccStmtByAccNoCntrl
}