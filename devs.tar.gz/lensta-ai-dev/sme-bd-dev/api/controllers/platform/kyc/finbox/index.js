module.exports = {
    bankAccStmt: require('./finbox-bankAcc-stmt.controller'),
};