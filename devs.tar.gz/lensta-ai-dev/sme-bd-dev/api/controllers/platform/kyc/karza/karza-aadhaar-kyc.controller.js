const axios = require('axios');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../../../error');

const addAadhaarKycDetailsCntrl = async (req, res, next) => {
    try {
        const panKycApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/aadhaar`, req.body, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (panKycApi.status != 200) {
            return next(new APIError('0148', StatusCodes.BAD_REQUEST));
        }

        res.status(panKycApi.status).json(panKycApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0148',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    } 
}

const getAadhaarKycByAadhaarNoCntrl = async (req, res, next) => {
    try {
        const aadhaarNoApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/aadhaar/${req.params.aadhaarNo}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (aadhaarNoApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(aadhaarNoApi.status).json(aadhaarNoApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

const generateAadhaarKycOtpCntrl = async (req, res, next) => {
    try {
        const aadhaarKycOtpApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/aadhaar/otp`, req.body, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (aadhaarKycOtpApi.status != 200) {
            return next(new APIError('0153', StatusCodes.BAD_REQUEST));
        }

        res.status(aadhaarKycOtpApi.status).json(aadhaarKycOtpApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0153',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    } 
}

module.exports = {
    addAadhaarKycDetailsCntrl,
    getAadhaarKycByAadhaarNoCntrl,
    generateAadhaarKycOtpCntrl
}