const axios = require('axios');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../../../error');

const addBankAccKycDetailsCntrl = async (req, res, next) => {
    try {
        const bankAccKycApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/bank-account`, req.body, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (bankAccKycApi.status != 200) {
            return next(new APIError('0154', StatusCodes.BAD_REQUEST));
        }

        res.status(bankAccKycApi.status).json(bankAccKycApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0154',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    } 
}

const getBankAccKycByAccNoCntrl = async (req, res, next) => {
    try {
        const bankAccNoApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/bank-account/${req.params.accountNumber}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (bankAccNoApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(bankAccNoApi.status).json(bankAccNoApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

module.exports = {
    addBankAccKycDetailsCntrl,
    getBankAccKycByAccNoCntrl
}