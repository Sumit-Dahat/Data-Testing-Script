module.exports = {
    panKyc: require('./karza-pan-kyc.controller'),
    gstKyc: require('./karza-gst-kyc.controller'),
    udyamKyc: require('./karza-udyam-kyc.controller'),
    aadhaarKyc: require('./karza-aadhaar-kyc.controller'),
    bankAccKyc: require('./karza-bankAcc-kyc.controller')
};