const axios = require('axios');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../../../error');

const addGstKycDetailsCntrl = async (req, res, next) => {
    try {
        const gstKycApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/gst`, req.body, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (gstKycApi.status != 200) {
            return next(new APIError('0161', StatusCodes.BAD_REQUEST));
        }

        res.status(gstKycApi.status).json(gstKycApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0161',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    } 
}

const addGstItrDetailsCntrl = async (req, res, next) => {
    try {
        const gstItrApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/gst-itr`, req.body, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (gstItrApi.status != 200) {
            return next(new APIError('0161', StatusCodes.BAD_REQUEST));
        }

        res.status(gstItrApi.status).json(gstItrApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0161',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    } 
}

const getGstKycByGstNoCntrl = async (req, res, next) => {
    try {
        const gstNoApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/gst/${req.params.gstin}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (gstNoApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(gstNoApi.status).json(gstNoApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}


const getGstItrByGstNoCntrl = async (req, res, next) => {
    try {
        const gstNoApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/karza/kyc/gst-itr/${req.params.gstin}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (gstNoApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(gstNoApi.status).json(gstNoApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

module.exports = {
    addGstKycDetailsCntrl,
    getGstKycByGstNoCntrl,
    addGstItrDetailsCntrl,
    getGstItrByGstNoCntrl
}