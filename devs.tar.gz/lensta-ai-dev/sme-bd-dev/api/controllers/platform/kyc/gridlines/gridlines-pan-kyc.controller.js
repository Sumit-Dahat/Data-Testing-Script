const axios = require('axios');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../../../error');

const addPanKycDetailsCntrl = async (req, res, next) => {
    try {
        const panKycApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/gridlines/kyc/pan`, req.body, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (panKycApi.status != 200) {
            return next(new APIError('0135', StatusCodes.BAD_REQUEST));
        }

        const linkedGstNosApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/gridlines/kyc/pan/${req.body.pan}/linked-gstins`, req.body ,{
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (linkedGstNosApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(panKycApi.status).json(panKycApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0135',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

const getPanKycByPanNoCntrl = async (req, res, next) => {
    try {
        const panNoApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/gridlines/kyc/pan/${req.params.pan}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (panNoApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(panNoApi.status).json(panNoApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}


const addPanLinkedGstNosCntrl = async (req, res, next) => {
    try {
        const linkedGstNosApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/gridlines/kyc/pan/${req.params.pan}/linked-gstins`, req.body ,{
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (linkedGstNosApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(linkedGstNosApi.status).json(linkedGstNosApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

const getGstNosByPanCntrl = async (req, res, next) => {
    try {
        const linkedGstNosApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/gridlines/kyc/pan/${req.params.pan}/linked-gstins`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (linkedGstNosApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(linkedGstNosApi.status).json(linkedGstNosApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

module.exports = {
    addPanKycDetailsCntrl,
    getPanKycByPanNoCntrl,
    addPanLinkedGstNosCntrl,
    getGstNosByPanCntrl
};