const axios = require('axios');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../../../error');

const addUdyamKycDetailsCntrl = async (req, res, next) => {
    try {
        const udyamKycApi = await axios.post(`${envConfig.KYC_SERVICE_API_BASE_URL}/gridlines/kyc/udyam`, req.body, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (udyamKycApi.status != 200) {
            return next(new APIError('0142', StatusCodes.BAD_REQUEST));
        }

        res.status(udyamKycApi.status).json(udyamKycApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0142',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    } 
}

const getUdyamKycByUdyamNoCntrl = async (req, res, next) => {
    try {
        const udyamNoApi = await axios.get(`${envConfig.KYC_SERVICE_API_BASE_URL}/gridlines/kyc/udyam/${req.params.udyamRegNo}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (udyamNoApi.status != 200) {
            return next(new APIError('0147', StatusCodes.BAD_REQUEST));
        }

        res.status(udyamNoApi.status).json(udyamNoApi.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0147',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
}

module.exports = {
    addUdyamKycDetailsCntrl,
    getUdyamKycByUdyamNoCntrl
}