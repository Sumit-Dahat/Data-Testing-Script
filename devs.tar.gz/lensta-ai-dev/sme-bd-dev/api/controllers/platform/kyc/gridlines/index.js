module.exports = {
    panKyc: require('./gridlines-pan-kyc.controller'),
    gstKyc: require('./gridlines-gst-kyc.controller'),
    udyamKyc: require('./gridlines-udyam-kyc.controller'),
    aadhaarKyc: require('./gridlines-aadhaar-kyc.controller'),
    bankAccKyc: require('./gridlines-bankAcc-kyc.controller')
};