const controllers = {
    buyerSeller: require('./buyer-seller/index'),

    financier: require('./financier/index'),

    platform: require('./platform/index')
};

module.exports = controllers;