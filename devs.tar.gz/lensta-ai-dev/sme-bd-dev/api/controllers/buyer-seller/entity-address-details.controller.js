const entAddrDetHelpers = require('../../helpers/buyer-seller').entAddressDetails;
const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require('../../services//generic-query.service');

const createAnEntAddrDetCntrl = async (req, res, next) => {
    try {
        const entAddressDetail = await entAddrDetHelpers.createAnEntAddrDet(req.body, {
            include: ['entity', 'addressType'],
            attributes: {
                exclude: ['entityId', 'addressTypeId']
            }
        });

        if (entAddressDetail.error) {
            return next(entAddressDetail.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Address Details added successfully.',
            data: entAddressDetail.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnEntAddrDetByIdCntrl = async (req, res, next) => {
    try {
        const entAddressDetail = await entAddrDetHelpers.getAnEntAddrDetyId(req.params.addressId, {
            include: ['entity', 'addressType'],
            attributes: {
                exclude: ['entityId', 'addressTypeId']
            }
        });

        if (entAddressDetail.error) {
            return next(entAddressDetail.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: entAddressDetail.data
        });

    } catch(error) {
        next(error);
    }
};

const getEntAddrDetByEntityIdCntrl = async (req, res, next) => {
    try {
        let entAddrDetails = await entAddrDetHelpers.getAllEntAddrDetls({
            where: [{
                entityId: req.params.entityId
            }, req.query],
            include: ['entity', 'addressType'],
            attributes: {
                exclude: ['entityId', 'addressTypeId']
            }
        });

        if (entAddrDetails.error) {
            return next(entAddrDetails.error);
        }

        const resultLength = entAddrDetails.data.length;

        entAddrDetails.data = [...applyLimitAndOffsetParams(
            entAddrDetails.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: entAddrDetails.data
        });

    } catch(error) {
        next(error);
    }
};

const updateAnEntAddrDetByIdCntrl = async (req, res, next) => {
    try {
        const entAddressDetail = await entAddrDetHelpers.updateAnEntAddrDetyId(req.params.addressId, req.body, {
            include: ['entity', 'addressType'],
            attributes: {
                exclude: ['entityId', 'addressTypeId']
            }
        });

        if (entAddressDetail.error) {
            return next(entAddressDetail.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Address Details updated successfully.',
            data: entAddressDetail.data
        });
        
    } catch(error) {
        next(error);
    }
};

const deleteAnEntAddrDetByIdCntrl = async (req, res, next) => {
    try {
        const entAddressDetail = await entAddrDetHelpers.deleteAnEntAddrDetyId(req.params.addressId, {
            include: ['entity', 'addressType'],
            attributes: {
                exclude: ['entityId', 'addressTypeId']
            }
        });

        if (entAddressDetail.error) {
            return next(entAddressDetail.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Address Details deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

const deleteEntAddrDetlsByEntityIdCntrl = async (req, res, next) => {
    try {
        const entAddressDetails = await entAddrDetHelpers.deleteEntAddrDetlsByEntityId(req.params.entityId, {
            include: ['entity', 'addressType'],
            attributes: {
                exclude: ['entityId', 'addressTypeId']
            }
        });
        
        if (entAddressDetails.error) {
            return next(entAddressDetails.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Address Detail(s) deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnEntAddrDetCntrl,
    
    getAnEntAddrDetByIdCntrl,
    getEntAddrDetByEntityIdCntrl,
    
    updateAnEntAddrDetByIdCntrl,
    
    deleteAnEntAddrDetByIdCntrl,
    deleteEntAddrDetlsByEntityIdCntrl,
}