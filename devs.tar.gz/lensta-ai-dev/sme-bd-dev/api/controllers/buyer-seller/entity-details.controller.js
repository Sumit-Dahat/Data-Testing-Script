const { StatusCodes } = require('http-status-codes');
const entDetailsHelpers = require('../../helpers/buyer-seller').entDetails;
const userHelpers = require('../../helpers/platform').user;
const { applyLimitAndOffsetParams } = require('../../services//generic-query.service');

const createAnBuyerSellerCntrl = async (req, res, next) => {
    try {
        /* Start Buyer / Seller Create DB transaction */
        const createAnBSTxn = await db.sequelize.transaction();

        // Create an Buyer / Seller
        const BSEntityDetls = await entDetailsHelpers.createAnBuyerSeller(req.body.entityDetails, {
            transaction: createAnBSTxn
        });

        if (BSEntityDetls.error) {
            await createAnBSTxn.rollback();
            return next(BSEntityDetls.error);
        }

        // Create an Buyer / Seller Admin
        req.body.adminDetails.entityId = BSEntityDetls.data.id;

        req.body.adminDetails.entityCategory = BSEntityDetls.data.entityCategory;
        
        req.body.adminDetails.userType = 'ADMIN';

        const BSAdmin = await userHelpers.createAnUser(req.body.adminDetails, {
            attributes: {
                exclude: ['password', 'encPassword']
            },
            transaction: createAnBSTxn
        });

        if (BSAdmin.error) {
            await createAnBSTxn.rollback();
            return next(BSAdmin.error);
        }

        await createAnBSTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Buyer / Seller Details added successfully.',
            data: {
                entityDetails: BSEntityDetls.data,
                adminDetails: BSAdmin.data
            }
        });

    } catch(error) {
        next(error);
    }
};
const getAnBuyerSellerProfileCntrl = async (req, res, next) => {
    try {
        req.params.entityId = req.user.entityId;

        getAnBuyerSellerByIdCntrl(req, res, next);

    } catch(error) {
        next(error);
    }
}

const getAnBuyerSellerByIdCntrl = async (req, res, next) => {
    try {
        let buyerSeller = await entDetailsHelpers.getAnBuyerSellerById(req.params.entityId, {
            include: [
                'entityType',
                {
                    model: db.Users,
                    as: 'users',
                    where: {
                        userType: 'ADMIN'
                    },
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ],
            attributes: {
                exclude: ['entityTypeId']
            }
        });

        if (buyerSeller.error) {
            return next(buyerSeller.error);
        }

        buyerSeller = buyerSeller.data.toJSON();

        let result = {
            entityDetails: {},
            adminDetails: buyerSeller.users[0]
        };

        delete buyerSeller.users;

        result.entityDetails = buyerSeller;
        
        res.status(StatusCodes.OK).json({
            error: null,
            data: result
        });

    } catch(error) {
        next(error);
    }
};

const getAvlLimitOfAnBuyerSellerByIdCntrl = async (req, res, next) => {
    try {
        /* Get available limit of an Entity */
        const entityAvlLimit = await entDetailsHelpers.getAvlLimitOfAnEntityById(req.params.entityId);

        if (entityAvlLimit.error) {
            return next(entityAvlLimit.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: entityAvlLimit.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllBuyerSellersCntrl = async (req, res, next) => {
    try {
        const buyerSellers = await entDetailsHelpers.getAllBuyerSellers({
            where: [req.query],
            include: [
                'entityType',
                {
                    model: db.Users,
                    as: 'users',
                    where: {
                        userType: 'ADMIN'
                    },
                    attributes: {
                        exclude: ['password', 'encPassword']
                    }
                }
            ],
            attributes: {
                exclude: ['entityTypeId']
            }
        });

        if (buyerSellers.error) {
            return next(buyerSellers.error);
        }

        let fetchResult = [...buyerSellers.data.map((buyerSeller) => {
            buyerSeller = buyerSeller.toJSON();
            
            let temp = {
                entityDetails: {},
                adminDetails: buyerSeller.users[0]
            };

            delete buyerSeller.users;

            temp.entityDetails = buyerSeller;

            return temp;
        })];

        const resultLength = fetchResult.length;

        fetchResult = [...applyLimitAndOffsetParams(
            fetchResult,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: fetchResult
        });

    } catch(error) {
        next(error);
    }
};

const updateAnBuyerSellerByIdCntrl = async (req, res, next) => {
    try {
        const BSToUpdate = await entDetailsHelpers.getAnBuyerSellerById(req.params.entityId);

        if (BSToUpdate.error) {
            return next(BSToUpdate.error);
        }
        
        // Start Buyer / Seller update DB transaction
        const updateBuyerSellerTxn = await db.sequelize.transaction();
        let updateResult = {};

        // Update Buyer / Seller Entity Details if present
        if (
            req.body.entityDetails &&
            Object.keys(req.body.entityDetails).length > 0
        ) {
            const updatedEntDetls = await entDetailsHelpers.updateAnBuyerSellerById(req.params.entityId, req.body.entityDetails, {
                transaction: updateBuyerSellerTxn
            });

            if (updatedEntDetls.error) {
                await updateBuyerSellerTxn.rollback();
                return next(updatedEntDetls.error);
            }

            updateResult.entityDetails = updatedEntDetls.data[1][0];
        }

        // Update Buyer / Seller Admin Details if present
        if (
            req.body.adminDetails &&
            Object.keys(req.body.adminDetails).length > 0
        ) {
            const buyerSellerAdmin = await userHelpers.updateAnUserById(
                req.body.adminDetails.id,
                req.body.adminDetails,
                {
                    attributes: {
                        exclude: ['password', 'encPassword'],
                    },
                    transaction: updateBuyerSellerTxn
                }
            );

            if (buyerSellerAdmin.error) {
                await updateBuyerSellerTxn.rollback();
                return next(buyerSellerAdmin.error);
            }

            updateResult.adminDetails = buyerSellerAdmin.data;
        }

        // Commit Buyer / Seller Update DB transaction and send response
        await updateBuyerSellerTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Buyer / Seller Details updated successfully.',
            data: updateResult
        });

    } catch(error) {
        next(error);
    }
};

const deleteAnBuyerSellerByIdCntrl = async (req, res, next) => {
    try {
        const deletedBuyerSeller = await entDetailsHelpers.deleteAllBuyerSellers({
            where: {
                id: req.params.entityId,
            }
        });

        if (deletedBuyerSeller.error) {
            return next(deletedBuyerSeller.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Buyer / Seller deleted successfully.`
        });

    } catch(error) {
        next(error);
    }
};

const deleteAllBuyerSellersCntrl = async (req, res, next) => {
    try {
        const deletedBuyerSellers = await entDetailsHelpers.deleteAllBuyerSellers({
            where: {
                [db.Sequelize.Op.or]: [
                    { entityCategory: 'BUYER' },
                    { entityCategory: 'SELLER' }
                ]
            }
        });

        if (deletedBuyerSellers.error) {
            return next(deletedBuyerSellers.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Buyer / Seller(s) deleted successfully.`
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnBuyerSellerCntrl,
    
    getAnBuyerSellerProfileCntrl,
    getAnBuyerSellerByIdCntrl,
    getAvlLimitOfAnBuyerSellerByIdCntrl,
    getAllBuyerSellersCntrl,
    
    updateAnBuyerSellerByIdCntrl,
    
    deleteAnBuyerSellerByIdCntrl,
    deleteAllBuyerSellersCntrl
}