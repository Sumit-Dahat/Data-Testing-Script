const axios = require('axios');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../../error');
const { appendFileMetadata } = require('../../services//generic.service');

const createAnEntityDocUploadCntrl = async (req, res, next) => {
    try {
        let formData = appendFileMetadata(req.body, req.files['document']);

        formData.append('createdById', req.user.id);
        formData.append('updatedById', req.user.id);

        const docUpload = await axios.post(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads`, formData, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (docUpload.status != 200) {
            return next(new APIError('0057', StatusCodes.BAD_REQUEST));
        }

        res.status(docUpload.status).json(docUpload.data);
        
    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0057',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const getAnEntityDocUploadByIdCntrl = async (req, res, next) => {
    try {
        const docUpload = await axios.get(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads/${req.params.documentId}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (docUpload.status != 200) {
            return next(new APIError('0060', StatusCodes.NOT_FOUND));
        }

        res.status(docUpload.status).json(docUpload.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0060',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const getEntityDocUploadsByEntityIdCntrl = async (req, res, next) => {
    try {
        const docUploads = await axios.get(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads`, {
            params: {
                entityId: req.params.entityId,
                ...req.query
            },
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (docUploads.status != 200) {
            return next(new APIError('0060', StatusCodes.NOT_FOUND));
        }

        res.status(docUploads.status).json(docUploads.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0060',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const getEntityDocSignedURLCntrl = async (req, res, next) => {
    try {
        const docURL = await axios.get(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads/${req.params.documentId}/signed-url`, {
            headers: {
                Authorization: req.headers.authorization
            },
            params: {
                action: req.query.action,
                expiresIn: req.query.expiresIn
            }
        });

        if (docURL.status != 200) {
            return next(new APIError('0000', StatusCodes.BAD_REQUEST));
        }

        res.status(docURL.status).json(docURL.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0000',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const updateAnEntityDocUploadByIdCntrl = async (req, res, next) => {
    try {
        let formData = appendFileMetadata(req.body, req.files['document']);

        formData.append('updatedById', req.user.id);

        const updatedDoc = await axios.put(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads/${req.params.documentId}`, formData, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (updatedDoc.status != 200) {
            return next(new APIError('0058', StatusCodes.BAD_REQUEST));
        }

        res.status(updatedDoc.status).json(updatedDoc.data);
        
    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0058',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const deleteAnEntityDocUploadByIdCntrl = async (req, res, next) => {
    try {
        const deletedDocUpload = await axios.delete(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads/${req.params.documentId}`, {
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (deletedDocUpload.status != 200) {
            return next(new APIError('0059', StatusCodes.BAD_REQUEST));
        }

        res.status(deletedDocUpload.status).json(deletedDocUpload.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0059',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

const deleteAllEntityDocUploadsByEntityIdCntrl = async (req, res, next) => {
    try {
        const deletedDocUploads = await axios.delete(`${envConfig.DOCS_SERVICE_API_BASE_URL}/document-uploads`, {
            params: {
                entityId: req.params.entityId
            },
            headers: {
                Authorization: req.headers.authorization
            }
        });

        if (deletedDocUploads.status != 200) {
            return next(new APIError('0059', StatusCodes.BAD_REQUEST));
        }

        res.status(deletedDocUploads.status).json(deletedDocUploads.data);

    } catch(error) {
        next(new APIError(
            (error.response.data.error.code) ? (error.response.data.error.code) : '0059',
            (error.response.status) ? (error.response.status) : StatusCodes.BAD_REQUEST
        ));
    }
};

module.exports = {
    createAnEntityDocUploadCntrl,
    
    getAnEntityDocUploadByIdCntrl,
    getEntityDocUploadsByEntityIdCntrl,
    getEntityDocSignedURLCntrl,
    
    updateAnEntityDocUploadByIdCntrl,
    
    deleteAnEntityDocUploadByIdCntrl,
    deleteAllEntityDocUploadsByEntityIdCntrl
};