const BSLinkHelpers = require('../../helpers/buyer-seller').buyerSellerLink;
const FUHelpers = require('../../helpers/financier').factoringUnit;
const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require('../../services//generic-query.service');

const createAnBSLinkCntrl = async (req, res, next) => {
    try {
        const newBSLink = await BSLinkHelpers.createAnBSLink(req.body, {
            include: ['buyer', 'seller'],
            attributes: {
                exclude: ['buyerId', 'sellerId']
            }
        });

        if (newBSLink.error) {
            return next(newBSLink.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Buyer Seller Link created successfully.',
            data: newBSLink.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnBSLinkByIdCntrl = async (req, res, next) => {
    try {
        const BSLink = await BSLinkHelpers.getAnBSLinkById(req.params.linkId, {
            include: ['buyer', 'seller'],
            attributes: {
                exclude: ['buyerId', 'sellerId']
            }
        });

        if (BSLink.error) {
            return next(BSLink.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: BSLink.data
        });

    } catch(error) {
        next(error);
    }
};

const getAllBSLinksCntrl = async (req, res, next) => {
    try {
        let BSLinks = await BSLinkHelpers.getAllBSLinks({
            where: [req.query],
            include: ['buyer', 'seller'],
            attributes: {
                exclude: ['buyerId', 'sellerId']
            }
        });

        if (BSLinks.error) {
            return next(BSLinks.error);
        }

        const resultLength = BSLinks.data.length;
            
        BSLinks.data = [...applyLimitAndOffsetParams(
            BSLinks.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: BSLinks.data
        });

    } catch(error) {
        next(error);
    }
};

const updateAnBSLinkByIdCntrl = async (req, res, next) => {
    try {
        const updateAnBSLinkTxn = await db.sequelize.transaction();

        /* Update BS Link */
        const updatedBSLink = await BSLinkHelpers.updateAnBSLinkById(req.params.linkId, req.body, {
            include: ['buyer', 'seller'],
            attributes: {
                exclude: ['buyerId', 'sellerId']
            },
            transaction: updateAnBSLinkTxn
        });

        if (updatedBSLink.error) {
            await updateAnBSLinkTxn.rollback();
            return next(updatedBSLink.error);
        }

        /* Send FUs from 'PENDING' state to 'OPEN_FOR_FINANCE' */
        if (req.body.sendForFinance == 'AUTO') {
            const factoringUnit = await FUHelpers.updateFactoringUnits({
                status: 'OPEN_FOR_FINANCE',
                fuListedDate: new Date(),
                nextCheckerUserId: null
            }, {
                where: {
                    buyerSellerLinkId: updatedBSLink.data.id,
                    status: 'PENDING'
                }
            });

            if (factoringUnit.error) {
                await updateAnBSLinkTxn.rollback();
                return next(factoringUnit.error);
            }
        }

        /* Send FUs from 'ROI_ADDED' state to 'AMT_DISBURSED' */
        if (req.body.acceptPayment == 'AUTO') {
            const factoringUnit = await FUHelpers.updateFactoringUnits({
                status: 'AMT_DISBURSED',
                factoredDate: new Date(),
                nextCheckerUserId: null
            }, {
                where: {
                    buyerSellerLinkId: updatedBSLink.data.id,
                    status: 'ROI_ADDED'
                }
            });

            if (factoringUnit.error) {
                await updateAnBSLinkTxn.rollback();
                return next(factoringUnit.error);
            }
        }

        await updateAnBSLinkTxn.commit();
        
        res.status(StatusCodes.OK).json({
            error: null,
            message: `Buyer Seller Link updated successfully.`,
            data: updatedBSLink.data
        }); 
        
    } catch(error) {
        next(error);
    }
};

const deleteAnBSLinkByIdCntrl = async (req, res, next) => {
    try {
        const deletedBSLink = await BSLinkHelpers.deleteAllBSLinks({
            where: {
                id: req.params.linkId
            }
        });

        if (deletedBSLink.error) {
            return next(deletedBSLink.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Buyer Seller Link deleted successfully.`
        });

    } catch(error) {
        next(error);
    }
};

const deleteAllBSLinksCntrl = async (req, res, next) => {
    try {
        const deletedBSLinks = await BSLinkHelpers.deleteAllBSLinks({
            where: {},
            truncate: true
        });

        if (deletedBSLinks.error) {
            return next(deletedBSLinks.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Buyer Seller Links deleted successfully.'
        });
        
    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnBSLinkCntrl,
    
    getAnBSLinkByIdCntrl,
    getAllBSLinksCntrl,
    
    updateAnBSLinkByIdCntrl,
    
    deleteAnBSLinkByIdCntrl,
    deleteAllBSLinksCntrl
}