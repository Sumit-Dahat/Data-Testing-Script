const { StatusCodes } = require("http-status-codes");
const entPromoterDetHelpers = require('../../helpers/buyer-seller').entPromoterDetails;
const { applyLimitAndOffsetParams } = require('../../services//generic-query.service');

const createAnEntPromtDetlCntrl = async (req, res, next) => {
    try {
        const entPromoterDet = await entPromoterDetHelpers.createAnEntPromtDetl(req.body, {
            include: ['entity'],
            attributes: {
                exclude: ['entityId']
            }
        });

        if (entPromoterDet.error) {
            return next(entPromoterDet.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Promoter Details added successfully.',
            data: entPromoterDet.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnEntPromtDetlByIdCntrl = async (req, res, next) => {
    try {
        const entityPromoterDetail = await entPromoterDetHelpers.getAnEntPromtDetlById(req.params.promoterDetailsId, {
            include: ['entity'],
            attributes: {
                exclude: ['entityId']
            }
        });

        if (entityPromoterDetail.error) {
            return next(entityPromoterDetail.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: entityPromoterDetail.data
        });

    } catch(error) {
        next(error);
    }
};

const getEntPromtDetlsByEntityIdCntrl = async (req, res, next) => {
    try {
        let entPromoterDetails = await entPromoterDetHelpers.getAllEntPromtDetls({
            where: [{
                entityId: req.params.entityId
            }, req.query],
            include: ['entity'],
            attributes: {
                exclude: ['entityId']
            }
        });

        if (entPromoterDetails.error) {
            return next(entPromoterDetails.error);
        }

        const resultLength = entPromoterDetails.data.length;

        entPromoterDetails.data = [...applyLimitAndOffsetParams(
            entPromoterDetails.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: entPromoterDetails.data
        });
        

    } catch(error) {
        next(error);
    }
};

const updateAnEntPromtDetlByIdCntrl = async (req, res, next) => {
    try {
        const updatedEntPromtDetl = await entPromoterDetHelpers.updateAnEntPromtDetlById(req.params.promoterDetailsId, req.body, {
            include: ['entity'],
            attributes: {
                exclude: ['entityId']
            }
        });

        if (updatedEntPromtDetl.error) {
            return next(updatedEntPromtDetl.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Entity Promoter Details updated successfully.`,
            data: updatedEntPromtDetl.data
        });
        
    } catch(error) {
        next(error);
    }
};

const deleteAnEntPromtDetlByIdCntrl = async (req, res, next) => {
    try {
        const deletedEntPromtDetl = await entPromoterDetHelpers.deleteAnEntPromtDetlById(req.params.promoterDetailsId, {
            include: ['entity'],
            attributes: {
                exclude: ['entityId']
            }
        });

        if (deletedEntPromtDetl.error) {
            return next(deletedEntPromtDetl.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Promoter Details deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

const deleteEntPromtDetlsByEntityIdCntrl = async (req, res, next) => {
    try {
        const deletedEntPromtDetls = await entPromoterDetHelpers.deleteEntPromtDetlsByEntityId(req.params.entityId);

        if (deletedEntPromtDetls.error) {
            return next(deletedEntPromtDetls.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Promoter Detail(s) deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnEntPromtDetlCntrl,
    
    getAnEntPromtDetlByIdCntrl,
    getEntPromtDetlsByEntityIdCntrl,
    
    updateAnEntPromtDetlByIdCntrl,
    
    deleteAnEntPromtDetlByIdCntrl,
    deleteEntPromtDetlsByEntityIdCntrl,
}