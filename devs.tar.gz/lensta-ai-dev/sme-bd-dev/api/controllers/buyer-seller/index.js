module.exports = {
    buyerSellerLink: require('./buyer-seller-link.controller'),

    entAddressDetails: require('./entity-address-details.controller'),

    entBankDetails: require('./entity-bank-details.controller'),

    entDetails: require('./entity-details.controller'),

    entDocuments: require('./entity-documents.controller'),

    entPromoterDetails: require('./entity-promoter-details.controller')
};