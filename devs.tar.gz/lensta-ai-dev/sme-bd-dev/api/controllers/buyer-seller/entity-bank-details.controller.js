const entBankDetailsHelpers = require('../../helpers/buyer-seller').entBankDetails;
const FUTxnHelpers = require('../../helpers/financier').FUTxn;
const { StatusCodes } = require("http-status-codes");
const { applyLimitAndOffsetParams } = require('../../services//generic-query.service');

const createAnEntBankDetCntrl = async (req, res, next) => {
    const createAnEntBankDetTxn = await db.sequelize.transaction();
    
    try {
        const defaultBankAccs = await entBankDetailsHelpers.getAllEntBankDetls({
            where: {
                entityId: req.params.entityId,
                isDefault: 1
            }
        });

        if (defaultBankAccs.error) {
            await createAnEntBankDetTxn.rollback();
            return next(defaultBankAccs.error);
        }

        if (
            (req.body.isDefault === 1) &&
            (defaultBankAccs.data.length > 0)
        ) {
            const updatedBankDetails = await entBankDetailsHelpers.updateEntBankDetlsByEntityId(req.params.entityId, {
                isDefault: 0
            }, { transaction: createAnEntBankDetTxn });

            if (updatedBankDetails.error) {
                return next(updatedBankDetails.error);
            }

        } else if (
            (req.body.isDefault === 0) &&
            (defaultBankAccs.data.length === 0)
        ) {
            req.body.isDefault = 1;
        }

        const entityBankDetail = await entBankDetailsHelpers.createAnEntBankDetl(req.body, {
            include: ['entity', 'bankAccountType'],
            attributes: {
                exclude: ['entityId', 'bankAccountTypeId']
            },
            transaction: createAnEntBankDetTxn
        });

        if (entityBankDetail.error) {
            await createAnEntBankDetTxn.rollback();
            return next(entityBankDetail.error);
        }

        await createAnEntBankDetTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Bank Details added successfully.',
            data: entityBankDetail.data
        });

    } catch(error) {
        next(error);
    }
};

const getAnEntBankDetailByIdCntrl = async (req, res, next) => {
    try {
        const entityBankDetail = await entBankDetailsHelpers.getAnEntBankDetlById(req.params.bankDetailsId, {
            include: ['entity', 'bankAccountType'],
            attributes: {
                exclude: ['entityId', 'bankAccountTypeId']
            }
        });

        if (entityBankDetail.error) {
            return next(entityBankDetail.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            data: entityBankDetail.data
        });

    } catch(error) {
        next(error);
    }
};

const getEntBankDetlsByEntityIdCntrl = async (req, res, next) => {
    try {
        let entityBankDetails = await entBankDetailsHelpers.getAllEntBankDetls({
            where: [{
                entityId: req.params.entityId
            }, req.query],
            include: ['entity', 'bankAccountType'],
            attributes: {
                exclude: ['entityId', 'bankAccountTypeId']
            }
        });

        if (entityBankDetails.error) {
            return next(entityBankDetails.error);
        }

        const resultLength = entityBankDetails.data.length;

        entityBankDetails.data = [...applyLimitAndOffsetParams(
            entityBankDetails.data,
            req.pagination.limit,
            req.pagination.offset
        )];

        res.status(StatusCodes.OK).json({
            error: null,
            count: resultLength,
            data: entityBankDetails.data
        });

    } catch(error) {
        next(error);
    }
};

const updateAnEntBankDetByIdCntrl = async (req, res, next) => {
    try {
        const entBankDetToUpdate = await entBankDetailsHelpers.getAnEntBankDetlById(req.params.bankDetailsId);

        if (entBankDetToUpdate.error) {
            return next(entBankDetToUpdate.error);
        }

        const updateEntBankDetTxn = await db.sequelize.transaction();
        
        if (entBankDetToUpdate.data.isDefault != req.body.isDefault) {
            const entityBankDetails = await entBankDetailsHelpers.getAllEntBankDetls({
                where: {
                    entityId: req.params.entityId
                }
            });

            if (entityBankDetails.error) {
                await updateEntBankDetTxn.rollback();
                return next(entityBankDetails.error);
            }

            const defaultAccounts = [...entityBankDetails.data.filter((account) => account.isDefault)];

            const nonDefaultAccounts = [...entityBankDetails.data.filter((account) => !account.isDefault)];

            if (req.body.isDefault == 0) {
                const updatedEntBankDet = await entBankDetailsHelpers.updateAnEntBankDetlById(
                    nonDefaultAccounts[0].id,
                    { isDefault: 1 },
                    { transaction: updateEntBankDetTxn }
                );

                if (updatedEntBankDet.error) {
                    await updateEntBankDetTxn.rollback();
                    return next(updatedEntBankDet.error);
                }

            } else if (req.body.isDefault == 1) {
                const updatedEntBankDet = await entBankDetailsHelpers.updateAnEntBankDetlById(
                    defaultAccounts[0].id,
                    { isDefault: 0 },
                    { transaction: updateEntBankDetTxn }
                );

                if (updatedEntBankDet.error) {
                    await updateEntBankDetTxn.rollback();
                    return next(updatedEntBankDet.error);
                }
            }
        }

        const updatedEntBankDet = await entBankDetailsHelpers.updateAnEntBankDetlById(
            req.params.bankDetailsId,
            req.body,
            {
                transaction: updateEntBankDetTxn,
                include: ['entity', 'bankAccountType'],
                attributes: {
                    exclude: ['entityId', 'bankAccountTypeId']
                }
            }
        );

        if (updatedEntBankDet.error) {
            await updateEntBankDetTxn.rollback();
            return next(updatedEntBankDet.error);
        }

        await updateEntBankDetTxn.commit();
        
        res.status(StatusCodes.OK).json({
            error: null,
            message: `Entity Bank Details updated successfully.`,
            data: updatedEntBankDet.data
        });
        
    } catch(error) {
        next(error);
    }
};

const deleteAnEntBankDetByIdCntrl = async (req, res, next) => {
    try {
        const entBankDetail = await entBankDetailsHelpers.getAnEntBankDetlById(req.params.bankDetailsId);

        if (entBankDetail.error) {
            return next(entBankDetail.error);
        }

        const deleteEntBankDetailTxn = await db.sequelize.transaction();

        await FUTxnHelpers.deleteFUTxns({
            where: {
                [db.Sequelize.Op.or]: [
                    { remitterBankDetailsId: req.params.bankDetailsId },
                    { beneficiaryBankDetailsId: req.params.bankDetailsId }
                ]
            },
            transaction: deleteEntBankDetailTxn
        });

        const delEntBankDetl = await entBankDetailsHelpers.deleteAnEntBankDetlById(req.params.bankDetailsId, {
            include: ['entity', 'bankAccountType'],
            attributes: {
                exclude: ['entityId', 'bankAccountTypeId']
            },
            transaction: deleteEntBankDetailTxn
        });

        if (delEntBankDetl.error) {
            await deleteEntBankDetailTxn.rollback();
            return next(delEntBankDetl.error);
        }

        if (entBankDetail.data.isDefault) {
            const entityBankDetails = await entBankDetailsHelpers.getAllEntBankDetls({
                where: {
                    entityId: req.params.entityId
                },
                transaction: deleteEntBankDetailTxn
            });

            if (
                (entityBankDetails.data) &&
                (entityBankDetails.data.length > 0)
            ) {
                const updatedEntBankDetails = await entBankDetailsHelpers.updateAnEntBankDetlById(entityBankDetails.data[0].id, { isDefault: 1 }, {
                    transaction: deleteEntBankDetailTxn
                });

                if (updatedEntBankDetails.error) {
                    await deleteEntBankDetailTxn.rollback();
                    return next(updatedEntBankDetails.error);
                }
            }
        }

        await deleteEntBankDetailTxn.commit();

        res.status(StatusCodes.OK).json({
            error: null,
            message: `Entity Bank Details deleted successfully.`
        });

    } catch(error) {
        next(error);
    }
};

const deleteEntBankDetlsByEntityIdCntrl = async (req, res, next) => {
    try {
        const delEntBankDetls = await entBankDetailsHelpers.deleteEntBankDetlsByEntityId(req.params.entityId, {
            include: ['entity', 'bankAccountType'],
            attributes: {
                exclude: ['entityId', 'bankAccountTypeId']
            }
        });

        if (delEntBankDetls.error) {
            return next(delEntBankDetls.error);
        }

        res.status(StatusCodes.OK).json({
            error: null,
            message: 'Entity Bank Detail(s) deleted successfully.'
        });

    } catch(error) {
        next(error);
    }
};

module.exports = {
    createAnEntBankDetCntrl,
    
    getAnEntBankDetailByIdCntrl,
    getEntBankDetlsByEntityIdCntrl,
    
    updateAnEntBankDetByIdCntrl,
    
    deleteAnEntBankDetByIdCntrl,
    deleteEntBankDetlsByEntityIdCntrl,
}