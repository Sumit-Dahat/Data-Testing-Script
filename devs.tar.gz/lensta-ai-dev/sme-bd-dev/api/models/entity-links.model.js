'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class EntityLinks extends Model {
    static associate(models) {
      EntityLinks.belongsTo(models.EntityDetails, {
        foreignKey: 'buyerId',
        as: 'buyer',
        onDelete: 'CASCADE'
      });

      EntityLinks.belongsTo(models.EntityDetails, {
        foreignKey: 'sellerId',
        as: 'seller',
        onDelete: 'CASCADE'
      });
    }
  }
  
  EntityLinks.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    buyerId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'buyerId'
      }
    },
    sellerId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'sellerId'
      }
    },
    creditPeriod: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    extendedCreditPeriod: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    sendForFinance: {
      type: DataTypes.ENUM('AUTO', 'MANUAL'),
      allowNull: false
    },
    acceptPayment: {
      type: DataTypes.ENUM('AUTO', 'MANUAL'),
      allowNull: false
    },
    costBearer: {
      type: DataTypes.ENUM('BUYER', 'SELLER', 'PERCENTAGE_SPLIT', 'PERIODIC_SPLIT'),
      allowNull: false
    },
    buyerPercentage: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    sellerPercentage: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    buyerStartDays: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    buyerEndDays: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    sellerStartDays: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    sellerEndDays: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'EntityLinks',
    timestamps: true
  });
  return EntityLinks;
};