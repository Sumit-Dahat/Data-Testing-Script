'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class IndustrySubSectors extends Model {
    static associate(models) {
      IndustrySubSectors.belongsTo(models.IndustrySectors, {
        foreignKey: 'industrySectorId',
        as: 'industrySector',
        onDelete: 'CASCADE'
      });
    }
  }
  
  IndustrySubSectors.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    industrySectorId: {
      type: DataTypes.UUID,
      onDelete: 'CASCADE',
      references: {
        model: 'IndustrySectors',
        key: 'id',
        as: 'industrySectorId'
      },
      allowNull: false
    },
    active: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 1
    },
    createdByUserId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'IndustrySubSectors',
    timestamps: true
  });
  return IndustrySubSectors;
};