'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class InvoiceActionHistory extends Model {
    static associate(models) {
      InvoiceActionHistory.belongsTo(models.Invoices, {
        foreignKey: 'invoiceId',
        as: 'invoice',
        onDelete: 'CASCADE'
      });

      InvoiceActionHistory.belongsTo(models.Users, {
        foreignKey: 'actionByUserId',
        as: 'actionByUser',
        onDelete: 'CASCADE'
      });
    }
  }
  InvoiceActionHistory.init({
    invoiceId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'Invoices',
        key: 'id',
        as: 'invoiceId'
      }
    },
    action: {
      type: DataTypes.ENUM('CREATE', 'UPDATE', 'APPROVE', 'REJECT'),
      allowNull: false
    },
    actionByUserId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'Users',
        key: 'id',
        as: 'actionByUserId'
      }
    },
    remarks: {
      type: DataTypes.STRING,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'InvoiceActionHistory',
    timestamps: true
  });

  InvoiceActionHistory.removeAttribute('id');
  
  return InvoiceActionHistory;
};