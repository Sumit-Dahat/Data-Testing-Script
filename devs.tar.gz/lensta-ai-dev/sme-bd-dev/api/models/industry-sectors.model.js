'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class IndustrySectors extends Model {
    static associate(models) {
      IndustrySectors.belongsTo(models.BusinessSectors, {
        foreignKey: 'businessSectorId',
        as: 'businessSector',
        onDelete: 'CASCADE'
      });
    }
  }
  
  IndustrySectors.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    businessSectorId: {
      type: DataTypes.UUID,
      onDelete: 'CASCADE',
      references: {
        model: 'BusinessSectors',
        key: 'id',
        as: 'businessSectorId'
      },
      allowNull: false
    },
    active: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 1
    },
    createdByUserId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'IndustrySectors',
    timestamps: true
  });
  return IndustrySectors;
};