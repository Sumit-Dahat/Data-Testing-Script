'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class FactoringUnits extends Model {
    static associate(models) {
      FactoringUnits.belongsTo(models.EntityLinks, {
        foreignKey: 'buyerSellerLinkId',
        as: 'buyerSellerLink',
        onDelete: 'CASCADE'
      });

      FactoringUnits.belongsTo(models.Users, {
        foreignKey: 'nextCheckerUserId',
        as: 'nextCheckerUser',
        onDelete: 'CASCADE'
      });

      FactoringUnits.belongsTo(models.Users, {
        foreignKey: 'createdByUserId',
        as: 'createdByUser',
        onDelete: 'CASCADE'
      });

      FactoringUnits.hasMany(models.Invoices, {
        foreignKey: 'factoringUnitNo',
        as: 'invoices',
        onDelete: 'CASCADE'
      });

      FactoringUnits.hasMany(models.FUPayments, {
        foreignKey: 'factoringUnitNo',
        as: 'payment',
        onDelete: 'CASCADE'
      });

      FactoringUnits.hasMany(models.FUActionHistory, {
        foreignKey: 'factoringUnitNo',
        as: 'actionHistory',
        onDelete: 'CASCADE'
      });
    }
  }
  FactoringUnits.init({
    factoringUnitNo: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: () => {
        const { generateCustomNanoId } = require('../services//generic.service');
        return `FU-${generateCustomNanoId(8)}`;
      }
    },
    factoringAmount: {
      type: DataTypes.VIRTUAL,
      get() {
        return (
          (this.invoices) ? this.invoices.map((invoice) => ((invoice.invoiceAmount - invoice.discountAmount) + invoice.taxAmount)).reduce((prev, next) => (prev + next), 0) : 0
        );
      }
    },
    factoredUnitBreakup: {
      type: DataTypes.VIRTUAL,
      get() {
        if (['AMT_DISBURSED','ACTIVE_DISBURSEMENT','OVERDUE_DISBURSEMENT','PAYMENT_CLOSED'].includes(this.status)) {
          let calc = {};

          calc['taxDeductedAmount'] = parseFloat(
            (this.factoringAmount - this.advanceTax).toFixed(2)
          );

          calc['sellerInterestAndFees'] = parseFloat(
            (this.sellerFees + this.sellerInterest).toFixed(2)
          );

          calc['buyerInterestAndFees'] = parseFloat(
            (this.buyerFees + this.buyerInterest).toFixed(2)
          );

          calc['disbursementAmount'] = parseFloat(
            (this.factoringAmount - calc['sellerInterestAndFees']).toFixed(2)
          );

          calc['collectedAmount'] = parseFloat(
            (this.factoringAmount + calc['buyerInterestAndFees']).toFixed(2)
          );

          return calc;

        } else {
          return {};
        }

      }
    },
    sumOfInvoiceAmounts: {
      type: DataTypes.VIRTUAL,
      get() {
        let sumOfInvAmts = {
          invoiceAmount: 0,
          discountAmount: 0,
          taxAmount: 0,
          totalAmount: 0
        };

        if (this.invoices) {
          this.invoices.forEach((invoice) => {
            sumOfInvAmts.invoiceAmount += invoice.invoiceAmount;
            sumOfInvAmts.discountAmount += invoice.discountAmount;
            sumOfInvAmts.taxAmount += invoice.taxAmount;
            sumOfInvAmts.totalAmount += invoice.totalAmount;
          });
        }

        return sumOfInvAmts;
      }
    },
    buyerSellerLinkId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityLinks',
        key: 'id',
        as: 'buyerSellerLinkId'
      }
    },
    status: {
      type: DataTypes.ENUM('PENDING', 'OPEN_FOR_FINANCE', 'ROI_ADDED', 'REJECTED', 'AMT_DISBURSED', 'AMT_REPAID', 'ACTIVE_DISBURSEMENT', 'OVERDUE_DISBURSEMENT', 'PAYMENT_CLOSED'),
      allowNull: false,
      defaultValue: 'PENDING'
    },
    fuListedDate: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    factoredDate: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    buyerFees: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    sellerFees: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    rateOfInterest: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    advanceTax: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    interest: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    buyerInterest: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    sellerInterest: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    nextCheckerUserId: {
      type: DataTypes.UUID,
      defaultValue: null,
      allowNull: true,
      onDelete: 'CASCADE',
      references: {
        model: 'Users',
        key: 'id',
        as: 'nextCheckerUserId'
      }
    },
    createdByUserId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'Users',
        key: 'id',
        as: 'createdByUserId'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'FactoringUnits',
    timestamps: true
  });
  return FactoringUnits;
};