'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class EntityBankDetails extends Model {
    static associate(models) {
      EntityBankDetails.belongsTo(models.BankAccountTypes, {
        foreignKey: 'bankAccountTypeId',
        as: 'bankAccountType',
        onDelete: 'CASCADE'
      });

      EntityBankDetails.belongsTo(models.EntityDetails, {
        foreignKey: 'entityId',
        as: 'entity',
        onDelete: 'CASCADE'
      });
    }
  }
  EntityBankDetails.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    entityId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'entityId'
      }
    },
    bankAccountTypeId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'BankAccountTypes',
        key: 'id',
        as: 'bankAccountTypeId'
      }
    },
    accountTitle: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    accountNo: {
      type: DataTypes.STRING,
      allowNull: false
    },
    bankAccKycVerified: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    ifsc: {
      type: DataTypes.STRING(11),
      allowNull: false
    },
    bankName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    branchName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    micrCode: {
      type: DataTypes.STRING,
      allowNull: false
    },
    swiftCode: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    isDefault: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'EntityBankDetails',
    timestamps: true
  });
  return EntityBankDetails;
};