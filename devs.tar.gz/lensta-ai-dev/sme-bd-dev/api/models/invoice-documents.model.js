'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class InvoiceDocuments extends Model {
    static associate(models) {
      InvoiceDocuments.belongsTo(models.Invoices, {
        foreignKey: 'invoiceId',
        as: 'invoice',
        onDelete: 'CASCADE'
      });
    }
  }
  InvoiceDocuments.init({
    documentId: {
      type: DataTypes.UUID,
      primaryKey: true
    },
    invoiceId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'Invoices',
        key: 'id',
        as: 'invoiceId'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString(),
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString(),
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'InvoiceDocuments',
    timestamps: true
  });
  return InvoiceDocuments;
};