'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class FUActionHistory extends Model {
    static associate(models) {
      FUActionHistory.belongsTo(models.FactoringUnits, {
        foreignKey: 'factoringUnitNo',
        as: 'factoringUnit',
        onDelete: 'CASCADE'
      });

      FUActionHistory.belongsTo(models.Users, {
        foreignKey: 'actionByUserId',
        as: 'actionByUser',
        onDelete: 'CASCADE'
      });
    }
  }
  FUActionHistory.init({
    factoringUnitNo: {
      type: DataTypes.STRING,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'FactoringUnits',
        key: 'factoringUnitNo',
        as: 'factoringUnitNo'
      }
    },
    action: {
      type: DataTypes.ENUM('CREATE', 'UPDATE', 'APPROVE', 'REJECT'),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('PENDING', 'OPEN_FOR_FINANCE', 'ROI_ADDED', 'REJECTED', 'AMT_DISBURSED', 'AMT_REPAID', 'ACTIVE_DISBURSEMENT', 'OVERDUE_DISBURSEMENT', 'PAYMENT_CLOSED'),
      allowNull: false
    },
    actionByUserId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'Users',
        key: 'id',
        as: 'actionByUserId'
      }
    },
    remarks: {
      type: DataTypes.STRING,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'FUActionHistory',
    timestamps: true
  });

  FUActionHistory.removeAttribute('id');
  
  return FUActionHistory;
};