'use strict';
const { Model } = require('sequelize');
const { getEncryptedString, getHashedString } = require('../services/crypto.service');

module.exports = (sequelize, DataTypes) => {
  class Users extends Model {
    static associate(models) {
      Users.belongsTo(models.EntityDetails, {
        foreignKey: 'entityId',
        as: 'entity',
        onDelete: 'CASCADE'
      });
    }
  }

  Users.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    lastName: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    mobileNo: {
      type: DataTypes.STRING(16),
      allowNull: false,
      unique: true
    },
    emailId: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    active: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 1
    },
    userType: {
      type: DataTypes.ENUM('ADMIN', 'OPERATION_MANAGER' ,'MASTER_MANAGER','COLLECTION_MANAGER', 'MAKER', 'CHECKER'),
      allowNull: false
    },
    entityId: {
      type: DataTypes.UUID,
      allowNull: true,
      defaultValue: null,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'entityId'
      }
    },
    password: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    encPassword: {
      type: DataTypes.TEXT
    },
    resetPassword:{
      type: DataTypes.TEXT,
      allowNull: true,
      defaultValue: null
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    hooks: {
      beforeCreate: (user, options) => {
        if (user.password) {
          user.encPassword = getEncryptedString(user.password);
          user.password = getHashedString(user.password);
        }
      }
    },
    sequelize,
    modelName: 'Users',
    timestamps: true
  });

  return Users;
};