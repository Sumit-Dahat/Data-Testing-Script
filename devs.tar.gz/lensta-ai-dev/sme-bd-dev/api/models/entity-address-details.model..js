'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class EntityAddressDetails extends Model {
    static associate(models) {
      EntityAddressDetails.belongsTo(models.AddressTypes, {
        foreignKey: 'addressTypeId',
        as: 'addressType',
        onDelete: 'CASCADE'
      });

      EntityAddressDetails.belongsTo(models.EntityDetails, {
        foreignKey: 'entityId',
        as: 'entity',
        onDelete: 'CASCADE'
      });
    }
  }
  
  EntityAddressDetails.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    entityId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'entityId'
      }
    },
    addressTypeId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'AddressTypes',
        key: 'id',
        as: 'addressTypeId'
      }
    },
    addressLineOne: {
      type: DataTypes.STRING,
      allowNull: false
    },
    addressLineTwo: {
      type: DataTypes.STRING,
      allowNull: false
    },
    pinCode: {
      type: DataTypes.STRING(6),
      allowNull: false
    },
    state: {
      type: DataTypes.STRING,
      allowNull: false
    },
    district: {
      type: DataTypes.STRING,
      allowNull: false
    },
    subDistrict: {
      type: DataTypes.STRING,
      allowNull: false
    },
    postOffice: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'EntityAddressDetails',
    timestamps: true
  });
  return EntityAddressDetails;
};