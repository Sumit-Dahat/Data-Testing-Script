'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class FUTransactions extends Model {
    static associate(models) {
      FUTransactions.belongsTo(models.FactoringUnits, {
        foreignKey: 'factoringUnitNo',
        as: 'factoringUnit',
        onDelete: 'CASCADE'
      });
    }
  }
  FUTransactions.init({
    transactionId: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: () => {
        const { generateCustomNanoId } = require('../services//generic.service');
        return `TRXN-${generateCustomNanoId(8)}`;
      }
    },
    factoringUnitNo: {
      type: DataTypes.STRING,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'FactoringUnits',
        key: 'factoringUnitNo',
        as: 'factoringUnitNo'
      }
    },
    collectFrom:{
      type: DataTypes.ENUM('BUYER', 'SELLER'),
      allowNull: false
    },
    factoredAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    disbursementAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    collectedAmount:{
      type: DataTypes.FLOAT,
      allowNull: false
    },
    transactionAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    remainingAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    dateOfTransaction: {
      type: DataTypes.DATE,
      allowNull: false
    },
    factoredDate: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    disbursementDate: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    rateOfInterest: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    accruedInterest: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    fees: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    referenceNo: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    narration: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'FUTransactions',
    timestamps: true
  });
  return FUTransactions;
};
