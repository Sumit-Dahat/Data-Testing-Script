'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class EntityDetails extends Model {
    static associate(models) {
      EntityDetails.belongsTo(models.EntityTypes, {
        foreignKey: 'entityTypeId',
        as: 'entityType',
        onDelete: 'CASCADE'
      });
      
      EntityDetails.belongsTo(models.BusinessSectors, {
        foreignKey: 'businessSectorId',
        as: 'businessSector',
        onDelete: 'CASCADE'
      });

      EntityDetails.belongsTo(models.IndustrySectors, {
        foreignKey: 'industrySectorId',
        as: 'industrySector',
        onDelete: 'CASCADE'
      });

      EntityDetails.belongsTo(models.IndustrySubSectors, {
        foreignKey: 'industrySubSectorId',
        as: 'industrySubSector',
        onDelete: 'CASCADE'
      });

      EntityDetails.belongsTo(models.EntityDetails, {
        foreignKey: 'createdByFinancierId',
        as: 'createdByFinancier',
        onDelete: 'CASCADE'
      });

      EntityDetails.hasOne(models.FinancierApprovalDetails, {
        foreignKey: 'financierId',
        as: 'approvalDetails',
        onDelete: 'CASCADE'
      });

      EntityDetails.hasMany(models.Users, {
        foreignKey: 'entityId',
        as: 'users',
        onDelete: 'CASCADE'
      });

      EntityDetails.hasMany(models.EntityBankDetails, {
        foreignKey: 'entityId',
        as: 'bankDetails',
        onDelete: 'CASCADE'
      });
    }
  }

  EntityDetails.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    entityCategory: {
      type: DataTypes.ENUM('BUYER', 'SELLER', 'FINANCIER'),
      allowNull: false
    },
    entityTypeId: {
      type: DataTypes.UUID,
      allowNull: true,
      defaultValue: null,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityTypes',
        key: 'id',
        as: 'entityTypeId'
      }
    },
    entityName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    registrationNo: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    pan: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    panKycVerified: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    udyamRegNo: {
      type: DataTypes.STRING(19),
      allowNull: true,
      defaultValue: null
    },
    udyamRegNoKycVerified: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    kycApiProvider:{
      type: DataTypes.ENUM('KARZA', 'GRIDLINES'),
      allowNull: false
    },
    dateOfIncorporation: {
      type: DataTypes.DATE,
      allowNull: false
    },
    startOfOperation: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    businessSectorId: {
      type: DataTypes.UUID,
      onDelete: 'CASCADE',
      references: {
        model: 'BusinessSectors',
        key: 'id',
        as: 'businessSectorId'
      },
      allowNull: true,
      defaultValue: null
    },
    industrySectorId: {
      type: DataTypes.UUID,
      onDelete: 'CASCADE',
      references: {
        model: 'IndustrySectors',
        key: 'id',
        as: 'industrySectorId'
      },
      allowNull: true,
      defaultValue: null
    },
    industrySubSectorId: {
      type: DataTypes.UUID,
      onDelete: 'CASCADE',
      references: {
        model: 'IndustrySubSectors',
        key: 'id',
        as: 'industrySubSectorId'
      },
      allowNull: true,
      defaultValue: null
    },
    salesInLastFy: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    profitInLastFy: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    sanctionedLimit: {
      type: DataTypes.FLOAT,
      allowNull: true,
      defaultValue: null
    },
    contactNo: {
      type: DataTypes.STRING(16),
      allowNull: true,
      defaultValue: null
    },
    emailId: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    themeHexcode: {
      type: DataTypes.STRING(6),
      allowNull: true,
      defaultValue: null
    },
    finLogoDocId: {
      type: DataTypes.UUID,
      allowNull: true,
      defaultValue: null
    },
    allDetailsFilled: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    approved: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    active: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 1
    },
    createdByFinancierId: {
      type: DataTypes.UUID,
      allowNull: true,
      defaultValue: null,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'createdByFinancierId'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'EntityDetails',
    timestamps: true
  });
  return EntityDetails;
};