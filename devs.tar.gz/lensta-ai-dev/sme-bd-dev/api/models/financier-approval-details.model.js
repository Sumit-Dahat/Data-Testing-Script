'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class FinancierApprovalDetails extends Model {
    static associate(models) {
      FinancierApprovalDetails.belongsTo(models.EntityDetails, {
        foreignKey: 'financierId',
        as: 'financier',
        onDelete: 'CASCADE'
      });
    }
  }
  FinancierApprovalDetails.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    dateOfExpiry: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    approvalType: {
      type: DataTypes.ENUM('TRIAL', 'PERMANENT'),
      allowNull: true,
      defaultValue: null
    },
    financierId: {
      type: DataTypes.UUID,
      allowNull: false,
      unique: true,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'financierId'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'FinancierApprovalDetails',
    timestamps: true
  });
  return FinancierApprovalDetails;
};