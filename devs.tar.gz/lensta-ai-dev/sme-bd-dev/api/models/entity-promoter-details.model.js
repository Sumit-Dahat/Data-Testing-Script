'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class EntityPromoterDetails extends Model {
    static associate(models) {
      EntityPromoterDetails.belongsTo(models.EntityDetails, {
        foreignKey: 'entityId',
        as: 'entity',
        onDelete: 'CASCADE'
      });
    }
  }
  EntityPromoterDetails.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    entityId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityDetails',
        key: 'id',
        as: 'entityId'
      }
    },
    promoterType: {
      type: DataTypes.ENUM('INDIVIDUAL', 'ENTITY'),
      allowNull: false
    },
    nameOrEntityName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    gender: {
      type: DataTypes.ENUM('MALE', 'FEMALE', 'OTHER'),
      allowNull: true,
      defaultValue: null
    },
    dobOrDoi: {
      type: DataTypes.DATE,
      allowNull: false
    },
    aadhaarOrRegNo: {
      type: DataTypes.STRING,
      allowNull: false
    },
    aadhaarKycVerified: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    dinOrCinNo: {
      type: DataTypes.STRING,
      allowNull: false
    },
    pan: {
      type: DataTypes.STRING(10),
      allowNull: true,
      defaultValue: null
    },
    panKycVerified: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    sharePercentage: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    emailId: {
      type: DataTypes.STRING,
      allowNull: false
    },
    contactNo: {
      type: DataTypes.STRING(16),
      allowNull: false
    },
    addressLineOne: {
      type: DataTypes.STRING,
      allowNull: false
    },
    addressLineTwo: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    pinCode: {
      type: DataTypes.STRING(6),
      allowNull: false
    },
    state: {
      type: DataTypes.STRING,
      allowNull: false
    },
    district: {
      type: DataTypes.STRING,
      allowNull: false
    },
    subDistrict: {
      type: DataTypes.STRING,
      allowNull: false
    },
    postOffice: {
      type: DataTypes.STRING,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'EntityPromoterDetails',
    timestamps: true
  });
  return EntityPromoterDetails;
};