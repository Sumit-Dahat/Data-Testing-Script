'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class FUPayments extends Model {
    static associate(models) {
      
      FUPayments.belongsTo(models.EntityBankDetails, {
        foreignKey: 'bankDetailsId',
        as: 'bankDetails',
        onDelete: 'CASCADE'
      });

      FUPayments.belongsTo(models.FactoringUnits, {
        foreignKey: 'factoringUnitNo',
        as: 'factoringUnit',
        onDelete: 'CASCADE'
      });
    }
  }
  FUPayments.init({
    paymentId: {
      type: DataTypes.STRING,
      primaryKey: true,
      defaultValue: () => {
        const { generateCustomNanoId } = require('../services//generic.service');
        return `PYMT-${generateCustomNanoId(8)}`;
      }
    },
    factoringUnitNo: {
      type: DataTypes.STRING,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'FactoringUnits',
        key: 'factoringUnitNo',
        as: 'factoringUnitNo'
      }
    },
    releaseTo:{
        type: DataTypes.ENUM('BUYER', 'SELLER'),
        allowNull: false
    },
    bankDetailsId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityBankDetails',
        key: 'id',
        as: 'bankDetailsId'
      }
    },
    accountHolderName: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    accountNo: {
      type: DataTypes.STRING,
      allowNull: false
    },
    ifsc: {
      type: DataTypes.STRING(11),
      allowNull: false
    },
    collectedAmount:{
      type: DataTypes.FLOAT,
      allowNull: false
    },
    paymentAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    remainingAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    referenceNo: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    narration: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    status: {
      type: DataTypes.ENUM('INITIATED', 'SUCCESSFUL', 'FAILED', 'CANCELLED'),
      allowNull: false
    },
    dateOfInitiate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    dateOfTransaction: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString()
    }
  }, {
    sequelize,
    modelName: 'FUPayments',
    timestamps: true
  });
  return FUPayments;
};
