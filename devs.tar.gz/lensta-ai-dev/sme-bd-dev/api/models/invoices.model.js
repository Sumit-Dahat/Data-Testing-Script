'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Invoices extends Model {
    static associate(models) {
      Invoices.belongsTo(models.EntityLinks, {
        foreignKey: 'buyerSellerLinkId',
        as: 'buyerSellerLink',
        onDelete: 'CASCADE'
      });
      
      Invoices.belongsTo(models.FactoringUnits, {
        foreignKey: 'factoringUnitNo',
        as: 'factoringUnit',
        onDelete: 'CASCADE'
      });

      Invoices.belongsTo(models.Users, {
        foreignKey: 'nextCheckerUserId',
        as: 'nextCheckerUser',
        onDelete: 'CASCADE'
      });

      Invoices.belongsTo(models.Users, {
        foreignKey: 'createdByUserId',
        as: 'createdByUser',
        onDelete: 'CASCADE'
      });

      Invoices.hasMany(models.InvoiceDocuments, {
        foreignKey: 'invoiceId',
        as: 'documents',
        onDelete: 'CASCADE'
      });

      Invoices.hasMany(models.InvoiceActionHistory, {
        foreignKey: 'invoiceId',
        as: 'actionHistory',
        onDelete: 'CASCADE'
      });
    }
  }
  Invoices.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    invoiceNo: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: () => {
        const { generateCustomNanoId } = require('../services//generic.service')
        return `INV-${generateCustomNanoId(8)}`;
      }
    },
    buyerSellerLinkId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'EntityLinks',
        key: 'id',
        as: 'buyerSellerLinkId'
      }
    },
    invoiceDate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    invoiceDueDate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    invoiceAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    discountAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    taxAmount: {
      type: DataTypes.FLOAT,
      allowNull: false
    },
    totalAmount: {
      type: DataTypes.VIRTUAL,
      get() {
        return ((this.invoiceAmount - this.discountAmount) + this.taxAmount);
      }
    },
    factoringUnitNo: {
      type: DataTypes.STRING,
      defaultValue: null,
      allowNull: true,
      onDelete: 'CASCADE',
      references: {
        model: 'FactoringUnits',
        key: 'factoringUnitNo',
        as: 'factoringUnitNo'
      }
    },
    approved: {
      type: DataTypes.SMALLINT,
      allowNull: false,
      defaultValue: 0
    },
    nextCheckerUserId: {
      type: DataTypes.UUID,
      defaultValue: null,
      allowNull: true,
      onDelete: 'CASCADE',
      references: {
        model: 'Users',
        key: 'id',
        as: 'nextCheckerUserId'
      }
    },
    createdByUserId: {
      type: DataTypes.UUID,
      allowNull: false,
      onDelete: 'CASCADE',
      references: {
        model: 'Users',
        key: 'id',
        as: 'createdByUserId'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString(),
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date().toISOString(),
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Invoices',
    timestamps: true
  });
  return Invoices;
};