'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EntityAddressDetails', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      entityId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'entityId'
        }
      },
      addressTypeId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'AddressTypes',
          key: 'id',
          as: 'addressTypeId'
        }
      },
      addressLineOne: {
        type: Sequelize.STRING,
        allowNull: false
      },
      addressLineTwo: {
        type: Sequelize.STRING,
        allowNull: false
      },
      pinCode: {
        type: Sequelize.STRING(6),
        allowNull: false
      },
      state: {
        type: Sequelize.STRING,
        allowNull: false
      },
      district: {
        type: Sequelize.STRING,
        allowNull: false
      },
      subDistrict: {
        type: Sequelize.STRING,
        allowNull: false
      },
      postOffice: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EntityAddressDetails');
  }
};