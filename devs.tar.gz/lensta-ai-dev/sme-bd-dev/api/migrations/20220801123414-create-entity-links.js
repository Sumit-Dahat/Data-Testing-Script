'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EntityLinks', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      buyerId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'buyerId'
        }
      },
      sellerId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'sellerId'
        }
      },
      creditPeriod: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      extendedCreditPeriod: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      sendForFinance: {
        type: Sequelize.ENUM('AUTO', 'MANUAL'),
        allowNull: false
      },
      acceptPayment: {
        type: Sequelize.ENUM('AUTO', 'MANUAL'),
        allowNull: false
      },
      costBearer: {
        type: Sequelize.ENUM('BUYER', 'SELLER', 'PERCENTAGE_SPLIT', 'PERIODIC_SPLIT'),
        allowNull: false
      },
      buyerPercentage: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      sellerPercentage: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      buyerStartDays: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      buyerEndDays: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      sellerStartDays: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      sellerEndDays: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EntityLinks');
  }
};