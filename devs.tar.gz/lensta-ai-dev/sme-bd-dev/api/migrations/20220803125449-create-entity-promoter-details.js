'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EntityPromoterDetails', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      entityId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'entityId'
        }
      },
      promoterType: {
        type: Sequelize.ENUM('INDIVIDUAL', 'ENTITY'),
        allowNull: false
      },
      nameOrEntityName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      gender: {
        type: Sequelize.ENUM('MALE', 'FEMALE', 'OTHER'),
        allowNull: true,
        defaultValue: null
      },
      dobOrDoi: {
        type: Sequelize.DATE,
        allowNull: false
      },
      aadhaarOrRegNo: {
        type: Sequelize.STRING,
        allowNull: false
      },
      aadhaarKycVerified: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      dinOrCinNo: {
        type: Sequelize.STRING,
        allowNull: false
      },
      pan: {
        type: Sequelize.STRING(10),
        allowNull: true,
        defaultValue: null
      },
      panKycVerified: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      sharePercentage: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      emailId: {
        type: Sequelize.STRING,
        allowNull: false
      },
      contactNo: {
        type: Sequelize.STRING(16),
        allowNull: false
      },
      addressLineOne: {
        type: Sequelize.STRING,
        allowNull: false
      },
      addressLineTwo: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      pinCode: {
        type: Sequelize.STRING(6),
        allowNull: false
      },
      state: {
        type: Sequelize.STRING,
        allowNull: false
      },
      district: {
        type: Sequelize.STRING,
        allowNull: false
      },
      subDistrict: {
        type: Sequelize.STRING,
        allowNull: false
      },
      postOffice: {
        type: Sequelize.STRING,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EntityPromoterDetails');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_EntityPromoterDetails_gender","enum_EntityPromoterDetails_promoterType";`);
  }
};