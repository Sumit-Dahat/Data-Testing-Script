'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('FUActionHistory', {
      factoringUnitNo: {
        type: Sequelize.STRING,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'FactoringUnits',
          key: 'factoringUnitNo',
          as: 'factoringUnitNo'
        }
      },
      action: {
        type: Sequelize.ENUM('CREATE', 'UPDATE', 'APPROVE', 'REJECT'),
        allowNull: false
      },
      status: {
        type: Sequelize.ENUM('PENDING', 'OPEN_FOR_FINANCE', 'ROI_ADDED', 'REJECTED', 'AMT_DISBURSED', 'AMT_REPAID', 'ACTIVE_DISBURSEMENT', 'OVERDUE_DISBURSEMENT', 'PAYMENT_CLOSED'),
        allowNull: false
      },
      actionByUserId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'Users',
          key: 'id',
          as: 'actionByUserId'
        }
      },
      remarks: {
        type: Sequelize.STRING,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('FUActionHistory');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_FUActionHistory_action", "enum_FUActionHistory_status";`);
  }
};