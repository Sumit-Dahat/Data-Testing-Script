'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('InvoiceActionHistory', {
      invoiceId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'Invoices',
          key: 'id',
          as: 'invoiceId'
        }
      },
      action: {
        type: Sequelize.ENUM('CREATE', 'UPDATE', 'APPROVE', 'REJECT'),
        allowNull: false
      },
      actionByUserId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'Users',
          key: 'id',
          as: 'actionByUserId'
        }
      },
      remarks: {
        type: Sequelize.STRING,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('InvoiceActionHistory');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_InvoiceActionHistory_action";`);
  }
};