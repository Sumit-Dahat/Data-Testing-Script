'use strict';

const { generateCustomNanoId } = require("../services//generic.service");

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('FUTransactions', {
      transactionId: {
        type: Sequelize.STRING,
        primaryKey: true,
        defaultValue: () => {
          const { generateCustomNanoId } = require('../services//generic.service');
          return `TRXN-${generateCustomNanoId(8)}`;
        }
      },
      factoringUnitNo: {
        type: Sequelize.STRING,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'FactoringUnits',
          key: 'factoringUnitNo',
          as: 'factoringUnitNo'
        }
      },
      collectFrom: {
        type: Sequelize.ENUM('BUYER', 'SELLER'),
        allowNull: false
      },
      factoredAmount: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      disbursementAmount: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      collectedAmount:{
        type: Sequelize.FLOAT,
        allowNull: false
      },
      transactionAmount: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      remainingAmount: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      dateOfTransaction: {
        type: Sequelize.DATE,
        allowNull: false
      },
      factoredDate: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null
      },
      disbursementDate: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null
      },
      rateOfInterest: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      accruedInterest: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      fees: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      referenceNo: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      narration: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('FUTransactions');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_FUTransactions_collectFrom";`);
  }
};