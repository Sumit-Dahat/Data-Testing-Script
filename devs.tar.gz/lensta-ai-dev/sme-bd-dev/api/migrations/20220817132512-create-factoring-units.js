'use strict';

const { generateCustomNanoId } = require("../services//generic.service");

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('FactoringUnits', {
      factoringUnitNo: {
        type: Sequelize.STRING,
        primaryKey: true,
        defaultValue: () => {
          return `FU-${generateCustomNanoId(8)}`;
        }
      },
      buyerSellerLinkId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityLinks',
          key: 'id',
          as: 'buyerSellerLinkId'
        }
      },
      status: {
        type: Sequelize.ENUM('PENDING', 'OPEN_FOR_FINANCE', 'ROI_ADDED', 'REJECTED', 'AMT_DISBURSED', 'AMT_REPAID', 'ACTIVE_DISBURSEMENT', 'OVERDUE_DISBURSEMENT', 'PAYMENT_CLOSED'),
        allowNull: false,
        defaultValue: 'PENDING'
      },
      fuListedDate: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null
      },
      factoredDate: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null
      },
      buyerFees: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      sellerFees: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      rateOfInterest: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      advanceTax: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      interest: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      buyerInterest: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      sellerInterest: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      nextCheckerUserId: {
        type: Sequelize.UUID,
        defaultValue: null,
        allowNull: true,
        onDelete: 'CASCADE',
        references: {
          model: 'Users',
          key: 'id',
          as: 'nextCheckerUserId'
        }
      },
      createdByUserId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'Users',
          key: 'id',
          as: 'createdByUserId'
        }
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('FactoringUnits');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_FactoringUnits_status";`);
  }
};