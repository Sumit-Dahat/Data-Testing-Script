'use strict';

const { generateCustomNanoId } = require("../services//generic.service");

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Invoices', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      invoiceNo: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: () => {
          const { generateCustomNanoId } = require('../services//generic.service')
          return `INV-${generateCustomNanoId(8)}`;
        }
      },
      buyerSellerLinkId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityLinks',
          key: 'id',
          as: 'buyerSellerLinkId'
        }
      },
      invoiceDate: {
        type: Sequelize.DATE,
        allowNull: false
      },
      invoiceDueDate: {
        type: Sequelize.DATE,
        allowNull: false
      },
      invoiceAmount: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      discountAmount: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      taxAmount: {
        type: Sequelize.FLOAT,
        allowNull: false
      },
      factoringUnitNo: {
        type: Sequelize.STRING,
        defaultValue: null,
        allowNull: true,
        onDelete: 'CASCADE',
        references: {
          model: 'FactoringUnits',
          key: 'factoringUnitNo',
          as: 'factoringUnitNo'
        }
      },
      approved: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      nextCheckerUserId: {
        type: Sequelize.UUID,
        defaultValue: null,
        allowNull: true,
        onDelete: 'CASCADE',
        references: {
          model: 'Users',
          key: 'id',
          as: 'nextCheckerUserId'
        }
      },
      createdByUserId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'Users',
          key: 'id',
          as: 'createdByUserId'
        }
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString(),
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString(),
        allowNull: false
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Invoices');
  }
};