'use strict';

const { generateCustomNanoId } = require("../services//generic.service");

module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('FUPayments', {
            paymentId: {
                type: Sequelize.STRING,
                primaryKey: true,
                defaultValue: () => {
                    const { generateCustomNanoId } = require('../services//generic.service');
                    return `PYMT-${generateCustomNanoId(8)}`;
                }
            },
            factoringUnitNo: {
                type: Sequelize.STRING,
                allowNull: false,
                onDelete: 'CASCADE',
                references: {
                    model: 'FactoringUnits',
                    key: 'factoringUnitNo',
                    as: 'factoringUnitNo'
                }
            },
            releaseTo: {
                type: Sequelize.ENUM('BUYER', 'SELLER'),
                allowNull: false
            },
            bankDetailsId: {
                type: Sequelize.UUID,
                allowNull: false,
                onDelete: 'CASCADE',
                references: {
                    model: 'EntityBankDetails',
                    key: 'id',
                    as: 'bankDetailsId'
                }
            },
            accountHolderName: {
                type: Sequelize.STRING,
                allowNull: true,
                defaultValue: null
            },
            accountNo: {
                type: Sequelize.STRING,
                allowNull: false
            },
            ifsc: {
                type: Sequelize.STRING(11),
                allowNull: false
            },
            collectedAmount: {
                type: Sequelize.FLOAT,
                allowNull: false
            },
            paymentAmount: {
                type: Sequelize.FLOAT,
                allowNull: false
            },
            remainingAmount: {
                type: Sequelize.FLOAT,
                allowNull: false
            },
            referenceNo: {
                type: Sequelize.STRING,
                allowNull: true,
                defaultValue: null
            },
            narration: {
                type: Sequelize.STRING,
                allowNull: true,
                defaultValue: null
            },
            status: {
                type: Sequelize.ENUM('INITIATED', 'SUCCESSFUL', 'FAILED', 'CANCELLED'),
                allowNull: false
            },
            dateOfInitiate: {
                type: Sequelize.DATE,
                allowNull: false
            },
            dateOfTransaction: {
                type: Sequelize.DATE,
                allowNull: true,
                defaultValue: null
            },
            createdAt: {
                type: Sequelize.DATE,
                allowNull: false,
                defaultValue: new Date().toISOString()
            },
            updatedAt: {
                type: Sequelize.DATE,
                allowNull: false,
                defaultValue: new Date().toISOString()
            }
        });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('FUPayments');

        await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_FUPayments_releaseTo";`);
        await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_FUPayments_status";`);

    }
};