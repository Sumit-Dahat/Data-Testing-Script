'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EntityDetails', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      entityCategory: {
        type: Sequelize.ENUM('BUYER', 'SELLER', 'FINANCIER'),
        allowNull: false
      },
      entityTypeId: {
        type: Sequelize.UUID,
        allowNull: true,
        defaultValue: null,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityTypes',
          key: 'id',
          as: 'entityTypeId'
        }
      },
      entityName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      registrationNo: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      pan: {
        type: Sequelize.STRING(10),
        allowNull: false
      },
      panKycVerified: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      udyamRegNo: {
        type: Sequelize.STRING(19),
        allowNull: true,
        defaultValue: null
      },
      udyamRegNoKycVerified: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      kycApiProvider:{
        type: Sequelize.ENUM('KARZA', 'GRIDLINES'),
        allowNull: false
      },
      dateOfIncorporation: {
        type: Sequelize.DATE,
        allowNull: false
      },
      startOfOperation: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null
      },
      businessSectorId: {
        type: Sequelize.UUID,
        onDelete: 'CASCADE',
        references: {
          model: 'BusinessSectors',
          key: 'id',
          as: 'businessSectorId'
        },
        allowNull: true,
        defaultValue: null
      },
      industrySectorId: {
        type: Sequelize.UUID,
        onDelete: 'CASCADE',
        references: {
          model: 'IndustrySectors',
          key: 'id',
          as: 'industrySectorId'
        },
        allowNull: true,
        defaultValue: null
      },
      industrySubSectorId: {
        type: Sequelize.UUID,
        onDelete: 'CASCADE',
        references: {
          model: 'IndustrySubSectors',
          key: 'id',
          as: 'industrySubSectorId'
        },
        allowNull: true,
        defaultValue: null
      },
      salesInLastFy: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      profitInLastFy: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      sanctionedLimit: {
        type: Sequelize.FLOAT,
        allowNull: true,
        defaultValue: null
      },
      contactNo: {
        type: Sequelize.STRING(16),
        allowNull: true,
        defaultValue: null
      },
      emailId: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      themeHexcode: {
        type: Sequelize.STRING(6),
        allowNull: true,
        defaultValue: null
      },
      finLogoDocId: {
        type: Sequelize.UUID,
        allowNull: true,
        defaultValue: null
      },
      allDetailsFilled: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      approved: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      active: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 1
      },
      createdByFinancierId: {
        type: Sequelize.UUID,
        allowNull: true,
        defaultValue: null,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'createdByFinancierId'
        }
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EntityDetails');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_EntityDetails_entityCategory", "enum_EntityDetails_entityType"`);
  }
};