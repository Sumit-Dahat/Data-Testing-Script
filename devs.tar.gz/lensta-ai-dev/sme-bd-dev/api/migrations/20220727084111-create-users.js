'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('Users', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      firstName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      lastName: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      mobileNo: {
        type: Sequelize.STRING(16),
        allowNull: false,
        unique: true
      },
      emailId: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
      },
      active: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 1
      },
      userType: {
        type: Sequelize.ENUM('ADMIN', 'OPERATION_MANAGER' ,'MASTER_MANAGER','COLLECTION_MANAGER', 'MAKER', 'CHECKER'),
        allowNull: false
      },
      entityId: {
        type: Sequelize.UUID,
        allowNull: true,
        defaultValue: null,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'entityId'
        }
      },
      password: {
        type: Sequelize.TEXT,
        allowNull: false
      },
      encPassword: {
        type: Sequelize.TEXT
      },
      resetPassword:{
        type: Sequelize.TEXT,
        allowNull: true,
        defaultValue: null
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('Users');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_Users_userType";`);
  }
};
