'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('FinancierApprovalDetails', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      dateOfExpiry: {
        type: Sequelize.DATE,
        allowNull: true,
        defaultValue: null
      },
      approvalType: {
        type: Sequelize.ENUM('TRIAL', 'PERMANENT'),
        allowNull: true,
        defaultValue: null
      },
      financierId: {
        type: Sequelize.UUID,
        allowNull: false,
        unique: true,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'financierId'
        }
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('FinancierApprovalDetails');

    await queryInterface.sequelize.query(`DROP TYPE IF EXISTS "enum_FinancierApprovalDetails_approvalType"`);
  }
};