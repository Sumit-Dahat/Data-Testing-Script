'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EntityBankDetails', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      entityId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'EntityDetails',
          key: 'id',
          as: 'entityId'
        }
      },
      bankAccountTypeId: {
        type: Sequelize.UUID,
        allowNull: false,
        onDelete: 'CASCADE',
        references: {
          model: 'BankAccountTypes',
          key: 'id',
          as: 'bankAccountTypeId'
        }
      },
      accountTitle: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      accountNo: {
        type: Sequelize.STRING,
        allowNull: false
      },
      bankAccKycVerified: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      ifsc: {
        type: Sequelize.STRING(11),
        allowNull: false
      },
      bankName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      branchName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      micrCode: {
        type: Sequelize.STRING,
        allowNull: false
      },
      swiftCode: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
      },
      isDefault: {
        type: Sequelize.SMALLINT,
        allowNull: false,
        defaultValue: 0
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: new Date().toISOString()
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EntityBankDetails');
  }
};