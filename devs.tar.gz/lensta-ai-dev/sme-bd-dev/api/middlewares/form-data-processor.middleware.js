const formidable = require('formidable');
const { StatusCodes } = require('http-status-codes');
const { APIError } = require('../error');

/**
 * @description To parse Form Data values to JSON
 * @param {(
 * 'createAnInvFromFile' |
 * 'addDocumentForInvoice' | 'createAnFUFromFile' |
 * 'createAnEntityDocUpload' | 
 * 'updateAnEntityDocUpload' |
 * 'createAnFinancier' |
 * 'createBankAccStmtDetails' |
 * 'updateAnFinancier')} method Method
 */
module.exports = (method) => {
    return async (req, res, next) => {
        /**
         * @function getErrorCode
         * @description Get specific error code as per the method name.
         * @param {((
         * 'createAnInvFromFile' |
         * 'addDocumentForInvoice' | 'createAnFUFromFile' |
         * 'createAnEntityDocUpload' | 
         * 'updateAnEntityDocUpload' |
         * 'createAnFinancier' |
         * 'createBankAccStmtDetails' |
         * 'updateAnFinancier'))} methodName Method name
         * @returns {string}
         */
        const getErrorCode = (methodName) => {
            const errorCodes = {
                createAnInvFromFile: '0090',
                addDocumentForInvoice: '0095',
                createAnFUFromFile: '0085',
                createAnEntityDocUpload: '0057',
                updateAnEntityDocUpload: '0058',
                createAnFinancier: '0007',
                updateAnFinancier: '0011',
                createBankAccStmtDetails:'0171'
            };
            
            return (errorCodes[methodName]) ? errorCodes[methodName] : '0000';
        };

        try {
            if (Object.keys(req.body).length == 0) {
                
                const form = new formidable.IncomingForm();

                const parsedFormData = await new Promise((resolve, reject) => {
                    form.parse(req, (error, fields, files) => {
                        if (error) {
                            reject(new APIError(getErrorCode(method), StatusCodes.BAD_REQUEST));
                        }
            
                        req.body = {...fields};
                        req.files = {...files};

                        if (
                            (method == 'createAnFinancier') ||
                            (method == 'updateAnFinancier') ||
                            (method == 'updateFinancierProfile')
                        ) {
                            Object.keys(req.body).forEach((key) => {
                                req.body[key] = JSON.parse(req.body[key]);
                            });
                        }

                        resolve(true);
                    });
                });

                if (parsedFormData instanceof Error) {
                    return next(parsedFormData);
                }
            }


            await next();
    
        } catch(error) {
            next(error);
        }
    }
};