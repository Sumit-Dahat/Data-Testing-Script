const { validationChainBuilder } = require("../generic.validator");

module.
exports = (method) => {
    switch(method) {
        case 'getAllFUPymts': {
            return [
                validationChainBuilder('query', {
                    name: 'limit'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'offset'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'releaseTo',
                    values: ['BUYER', 'SELLER']
                }, 'enum', false),

                validationChainBuilder('query', {
                    name: 'paymentAmount',
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'remainingAmount'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'dateOfInitiate'
                }, 'ISO8601String', false),

                validationChainBuilder('query', {
                    name: 'accountNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('query', {
                    name: 'ifsc',
                    pattern: /^[A-Z]{4}0[A-Z|\d]{6}$/
                }, 'regex', false),

                validationChainBuilder('query', {
                    name: 'narration'
                }, 'alphaNumericString', false)
            ];
        }
        case 'createAnFUPymt': {
            return [
    
                validationChainBuilder('body', {
                    name: 'releaseTo',
                    values: ['BUYER', 'SELLER']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'bankDetailsId'
                }, 'uuid-v4', true),

                validationChainBuilder('query', {
                    name: 'accountHolderName'
                }, 'alphaNumericString', false),

                validationChainBuilder('query', {
                    name: 'accountNo'
                }, 'alphaNumericString', false),
                
                validationChainBuilder('body', {
                    name: 'ifsc',
                    pattern: /^[A-Z]{4}0[A-Z|\d]{6}$/
                }, 'regex', true),

                validationChainBuilder('body', {
                    name: 'collectedAmount',
                    min: 0.0,
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'paymentAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'remainingAmount',
                    min: 0.0
                }, 'float', true),
                 
                validationChainBuilder('body', {
                    name: 'referenceNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('body', {
                    name: 'narration'
                }, 'alphaNumericString', true),

                validationChainBuilder('body', {
                    name: 'status',
                    values: ['INITIATED', 'SUCCESSFUL', 'FAILED', 'CANCELLED']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'dateOfInitiate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'dateOfTransaction'
                }, 'ISO8601String', false),
            ];
        }

        case 'updateAnFUPayment': {
            return [
                validationChainBuilder('body', {
                    name: 'releaseTo',
                    values: ['BUYER', 'SELLER']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'bankDetailsId'
                }, 'uuid-v4', true),

                validationChainBuilder('query', {
                    name: 'accountHolderName'
                }, 'alphaNumericString', false),

                validationChainBuilder('query', {
                    name: 'accountNo'
                }, 'alphaNumericString', false),
                
                validationChainBuilder('body', {
                    name: 'ifsc',
                    pattern: /^[A-Z]{4}0[A-Z|\d]{6}$/
                }, 'regex', true),

                validationChainBuilder('body', {
                    name: 'collectedAmount',
                    min: 0.0,
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'paymentAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'remainingAmount',
                    min: 0.0
                }, 'float', true),
                 
                validationChainBuilder('body', {
                    name: 'referenceNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('body', {
                    name: 'narration'
                }, 'alphaNumericString', true),

                validationChainBuilder('body', {
                    name: 'status',
                    values: ['INITIATED', 'SUCCESSFUL', 'FAILED', 'CANCELLED']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'dateOfInitiate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'dateOfTransaction'
                }, 'ISO8601String', false),
            ];
        }

        default: {
            return [];
        }
    }
};