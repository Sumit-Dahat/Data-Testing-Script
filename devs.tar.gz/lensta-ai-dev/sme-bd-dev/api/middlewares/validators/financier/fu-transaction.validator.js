const { validationChainBuilder } = require("../generic.validator");

module.exports = (method) => {
    switch(method) {
        case 'getAllFUTxns': {
            return [
                validationChainBuilder('query', {
                    name: 'limit'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'offset'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'collectFrom',
                    values: ['BUYER', 'SELLER']
                }, 'enum', false),

                validationChainBuilder('query', {
                    name: 'transactionAmount',
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'remainingAmount'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'dateOfTransaction'
                }, 'ISO8601String', false),

                validationChainBuilder('query', {
                    name: 'narration'
                }, 'alphaNumericString', false)
            ];
        }

        case 'createAnFUTxn': {
            return [
    
                validationChainBuilder('body', {
                    name: 'collectFrom',
                    values: ['BUYER', 'SELLER']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'factoredAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'disbursementAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'collectedAmount',
                    min: 0.0,
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'transactionAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'remainingAmount',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'dateOfTransaction'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'factoredDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'disbursementDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'rateOfInterest',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'accruedInterest',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'fees',
                    min: 0.0
                }, 'float', true),
                
                validationChainBuilder('body', {
                    name: 'referenceNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('body', {
                    name: 'narration'
                }, 'alphaNumericString', false)
            ];
        }

        case 'updateAnFUTransaction': {
            return [

                validationChainBuilder('body', {
                    name: 'collectFrom',
                    values: ['BUYER', 'SELLER']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'factoredAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'disbursementAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'collectedAmount',
                    min: 0.0,
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'transactionAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'remainingAmount',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'dateOfTransaction'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'factoredDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'disbursementDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'rateOfInterest',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'accruedInterest',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'fees',
                    min: 0.0
                }, 'float', true),
                
                validationChainBuilder('body', {
                    name: 'referenceNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('body', {
                    name: 'narration'
                }, 'alphaNumericString', false)
            ];
        }

        default: {
            return [];
        }
    }
};