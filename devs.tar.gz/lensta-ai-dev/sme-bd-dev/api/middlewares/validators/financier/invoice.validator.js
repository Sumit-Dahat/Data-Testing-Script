const { validationChainBuilder } = require("../generic.validator");

module.exports = (method) => {
    switch(method) {
        case 'getAllInvoices': {
            return [
                validationChainBuilder('query', {
                    name: 'limit'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'offset'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'approved'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'invoiceNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('query', {
                    name: 'buyerName'
                }, 'charString', false),

                validationChainBuilder('query', {
                    name: 'sellerName'
                }, 'charString', false),

                validationChainBuilder('query', {
                    name: 'invoiceAmount'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'invoiceDate',
                    pattern: /^\d{4}-\d{2}-\d{2},\d{4}-\d{2}-\d{2}$/
                }, 'regex', false),

                validationChainBuilder('query', {
                    name: 'invoiceDueDate',
                    pattern: /^\d{4}-\d{2}-\d{2},\d{4}-\d{2}-\d{2}$/
                }, 'regex', false)
            ];
        }

        case 'getAllInvoiceDocuments': {
            return [
                validationChainBuilder('query', {
                    name: 'limit'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'offset'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'documentType',
                    values: ['INVOICE']
                }, 'enum', false),
                
                validationChainBuilder('query', {
                    name: 'title'
                }, 'alphaNumericString', false),

                validationChainBuilder('query', {
                    name: 'userId'
                }, 'uuid-v4', false),
                
                validationChainBuilder('query', {
                    name: 'entityId'
                }, 'uuid-v4', false)
            ];
        }

        case 'createAnInvFromJSON': {
            return [
                validationChainBuilder('body', {
                    name: 'buyerId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'sellerId'
                }, 'uuid-v4', true),
                
                validationChainBuilder('body', {
                    name: 'invoiceNo'
                }, 'alphaNumericString', true),

                validationChainBuilder('body', {
                    name: 'invoiceDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'invoiceDueDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'invoiceAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'discountAmount',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'taxAmount',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'createdByUserId'
                }, 'uuid-v4', true)
            ];
        }

        case 'createAnInvFromFile': {
            return [
                validationChainBuilder('body', {
                    name: 'buyerId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'sellerId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'createdByUserId'
                }, 'uuid-v4', true)
            ];
        }

        case 'updateAnInvoice': {
            return [
                validationChainBuilder('body', {
                    name: 'buyerId'
                }, 'uuid-v4', false),

                validationChainBuilder('body', {
                    name: 'sellerId'
                }, 'uuid-v4', false),
                
                validationChainBuilder('body', {
                    name: 'invoiceNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('body', {
                    name: 'invoiceDate'
                }, 'ISO8601String', false),

                validationChainBuilder('body', {
                    name: 'invoiceDueDate'
                }, 'ISO8601String', false),

                validationChainBuilder('body', {
                    name: 'invoiceAmount',
                    min: 0.1
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'discountAmount',
                    min: 0.0
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'taxAmount',
                    min: 0.0
                }, 'float', false)
            ];
        }

        case 'addDocumentForInvoice': {
            return [
                validationChainBuilder('body', {
                    name: 'title'
                }, 'alphaNumericString', true),

                validationChainBuilder('body', {
                    name: 'userId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'entityId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'documentType',
                    values: ['INVOICE']
                }, 'enum', true)
            ];
        }

        case 'approveOrRejectAnInvoice': {
            return [
                validationChainBuilder('body', {
                    name: 'approved',
                    values: [0, 1]
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'remarks'
                }, 'alphaNumericString', false)
            ];
        }

        case 'invoiceDocSignedURL': {
            return [
                validationChainBuilder('query', {
                    name: 'action',
                    values: ['VIEW', 'DOWNLOAD']
                }, 'enum', true),

                validationChainBuilder('query', {
                    name: 'expiresIn',
                    min: 1
                }, 'int', true)
            ];
        }

        default: {
            return [];
        }
    }
};