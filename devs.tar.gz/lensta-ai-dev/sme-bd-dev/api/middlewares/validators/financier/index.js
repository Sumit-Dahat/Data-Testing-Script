module.exports = {
   
    invoice: require('./invoice.validator'),
    
    factoringUnit: require('./factoring-unit.validator'),
    
    FUTxn: require('./fu-transaction.validator'),

    FUPymt: require('./fu-payment.validator')

};