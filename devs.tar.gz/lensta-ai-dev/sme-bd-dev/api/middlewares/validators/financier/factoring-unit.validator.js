const { validationChainBuilder } = require("../generic.validator");

module.exports = (method) => {
    switch (method) {
        case 'getAllFactoringUnits': {
            return [
                validationChainBuilder('query', {
                    name: 'limit'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'offset'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'factoringUnitNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('query', {
                    name: 'factoringAmount'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'status',
                    values: ['PENDING', 'OPEN_FOR_FINANCE', 'ROI_ADDED', 'AMT_DISBURSED', 'ACTIVE_DISBURSEMENT', 'OVERDUE_DISBURSEMENT', 'PAYMENT_CLOSED', 'REJECTED']
                }, 'enum', false),

                validationChainBuilder('query', {
                    name: 'invoiceDate',
                    pattern: /^\d{4}-\d{2}-\d{2},\d{4}-\d{2}-\d{2}$/
                }, 'regex', false),

                validationChainBuilder('query', {
                    name: 'invoiceDueDate',
                    pattern: /^\d{4}-\d{2}-\d{2},\d{4}-\d{2}-\d{2}$/
                }, 'regex', false),

                validationChainBuilder('query', {
                    name: 'fuListedDate',
                    pattern: /^\d{4}-\d{2}-\d{2},\d{4}-\d{2}-\d{2}$/
                }, 'regex', false),

                validationChainBuilder('query', {
                    name: 'fuDueDate',
                    pattern: /^\d{4}-\d{2}-\d{2},\d{4}-\d{2}-\d{2}$/
                }, 'regex', false),

                validationChainBuilder('query', {
                    name: 'creditPeriod'
                }, 'numericString', false),

                validationChainBuilder('query', {
                    name: 'buyerName'
                }, 'charString', false),

                validationChainBuilder('query', {
                    name: 'sellerName'
                }, 'charString', false)
            ];
        }

        case 'createAnFUFromJSON': {
            return [
                validationChainBuilder('body', {
                    name: 'buyerId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'sellerId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'status',
                    values: ['PENDING']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'createdByUserId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceNo'
                }, 'alphaNumericString', true),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceDueDate'
                }, 'ISO8601String', true),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceAmount',
                    min: 0.1
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.discountAmount',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.taxAmount',
                    min: 0.0
                }, 'float', true),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.createdByUserId'
                }, 'uuid-v4', true)
            ];
        }

        case 'createAnFUFromFile': {
            return [
                validationChainBuilder('body', {
                    name: 'buyerId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'sellerId'
                }, 'uuid-v4', true),

                validationChainBuilder('body', {
                    name: 'createdByUserId'
                }, 'uuid-v4', true)
            ];
        }

        case 'updateAnFactoringUnit': {
            return [
                validationChainBuilder('body', {
                    name: 'buyerId'
                }, 'uuid-v4', false),

                validationChainBuilder('body', {
                    name: 'sellerId'
                }, 'uuid-v4', false),

                validationChainBuilder('body', {
                    name: 'status',
                    values: ['PENDING', 'OPEN_FOR_FINANCE']
                }, 'enum', false),

                validationChainBuilder('body', {
                    name: 'buyerFees',
                    min: 0.0
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'sellerFees',
                    min: 0.0
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'rateOfInterest',
                    min: 0.1
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'createdByUserId'
                }, 'uuid-v4', false),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceNo'
                }, 'alphaNumericString', false),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceDate'
                }, 'ISO8601String', false),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceDueDate'
                }, 'ISO8601String', false),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.invoiceAmount',
                    min: 0.1
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.discountAmount',
                    min: 0.0
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.taxAmount',
                    min: 0.0
                }, 'float', false),

                validationChainBuilder('body', {
                    name: 'invoiceDetails.createdByUserId'
                }, 'uuid-v4', false)
            ];
        }

        case 'combineTwoFU': {
            return [
                validationChainBuilder('body', {
                    name: "factoringUnit1No"
                }, 'alphaNumericString', true),

                validationChainBuilder('body', {
                    name: "factoringUnit2No"
                }, 'alphaNumericString', true)
            ];
        }

        case 'sendForFinance': {
            return [
                validationChainBuilder('body', {
                    name: 'status',
                    values: ['PENDING']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'approved',
                }, 'int', true),

                validationChainBuilder('body', {
                    name: 'remarks',
                }, 'alphaNumericString', false)
            ];
        }

        case 'validateROI': {
            return [
                validationChainBuilder('body', {
                    name: 'status',
                    values: ['OPEN_FOR_FINANCE']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'approved',
                    values: [0, 1]
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'remarks'
                }, 'alphaNumericString', false)
            ];
        }

        case 'disburseAmt': {
            return [
                validationChainBuilder('body', {
                    name: 'status',
                    values: ['ROI_ADDED']
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'approved',
                    values: [0, 1]
                }, 'enum', true),

                validationChainBuilder('body', {
                    name: 'remarks'
                }, 'alphaNumericString', false)
            ];
        }

        default: {
            return [];
        }
    }
};