const { validationResult } = require("express-validator");
const { StatusCodes } = require("http-status-codes");
const { APIError } = require("../../error");

module.exports = (req, res, next) => {
    try {
        const result = validationResult(req);

        if (result.isEmpty()) {
            next();
        } else {
            return next(
                new APIError(
                    '0069', 
                    StatusCodes.BAD_REQUEST,
                    result.array({
                        onlyFirstError: true
                    })[0].msg
                )
            );
        }

    } catch(error) {
        next(error);
    }
}