'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('EntityAddressDetails', [
      {
        id: '83fa12e8-9722-493e-bac5-6c0520a2894e',
        entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
        addressTypeId: 'a2065e75-6c31-4e52-b9d5-00dd390c414a',
        addressLineOne: '211, 1st Main Road',
        addressLineTwo: '7th block',
        pinCode: '560030',
        state: 'Karnataka',
        district: 'Bengaluru',
        subDistrict: 'Bengaluru Urban',
        postOffice: 'Bengaluru',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'da7382ab-9853-4fe0-928d-cb04151293ef',
        entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
        addressTypeId: '47caa64a-4e33-4353-a7f2-6630020f6893',
        addressLineOne: '415, 3rd Main Road',
        addressLineTwo: '9th block',
        pinCode: '560030',
        state: 'Karnataka',
        district: 'Bengaluru',
        subDistrict: 'Bengaluru Urban',
        postOffice: 'Bengaluru',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('EntityAddressDetails', null, {});
  }
};
