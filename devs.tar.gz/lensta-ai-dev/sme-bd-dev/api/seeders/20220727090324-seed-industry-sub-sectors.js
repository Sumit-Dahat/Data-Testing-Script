'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('IndustrySubSectors', [
      {
        id: 'deacde1d-4387-4335-9047-b0b8c586511a',
        name: 'Tyre',
        industrySectorId: '263bf91c-7eb1-4acd-abd5-ddaf347f663f',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'e35dfcf6-263c-4a78-9fb9-fc53292800ce',
        name: 'Building',
        industrySectorId: 'fb1baa74-6f8d-4337-8cb5-69a5592444ed',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '86f13f25-6b88-442c-8a28-3297bf42b335',
        name: 'Ornament',
        industrySectorId: 'a6d7da04-2556-4a47-b752-4df1f5e71081',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('IndustrySubSectors', null, {});
  }
};
