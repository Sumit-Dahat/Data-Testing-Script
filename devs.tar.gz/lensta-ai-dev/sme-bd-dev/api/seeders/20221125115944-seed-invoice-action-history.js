'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('InvoiceActionHistory', [
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d43',
        invoiceId: '97099199-5631-4424-bc9b-68a2d9a30e62',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d44',
        invoiceId: '97099199-5631-4424-bc9b-68a2d9a30e62',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d45',
        invoiceId: '97099199-5631-4424-bc9b-68a2d9a30e62',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d46',
        invoiceId: '97099199-5631-4424-bc9b-68a2d9a30e62',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d47',
        invoiceId: '97099199-5631-4424-bc9b-68a2d9a30e62',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d48',
        invoiceId: '7279bb05-a14c-4d70-8828-d0b972a8da76',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d49',
        invoiceId: '7279bb05-a14c-4d70-8828-d0b972a8da76',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d50',
        invoiceId: '7279bb05-a14c-4d70-8828-d0b972a8da76',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d51',
        invoiceId: '7279bb05-a14c-4d70-8828-d0b972a8da76',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d52',
        invoiceId: '7279bb05-a14c-4d70-8828-d0b972a8da76',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d53',
        invoiceId: 'd081146e-633e-4697-904a-23082efaace5',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d54',
        invoiceId: 'd081146e-633e-4697-904a-23082efaace5',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d55',
        invoiceId: 'd081146e-633e-4697-904a-23082efaace5',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d56',
        invoiceId: 'd081146e-633e-4697-904a-23082efaace5',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d57',
        invoiceId: 'd081146e-633e-4697-904a-23082efaace5',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d58',
        invoiceId: 'be50216c-8554-4c85-8199-b0bab7366254',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d59',
        invoiceId: 'be50216c-8554-4c85-8199-b0bab7366254',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d60',
        invoiceId: 'be50216c-8554-4c85-8199-b0bab7366254',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d61',
        invoiceId: 'be50216c-8554-4c85-8199-b0bab7366254',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d62',
        invoiceId: 'be50216c-8554-4c85-8199-b0bab7366254',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d63',
        invoiceId: '9fd32c61-7fe0-40d0-b682-4707fdd084ee',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d64',
        invoiceId: '9fd32c61-7fe0-40d0-b682-4707fdd084ee',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d65',
        invoiceId: '9fd32c61-7fe0-40d0-b682-4707fdd084ee',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d66',
        invoiceId: '9fd32c61-7fe0-40d0-b682-4707fdd084ee',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d67',
        invoiceId: '9fd32c61-7fe0-40d0-b682-4707fdd084ee',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d68',
        invoiceId: 'ba74acae-fb20-48c2-a47d-a26c124a9861',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d69',
        invoiceId: 'ba74acae-fb20-48c2-a47d-a26c124a9861',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d70',
        invoiceId: 'ba74acae-fb20-48c2-a47d-a26c124a9861',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d71',
        invoiceId: 'ba74acae-fb20-48c2-a47d-a26c124a9861',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d72',
        invoiceId: 'ba74acae-fb20-48c2-a47d-a26c124a9861',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d73',
        invoiceId: '58865e0c-2743-4fff-929f-48a39262d670',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d74',
        invoiceId: '58865e0c-2743-4fff-929f-48a39262d670',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d75',
        invoiceId: '58865e0c-2743-4fff-929f-48a39262d670',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d76',
        invoiceId: '58865e0c-2743-4fff-929f-48a39262d670',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d77',
        invoiceId: '58865e0c-2743-4fff-929f-48a39262d670',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d78',
        invoiceId: 'a1171457-edd0-4224-92a3-65fdb2ddb637',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d79',
        invoiceId: 'a1171457-edd0-4224-92a3-65fdb2ddb637',
        action: 'APPROVE',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d80',
        invoiceId: 'a1171457-edd0-4224-92a3-65fdb2ddb637',
        action: 'APPROVE',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d81',
        invoiceId: 'a1171457-edd0-4224-92a3-65fdb2ddb637',
        action: 'APPROVE',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d82',
        invoiceId: 'a1171457-edd0-4224-92a3-65fdb2ddb637',
        action: 'APPROVE',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Invoice approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d83',
        invoiceId: '9fb8f0c9-8c26-48c4-a0ac-1b3bbf07c761',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        // id: 'c5b2fe05-e500-4c60-b9d9-5992226e0d84',
        invoiceId: '72cb887e-7328-49a9-b2b2-1d138a92d6ca',
        action: 'CREATE',
        actionByUserId: 'cba36e47-0604-42c4-b3f4-145ae29850ae',
        remarks: 'Invoice created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('InvoiceActionHistory', null, {});
  }
};
