'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('BusinessSectors', [
      {
        id: '3eb67055-b1cb-43fc-b69b-2af22904f22d',
        name: 'Manufacturing',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '30549e73-952a-496d-9b4e-9f11263a7bd3',
        name: 'Service',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '66f168b3-c3f0-444a-8d48-9cec25adea03',
        name: 'Trading',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('BusinessSectors', null, {});
  }
};
