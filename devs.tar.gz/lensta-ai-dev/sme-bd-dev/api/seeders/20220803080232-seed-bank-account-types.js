'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('BankAccountTypes', [
      {
        id: 'e5ac0e15-1264-41cd-a8c0-6119e4688076',
        name: 'Savings',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date,
        updatedAt: new Date().toISOString()
      },
      {
        id: 'e4ba09db-a6e2-4722-8ccf-10be789684f3',
        name: 'Current',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date,
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('BankAccountTypes', null, {});
  }
};
