'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('CheckerLevels', [
      {
        id: 'fae77528-a475-46f0-9629-5442b732ddb9',
        levelName: 'Buyer Level 1',
        userId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '7eac6631-f1a4-43bb-b6ee-2cfec49e35d2',
        levelName: 'Buyer Level 2',
        userId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '8fecd30f-55c1-4e71-9d87-64f411ff69cd',
        levelName: 'Seller Level 1',
        userId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'c8b73dff-f4f4-4364-8464-7506fedab5ba',
        levelName: 'Seller Level 2',
        userId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '1e33989d-84d9-4284-a80a-109651be9b0b',
        levelName: 'Financier Level 1',
        userId: '20280e46-07c4-4b68-b98e-da36062c3534',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'f26d7a9f-f59f-4d08-80aa-54bc150678a3',
        levelName: 'Financier Level 2',
        userId: 'c2caee39-6756-4060-b0c6-51241d03850d',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('CheckerLevels', null, {});
  }
};
