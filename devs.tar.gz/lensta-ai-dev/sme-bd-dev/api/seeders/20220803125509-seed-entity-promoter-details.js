'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('EntityPromoterDetails', [
      {
        id: 'cd3983e4-680a-4ee2-b478-b71fd68f8055',
        entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
        promoterType: 'INDIVIDUAL',
        nameOrEntityName: 'Hughie Doe',
        gender: 'MALE',
        dobOrDoi: new Date(),
        aadhaarOrRegNo: '987123098123',
        aadhaarKycVerified: 1,
        dinOrCinNo: '871267128712',
        pan: 'BASIU7612N',
        panKycVerified: 1,
        sharePercentage: 70.0,
        emailId: 'hughie.doe@gmail.com',
        contactNo: '+917809120934',
        addressLineOne: '7th block, Main Road',
        addressLineTwo: 'Near Bliss Restaurant',
        pinCode: '651209',
        state: 'Karnataka',
        district: 'Bengaluru',
        subDistrict: 'Bengaluru Urban',
        postOffice: 'Bengaluru',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '760eb881-b462-4aad-a6ec-b49671b979dd',
        entityId: '68f1050c-8d49-416f-a1bc-9055b08fc83c',
        promoterType: 'INDIVIDUAL',
        nameOrEntityName: 'Maeve Doe',
        gender: 'FEMALE',
        dobOrDoi: new Date(),
        aadhaarOrRegNo: '987123098126',
        aadhaarKycVerified: 1,
        dinOrCinNo: '871267128725',
        pan: 'BASIU7612Y',
        panKycVerified: 1,
        sharePercentage: 5.0,
        emailId: 'maeve.doe@gmail.com',
        contactNo: '+917809120967',
        addressLineOne: '9th block, Main Road',
        addressLineTwo: 'Near Apollo Hospital',
        pinCode: '651215',
        state: 'Karnataka',
        district: 'Bengaluru',
        subDistrict: 'Bengaluru Rural',
        postOffice: 'Bengaluru',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
  }
};
