'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('EntityTypes', [
      {
        id: 'd55eda4e-b70c-445a-a969-122e8c21d66b',
        name: 'Public',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'efd03308-bc31-4edc-854e-c67c13f138ae',
        name: 'Private',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
  }
};
