'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('AddressTypes', [
      {
        id: 'a2065e75-6c31-4e52-b9d5-00dd390c414a',
        name: 'Home',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '47caa64a-4e33-4353-a7f2-6630020f6893',
        name: 'Work',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('AddressTypes', null, {});
  }
};
