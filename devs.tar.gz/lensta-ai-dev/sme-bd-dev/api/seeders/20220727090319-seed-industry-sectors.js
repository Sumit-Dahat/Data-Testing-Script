'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('IndustrySectors', [
      {
        id: '263bf91c-7eb1-4acd-abd5-ddaf347f663f',
        name: 'Automobile',
        businessSectorId: '3eb67055-b1cb-43fc-b69b-2af22904f22d',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'fb1baa74-6f8d-4337-8cb5-69a5592444ed',
        name: 'Construction',
        businessSectorId: '30549e73-952a-496d-9b4e-9f11263a7bd3',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'a6d7da04-2556-4a47-b752-4df1f5e71081',
        name: 'Gold',
        businessSectorId: '66f168b3-c3f0-444a-8d48-9cec25adea03',
        active: 1,
        createdByUserId: '2994aba6-73de-4e53-a201-4f34cb7bf074',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('IndustrySectors', null, {});
  }
};
