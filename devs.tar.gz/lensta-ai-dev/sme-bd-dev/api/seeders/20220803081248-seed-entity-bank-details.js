'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('EntityBankDetails', [
        {
          id: '42658b4d-938f-48a9-9a31-770de6deddb8',
          entityId: 'de918065-9638-486c-b867-babf264a3dc6',
          bankAccountTypeId: 'e4ba09db-a6e2-4722-8ccf-10be789684f3',
          accountTitle: 'Business Account',
          accountNo: '21420167518933',
          bankAccKycVerified: 1,
          ifsc: 'PNBN0123620',
          bankName: 'MCB Bank',
          branchName: 'Chennai',
          micrCode: '712612127',
          swiftCode: 'CHNNI01278',
          isDefault: 1,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
        id: '0f7a7ad3-06f5-4f2d-a0a9-375b1ec0b58d',
        entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
        bankAccountTypeId: 'e5ac0e15-1264-41cd-a8c0-6119e4688076',
        accountTitle: 'Personal Account',
        accountNo: '21420167518922',
        bankAccKycVerified: 1,
        ifsc: 'BOBN0125620',
        bankName: 'ABC Bank',
        branchName: 'Bengaluru',
        micrCode: '71261287',
        swiftCode: 'BNGLR01267',
        isDefault: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '95c56eae-867a-4ba3-8800-2a4d39844e54',
        entityId: '68f1050c-8d49-416f-a1bc-9055b08fc83c',
        bankAccountTypeId: 'e4ba09db-a6e2-4722-8ccf-10be789684f3',
        accountTitle: 'Business Account',
        accountNo: '21420167518934',
        bankAccKycVerified: 1,
        ifsc: 'SBIN0125620',
        bankName: 'ABC Bank',
        branchName: 'Bengaluru',
        micrCode: '71261290',
        swiftCode: 'BNGLR01258',
        isDefault: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '95c56eae-867a-4ba3-8800-2a4d39844e89',
        entityId: 'a4d79856-a596-4d1b-9c2c-304efb1b4c75',
        bankAccountTypeId: 'e4ba09db-a6e2-4722-8ccf-10be789684f3',
        accountTitle: 'Business Account',
        accountNo: '21420167518941',
        bankAccKycVerified: 1,
        ifsc: 'SBIN0125620',
        bankName: 'PNB Bank',
        branchName: 'Delhi',
        micrCode: '71261290',
        swiftCode: 'BNGLR01258',
        isDefault: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
    ], {})
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('EntityBankDetails', null, {});
  }
};
