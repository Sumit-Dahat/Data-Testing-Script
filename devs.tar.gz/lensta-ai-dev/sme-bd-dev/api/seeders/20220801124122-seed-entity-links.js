'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('EntityLinks', [
      {
        id: '062a6db3-6674-43a5-bb1f-e5402d3c0818',
        buyerId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
        sellerId: 'a4d79856-a596-4d1b-9c2c-304efb1b4c75',
        creditPeriod: 5,
        extendedCreditPeriod: 10,
        sendForFinance: 'MANUAL',
        acceptPayment: 'MANUAL',
        costBearer: 'PERCENTAGE_SPLIT',
        buyerPercentage: 80,
        sellerPercentage: 20,
        buyerStartDays: 0,
        buyerEndDays: 0,
        sellerStartDays: 0,
        sellerEndDays: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
  }
};
