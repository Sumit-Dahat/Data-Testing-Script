'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('FinancierApprovalDetails', [
      {
        id: '063c793b-e302-4aef-9dd8-7d13f9922015',
        dateOfExpiry: new Date(),
        approvalType: 'TRIAL',
        financierId: 'de918065-9638-486c-b867-babf264a3dc6',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '063c793b-e302-4aef-9dd8-7d13f9922016',
        dateOfExpiry: new Date(),
        approvalType: 'PERMANENT',
        financierId: 'fd0b23fc-5920-49df-82fd-500e06a1eda1',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('FinancierApprovalDetails', null, {});
  }
};
