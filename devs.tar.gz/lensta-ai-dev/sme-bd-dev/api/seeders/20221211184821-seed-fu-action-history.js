'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('FUActionHistory', [
      {
        factoringUnitNo: 'FU-87as76A',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-a967as6',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-6712jtu',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-6712jtu',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-6712jtu',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-b12769i',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-b12769i',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-b12769i',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-g176jk1',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-g176jk1',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-g176jk1',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-g176jk1',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: '20280e46-07c4-4b68-b98e-da36062c3534',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-g176jk1',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: 'c2caee39-6756-4060-b0c6-51241d03850d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-8ang7as',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-8ang7as',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-8ang7as',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-8ang7as',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: '20280e46-07c4-4b68-b98e-da36062c3534',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-8ang7as',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: 'c2caee39-6756-4060-b0c6-51241d03850d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: '20280e46-07c4-4b68-b98e-da36062c3534',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: 'c2caee39-6756-4060-b0c6-51241d03850d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'APPROVE',
        status: 'ROI_ADDED',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'APPROVE',
        status: 'ROI_ADDED',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'APPROVE',
        status: 'ROI_ADDED',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-xajh12i',
        action: 'REJECT',
        status: 'ROI_ADDED',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit rejected.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'CREATE',
        status: 'PENDING',
        actionByUserId: '7a45ca25-a4c2-4aa7-8410-7f08eb84dfe7',
        remarks: 'Factoring Unit created.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'APPROVE',
        status: 'PENDING',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: '20280e46-07c4-4b68-b98e-da36062c3534',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'APPROVE',
        status: 'OPEN_FOR_FINANCE',
        actionByUserId: 'c2caee39-6756-4060-b0c6-51241d03850d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'APPROVE',
        status: 'ROI_ADDED',
        actionByUserId: '03e10e26-72c0-4c8c-bfbc-14ed5a3502d5',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'APPROVE',
        status: 'ROI_ADDED',
        actionByUserId: 'de53e1d7-3154-4e9d-ab59-b5d4162b3228',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'APPROVE',
        status: 'ROI_ADDED',
        actionByUserId: '66420181-c1b4-4b90-b29f-cd5b0df2397d',
        remarks: 'Factoring Unit approved.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        factoringUnitNo: 'FU-ua67mna',
        action: 'REJECT',
        status: 'ROI_ADDED',
        actionByUserId: '85da64c8-b4c6-429c-97ec-8c2164bf4e12',
        remarks: 'Factoring Unit rejected.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('FUActionHistory', null, {});
  }
};
