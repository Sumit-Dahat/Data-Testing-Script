const addressTypeCntrls = require('../../controllers/platform/index').addressType;
const addressTypeRouter = require('express').Router();
const existingDetails = require('../../middlewares/existing-details/index');
const auth = require('../../middlewares/auth/index');
const sanitizers = require('../../middlewares/sanitizers');
const validators = require('../../middlewares/validators/index');

addressTypeRouter
    .route('/address-types/:addressTypeId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'addressTypeId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        addressTypeCntrls.getAnAddressTypeByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder
            ('param', {
                name: 'addressTypeId'
            }, 'uuid-v4', true),

        validators.platform.addressType('updateAnAddressType'),

        validators.validationResultChecker,

        sanitizers.platform.addressType('updateAnAddressType'),

        existingDetails.addressType,

        addressTypeCntrls.updateAnAddressTypeByIdCntrl
    );

addressTypeRouter
    .route('/address-types')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER']
        }),

        validators.platform.addressType('getAllAddressTypes'),

        validators.validationResultChecker,

        sanitizers.platform.addressType('getAllAddressTypes'),

        addressTypeCntrls.getAllAddressTypesCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.platform.addressType('createAnAddressType'),

        validators.validationResultChecker,

        sanitizers.platform.addressType('createAnAddressType'),

        existingDetails.addressType,

        addressTypeCntrls.createAnAddressTypeCntrl
    );

module.exports = addressTypeRouter;