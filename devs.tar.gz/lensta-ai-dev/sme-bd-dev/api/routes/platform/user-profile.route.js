const userCntrls = require('../../controllers/platform/index').user;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const existingDetails = require('../../middlewares/existing-details/index');
const sanitizers = require('../../middlewares/sanitizers/index');

const userProfileRouter = require("express").Router();
    
userProfileRouter
    .route('/platform/users/profile')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'MAKER': ['BUYER', 'SELLER', 'FINANCIER'],
            'CHECKER': ['BUYER', 'SELLER', 'FINANCIER'],
            'COLLECTION_MANAGER': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        userCntrls.getUserProfileCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER'],
            'COLLECTION_MANAGER': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.platform.user('updateAnUser'),
        
        validators.validationResultChecker,

        sanitizers.platform.user('updateAnUser'),

        existingDetails.user,
        
        userCntrls.updateUserProfileCntrl
    );

module.exports = userProfileRouter;