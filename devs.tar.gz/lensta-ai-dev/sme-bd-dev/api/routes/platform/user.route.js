const userCntrls = require('../../controllers/platform/index').user;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const existingDetails = require('../../middlewares/existing-details/index');
const userRouter = require("express").Router();
    
userRouter
    .route('/platform/users/entity/:entityId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.platform.user('getAllUsers'),
        
        validators.validationResultChecker,

        sanitizers.platform.user('getAllUsers'),
        
        userCntrls.getAllUsersByEntityIdCntrl
    );

userRouter
    .route("/platform/users/:userId/password")
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER'],
            'COLLECTION_MANAGER': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'userId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        userCntrls.getUserPasswordCntrl
    );

userRouter
    .route('/platform/users/:userId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null]
        }),
        
        validators.validationChainBuilder('param', {
            name: 'userId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        userCntrls.getAnUserByIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'userId'
        }, 'uuid-v4', true),
        
        validators.platform.user('updateAnUser'),
        
        validators.validationResultChecker,

        sanitizers.platform.user('updateAnUser'),

        existingDetails.user,
        
        userCntrls.updateAnUserByIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'userId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        userCntrls.deleteAnUserByIdCntrl
    );

userRouter
    .route("/platform/users")
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null]
        }),
        
        validators.platform.user('getAllUsers'),
        
        validators.validationResultChecker,

        sanitizers.platform.user('getAllUsers'),
        
        userCntrls.getAllPlatformUsersCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.platform.user('createAnUser'),
        
        validators.validationResultChecker,

        sanitizers.platform.user('createAnUser'),
        
        existingDetails.user,
        
        userCntrls.createAnUserCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null]
        }),
        
        userCntrls.deleteAllUsersCntrl
    );
    
module.exports = userRouter;