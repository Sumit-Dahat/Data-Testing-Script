const karzaAadhaarKycRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const validators = require('../../../../middlewares/validators');
const existingDetails = require('../../../../middlewares/existing-details/index');
const sanitizers = require('../../../../middlewares/sanitizers');
const controllers = require('../../../../controllers');

karzaAadhaarKycRouter
.route('/karza/kyc/aadhaar/otp')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.karza.aadhaarKyc('generateAadhaarKycOtp'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.karza.aadhaarKyc('generateAadhaarKycOtp'),

    existingDetails.aadhaar,
    
    controllers.platform.kyc.karza.aadhaarKyc.generateAadhaarKycOtpCntrl
);

karzaAadhaarKycRouter
.route('/karza/kyc/aadhaar/:aadhaarNo')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'aadhaarNo',
        pattern: /^[\d]{12}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.karza.aadhaarKyc.getAadhaarKycByAadhaarNoCntrl
);

karzaAadhaarKycRouter
.route('/karza/kyc/aadhaar')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.karza.aadhaarKyc('addAadhaarKycDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.karza.aadhaarKyc('addAadhaarKycDetails'),

    existingDetails.aadhaar,
    
    controllers.platform.kyc.karza.aadhaarKyc.addAadhaarKycDetailsCntrl
);

module.exports = karzaAadhaarKycRouter;