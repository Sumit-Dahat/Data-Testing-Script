const karzaGstKycRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const validators = require('../../../../middlewares/validators');
const sanitizers = require('../../../../middlewares/sanitizers');
const controllers = require('../../../../controllers');

karzaGstKycRouter
.route('/karza/kyc/gst/:gstin')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'gstin',
        pattern: /^[\d]{2}[A-Z]{5}[\d]{4}[A-Z]{1}[\d]{1}[Z]{1}[A-Z\d]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.karza.gstKyc.getGstKycByGstNoCntrl
);

karzaGstKycRouter
.route('/karza/kyc/gst')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'FINANCIER','BUYER', 'SELLER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.karza.gstKyc('addGstKycDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.karza.gstKyc('addGstKycDetails'),
    
    controllers.platform.kyc.karza.gstKyc.addGstKycDetailsCntrl
);


karzaGstKycRouter
.route('/karza/kyc/gst-itr')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'FINANCIER','BUYER', 'SELLER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.karza.gstKyc('addGstItrDetails'),

    validators.validationResultChecker,

    sanitizers.platform.kyc.karza.gstKyc('addGstItrDetails'),
    
    controllers.platform.kyc.karza.gstKyc.addGstItrDetailsCntrl
)
karzaGstKycRouter
.route('/karza/kyc/gst-itr/:gstin')
.get(
    auth.validateLogin,

    validators.routeAccess({
        'ADMIN': [null, 'FINANCIER','BUYER', 'SELLER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'gstin',
        pattern: /^[\d]{2}[A-Z]{5}[\d]{4}[A-Z]{1}[\d]{1}[Z]{1}[A-Z\d]{1}$/
    }, 'regex', true),
    
    validators.validationResultChecker,

    controllers.platform.kyc.karza.gstKyc.getGstItrByGstNoCntrl
    
);

module.exports = karzaGstKycRouter;