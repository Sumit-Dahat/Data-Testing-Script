const karzaPanKycRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const validators = require('../../../../middlewares/validators');
const sanitizers = require('../../../../middlewares/sanitizers');
const existingDetails = require('../../../../middlewares/existing-details/index');
const controllers = require('../../../../controllers');

karzaPanKycRouter
.route('/karza/kyc/pan/:pan')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'pan',
        pattern: /^[A-Z]{5}[\d]{4}[A-Z]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.karza.panKyc.getPanKycByPanNoCntrl
);

karzaPanKycRouter
.route('/karza/kyc/pan')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.karza.panKyc('addPanKycDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.karza.panKyc('addPanKycDetails'),

    existingDetails.pan.buyerSellers,
    
    controllers.platform.kyc.karza.panKyc.addPanKycDetailsCntrl
);

karzaPanKycRouter
.route('/karza/kyc/pan/:pan/linked-gstins')
.get(
    auth.validateLogin,

    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'pan',
        pattern: /^[A-Z]{5}[\d]{4}[A-Z]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.karza.panKyc.getGstNosByPanCntrl
)
.post(
    auth.validateLogin,

    validators.routeAccess({
        'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'pan',
        pattern: /^[A-Z]{5}\d{4}[A-Z]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.karza.panKyc.addPanLinkedGstNosCntrl
);

module.exports = karzaPanKycRouter;