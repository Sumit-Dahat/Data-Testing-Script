const gridlinesBankAccKycRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const validators = require('../../../../middlewares/validators');
const existingDetails = require('../../../../middlewares/existing-details/index');
const sanitizers = require('../../../../middlewares/sanitizers');
const controllers = require('../../../../controllers');

gridlinesBankAccKycRouter
.route('/gridlines/kyc/bank-account')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.gridlines.bankAccKyc('addBankAccKycDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.gridlines.bankAccKyc('addBankAccKycDetails'),
    
    existingDetails.bank,
    
    controllers.platform.kyc.gridlines.bankAccKyc.addBankAccKycDetailsCntrl
);

gridlinesBankAccKycRouter
.route('/gridlines/kyc/bank-account/:accountNumber')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'accountNumber',
        pattern: /^[a-zA-Z0-9]{5,25}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.bankAccKyc.getBankAccKycByAccNoCntrl
);


module.exports = gridlinesBankAccKycRouter;