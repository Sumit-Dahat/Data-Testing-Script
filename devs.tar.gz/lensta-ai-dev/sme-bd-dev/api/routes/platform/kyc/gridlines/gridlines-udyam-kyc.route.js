const gridlinesUdyamKycRouter = require("express").Router();
const auth = require("../../../../middlewares/auth");
const validators = require("../../../../middlewares/validators");
const sanitizers = require("../../../../middlewares/sanitizers");
const existingDetails = require('../../../../middlewares/existing-details/index');
const controllers = require("../../../../controllers");

gridlinesUdyamKycRouter.route("/gridlines/kyc/udyam/:udyamRegNo").get(
    auth.validateLogin,

    validators.routeAccess({
        ADMIN: ["BUYER", "SELLER", "FINANCIER"],
        MASTER_MANAGER: ["FINANCIER"],
    }),

    validators.validationChainBuilder(
        "param",
        {
            name: "udyamRegNo",
            pattern: /^UDYAM-[A-Z]{2}-[\d]{2}-[\d]{7}$/,
        },
        "regex",
        true
    ),

    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.udyamKyc.getUdyamKycByUdyamNoCntrl
);

gridlinesUdyamKycRouter.route("/gridlines/kyc/udyam").post(
    auth.validateLogin,

    validators.routeAccess({
        ADMIN: [null, "BUYER", "SELLER", "FINANCIER"],
        OPERATION_MANAGER: [null],
        MASTER_MANAGER: ["FINANCIER"],
    }),

    validators.platform.kyc.gridlines.udyamKyc("addUdyamKycDetails"),

    validators.validationResultChecker,

    sanitizers.platform.kyc.gridlines.udyamKyc("addUdyamKycDetails"),

    existingDetails.udyam,

    controllers.platform.kyc.gridlines.udyamKyc.addUdyamKycDetailsCntrl
);

module.exports = gridlinesUdyamKycRouter;
