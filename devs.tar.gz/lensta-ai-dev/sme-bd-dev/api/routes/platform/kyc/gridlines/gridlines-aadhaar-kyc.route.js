const gridlinesAadhaarKycRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const validators = require('../../../../middlewares/validators');
const existingDetails = require('../../../../middlewares/existing-details/index');
const sanitizers = require('../../../../middlewares/sanitizers');
const controllers = require('../../../../controllers');

gridlinesAadhaarKycRouter
.route('/gridlines/kyc/aadhaar/otp')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.gridlines.aadhaarKyc('generateAadhaarKycOtp'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.gridlines.aadhaarKyc('generateAadhaarKycOtp'),

    existingDetails.aadhaar,
    
    controllers.platform.kyc.gridlines.aadhaarKyc.generateAadhaarKycOtpCntrl
);

gridlinesAadhaarKycRouter
.route('/gridlines/kyc/aadhaar/:aadhaarNo')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'aadhaarNo',
        pattern: /^[\d]{12}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.aadhaarKyc.getAadhaarKycByAadhaarNoCntrl
);

gridlinesAadhaarKycRouter
.route('/gridlines/kyc/aadhaar')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.gridlines.aadhaarKyc('addAadhaarKycDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.gridlines.aadhaarKyc('addAadhaarKycDetails'),
    
    existingDetails.aadhaar,

    controllers.platform.kyc.gridlines.aadhaarKyc.addAadhaarKycDetailsCntrl
);

module.exports = gridlinesAadhaarKycRouter;