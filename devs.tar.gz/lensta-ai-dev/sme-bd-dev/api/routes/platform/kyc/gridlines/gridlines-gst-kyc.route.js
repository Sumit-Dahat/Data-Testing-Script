const gridlinesGstKycRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const validators = require('../../../../middlewares/validators');
const sanitizers = require('../../../../middlewares/sanitizers');
const controllers = require('../../../../controllers');

gridlinesGstKycRouter
.route('/gridlines/kyc/gst/:gstin')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'gstin',
        pattern: /^[\d]{2}[A-Z]{5}[\d]{4}[A-Z]{1}[\d]{1}[Z]{1}[A-Z\d]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.gstKyc.getGstKycByGstNoCntrl
);

gridlinesGstKycRouter
.route('/gridlines/kyc/gst')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.gridlines.gstKyc('addGstKycDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.gridlines.gstKyc('addGstKycDetails'),
    
    controllers.platform.kyc.gridlines.gstKyc.addGstKycDetailsCntrl
);


gridlinesGstKycRouter
.route('/gridlines/kyc/gst-itr')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'FINANCIER','BUYER', 'SELLER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.gridlines.gstKyc('addGstItrDetails'),

    validators.validationResultChecker,

    sanitizers.platform.kyc.gridlines.gstKyc('addGstItrDetails'),
    
    controllers.platform.kyc.gridlines.gstKyc.addGstItrDetailsCntrl
)


gridlinesGstKycRouter
.route('/gridlines/kyc/gst-itr/:gstin')
.get(
    auth.validateLogin,

    validators.routeAccess({
        'ADMIN': [null, 'FINANCIER','BUYER', 'SELLER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'gstin',
        pattern: /^[\d]{2}[A-Z]{5}[\d]{4}[A-Z]{1}[\d]{1}[Z]{1}[A-Z\d]{1}$/
    }, 'regex', true),
    
    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.gstKyc.getGstItrByGstNoCntrl
    
);

module.exports = gridlinesGstKycRouter;