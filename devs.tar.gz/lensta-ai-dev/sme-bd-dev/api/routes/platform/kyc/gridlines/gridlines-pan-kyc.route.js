const gridlinesPanKycRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const validators = require('../../../../middlewares/validators');
const sanitizers = require('../../../../middlewares/sanitizers');
const existingDetails = require('../../../../middlewares/existing-details/index');
const controllers = require('../../../../controllers');

gridlinesPanKycRouter
.route('/gridlines/kyc/pan/:pan')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'pan',
        pattern: /^[A-Z]{5}[\d]{4}[A-Z]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.panKyc.getPanKycByPanNoCntrl
);

gridlinesPanKycRouter
.route('/gridlines/kyc/pan')
.post(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.platform.kyc.gridlines.panKyc('addPanKycDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.gridlines.panKyc('addPanKycDetails'),

    existingDetails.pan.buyerSellers,
    
    controllers.platform.kyc.gridlines.panKyc.addPanKycDetailsCntrl
);

gridlinesPanKycRouter
.route('/gridlines/kyc/pan/:pan/linked-gstins')
.get(
    auth.validateLogin,

    validators.routeAccess({
        'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'pan',
        pattern: /^[A-Z]{5}[\d]{4}[A-Z]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.panKyc.getGstNosByPanCntrl
)
.post(
    auth.validateLogin,

    validators.routeAccess({
        'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'pan',
        pattern: /^[A-Z]{5}\d{4}[A-Z]{1}$/
    }, 'regex', true),

    validators.validationResultChecker,

    controllers.platform.kyc.gridlines.panKyc.addPanLinkedGstNosCntrl
);

module.exports = gridlinesPanKycRouter;