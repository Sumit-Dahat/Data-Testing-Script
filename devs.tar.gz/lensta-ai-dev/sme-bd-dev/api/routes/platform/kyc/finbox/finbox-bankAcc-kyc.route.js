const finboxBankAccStmtRouter = require('express').Router();
const auth = require('../../../../middlewares/auth');
const formDataProcessor = require('../../../../middlewares/form-data-processor.middleware')
const validators = require('../../../../middlewares/validators');
const sanitizers = require('../../../../middlewares/sanitizers');
const controllers = require('../../../../controllers');


finboxBankAccStmtRouter
.route('/finbox/stmt/bank-account/')
.post(
    
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    formDataProcessor('createBankAccStmtDetails'),

    validators.singleFile('document', envConfig.MAX_FILE_SIZE_MB, envConfig.DOC_EXT),

    validators.platform.kyc.finbox.bankAccStmt('addBankAccStmtDetails'),
    
    validators.validationResultChecker,

    sanitizers.platform.kyc.finbox.bankAccStmt('addBankAccStmtDetails'),
    
    controllers.platform.kyc.finbox.bankAccStmt.addBankAccStmtDetailsCntrl
)

finboxBankAccStmtRouter
.route('/finbox/stmt/bank-account/:accountNumber')
.get(
    auth.validateLogin,
    
    validators.routeAccess({
        'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
        'OPERATION_MANAGER': [null],
        'MASTER_MANAGER': ['FINANCIER']
    }),

    validators.validationChainBuilder('param', {
        name: 'accountNumber',
        pattern: /^[a-zA-Z0-9]{5,25}$/
    }, 'regex', true),
    
    controllers.platform.kyc.finbox.bankAccStmt.getBankAccStmtByAccNoCntrl
)


module.exports = finboxBankAccStmtRouter;