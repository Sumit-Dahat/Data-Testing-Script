const businessSectorRouter = require('express').Router();
const businessSectorCntrls = require('../../controllers/platform/index').businessSector;
const existingDetails = require('../../middlewares/existing-details/index');
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

businessSectorRouter
    .route('/business-sectors/:businessSectorId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'businessSectorId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        businessSectorCntrls.getAnBusinessSectorByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'businessSectorId'
        }, 'uuid-v4', true),

        validators.platform.businessSector('updateAnBusinessSector'),

        validators.validationResultChecker,

        sanitizers.platform.businessSector('updateAnBusinessSector'),

        existingDetails.businessSector,

        businessSectorCntrls.updateAnBusinessSectorByIdCntrl
    );

businessSectorRouter
    .route('/business-sectors')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER']
        }),

        validators.platform.businessSector('getAllBusinessSectors'),

        validators.validationResultChecker,

        sanitizers.platform.businessSector('getAllBusinessSectors'),

        businessSectorCntrls.getAllBusinessSectorsCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null, 'FINANCIER']
        }),

        validators.platform.businessSector('createAnBusinessSector'),

        validators.validationResultChecker,

        sanitizers.platform.businessSector('createAnBusinessSector'),

        existingDetails.businessSector,

        businessSectorCntrls.createAnBusinessSectorCntrl
    );

module.exports = businessSectorRouter;