const checkerLevelCntrls = require('../../controllers/platform/index').checkerLevel;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const checkerLevelRouter = require("express").Router();

checkerLevelRouter
    .route('/platform/users/checker-levels/:checkerLevelId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),

        validators.validationChainBuilder('param', {
            name: 'checkerLevelId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        checkerLevelCntrls.getAnCheckerLevelByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),

        validators.validationChainBuilder('param', {
            name: 'checkerLevelId'
        }, 'uuid-v4', true),

        validators.platform.user('updateAnCheckerLevel'),

        validators.validationResultChecker,

        sanitizers.platform.user('updateAnCheckerLevel'),

        checkerLevelCntrls.updateAnCheckerLevelByIdCntrl
    )
    .delete(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),

        validators.validationChainBuilder('param', {
            name: 'checkerLevelId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        checkerLevelCntrls.deleteAnCheckerLevelByIdCntrl
    );

checkerLevelRouter
    .route('/platform/users/checker-levels')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),

        validators.platform.user('getAllCheckerLevels'),

        validators.validationResultChecker,

        sanitizers.platform.user('getAllCheckerLevels'),

        checkerLevelCntrls.getAllEntityCheckerLevelsCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),

        validators.platform.user('createAnCheckerLevel'),

        validators.validationResultChecker,

        sanitizers.platform.user('createAnCheckerLevel'),

        checkerLevelCntrls.createAnCheckerLevelCntrl
    );

module.exports = checkerLevelRouter;