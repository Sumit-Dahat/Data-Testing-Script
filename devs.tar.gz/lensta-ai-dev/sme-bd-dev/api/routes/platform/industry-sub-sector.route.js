const industrySubSectorRouter = require('express').Router();
const industrySubSectorCntrls = require('../../controllers/platform/index').industrySubSector;
const existingDetails = require('../../middlewares/existing-details/index');
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

industrySubSectorRouter
    .route('/industry-sub-sectors/:industrySubSectorId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'industrySubSectorId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        industrySubSectorCntrls.getAnIndustrySubSectorByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'industrySubSectorId'
        }, 'uuid-v4', true),

        validators.platform.industrySubSector('updateAnIndustrySubSector'),

        validators.validationResultChecker,

        sanitizers.platform.industrySubSector('updateAnIndustrySubSector'),

        existingDetails.industrySubSector,

        industrySubSectorCntrls.updateAnIndustrySubSectorByIdCntrl
    );

industrySubSectorRouter
    .route('/industry-sub-sectors')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER']
        }),

        validators.platform.industrySubSector('getAllIndustrySubSectors'),

        validators.validationResultChecker,

        sanitizers.platform.industrySubSector('getAllIndustrySubSectors'),

        industrySubSectorCntrls.getAllIndustrySubSectorsCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.platform.industrySubSector('createAnIndustrySubSector'),

        validators.validationResultChecker,

        sanitizers.platform.industrySubSector('createAnIndustrySubSector'),

        existingDetails.industrySubSector,

        industrySubSectorCntrls.createAnIndustrySubSectorCntrl
    );

module.exports = industrySubSectorRouter;