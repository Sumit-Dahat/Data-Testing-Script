const authCntrl = require('../../controllers/platform/index').auth;
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

const authRouter = require("express").Router()

authRouter
    .route('/platform/auth/login')    
    .post(
        validators.platform.auth('login'),

        validators.validationResultChecker,

        sanitizers.platform.auth('login'),

        authCntrl.loginCntrl
    );

authRouter
    .route('/platform/auth/reset-password')    
    .post(
        validators.platform.auth('sendResetPasswordLink'),
        validators.validationResultChecker,
        sanitizers.platform.auth('sendResetPasswordLink'),
        authCntrl.sendResetPasswordLink
    );

authRouter
.route('/platform/auth/reset-password/:userId/:token')    
.post(
    validators.platform.auth('resetPassword'),
    validators.validationResultChecker,
    sanitizers.platform.auth('resetPassword'),
    authCntrl.resetPassword
);

module.exports = authRouter