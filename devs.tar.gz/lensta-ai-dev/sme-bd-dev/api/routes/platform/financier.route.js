const financierCntrls = require('../../controllers/platform/index').financier;
const auth = require('../../middlewares/auth/index');
const formDataProcessor = require('../../middlewares/form-data-processor.middleware');
const existingDetails = require('../../middlewares/existing-details/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

const financierRouter = require("express").Router();

financierRouter
    .route('/financiers/logo/:logoDocumentId/signed-url')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': [null, 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER'],
            'COLLECTION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER', 'FINANCIER'],
            'CHECKER': ['BUYER', 'SELLER', 'FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'logoDocumentId'
        }, 'uuid-v4', true),

        validators.platform.financier('finLogoSignedURL'),
        
        validators.validationResultChecker,

        sanitizers.platform.financier('finLogoSignedURL'),
        
        financierCntrls.getFinLogoSignedURLCntrl
    );

financierRouter
    .route('/financiers/:financierId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null],
            'OPERATION_MANAGER': [null]
        }),
        
        validators.validationChainBuilder('param', {
            name: 'financierId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        financierCntrls.getAnFinancierByIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null],
            'OPERATION_MANAGER': [null]
        }),

        formDataProcessor('updateAnFinancier'),
        
        validators.validationChainBuilder('param', {
            name: 'financierId'
        }, 'uuid-v4', true),
        
        validators.platform.financier('updateAnFinancier'),
        
        validators.validationResultChecker,

        sanitizers.platform.financier('updateAnFinancier'),

        existingDetails.financier,
        
        existingDetails.user,
        
        financierCntrls.updateAnFinancierByIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null],
            'OPERATION_MANAGER': [null]
        }),
        
        validators.validationChainBuilder('param', {
            name: 'financierId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        financierCntrls.deleteAnFinancierByIdCntrl
    );

financierRouter 
    .route("/financiers")
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null],
            'OPERATION_MANAGER': [null]
        }),
        
        validators.platform.financier('getAllFinanciers'),
        
        validators.validationResultChecker,

        sanitizers.platform.financier('getAllFinanciers'),
        
        financierCntrls.getAllFinanciersCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null],
            'OPERATION_MANAGER': [null]
        }),

        formDataProcessor('createAnFinancier'),
        
        validators.platform.financier('createAnFinancier'),
        
        validators.validationResultChecker,

        sanitizers.platform.financier('createAnFinancier'),
        
        existingDetails.financier,
        
        existingDetails.user,
        
        financierCntrls.createAnFinancierCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': [null],
            'OPERATION_MANAGER': [null]
        }),
        
        financierCntrls.deleteAllFinanciersCntrl
    );
    
module.exports = financierRouter