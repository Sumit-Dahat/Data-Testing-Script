const bankAccountTypeRouter = require('express').Router();
const bankAccountTypeCntrls = require('../../controllers/platform/index').bankAccountType;
const existingDetails = require('../../middlewares/existing-details/index');
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

bankAccountTypeRouter
    .route('/bank-account-types/:bankAccountTypeId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'bankAccountTypeId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        bankAccountTypeCntrls.getAnBankAccountTypeByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'bankAccountTypeId'
        }, 'uuid-v4', true),

        validators.platform.bankAccountType('updateAnBankAccountType'),

        validators.validationResultChecker,

        sanitizers.platform.bankAccountType('updateAnBankAccountType'),

        existingDetails.bankAccountType,

        bankAccountTypeCntrls.updateAnBankAccountTypeByIdCntrl
    );

bankAccountTypeRouter
    .route('/bank-account-types')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER']
        }),

        validators.platform.bankAccountType('getAllBankAccountTypes'),

        validators.validationResultChecker,

        sanitizers.platform.bankAccountType('getAllBankAccountTypes'),

        bankAccountTypeCntrls.getAllBankAccountTypesCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.platform.bankAccountType('createAnBankAccountType'),

        validators.validationResultChecker,

        sanitizers.platform.bankAccountType('createAnBankAccountType'),

        existingDetails.bankAccountType,

        bankAccountTypeCntrls.createAnBankAccountTypeCntrl
    );

module.exports = bankAccountTypeRouter;