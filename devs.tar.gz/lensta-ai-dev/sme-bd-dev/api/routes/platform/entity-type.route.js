const entityTypeRouter = require('express').Router();
const entityTypeCntrls = require('../../controllers/platform/index').entityType;
const existingDetails = require('../../middlewares/existing-details/index');
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

entityTypeRouter
    .route('/entity-types/:entityTypeId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'entityTypeId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        entityTypeCntrls.getAnEntityTypeByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),


        validators.validationChainBuilder('param', {
            name: 'entityTypeId'
        }, 'uuid-v4', true),
        

        validators.platform.entityType('updateAnEntityType'),

        
        validators.validationResultChecker,

        sanitizers.platform.entityType('updateAnEntityType'),
    
        existingDetails.entityType,

        entityTypeCntrls.updateAnEntityTypeByIdCntrl
    );

entityTypeRouter
    .route('/entity-types')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER']
        }),

        validators.platform.entityType('getAllEntityTypes'),

        validators.validationResultChecker,

        sanitizers.platform.entityType('getAllEntityTypes'),

        entityTypeCntrls.getAllEntityTypesCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.platform.entityType('createAnEntityType'),

        validators.validationResultChecker,

        sanitizers.platform.entityType('createAnEntityType'),

        existingDetails.entityType,

        entityTypeCntrls.createAnEntityTypeCntrl
    );

module.exports = entityTypeRouter;