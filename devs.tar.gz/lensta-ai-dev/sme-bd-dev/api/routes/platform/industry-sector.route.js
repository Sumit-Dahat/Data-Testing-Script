const industrySectorRouter = require('express').Router();
const industrySectorCntrls = require('../../controllers/platform/index').industrySector;
const existingDetails = require('../../middlewares/existing-details/index');
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

industrySectorRouter
    .route('/industry-sectors/:industrySectorId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'industrySectorId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        industrySectorCntrls.getAnIndustrySectorByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.validationChainBuilder('param', {
            name: 'industrySectorId'
        }, 'uuid-v4', true),

        validators.platform.industrySector('updateAnIndustrySector'),

        validators.validationResultChecker,

        sanitizers.platform.industrySector('updateAnIndustrySector'),

        existingDetails.industrySector,

        industrySectorCntrls.updateAnIndustrySectorByIdCntrl
    );

industrySectorRouter
    .route('/industry-sectors')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null, 'BUYER', 'SELLER', 'FINANCIER']
        }),

        validators.platform.industrySector('getAllIndustrySectors'),

        validators.validationResultChecker,

        sanitizers.platform.industrySector('getAllIndustrySectors'),

        industrySectorCntrls.getAllIndustrySectorsCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': [null]
        }),

        validators.platform.industrySector('createAnIndustrySector'),

        validators.validationResultChecker,

        sanitizers.platform.industrySector('createAnIndustrySector'),

        existingDetails.industrySector,

        industrySectorCntrls.createAnIndustrySectorCntrl
    );

module.exports = industrySectorRouter;