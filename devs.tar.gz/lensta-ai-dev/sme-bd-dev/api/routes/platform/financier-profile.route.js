const finProfileCntrls = require("../../controllers/platform/index").financierProfile;
const auth = require("../../middlewares/auth/index");
const formDataProcessor = require("../../middlewares/form-data-processor.middleware");
const existingDetails = require('../../middlewares/existing-details/index');
const validators = require("../../middlewares/validators/index");
const sanitizers = require("../../middlewares/sanitizers");

const finProfileRouter = require("express").Router();

finProfileRouter
    .route("/financiers/profile/users/:userId")
    .get(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.validationChainBuilder(
            "param",
            {
                name: "userId",
            },
            "uuid-v4",
            true
        ),

        validators.validationResultChecker,

        finProfileCntrls.getAnFinancierUserByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.validationChainBuilder(
            "param",
            {
                name: "userId",
            },
            "uuid-v4",
            true
        ),

        validators.platform.financier("updateAnFinancierUser"),

        validators.validationResultChecker,

        sanitizers.platform.financier("updateAnFinancierUser"),

        existingDetails.user,

        finProfileCntrls.updateAnFinancierUserByIdCntrl
    )
    .delete(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.validationChainBuilder(
            "param",
            {
                name: "userId",
            },
            "uuid-v4",
            true
        ),

        validators.validationResultChecker,

        finProfileCntrls.deleteAnFinancierUserByIdCntrl
    );

finProfileRouter
    .route("/financiers/profile/users")
    .get(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.platform.financier("getFinancierUsers"),

        validators.validationResultChecker,

        sanitizers.platform.financier("getFinancierUsers"),

        finProfileCntrls.getFinancierUsersCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.platform.financier("createAnFinancierUser"),

        validators.validationResultChecker,

        sanitizers.platform.financier("createAnFinancierUser"),

        existingDetails.financier,
        
        existingDetails.user,

        finProfileCntrls.createAnFinancierUserCntrl
    );

finProfileRouter
    .route("/financiers/profile/bank-details/:bankDetailsId")
    .get(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.validationChainBuilder(
            "param",
            {
                name: "bankDetailsId",
            },
            "uuid-v4",
            true
        ),

        validators.validationResultChecker,

        finProfileCntrls.getAnFinBankDetailByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.validationChainBuilder(
            "param",
            {
                name: "bankDetailsId",
            },
            "uuid-v4",
            true
        ),

        validators.platform.financier("updateAnFinancierBankDetail"),

        validators.validationResultChecker,

        sanitizers.platform.financier("updateAnFinancierBankDetail"),

        existingDetails.financierBank,

        finProfileCntrls.updateAnFinBankDetailByIdCntrl
    )
    .delete(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.validationChainBuilder(
            "param",
            {
                name: "bankDetailsId",
            },
            "uuid-v4",
            true
        ),

        validators.validationResultChecker,

        finProfileCntrls.deleteAnFinBankDetailByIdCntrl
    );

finProfileRouter
    .route("/financiers/profile/bank-details")
    .get(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.platform.financier("getFinancierBankDetails"),

        validators.validationResultChecker,

        sanitizers.platform.financier("getFinancierBankDetails"),

        finProfileCntrls.getFinBankDetailsByFinIdCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        validators.platform.financier("createAnFinancierBankDetail"),

        validators.validationResultChecker,

        sanitizers.platform.financier("createAnFinancierBankDetail"),

        existingDetails.financierBank,

        finProfileCntrls.createAnFinancierBankDetailCntrl
    );

finProfileRouter
    .route("/financiers/profile")
    .get(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        finProfileCntrls.getFinancierProfileCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            ADMIN: ["FINANCIER"],
            MASTER_MANAGER: ["FINANCIER"],
        }),

        formDataProcessor("updateFinancierProfile"),

        validators.platform.financier("updateFinancierProfile"),

        validators.validationResultChecker,

        sanitizers.platform.financier("updateFinancierProfile"),

        existingDetails.financier,
        
        existingDetails.user,

        finProfileCntrls.updateFinancierProfileCntrl
    );

module.exports = finProfileRouter;
