const entDetailsCntrls = require('../../controllers/buyer-seller/index').entDetails;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const existingDetails = require('../../middlewares/existing-details/index');
const buyerSellerRouter = require("express").Router();

buyerSellerRouter
    .route('/buyer-seller/profile')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        entDetailsCntrls.getAnBuyerSellerProfileCntrl
    );

buyerSellerRouter
    .route('/buyer-seller/:entityId/available-limit')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER'],
            'MAKER': ['FINANCIER'],
            'CHECKER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,

        entDetailsCntrls.getAvlLimitOfAnBuyerSellerByIdCntrl
    );

buyerSellerRouter
    .route('/buyer-seller/:entityId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entDetailsCntrls.getAnBuyerSellerByIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.buyerSeller.entityDetails('updateAnBuyerSeller'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityDetails('updateAnBuyerSeller'),

        existingDetails.buyerSeller,

        existingDetails.user,
        
        entDetailsCntrls.updateAnBuyerSellerByIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entDetailsCntrls.deleteAnBuyerSellerByIdCntrl
    );
    
buyerSellerRouter 
    .route("/buyer-seller")
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.buyerSeller.entityDetails('getAllBuyerSellers'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityDetails('getAllBuyerSellers'),
        
        entDetailsCntrls.getAllBuyerSellersCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.buyerSeller.entityDetails('createAnBuyerSeller'),
        
        validators.validationResultChecker,
        
        sanitizers.buyerSeller.entityDetails('createAnBuyerSeller'),
        
        existingDetails.buyerSeller,
        
        existingDetails.user,
        
        entDetailsCntrls.createAnBuyerSellerCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        entDetailsCntrls.deleteAllBuyerSellersCntrl
    );

module.exports = buyerSellerRouter