const entityDocumentRouter = require('express').Router();
const entDocumentsCntrls = require('../../controllers/buyer-seller/index').entDocuments;
const auth = require('../../middlewares/auth/index');
const formDataProcessor = require('../../middlewares/form-data-processor.middleware');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

entityDocumentRouter
    .route('/buyer-seller/:entityId/documents/:documentId/signed-url')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'documentId'
        }, 'uuid-v4', true),

        validators.buyerSeller.entityDocuments('entityDocSignedURL'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityDocuments('entityDocSignedURL'),
        
        entDocumentsCntrls.getEntityDocSignedURLCntrl
    );

entityDocumentRouter
    .route('/buyer-seller/:entityId/documents/:documentId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'documentId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entDocumentsCntrls.getAnEntityDocUploadByIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),

        formDataProcessor('updateAnEntityDocUpload'),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'documentId'
        }, 'uuid-v4', true),

        validators.buyerSeller.entityDocuments('updateAnEntityDocUpload'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityDocuments('updateAnEntityDocUpload'),
        
        entDocumentsCntrls.updateAnEntityDocUploadByIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'documentId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entDocumentsCntrls.deleteAnEntityDocUploadByIdCntrl
    );

entityDocumentRouter
    .route('/buyer-seller/:entityId/documents')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),

        validators.buyerSeller.entityDocuments('getEntityDocUploads'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityDocuments('getEntityDocUploads'),
        
        entDocumentsCntrls.getEntityDocUploadsByEntityIdCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),

        formDataProcessor('createAnEntityDocUpload'),

        validators.singleFile('document', envConfig.MAX_FILE_SIZE_MB, envConfig.DOC_EXT),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),

        validators.buyerSeller.entityDocuments('createAnEntityDocUpload'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityDocuments('createAnEntityDocUpload'),
        
        entDocumentsCntrls.createAnEntityDocUploadCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entDocumentsCntrls.deleteAllEntityDocUploadsByEntityIdCntrl
    );

module.exports = entityDocumentRouter;