const BSLinkCntrls = require('../../controllers/buyer-seller/index').buyerSellerLink;
const auth = require('../../middlewares/auth/index');
const existingDetails = require("../../middlewares/existing-details");
const sanitizers = require('../../middlewares/sanitizers');
const validators = require('../../middlewares/validators/index');
const BSLinkRouter = require("express").Router();

BSLinkRouter
    .route('/buyer-seller/links/:linkId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'linkId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        BSLinkCntrls.getAnBSLinkByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),

        validators.validationChainBuilder('param', {
            name: 'linkId'
        }, 'uuid-v4', true),

        validators.buyerSeller.buyerSellerLink('updateAnBSLink'),

        validators.validationResultChecker,

        sanitizers.buyerSeller.buyerSellerLink('updateAnBSLink'),

        existingDetails.buyerSellerLink,

        BSLinkCntrls.updateAnBSLinkByIdCntrl
    )
    .delete(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),

        validators.validationChainBuilder
            ('param', {
                name: 'linkId'
            }, 'uuid-v4', true),

        validators.validationResultChecker,

        BSLinkCntrls.deleteAnBSLinkByIdCntrl
    );

BSLinkRouter
    .route('/buyer-seller/links')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.buyerSeller.buyerSellerLink('getAllBSLinks'),

        validators.validationResultChecker,

        sanitizers.buyerSeller.buyerSellerLink('getAllBSLinks'),

        BSLinkCntrls.getAllBSLinksCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),

        validators.buyerSeller.buyerSellerLink('createAnBSLink'),

        validators.validationResultChecker,

        sanitizers.buyerSeller.buyerSellerLink('createAnBSLink'),

        existingDetails.buyerSellerLink,

        BSLinkCntrls.createAnBSLinkCntrl
    )
    .delete(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),

        BSLinkCntrls.deleteAllBSLinksCntrl
    );

module.exports = BSLinkRouter