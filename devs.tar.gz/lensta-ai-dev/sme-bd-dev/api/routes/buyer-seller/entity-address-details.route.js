const entAddressDetailsCntrls = require('../../controllers/buyer-seller/index').entAddressDetails;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const entityAddrDetailsRouter = require("express").Router();

entityAddrDetailsRouter
    .route('/buyer-seller/:entityId/address-details/:addressId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'addressId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entAddressDetailsCntrls.getAnEntAddrDetByIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'addressId'
        }, 'uuid-v4', true),
        
        validators.buyerSeller.entityAddrDetails('updateAnEntAddrDet'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityAddrDetails('updateAnEntAddrDet'),
        
        entAddressDetailsCntrls.updateAnEntAddrDetByIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'addressId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entAddressDetailsCntrls.deleteAnEntAddrDetByIdCntrl
    );

entityAddrDetailsRouter
    .route('/buyer-seller/:entityId/address-details')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),

        validators.buyerSeller.entityAddrDetails('getAllEntAddrDetls'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityAddrDetails('getAllEntAddrDetls'),
        
        entAddressDetailsCntrls.getEntAddrDetByEntityIdCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.buyerSeller.entityAddrDetails('createAnEntAddrDet'),
        
        validators.validationResultChecker,
        
        sanitizers.buyerSeller.entityAddrDetails('createAnEntAddrDet'),
        
        entAddressDetailsCntrls.createAnEntAddrDetCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entAddressDetailsCntrls.deleteEntAddrDetlsByEntityIdCntrl
    );

module.exports = entityAddrDetailsRouter