const entBankDetailsCntrls = require('../../controllers/buyer-seller/index').entBankDetails;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const existingDetails = require('../../middlewares/existing-details/index');
const entityBankDetailsRouter = require("express").Router();

entityBankDetailsRouter
    .route('/buyer-seller/:entityId/bank-details/:bankDetailsId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'bankDetailsId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entBankDetailsCntrls.getAnEntBankDetailByIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'bankDetailsId'
        }, 'uuid-v4', true),
        
        validators.buyerSeller.entityBankDetails('updateAnEntBankDetl'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityBankDetails('updateAnEntBankDetl'),

        existingDetails.buyerSellerBank,
        
        entBankDetailsCntrls.updateAnEntBankDetByIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'bankDetailsId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entBankDetailsCntrls.deleteAnEntBankDetByIdCntrl
    );

entityBankDetailsRouter
    .route('/buyer-seller/:entityId/bank-details')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),

        validators.buyerSeller.entityBankDetails('getAllEntBankDetls'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityBankDetails('getAllEntBankDetls'),
        
        entBankDetailsCntrls.getEntBankDetlsByEntityIdCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.buyerSeller.entityBankDetails('createAnEntBankDetl'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityBankDetails('createAnEntBankDetl'),
        
        existingDetails.buyerSellerBank,

        entBankDetailsCntrls.createAnEntBankDetCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entBankDetailsCntrls.deleteEntBankDetlsByEntityIdCntrl
    );

module.exports = entityBankDetailsRouter