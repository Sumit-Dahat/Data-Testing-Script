const entPromoterDetailsCntrls = require('../../controllers/buyer-seller/index').entPromoterDetails;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const existingDetails = require('../../middlewares/existing-details/index');
const entityPromoterDetailsRouter = require("express").Router();

entityPromoterDetailsRouter
    .route('/buyer-seller/:entityId/promoter-details/:promoterDetailsId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'promoterDetailsId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entPromoterDetailsCntrls.getAnEntPromtDetlByIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'promoterDetailsId'
        }, 'uuid-v4', true),
        
        validators.buyerSeller.entityPromoterDetails('updateAnEntPromtDetl'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityPromoterDetails('updateAnEntPromtDetl'),
        
        existingDetails.buyerSellerPromoter,

        entPromoterDetailsCntrls.updateAnEntPromtDetlByIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationChainBuilder('param', {
            name: 'promoterDetailsId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entPromoterDetailsCntrls.deleteAnEntPromtDetlByIdCntrl
    );

entityPromoterDetailsRouter
    .route('/buyer-seller/:entityId/promoter-details')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),

        validators.buyerSeller.entityPromoterDetails('getAllEntPromtDetls'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityPromoterDetails('getAllEntPromtDetls'),
        
        entPromoterDetailsCntrls.getEntPromtDetlsByEntityIdCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.buyerSeller.entityPromoterDetails('createAnEntPromtDetl'),
        
        validators.validationResultChecker,

        sanitizers.buyerSeller.entityPromoterDetails('createAnEntPromtDetl'),
        
        existingDetails.buyerSellerPromoter,

        entPromoterDetailsCntrls.createAnEntPromtDetlCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MASTER_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'entityId'
        }, 'uuid-v4', true),
        
        validators.validationResultChecker,
        
        entPromoterDetailsCntrls.deleteEntPromtDetlsByEntityIdCntrl
    );

module.exports = entityPromoterDetailsRouter