const factoringUnitCntrls = require('../../controllers/financier/index').factoringUnit;
const auth = require('../../middlewares/auth/index');
const formDataProcessor = require('../../middlewares/form-data-processor.middleware')
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const factoringUnitRouter = require("express").Router();

factoringUnitRouter
    .route('/factoring-units/:factoringUnitNo/disburse-amount')
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER'],
            'MAKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),

        validators.financier.factoringUnit('disburseAmt'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('disburseAmt'),

        factoringUnitCntrls.disburseAmtCntrl
    );

factoringUnitRouter
    .route('/factoring-units/:factoringUnitNo/validate-roi')
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'MAKER': ['FINANCIER'],
            'CHECKER': ['FINANCIER']
        }),

        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),

        validators.financier.factoringUnit('validateROI'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('validateROI'),

        factoringUnitCntrls.validateROICntrl
    );

factoringUnitRouter
    .route('/factoring-units/:factoringUnitNo/send-for-finance')
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),

        validators.financier.factoringUnit('sendForFinance'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('sendForFinance'),

        factoringUnitCntrls.sendFUForFinanceCntrl
    );

factoringUnitRouter
    .route('/factoring-units/combine')
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),
        
        validators.financier.factoringUnit('combineTwoFU'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('combineTwoFU'),
        
        factoringUnitCntrls.combineTwoFUsCntrl
    );

factoringUnitRouter
    .route('/factoring-units/:factoringUnitNo')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationResultChecker,
        
        factoringUnitCntrls.getAnFUByFUNoCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER', 'FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.financier.factoringUnit('updateAnFactoringUnit'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('updateAnFactoringUnit'),
        
        factoringUnitCntrls.updateAnFUByFUNoCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationResultChecker,
        
        factoringUnitCntrls.deleteAnFUByFUNoCntrl
    );

factoringUnitRouter
    .route('/factoring-units-using-file')
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER']
        }),
        
        formDataProcessor('createAnFUFromFile'),

        validators.financier.factoringUnit('createAnFUFromFile'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('createAnFUFromFile'),
        
        factoringUnitCntrls.createAnFUFromFileCntrl
    );

factoringUnitRouter
    .route('/factoring-units')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER', 'FINANCIER'],
            'CHECKER': ['BUYER', 'SELLER', 'FINANCIER']
        }),
        
        validators.financier.factoringUnit('getAllFactoringUnits'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('getAllFactoringUnits'),
        
        factoringUnitCntrls.getAllFactoringUnitsCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER']
        }),

        validators.financier.factoringUnit('createAnFUFromJSON'),
        
        validators.validationResultChecker,

        sanitizers.financier.factoringUnit('createAnFUFromJSON'),
        
        factoringUnitCntrls.createAnFUFromJSONCntrl
    );

module.exports = factoringUnitRouter