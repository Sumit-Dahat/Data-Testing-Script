const FUTxnCntrls = require('../../controllers/financier/index').FUTxn;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

const FUTxnRouter = require("express").Router();

FUTxnRouter
    .route('/factoring-units/:factoringUnitNo/transactions/:transactionId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationChainBuilder('param', {
            name: 'transactionId'
        }, 'alphaNumericString', true),
        
        validators.validationResultChecker,
        
        FUTxnCntrls.getAnFUTxnByTxnIdCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationChainBuilder('param', {
            name: 'transactionId'
        }, 'alphaNumericString', true),
        
        validators.financier.FUTxn('updateAnFUTransaction'),
        
        validators.validationResultChecker,

        sanitizers.financier.FUTxn('updateAnFUTransaction'),
        
        FUTxnCntrls.updateAnFUTxnByTxnIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationChainBuilder('param', {
            name: 'transactionId'
        }, 'alphaNumericString', true),
        
        validators.validationResultChecker,
        
        FUTxnCntrls.deleteAnFUTxnByTxnIdCntrl
    );

FUTxnRouter    
    .route('/factoring-units/:factoringUnitNo/transactions')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.financier.FUTxn('getAllFUTxns'),
        
        validators.validationResultChecker,

        sanitizers.financier.FUTxn('getAllFUTxns'),
        
        FUTxnCntrls.getFUTxnsByFUNoCntrl
    )
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER','BUYER', 'SELLER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),

        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.financier.FUTxn('createAnFUTxn'),
        
        validators.validationResultChecker,

        sanitizers.financier.FUTxn('createAnFUTxn'),
        
        FUTxnCntrls.createAnFUTxnCntrl
    );

module.exports = FUTxnRouter;