const invoiceCntrls = require('../../controllers/financier/index').invoice;
const auth = require('../../middlewares/auth/index');
const formDataProcessor = require('../../middlewares/form-data-processor.middleware');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');
const invoiceRouter = require("express").Router();

invoiceRouter
    .route('/invoices/:invoiceId/documents/:documentId/signed-url')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.validationChainBuilder('param', {
            name: 'documentId'
        }, 'uuid-v4', true),

        validators.financier.invoice('invoiceDocSignedURL'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('invoiceDocSignedURL'),

        invoiceCntrls.getInvDocSignedURLCntrl
    );

invoiceRouter
    .route('/invoices/:invoiceId/documents/:documentId')
    .delete(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.validationChainBuilder('param', {
            name: 'documentId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        invoiceCntrls.deleteAnInvoiceDocumentByIdCntrl
    );

invoiceRouter
    .route('/invoices/:invoiceId/documents')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.financier.invoice('getAllInvoiceDocuments'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('getAllInvoiceDocuments'),

        invoiceCntrls.getAllInvoiceDocumentsCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER']
        }),

        formDataProcessor('addDocumentForInvoice'),

        validators.singleFile('document', envConfig.MAX_FILE_SIZE_MB, envConfig.DOC_EXT),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.financier.invoice('addDocumentForInvoice'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('addDocumentForInvoice'),

        invoiceCntrls.addDocumentForInvoiceCntrl
    );

invoiceRouter
    .route('/invoices/:invoiceId/approve-or-reject')
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.financier.invoice('approveOrRejectAnInvoice'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('approveOrRejectAnInvoice'),

        invoiceCntrls.approveOrRejectAnInvoiceCntrl
    );

invoiceRouter
    .route('/invoices/:invoiceId')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        invoiceCntrls.getAnInvoiceByIdCntrl
    )
    .put(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER'],
            'MAKER': ['BUYER', 'SELLER'],
        }),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.financier.invoice('updateAnInvoice'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('updateAnInvoice'),

        invoiceCntrls.updateAnInvoiceByIdCntrl
    )
    .delete(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER'],
            'MAKER': ['BUYER', 'SELLER']
        }),

        validators.validationChainBuilder('param', {
            name: 'invoiceId'
        }, 'uuid-v4', true),

        validators.validationResultChecker,

        invoiceCntrls.deleteAnInvoiceByIdCntrl
    );

invoiceRouter
    .route('/invoices-using-file')
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['SELLER'],
            'MAKER': ['SELLER']
        }),

        formDataProcessor('createAnInvFromFile'),
        
        validators.financier.invoice('createAnInvFromFile'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('createAnInvFromFile'),

        invoiceCntrls.createAnInvFromFileCntrl
    );

invoiceRouter
    .route('/invoices')
    .get(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),

        validators.financier.invoice('getAllInvoices'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('getAllInvoices'),

        invoiceCntrls.getAllInvoicesCntrl
    )
    .post(
        auth.validateLogin,

        validators.routeAccess({
            'ADMIN': ['SELLER'],
            'MAKER': ['SELLER']
        }),
        
        validators.financier.invoice('createAnInvFromJSON'),

        validators.validationResultChecker,

        sanitizers.financier.invoice('createAnInvFromJSON'),

        invoiceCntrls.createAnInvFromJSONCntrl
    );

module.exports = invoiceRouter