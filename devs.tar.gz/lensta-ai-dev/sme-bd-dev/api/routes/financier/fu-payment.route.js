const FUPymtCntrls = require('../../controllers/financier/index').FUPymt;
const auth = require('../../middlewares/auth/index');
const validators = require('../../middlewares/validators/index');
const sanitizers = require('../../middlewares/sanitizers/index');

const FUPymtRouter = require("express").Router();

FUPymtRouter
    .route('/factoring-units/:factoringUnitNo/payments/:paymentId')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationChainBuilder('param', {
            name: 'paymentId'
        }, 'alphaNumericString', true),
        
        validators.validationResultChecker,
        
        FUPymtCntrls.getFUPymtByFUNoCntrl
    )
    .put(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationChainBuilder('param', {
            name: 'paymentId'
        }, 'alphaNumericString', true),
        
        validators.financier.FUPymt('updateAnFUTransaction'),
        
        validators.validationResultChecker,

        sanitizers.financier.FUPymt('updateAnFUTransaction'),
        
        FUPymtCntrls.updateAnFUPymtByPymtIdCntrl
    )
    .delete(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.validationChainBuilder('param', {
            name: 'paymentId'
        }, 'alphaNumericString', true),
        
        validators.validationResultChecker,
        
        FUPymtCntrls.deleteAnFUPymtByPymtIdCntrl
    );

FUPymtRouter   
    .route('/factoring-units/:factoringUnitNo/payments')
    .get(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['BUYER', 'SELLER', 'FINANCIER'],
            'OPERATION_MANAGER': ['FINANCIER'],
            'MAKER': ['BUYER', 'SELLER'],
            'CHECKER': ['BUYER', 'SELLER']
        }),
        
        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.financier.FUPymt('getAllFUPymts'),
        
        validators.validationResultChecker,

        sanitizers.financier.FUPymt('getAllFUPymts'),
        
        FUPymtCntrls.getFUPymtByFUNoCntrl
    ) 
    .post(
        auth.validateLogin,
        
        validators.routeAccess({
            'ADMIN': ['FINANCIER','BUYER', 'SELLER'],
            'OPERATION_MANAGER': ['FINANCIER']
        }),

        validators.validationChainBuilder('param', {
            name: 'factoringUnitNo'
        }, 'alphaNumericString', true),
        
        validators.financier.FUPymt('createAnFUPymt'),
        
        validators.validationResultChecker,

        sanitizers.financier.FUPymt('createAnFUPymt'),
        
        FUPymtCntrls.createAnFUPymtCntrl
    );

module.exports = FUPymtRouter;