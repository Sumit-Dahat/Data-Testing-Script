const userHelpers = require('../../../api/helpers/platform').user;
const { APIError } = require('../../../api/error');
let userTxn;

module.exports = describe('User', () => {
    describe('Create', () => {
        beforeEach(async () => {
            userTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await userTxn.rollback();
        });

        it('For valid input: Should create an user', async () => {
            const user = await userHelpers.createAnUser({
                firstName: 'Demo',
                lastName: 'User',
                mobileNo: '+918712096512',
                emailId: 'demo.user@gmail.com',
                active: 1,
                userType: 'MAKER',
                entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
                password: 'demouser123'
            }, {
                transaction: userTxn
            });

            expect(user.error).toBe(null);
            expect(user.data.firstName).toBe('Demo');
            expect(user.data.entityId).toBe('69ac82c2-5b17-4b11-8fbc-0e37de3325d3');
        });

        it('For invalid input: Should return an Error object', async () => {
            const user = await userHelpers.createAnUser({
                firstName: 'Demo',
                lastName: 'Checker'
            }, {
                transaction: userTxn
            });

            expect(user.data).toBe(null);
            expect(user.error instanceof APIError).toBe(true);
            expect(user.error.code).toBe('0028');
            expect(user.error.status).toBe(400);
        });
    });

    describe('Get One', () => {
        beforeEach(async () => {
            userTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await userTxn.rollback();
        });

        it('For valid input: Should return the correct user', async () => {
            const user = await userHelpers.getAnUser({
                where: {
                    firstName: 'John',
                    lastName: 'Doe'
                },
                transaction: userTxn
            });

            expect(user.error).toBe(null);
            expect(user.data.firstName).toBe('John');
            expect(user.data.lastName).toBe('Doe');
        });

        it('For invalid input: Should return an Error object', async () => {
            const user = await userHelpers.getAnUser({
                where: {
                    where: {}
                },
                transaction: userTxn
            });

            expect(user.data).toBe(null);
            expect(user.error instanceof APIError).toBe(true);
            expect(user.error.code).toBe('0038');
            expect(user.error.status).toBe(400);
        });
    });

    describe('Get by ID', () => {
        beforeEach(async () => {
            userTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await userTxn.rollback();
        });

        it('For valid input: Should return the correct user', async () => {
            const user = await userHelpers.getAnUserById('2994aba6-73de-4e53-a201-4f34cb7bf074', {
                transaction: userTxn
            });

            expect(user.error).toBe(null);
            expect(user.data.firstName).toBe('Platform');
            expect(user.data.userType).toBe('ADMIN');
            expect(user.data.entityId).toBe(null);
        });

        it('For invalid input: Should return an Error object', async () => {
            const user = await userHelpers.getAnUserById({
                where: '2994aba6-73de-4e53-a201-4f34cb7bf074'
            }, {
                transaction: userTxn
            });

            expect(user.data).toBe(null);
            expect(user.error instanceof APIError).toBe(true);
            expect(user.error.code).toBe('0038');
            expect(user.error.status).toBe(404);
        });
    });

    describe('Get All', () => {
        beforeEach(async () => {
            userTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await userTxn.rollback();
        });

        it('For valid input: Should return all users', async () => {
            const users = await userHelpers.getAllUsers({
                where: {},
                transaction: userTxn
            });

            expect(users.error).toBe(null);
            expect(users.data.length).toBe(17);
        });

        it('For invalid input: Should return an Error object', async () => {
            const users = await userHelpers.getAllUsers({
                where: {
                    where: {}
                },
                transaction: userTxn
            });

            expect(users.data).toBe(null);
            expect(users.error instanceof APIError).toBe(true);
            expect(users.error.code).toBe('0038');
            expect(users.error.status).toBe(400);
        });
    });

    describe('Update by ID', () => {
        beforeEach(async () => {
            userTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await userTxn.rollback();
        });

        it('For valid input: Should return the updated user', async () => {
            const updatedUser = await userHelpers.updateAnUserById('0189319c-4bd0-44b5-86f8-51b8220d38e8', {
                firstName: 'MLK',
                lastName: 'Administrator'
            }, {
                transaction: userTxn
            });

            expect(updatedUser.error).toBe(null);
            expect(updatedUser.data.firstName).toBe('MLK');
            expect(updatedUser.data.lastName).toBe('Administrator');
        });

        it('For invalid input: Should return an Error object', async () => {
            const updatedUser = await userHelpers.updateAnUserById({
                id: 'c2caee39-6756-4060-b0c6-51241d03850d'
            }, {
                firstName: 'Fin'
            }, {
                transaction: userTxn
            });

            expect(updatedUser.data).toBe(null);
            expect(updatedUser.error.code).toBe('0039');
            expect(updatedUser.error.status).toBe(400);
        });
    });

    describe('Delete All', () => {
        beforeEach(async () => {
            userTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await userTxn.rollback();
        });

        it('For valid input: Should return the number of deleted user(s)', async () => {
            const deletedUsers = await userHelpers.deleteAllUsers({
                where: {
                    userType: 'MAKER'
                },
                transaction: userTxn
            });

            expect(deletedUsers.error).toBe(null);
            expect(deletedUsers.data).toBe(3);
        });

        it('For invalid input: Should return an Error object', async () => {
            const deletedUsers = await userHelpers.deleteAllUsers({
                ...{},
                transaction: userTxn
            });

            expect(deletedUsers.data).toBe(null);
            expect(deletedUsers.error instanceof APIError).toBe(true);
            expect(deletedUsers.error.code).toBe('0040');
            expect(deletedUsers.error.status).toBe(400);
        });
    });
});