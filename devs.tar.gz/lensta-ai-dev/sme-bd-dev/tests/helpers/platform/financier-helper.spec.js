const financierHelpers = require('../../../api/helpers/platform').financier;
const { APIError } = require('../../../api/error');
let financierTxn;

module.exports = describe('Financier', () => {
    describe('Create an Financier', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return the created Financier', async () => {
            const financier = await financierHelpers.createAnFinancier({
                entityCategory: 'FINANCIER',
                entityName: 'JPMC Bank',
                registrationNo: '7612091278',
                pan: 'HUGIT6154T',
                dateOfIncorporation: '1990-01-01',
                approved: 1,
                active: 1,
                themeHexcode: '0E353D'
            }, {
                transaction: financierTxn
            });

            expect(financier.error).toBe(null);
            expect(financier.data.entityName).toBe('JPMC Bank');
            expect(financier.data.registrationNo).toBe('7612091278');
        });

        it('For invalid input: Should return an Error object', async () => {
            const financier = await financierHelpers.createAnFinancier({
                registrationNo: '761298120913',
                pan: 'HUGIT6154U',
                approved: 1,
                active: 1,
                themeHexcode: '0E353D',
                finLogoDocId: null,
                createdByFinancierId: null
            }, {
                transaction: financierTxn
            });

            expect(financier.data).toBe(null);
            expect(financier.error instanceof APIError).toBe(true);
            expect(financier.error.code).toBe('0041');
            expect(financier.error.status).toBe(400);
        });
    });

    describe('Create an Financier Approval', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return the created Financier Approval', async () => {
            const financier = await financierHelpers.createAnFinancier({
                entityCategory: 'FINANCIER',
                entityName: 'KPMG Bank',
                registrationNo: '671209126712',
                pan: 'HUROY6156T',
                dateOfIncorporation: '1990-01-01',
                approved: 1,
                active: 1,
                themeHexcode: '0E353D',
                finLogoDocId: null,
                createdByFinancierId: null
            }, {
                transaction: financierTxn
            });

            const finApproval = await financierHelpers.createAnFinancierApproval({
                dateOfExpiry: new Date(),
                approvalType: 'TRIAL',
                financierId: financier.data.id
            }, {
                transaction: financierTxn
            });

            expect(finApproval.error).toBe(null);
            expect(finApproval.data.approvalType).toBe('TRIAL');
            expect(finApproval.data.financierId).toBe(financier.data.id);
        });

        it('For invalid input: Should return an Error object', async () => {
            const finApproval = await financierHelpers.createAnFinancierApproval({
                dateOfExpiry: new Date()
            }, {
                transaction: financierTxn
            });

            expect(finApproval.data).toBe(null);
            expect(finApproval.error.code).toBe('0005');
            expect(finApproval.error.status).toBe(400);
        });
    });

    describe('Get an Financier by ID', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return the correct Financier', async () => {
            const financier = await financierHelpers.getAnFinancierById('fd0b23fc-5920-49df-82fd-500e06a1eda1', {
                transaction: financierTxn
            });

            expect(financier.error).toBe(null);
            expect(financier.data.id).toBe('fd0b23fc-5920-49df-82fd-500e06a1eda1');
            expect(financier.data.entityName).toBe('Union Bank of India');
        });

        it('For invalid input: Should return an Error object', async () => {
            const financier = await financierHelpers.getAnFinancierById({
                id: 'fd0b23fc-5920-49df-82fd-500e06a1eda1'
            }, {
                transaction: financierTxn
            });

            expect(financier.data).toBe(null);
            expect(financier.error instanceof APIError).toBe(true);
            expect(financier.error.code).toBe('0044');
            expect(financier.error.status).toBe(404);
        });
    });

    describe('Get All Financiers', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return all Financiers', async () => {
            const financiers = await financierHelpers.getAllFinanciers({
                where: {
                    entityCategory: 'FINANCIER'
                },
                transaction: financierTxn
            });

            expect(financiers.error).toBe(null);
            expect(financiers.data.length).toBe(2);
        });

        it('For invalid input: Should return an Error object', async () => {
            const financiers = await financierHelpers.getAllFinanciers({
                where: {
                    where: {}
                },
                transaction: financierTxn
            });

            expect(financiers.data).toBe(null);
            expect(financiers.error instanceof APIError).toBe(true);
            expect(financiers.error.code).toBe('0044');
            expect(financiers.error.status).toBe(404);
        });
    });

    describe('Get Financier Approval by Financier ID', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return the correct Financier Approval', async () => {
            const finApproval = await financierHelpers.getFinApprovalByFinancierId('fd0b23fc-5920-49df-82fd-500e06a1eda1', {
                transaction: financierTxn
            });

            expect(finApproval.error).toBe(null);
            expect(finApproval.data.financierId).toBe('fd0b23fc-5920-49df-82fd-500e06a1eda1');
            expect(finApproval.data.approvalType).toBe('PERMANENT');
        });

        it('For invalid input: Should return an Error object', async () => {
            const finApproval = await financierHelpers.getFinApprovalByFinancierId({
                id: 'fd0b23fc-5920-49df-82fd-500e06a1eda1'
            }, {
                transaction: financierTxn
            });

            expect(finApproval.data).toBe(null);
            expect(finApproval.error instanceof APIError).toBe(true);
            expect(finApproval.error.code).toBe('0008');
            expect(finApproval.error.status).toBe(404);
        });
    });

    describe('Update an Financier by ID', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return the updated Financier', async () => {
            const updatedFin = await financierHelpers.updateAnFinancierById('fd0b23fc-5920-49df-82fd-500e06a1eda1', {
                entityName: 'JPMC Bank'
            }, {
                transaction: financierTxn
            });

            expect(updatedFin.error).toBe(null);
            expect(updatedFin.data.id).toBe('fd0b23fc-5920-49df-82fd-500e06a1eda1');
            expect(updatedFin.data.entityName).toBe('JPMC Bank');
        });

        it('For invalid input: Should return an Error object', async () => {
            const updatedFin = await financierHelpers.updateAnFinancierById({
                id: 'fd0b23fc-5920-49df-82fd-500e06a1eda1'
            }, {
                entityName: 'JPMC Bank'
            }, {
                transaction: financierTxn
            });

            expect(updatedFin.data).toBe(null);
            expect(updatedFin.error instanceof APIError).toBe(true);
            expect(updatedFin.error.code).toBe('0042');
            expect(updatedFin.error.status).toBe(400);
        });
    });

    describe('Update an Financier Approval by Financier ID', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return the updated Financier Approval', async () => {
            const updatedFinApprvl = await financierHelpers.updateAnFinApprovalByFinancierId('fd0b23fc-5920-49df-82fd-500e06a1eda1', {
                approvalType: 'TRIAL'
            }, {
                transaction: financierTxn
            });

            expect(updatedFinApprvl.error).toBe(null);
            expect(updatedFinApprvl.data.financierId).toBe('fd0b23fc-5920-49df-82fd-500e06a1eda1');
            expect(updatedFinApprvl.data.approvalType).toBe('TRIAL');
        });

        it('For invalid input: Should return an Error object', async () => {
            const updatedFinApprvl = await financierHelpers.updateAnFinApprovalByFinancierId({
                financierId: 'fd0b23fc-5920-49df-82fd-500e06a1eda1'
            }, {
                approvalType: 'TRIAL'
            }, {
                transaction: financierTxn
            });

            expect(updatedFinApprvl.data).toBe(null);
            expect(updatedFinApprvl.error instanceof APIError).toBe(true);
            expect(updatedFinApprvl.error.code).toBe('0014');
            expect(updatedFinApprvl.error.status).toBe(400);
        });
    });

    describe('Delete All Financiers', () => {
        beforeEach(async () => {
            financierTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await financierTxn.rollback();
        });

        it('For valid input: Should return the number of deleted Financier(s)', async () => {
            const deletedFin = await financierHelpers.deleteAllFinanciers({
                where: {
                    entityCategory: 'FINANCIER'
                },
                transaction: financierTxn
            });

            expect(deletedFin.error).toBe(null);
            expect(deletedFin.data).toBe(2);
        });

        it('For invalid input: Should return an Error object', async () => {
            const deletedFin = await financierHelpers.deleteAllFinanciers({
                ...{},
                transaction: financierTxn
            });

            expect(deletedFin.data).toBe(null);
            expect(deletedFin.error instanceof APIError).toBe(true);
            expect(deletedFin.error.code).toBe('0043');
            expect(deletedFin.error.status).toBe(400);
        });
    });
});