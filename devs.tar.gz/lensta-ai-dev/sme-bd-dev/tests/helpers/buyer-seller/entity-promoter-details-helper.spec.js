const entPromoterDetHelpers = require('../../../api/helpers/buyer-seller').entPromoterDetails;
const { APIError } = require('../../../api/error');
let entPromoterDetTxn;

module.exports = describe('Entity Promoter Detail', () => {
    describe('Create', () => {
        beforeEach(async () => {
            entPromoterDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entPromoterDetTxn.rollback();
        });

        it('For valid input: Should return an created data object', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.createAnEntPromtDetl({
                entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
                promoterType: 'INDIVIDUAL',
                nameOrEntityName: 'Buyer Promoter',
                gender: 'MALE',
                dobOrDoi: new Date(),
                aadhaarOrRegNo: '9876120988790',
                dinOrCinNo: '871267127865',
                pan: 'BASIU7786Y',
                sharePercentage: 30.0,
                emailId: 'buyer.promoter@gmail.com',
                contactNo: '+917809120765',
                addressLineOne: '8th block, Main Road',
                addressLineTwo: 'Near Post Office',
                pinCode: '651210',
                state: 'Karnataka',
                district: 'Bengaluru',
                subDistrict: 'Bengaluru Urban',
                postOffice: 'Bengaluru'
            }, {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.error).toBe(null);
            expect(entPromoterDetail.data.nameOrEntityName).toBe('Buyer Promoter');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.createAnEntPromtDetl({
                nameOrEntityName: 'Direct Promoter',
                gender: 'MALE',
                dobOrDoi: new Date(),
                aadhaarOrRegNo: '9876120987128',
                dinOrCinNo: '871267128714',
                pan: 'BASIU7612K',
                sharePercentage: 10.0,
                emailId: 'direct.promoter@gmail.com',
                contactNo: '+917809120936',
                addressLineOne: '9th block, Main Road',
                addressLineTwo: 'Behind Post Office',
                pinCode: '651211',
                state: 'Karnataka',
                district: 'Bengaluru',
                subDistrict: 'Bengaluru Urban',
                postOffice: 'Bengaluru'
            }, {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.data).toBe(null);
            expect(entPromoterDetail.error instanceof APIError).toBe(true);
            expect(entPromoterDetail.error.status).toBe(400);
            expect(entPromoterDetail.error.code).toBe('0053');
        });
    });

    describe('Get by ID', () => {
        beforeEach(async () => {
            entPromoterDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entPromoterDetTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.getAnEntPromtDetlById('cd3983e4-680a-4ee2-b478-b71fd68f8055', {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.error).toBe(null);
            expect(entPromoterDetail.data.id).toBe('cd3983e4-680a-4ee2-b478-b71fd68f8055');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.getAnEntPromtDetlById({
                id: 'cd3983e4-680a-4ee2-b478-b71fd68f8055'
            }, {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.data).toBe(null);
            expect(entPromoterDetail.error instanceof APIError).toBe(true);
            expect(entPromoterDetail.error.status).toBe(404);
            expect(entPromoterDetail.error.code).toBe('0056');
        });
    });

    describe('Get All', () => {
        beforeEach(async () => {
            entPromoterDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entPromoterDetTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entPromoterDetails = await entPromoterDetHelpers.getAllEntPromtDetls({
                where: {
                    entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3'
                },
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetails.error).toBe(null);
            expect(entPromoterDetails.data.length).toBe(1);
        });

        it('For invalid input: Should return all data objects', async () => {
            const entPromoterDetails = await entPromoterDetHelpers.getAllEntPromtDetls({
                ...{},
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetails.data.length).toBeGreaterThan(0);
        });
    });

    describe('Update by ID', () => {
        beforeEach(async () => {
            entPromoterDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entPromoterDetTxn.rollback();
        });

        it('For valid input: Should return the updated object', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.updateAnEntPromtDetlById('cd3983e4-680a-4ee2-b478-b71fd68f8055', {
                pinCode: '500101'
            }, {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.error).toBe(null);
            expect(entPromoterDetail.data.pinCode).toBe('500101');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.updateAnEntPromtDetlById(undefined, {
                pinCode: '500101'
            }, {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.data).toBe(null);
            expect(entPromoterDetail.error instanceof APIError).toBe(true);
            expect(entPromoterDetail.error.status).toBe(400);
            expect(entPromoterDetail.error.code).toBe('0054');
        });
    });

    describe('Delete by ID', () => {
        beforeEach(async () => {
            entPromoterDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entPromoterDetTxn.rollback();
        });

        it('For valid input: Should return 1', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.deleteAnEntPromtDetlById('cd3983e4-680a-4ee2-b478-b71fd68f8055', {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.error).toBe(null);
            expect(entPromoterDetail.data).toBe(1);
        });

        it('For invalid input: Should return an Error object', async () => {
            const entPromoterDetail = await entPromoterDetHelpers.deleteAnEntPromtDetlById({
                id: null
            }, {
                transaction: entPromoterDetTxn
            });

            expect(entPromoterDetail.data).toBe(null);
            expect(entPromoterDetail.error instanceof APIError).toBe(true);
            expect(entPromoterDetail.error.status).toBe(400);
            expect(entPromoterDetail.error.code).toBe('0055');
        });
    });

    describe('Delete by Entity ID', () => {
        beforeEach(async () => {
            entPromoterDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entPromoterDetTxn.rollback();
        });

        it('For valid input: Should return the number of deleted objects', async () => {
            const deletedEntPromtDetls = await entPromoterDetHelpers.deleteEntPromtDetlsByEntityId('69ac82c2-5b17-4b11-8fbc-0e37de3325d3', {
                transaction: entPromoterDetTxn
            });

            expect(deletedEntPromtDetls.error).toBe(null);
            expect(deletedEntPromtDetls.data).toBe(1);
        });

        it('For invalid input: Should return an Error object', async () => {
            const deletedEntPromtDetls = await entPromoterDetHelpers.deleteEntPromtDetlsByEntityId({
                id: null
            }, {
                transaction: entPromoterDetTxn
            });

            expect(deletedEntPromtDetls.data).toBe(null);
            expect(deletedEntPromtDetls.error instanceof APIError).toBe(true);
            expect(deletedEntPromtDetls.error.status).toBe(400);
            expect(deletedEntPromtDetls.error.code).toBe('0055');
        });
    });
});