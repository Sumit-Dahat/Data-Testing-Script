const entDetailsHelpers = require('../../../api/helpers/buyer-seller').entDetails;
const { APIError } = require('../../../api/error');
let entDetailsTxn;

module.exports = describe('Buyer-Seller', () => {
    describe('Create', () => {
        beforeEach(async () => {
            entDetailsTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entDetailsTxn.rollback();
        });

        it('For valid input: Should return an created data object', async () => {
            const entityDetail = await entDetailsHelpers.createAnBuyerSeller({
                entityCategory: 'BUYER',
                entityTypeId: 'efd03308-bc31-4edc-854e-c67c13f138ae',
                entityName: 'Mock Buyer 1',
                registrationNo: '7612981298',
                pan: 'YTREF8712U',
                udyamRegNo: 'UDYAM-MH-35-7812091',
                dateOfIncorporation: new Date(),
                startOfOperation: new Date(),
                businessSectorId: '30549e73-952a-496d-9b4e-9f11263a7bd3',
                industrySectorId: 'fb1baa74-6f8d-4337-8cb5-69a5592444ed',
                industrySubSectorId: '4f11f72b-8c38-45bb-917e-bef9fd3c18ac',
                salesInLastFy: 20000.0,
                profitInLastFy: 2000.0,
                sanctionedLimit: 200000.0,
                contactNo: '+917812091265',
                emailId: 'mock.buyer1@gmail.com',
                approved: 1,
                active: 1,
                createdByFinancierId: 'de918065-9638-486c-b867-babf264a3dc6'
            }, {
                transaction: entDetailsTxn
            });

            expect(entityDetail.error).toBe(null);
            expect(entityDetail.data.entityCategory).toBe('BUYER');
            expect(entityDetail.data.entityName).toBe('Mock Buyer 1');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entityDetail = await entDetailsHelpers.createAnBuyerSeller({
                entity: 'BUYER'
            }, {
                transaction: entDetailsTxn
            });

            expect(entityDetail.data).toBe(null);
            expect(entityDetail.error instanceof APIError).toBe(true);
            expect(entityDetail.error.status).toBe(400);
            expect(entityDetail.error.code).toBe('0032');
        });
    });

    describe('Get One', () => {
        beforeEach(async () => {
            entDetailsTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entDetailsTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entityDetail = await entDetailsHelpers.getAnBuyerSeller({
                where: {
                    entityCategory: 'BUYER',
                    entityName: 'Larsen & Toubro Limited'
                },
                transaction: entDetailsTxn
            });

            expect(entityDetail.error).toBe(null);
            expect(entityDetail.data.entityCategory).toBe('BUYER');
            expect(entityDetail.data.entityName).toBe('Larsen & Toubro Limited');
        });

        it('For invalid input: Should return null', async () => {
            const entityDetail = await entDetailsHelpers.getAnBuyerSeller({
                where: {
                    active: 2
                },
                transaction: entDetailsTxn
            });

            expect(entityDetail.data).toBe(null);
        });
    });

    describe('Get by ID', () => {
        beforeEach(async () => {
            entDetailsTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entDetailsTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entityDetail = await entDetailsHelpers.getAnBuyerSellerById('a4d79856-a596-4d1b-9c2c-304efb1b4c75', {
                transaction: entDetailsTxn
            });

            expect(entityDetail.error).toBe(null);
            expect(entityDetail.data.id).toBe('a4d79856-a596-4d1b-9c2c-304efb1b4c75');
            expect(entityDetail.data.entityName).toBe('JSW Steel Limited');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entityDetail = await entDetailsHelpers.getAnBuyerSellerById({
                id: null
            }, {
                transaction: entDetailsTxn
            });

            expect(entityDetail.data).toBe(null);
            expect(entityDetail.error instanceof APIError).toBe(true);
            expect(entityDetail.error.status).toBe(404);
            expect(entityDetail.error.code).toBe('0035');
        });
    });

    describe('Get Available Limit by Entity ID', () => {
        beforeEach(async () => {
            entDetailsTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entDetailsTxn.rollback();
        });

        it('For valid input: Should return the correct available limit of an Entity', async () => {
            const availableLimit = await entDetailsHelpers.getAvlLimitOfAnEntityById('69ac82c2-5b17-4b11-8fbc-0e37de3325d3');

            expect(availableLimit.error).toBe(null);
            expect(availableLimit.data).toBe(200000.00);
        });

        it('For invalid input: Should return an Error object', async () => {
            const avlLimit = await entDetailsHelpers.getAvlLimitOfAnEntityById({
                entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3'
            });

            expect(avlLimit.data).toBe(null);
            expect(avlLimit.error instanceof APIError).toBe(true);
            expect(avlLimit.error.status).toBe(400);
            expect(avlLimit.error.code).toBe('0018');
        });
    });

    describe('Get All', () => {
        beforeEach(async () => {
            entDetailsTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entDetailsTxn.rollback();
        });

        it('For valid input: Should return the correct data object(s)', async () => {
            const entityDetails = await entDetailsHelpers.getAllBuyerSellers({
                where: {
                    entityCategory: {
                        [db.Sequelize.Op.in]: ['BUYER', 'SELLER']
                    }
                },
                transaction: entDetailsTxn
            });

            expect(entityDetails.error).toBe(null);
            expect(entityDetails.data.length).toBe(4);
            expect(entityDetails.data.filter((ent) => (ent.entityCategory == 'BUYER')).length).toBe(2);
            expect(entityDetails.data.filter((ent) => (ent.entityCategory == 'SELLER')).length).toBe(2);
        });

        it('For invalid input: Should return all data objects', async () => {
            const entityDetails = await entDetailsHelpers.getAllBuyerSellers({
                ...{},
                transaction: entDetailsTxn
            });

            expect(entityDetails.data.length).toBe(6);
        });
    });

    describe('Update by ID', () => {
        beforeEach(async () => {
            entDetailsTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entDetailsTxn.rollback();
        });

        it('For valid input: Should return the updated data object', async () => {
            const entityDetail = await entDetailsHelpers.updateAnBuyerSellerById('69ac82c2-5b17-4b11-8fbc-0e37de3325d3', {
                pan: 'GREIU9812P'
            }, {
                transaction: entDetailsTxn
            });

            expect(entityDetail.error).toBe(null);
            expect(entityDetail.data[0]).toBe(1);
            expect(entityDetail.data[1][0].pan).toBe('GREIU9812P');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entityDetail = await entDetailsHelpers.updateAnBuyerSellerById(undefined, {
                pan: 'GREIU9812L'
            }, {
                transaction: entDetailsTxn
            });

            expect(entityDetail.data).toBe(null);
            expect(entityDetail.error instanceof APIError).toBe(true);
            expect(entityDetail.error.status).toBe(400);
            expect(entityDetail.error.code).toBe('0033');
        });
    });

    describe('Delete All', () => {
        beforeEach(async () => {
            entDetailsTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entDetailsTxn.rollback();
        });

        it('For valid input: Should return the number of deleted object(s)', async () => {
            const entityDetails = await entDetailsHelpers.deleteAllBuyerSellers({
                where: {
                    entityCategory: {
                        [db.Sequelize.Op.in]: ['BUYER', 'SELLER']
                    }
                },
                transaction: entDetailsTxn
            });

            expect(entityDetails.error).toBe(null);
            expect(entityDetails.data).toBe(4);
        });

        it('For invalid input: Should return an Error object', async () => {
            const entityDetails = await entDetailsHelpers.deleteAllBuyerSellers({
                ...{},
                transaction: entDetailsTxn
            });

            expect(entityDetails.data).toBe(null);
            expect(entityDetails.error instanceof APIError).toBe(true);
            expect(entityDetails.error.status).toBe(400);
            expect(entityDetails.error.code).toBe('0034');
        });
    });
});