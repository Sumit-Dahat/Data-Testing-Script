const entBankDetailHelpers = require('../../../api/helpers/buyer-seller').entBankDetails;
const { APIError } = require('../../../api/error');
let entBankDetTxn;

module.exports = describe('Entity Bank Detail', () => {
    describe('Create', () => {
        beforeEach(async () => {
            entBankDetTxn = await db.sequelize.transaction();
        });

        afterEach(async () => {
            await entBankDetTxn.rollback();
        });

        it('For valid input: Should return an created data object', async () => {
            const entBankDetail = await entBankDetailHelpers.createAnEntBankDetl({
                entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
                bankAccountTypeId: 'e5ac0e15-1264-41cd-a8c0-6119e4688076',
                accountTitle: 'Joint Account',
                accountNo: '8712091276',
                ifsc: 'JHAS987TYR',
                bankName: 'JPMC Bank',
                branchName: 'Chennai',
                micrCode: '8712091',
                swiftCode: 'CHNNR01267',
                isDefault: 0
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.error).toBe(null);
            expect(entBankDetail.data.accountTitle).toBe('Joint Account');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entBankDetail = await entBankDetailHelpers.createAnEntBankDetl({
                accountTitle: 'Individual Account',
                accountNo: '8712091277',
                ifsc: 'JHAS987TYU',
                bankName: 'UTI Bank',
                branchName: 'Chennai',
                micrCode: '8712092',
                swiftCode: 'CHNNR01268',
                isDefault: 0
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.data).toBe(null);
            expect(entBankDetail.error instanceof APIError).toBe(true);
            expect(entBankDetail.error.status).toBe(400);
            expect(entBankDetail.error.code).toBe('0049');
        });
    });

    describe('Get by ID', () => {
        beforeEach(async () => {
            entBankDetTxn = await db.sequelize.transaction();
        });

        afterEach(async () => {
            await entBankDetTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entBankDetail = await entBankDetailHelpers.getAnEntBankDetlById('0f7a7ad3-06f5-4f2d-a0a9-375b1ec0b58d', {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.error).toBe(null);
            expect(entBankDetail.data.id).toBe('0f7a7ad3-06f5-4f2d-a0a9-375b1ec0b58d');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entBankDetail = await entBankDetailHelpers.getAnEntBankDetlById({
                id: '0f7a7ad3-06f5-4f2d-a0a9-375b1ec0b58d'
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.data).toBe(null);
            expect(entBankDetail.error instanceof APIError).toBe(true);
            expect(entBankDetail.error.status).toBe(404);
            expect(entBankDetail.error.code).toBe('0052');
        });
    });

    describe('Get All', () => {
        beforeEach(async () => {
            entBankDetTxn = await db.sequelize.transaction();
        });

        afterEach(async () => {
            await entBankDetTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entBankDetails = await entBankDetailHelpers.getAllEntBankDetls({
                where: {
                    entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3'
                },
                transaction: entBankDetTxn
            });

            expect(entBankDetails.error).toBe(null);
            expect(entBankDetails.data.length).toBe(1);
        });

        it('For invalid input: Should return all data objects', async () => {
            const entBankDetails = await entBankDetailHelpers.getAllEntBankDetls({
                ...{},
                transaction: entBankDetTxn
            });

            expect(entBankDetails.data.length).toBeGreaterThan(0);
        });
    });

    describe('Update by ID', () => {
        beforeEach(async () => {
            entBankDetTxn = await db.sequelize.transaction();
        });

        afterEach(async () => {
            await entBankDetTxn.rollback();
        });

        it('For valid input: Should return the updated object', async () => {
            const entBankDetail = await entBankDetailHelpers.updateAnEntBankDetlById('0f7a7ad3-06f5-4f2d-a0a9-375b1ec0b58d', {
                bankName: 'DLF Bank'
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.error).toBe(null);
            expect(entBankDetail.data.bankName).toBe('DLF Bank');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entBankDetail = await entBankDetailHelpers.updateAnEntBankDetlById(undefined, {
                bankName: 'DCBA Bank'
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.data).toBe(null);
            expect(entBankDetail.error instanceof APIError).toBe(true);
            expect(entBankDetail.error.status).toBe(400);
            expect(entBankDetail.error.code).toBe('0050');
        });
    });

    describe('Update by Entity ID', () => {
        beforeEach(async () => {
            entBankDetTxn = await db.sequelize.transaction();
        });

        afterEach(async () => {
            await entBankDetTxn.rollback();
        });

        it('For valid input: Should return the updated objects', async () => {
            const entBankDetails = await entBankDetailHelpers.updateEntBankDetlsByEntityId('69ac82c2-5b17-4b11-8fbc-0e37de3325d3', {
                accountTitle: 'Company Account'
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetails.error).toBe(null);
            expect(entBankDetails.data[0]).toBe(1);
            expect(entBankDetails.data[1].length).toBe(1);
            expect(entBankDetails.data[1][0].accountTitle).toBe('Company Account');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entBankDetails = await entBankDetailHelpers.updateEntBankDetlsByEntityId({
                where: {
                    id: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3'
                }
            }, {
                accountTitle: 'Company Account'
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetails.data).toBe(null);
            expect(entBankDetails.error instanceof APIError).toBe(true);
            expect(entBankDetails.error.status).toBe(400);
            expect(entBankDetails.error.code).toBe('0050');
        });
    });

    describe('Delete by ID', () => {
        beforeEach(async () => {
            entBankDetTxn = await db.sequelize.transaction();
        });

        afterEach(async () => {
            await entBankDetTxn.rollback();
        });

        it('For valid input: Should return 1', async () => {
            const entBankDetail = await entBankDetailHelpers.deleteAnEntBankDetlById('0f7a7ad3-06f5-4f2d-a0a9-375b1ec0b58d', {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.error).toBe(null);
            expect(entBankDetail.data).toBe(1);
        });

        it('For invalid input: Should return an Error object', async () => {
            const entBankDetail = await entBankDetailHelpers.deleteAnEntBankDetlById({
                id: null
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.data).toBe(null);
            expect(entBankDetail.error instanceof APIError).toBe(true);
            expect(entBankDetail.error.status).toBe(400);
            expect(entBankDetail.error.code).toBe('0051');
        });
    });

    describe('Delete by Entity ID', () => {
        beforeEach(async () => {
            entBankDetTxn = await db.sequelize.transaction();
        });

        afterEach(async () => {
            await entBankDetTxn.rollback();
        });

        it('For valid input: Should return the number of deleted objects', async () => {
            const entBankDetail = await entBankDetailHelpers.deleteEntBankDetlsByEntityId('69ac82c2-5b17-4b11-8fbc-0e37de3325d3', {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.error).toBe(null);
            expect(entBankDetail.data).toBe(1);
        });

        it('For invalid input: Should return an Error object', async () => {
            const entBankDetail = await entBankDetailHelpers.deleteEntBankDetlsByEntityId({
                id: null
            }, {
                transaction: entBankDetTxn
            });

            expect(entBankDetail.data).toBe(null);
            expect(entBankDetail.error instanceof APIError).toBe(true);
            expect(entBankDetail.error.status).toBe(400);
            expect(entBankDetail.error.code).toBe('0051');
        });
    });
});