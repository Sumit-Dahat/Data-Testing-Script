const BSLinkHelpers = require('../../../api/helpers/buyer-seller').buyerSellerLink;
const { APIError } = require('../../../api/error');
let BSLinkTxn;

module.exports = describe('Buyer Seller Link', () => {
    describe('Create', () => {
        beforeEach(async () => {
            BSLinkTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await BSLinkTxn.rollback();
        });

        it('For valid input: Should create an Buyer-Seller Link', async () => {
            const BSLink = await BSLinkHelpers.createAnBSLink({
                buyerId: '68f1050c-8d49-416f-a1bc-9055b08fc83c',
                sellerId: '03b1a405-fac8-4efb-ad5e-504731c47e9e',
                creditPeriod: 5,
                extendedCreditPeriod: 10,
                sendForFinance: 'MANUAL',
                acceptPayment: 'MANUAL',
                costBearer: 'PERCENTAGE_SPLIT',
                buyerPercentage: 60,
                sellerPercentage: 40,
                buyerStartDays: 0,
                buyerEndDays: 0,
                sellerStartDays: 0,
                sellerEndDays: 0
            }, {
                transaction: BSLinkTxn
            });

            expect(BSLink.error).toBe(null);
            expect(BSLink.data.buyerId).toBe('68f1050c-8d49-416f-a1bc-9055b08fc83c');
        });
        
        it('For invalid input: Should return an Error object', async () => {
            const BSLink = await BSLinkHelpers.createAnBSLink({
                creditPeriod: 5,
                extendedCreditPeriod: 10,
                sendForFinance: 'MANUAL',
                acceptPayment: 'MANUAL',
                costBearer: 'PERCENTAGE_SPLIT',
                buyerPercentage: 60,
                sellerPercentage: 40,
                buyerStartDays: 0,
                buyerEndDays: 0,
                sellerStartDays: 0,
                sellerEndDays: 0
            }, {
                transaction: BSLinkTxn
            });

            expect(BSLink.data).toBe(null);
            expect(BSLink.error instanceof APIError).toBe(true);
            expect(BSLink.error.status).toBe(400);
            expect(BSLink.error.code).toBe('0022');
        });
    });

    describe('Get by ID', () => {
        beforeEach(async () => {
            BSLinkTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await BSLinkTxn.rollback();
        });

        it('For valid input: Should return correct Buyer-Seller Link', async () => {
            const BSLink = await BSLinkHelpers.getAnBSLinkById('062a6db3-6674-43a5-bb1f-e5402d3c0818', {
                transaction: BSLinkTxn
            });

            expect(BSLink.error).toBe(null);
            expect(BSLink.data.id).toBe('062a6db3-6674-43a5-bb1f-e5402d3c0818');
        });

        it('For invalid input: Should return an Error object', async () => {
            const BSLink = await BSLinkHelpers.getAnBSLinkById(undefined, {
                transaction: BSLinkTxn
            });

            expect(BSLink.error instanceof APIError).toBe(true);
            expect(BSLink.error.status).toBe(404);
            expect(BSLink.error.code).toBe('0023');
        });
    });

    describe('Get All', () => {
        beforeEach(async () => {
            BSLinkTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await BSLinkTxn.rollback();
        });

        it('For valid input: Should return an array of Buyer-Seller Link objects', async () => {
            const BSLinks = await BSLinkHelpers.getAllBSLinks({
                where: {},
                transaction: BSLinkTxn
            });

            expect(BSLinks.error).toBe(null);
            expect(BSLinks.data.length).toBe(1);
        });

        it('For invalid input: Should return all data objects', async () => {
            const BSLinks = await BSLinkHelpers.getAllBSLinks({
                ...{},
                transaction: BSLinkTxn
            });

            expect(BSLinks.data.length).toBeGreaterThan(0);
        });
    });

    describe('Update by ID', () => {
        beforeEach(async () => {
            BSLinkTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await BSLinkTxn.rollback();
        });

        it('For valid input: Should return the updated data object', async () => {
            const updatedBSLink = await BSLinkHelpers.updateAnBSLinkById('062a6db3-6674-43a5-bb1f-e5402d3c0818', {
                buyerPercentage: 50,
                sellerPercentage: 50
            }, {
                transaction: BSLinkTxn
            });

            expect(updatedBSLink.error).toBe(null);
            expect(updatedBSLink.data.buyerPercentage).toBe(50);
            expect(updatedBSLink.data.sellerPercentage).toBe(50);
        });

        it('For invalid input: Should return an Error object', async () => {
            const updatedBSLink = await BSLinkHelpers.updateAnBSLinkById(undefined, {
                buyerPercentage: 50,
                sellerPercentage: 50
            }, {
                transaction: BSLinkTxn
            });

            expect(updatedBSLink.error instanceof APIError).toBe(true);
            expect(updatedBSLink.error.status).toBe(400);
            expect(updatedBSLink.error.code).toBe('0024');
        });
    });

    describe('Delete All', () => {
        beforeEach(async () => {
            BSLinkTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await BSLinkTxn.rollback();
        });

        it('For valid input: Should return the number of deleted objects', async () => {
            const deletedBSLinks = await BSLinkHelpers.deleteAllBSLinks({
                where: {},
                transaction: BSLinkTxn
            });

            expect(deletedBSLinks.error).toBe(null);
            expect(deletedBSLinks.data).toBeGreaterThan(0);
        });

        it('For invalid input: Should return an Error object', async () => {
            const deletedBSLinks = await BSLinkHelpers.deleteAllBSLinks({
                ...{},
                transaction: BSLinkTxn
            });

            expect(deletedBSLinks.data).toBe(null);
            expect(deletedBSLinks.error instanceof APIError).toBe(true);
            expect(deletedBSLinks.error.status).toBe(400);
            expect(deletedBSLinks.error.code).toBe('0025');
        });
    });
});