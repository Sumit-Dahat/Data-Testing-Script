const entAddrDetHelpers = require('../../../api/helpers/buyer-seller').entAddressDetails;
const { APIError } = require('../../../api/error');
let entAddrDetTxn;

module.exports = describe('Entity Address Detail', () => {
    describe('Create', () => {
        beforeEach(async () => {
            entAddrDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entAddrDetTxn.rollback();
        });

        it('For valid input: Should return an created data object', async () => {
            const entAddrDetail = await entAddrDetHelpers.createAnEntAddrDet({
                entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3',
                addressTypeId: 'a2065e75-6c31-4e52-b9d5-00dd390c414a',
                addressLineOne: '211, 1st Main Road',
                addressLineTwo: '15th block',
                pinCode: '560030',
                state: 'Karnataka',
                district: 'Bengaluru',
                subDistrict: 'Bengaluru Urban',
                postOffice: 'Bengaluru'
            }, {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.error).toBe(null);
            expect(entAddrDetail.data.addressLineTwo).toBe('15th block');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entAddrDetail = await entAddrDetHelpers.createAnEntAddrDet({
                addressLineOne: '211, 1st Main Road',
                addressLineTwo: '15th block',
                pinCode: '560030',
                state: 'Karnataka',
                district: 'Bengaluru',
                subDistrict: 'Bengaluru Urban',
                postOffice: 'Bengaluru'
            }, {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.data).toBe(null);
            expect(entAddrDetail.error instanceof APIError).toBe(true);
            expect(entAddrDetail.error.status).toBe(400);
            expect(entAddrDetail.error.code).toBe('0045');
        });
    });

    describe('Get by ID', () => {
        beforeEach(async () => {
            entAddrDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entAddrDetTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entAddrDetail = await entAddrDetHelpers.getAnEntAddrDetyId('83fa12e8-9722-493e-bac5-6c0520a2894e', {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.error).toBe(null);
            expect(entAddrDetail.data.id).toBe('83fa12e8-9722-493e-bac5-6c0520a2894e');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entAddrDetail = await entAddrDetHelpers.getAnEntAddrDetyId({
                id: '83fa12e8-9722-493e-bac5-6c0520a2894e'
            }, {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.data).toBe(null);
            expect(entAddrDetail.error instanceof APIError).toBe(true);
            expect(entAddrDetail.error.status).toBe(404);
            expect(entAddrDetail.error.code).toBe('0048');
        });
    });

    describe('Get All', () => {
        beforeEach(async () => {
            entAddrDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entAddrDetTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entAddrDetails = await entAddrDetHelpers.getAllEntAddrDetls({
                where: {
                    entityId: '69ac82c2-5b17-4b11-8fbc-0e37de3325d3'
                },
                transaction: entAddrDetTxn
            });

            expect(entAddrDetails.error).toBe(null);
            expect(entAddrDetails.data.length).toBe(2);
        });

        it('For invalid input: Should return all data objects', async () => {
            const entAddrDetails = await entAddrDetHelpers.getAllEntAddrDetls({
                ...{},
                transaction: entAddrDetTxn
            });

            expect(entAddrDetails.data.length).toBeGreaterThan(0);
        });
    });

    describe('Update by ID', () => {
        beforeEach(async () => {
            entAddrDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entAddrDetTxn.rollback();
        });

        it('For valid input: Should return the updated object', async () => {
            const entAddrDetail = await entAddrDetHelpers.updateAnEntAddrDetyId('83fa12e8-9722-493e-bac5-6c0520a2894e', {
                pinCode: '560050'
            }, {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.error).toBe(null);
            expect(entAddrDetail.data.pinCode).toBe('560050');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entAddrDetail = await entAddrDetHelpers.updateAnEntAddrDetyId(undefined, {
                pinCode: '560050'
            }, {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.data).toBe(null);
            expect(entAddrDetail.error instanceof APIError).toBe(true);
            expect(entAddrDetail.error.status).toBe(400);
            expect(entAddrDetail.error.code).toBe('0046');
        });
    });

    describe('Delete by ID', () => {
        beforeEach(async () => {
            entAddrDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entAddrDetTxn.rollback();
        });

        it('For valid input: Should return 1', async () => {
            const entAddrDetail = await entAddrDetHelpers.deleteAnEntAddrDetyId('83fa12e8-9722-493e-bac5-6c0520a2894e', {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.error).toBe(null);
            expect(entAddrDetail.data).toBe(1);
        });

        it('For invalid input: Should return an Error object', async () => {
            const entAddrDetail = await entAddrDetHelpers.deleteAnEntAddrDetyId({
                id: null
            }, {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.data).toBe(null);
            expect(entAddrDetail.error instanceof APIError).toBe(true);
            expect(entAddrDetail.error.status).toBe(400);
            expect(entAddrDetail.error.code).toBe('0047');
        });
    });

    describe('Delete by Entity ID', () => {
        beforeEach(async () => {
            entAddrDetTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await entAddrDetTxn.rollback();
        });

        it('For valid input: Should return the number of deleted objects', async () => {
            const entAddrDetail = await entAddrDetHelpers.deleteEntAddrDetlsByEntityId('69ac82c2-5b17-4b11-8fbc-0e37de3325d3', {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.error).toBe(null);
            expect(entAddrDetail.data).toBe(2);
        });

        it('For invalid input: Should return an Error object', async () => {
            const entAddrDetail = await entAddrDetHelpers.deleteEntAddrDetlsByEntityId({
                id: null
            }, {
                transaction: entAddrDetTxn
            });

            expect(entAddrDetail.data).toBe(null);
            expect(entAddrDetail.error instanceof APIError).toBe(true);
            expect(entAddrDetail.error.status).toBe(400);
            expect(entAddrDetail.error.code).toBe('0047');
        });
    });
});