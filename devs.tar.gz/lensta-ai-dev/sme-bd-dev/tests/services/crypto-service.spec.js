const cryptoService = require('../../api/services/crypto.service');

module.exports = describe('Crypto', () => {
    describe('Encryption service', () => {
        it('For valid input: Should return an encrypted string', () => {
            const encString = cryptoService.getEncryptedString('hello');
    
            expect(
                cryptoService.getDecryptedString(encString)
            ).toBe('hello');
        });
    
        it('For invalid input: Should return an Error object', () => {
            const encString = cryptoService.getEncryptedString(123);
    
            expect(encString).toBe('');
        });
    });
    
    describe('Decryption service', () => {
        it('For valid input: Should return an correct decrypted string', () => {
            const decString = cryptoService.getDecryptedString(
                cryptoService.getEncryptedString('hello')
            );
    
            expect(decString).toBe('hello');
        });
    
        it('For invalid input: Should return an invalid string', () => {
            const decString = cryptoService.getDecryptedString(123);
    
            expect(decString).toBe('');
        });
    });
});