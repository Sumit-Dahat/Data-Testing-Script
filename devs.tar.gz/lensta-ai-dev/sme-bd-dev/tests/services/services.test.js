const { getFilePaths } = require('../../api/services/generic.service');

beforeAll(async () => {
    await require('../../init')();
});

describe('Services', () => {
    const filePaths = getFilePaths(__dirname);

    filePaths.forEach((filePath) => require(filePath));
});