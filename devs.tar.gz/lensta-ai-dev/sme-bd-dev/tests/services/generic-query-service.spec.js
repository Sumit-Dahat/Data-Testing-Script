const genericQueryService = require('../../api/services//generic-query.service');
const { APIError } = require('../../api/error');

module.exports = describe('Generic Query Service', () => {
    describe('Generate Query', () => {
        it('For valid input: Should return an generated query object', () => {
            const query = genericQueryService.generateQuery({
                id: '1',
                active: '0',
                buyerPercentage: '50',
                factoringAmount: '100.5'
            });

            expect(query.id).toBe('1');
            expect(query.active).toBe(0);
            expect(query.buyerPercentage).toBe(50);
            expect(query.factoringAmount).toBe(100.5);
        });

        it('For invalid input: Should return incorrect output', () => {
            const query = genericQueryService.generateQuery({
                sellerPercentage: '60.5'
            });

            expect(query.sellerPercentage).toBe(60);
        });
    });

    describe('Rename Query Fields', () => {
        it('For valid input: Should return an object with renamed fields', () => {
            const query = genericQueryService.renameQueryFields({
                buyerId: '123'
            }, {
                buyerId: 'buyer'
            });

            expect(query).not.toHaveProperty('buyerId');
            expect(query.buyer).toBe('123');
        });

        it('For invalid input: Should return incorrect output', () => {
            const query = genericQueryService.renameQueryFields({
                buyerId: '123'
            }, {
                seller: 'buyer'
            });

            expect(query.buyerId).toBe('123');
        });
    });

    describe('Set Pagination Parameters', () => {
        it('For valid input: Should return an object with limit & offset values', () => {
            const query = genericQueryService.setPaginationParams({
                limit: '-1',
                offset: '-2',
            });

            expect(query.limit).toBe(5);
            expect(query.offset).toBe(0);
        });

        it('For invalid input: Should return an Error object', () => {
            const query = genericQueryService.setPaginationParams(undefined);

            expect(query instanceof APIError).toBe(true);
            expect(query.status).toBe(500);
            expect(query.code).toBe('0000');
        });
    });

    describe('Apply Limit & Offset Params', () => {
        it('For valid input: Should return an array with limit & offset values applied', () => {
            const result = genericQueryService.applyLimitAndOffsetParams([1, 2, 3, 4, 5], 2, 1);

            expect(result.length).toBe(2);
            expect(result[0]).toBe(2);
        });

        it('For invalid input: Should return an Error object', () => {
            const result = genericQueryService.applyLimitAndOffsetParams(undefined, 2, 1);

            expect(result instanceof APIError).toBe(true);
            expect(result.status).toBe(500);
            expect(result.code).toBe('0000');
        });
    });
});