const genericService = require('../../api/services//generic.service');
const { APIError } = require('../../api/error');

module.exports = describe('Generic', () => {
    describe('Create One', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });

        it('For valid input: Should return an created data object', async () => {
            const entityType = await genericService.genericCreateOne('EntityTypes', {
                name: 'Public',
                active: 1,
                createdByUserId: 'de918065-9638-486c-b867-babf264a3dc6'
            }, {
                transaction: genericServiceTxn
            });
    
            expect(entityType.error).toBe(null);
            expect(entityType.data.name).toBe('Public');
        });
    
        it('For invalid input: Should return an Error object', async () => {
            const entityType = await genericService.genericCreateOne('EntityTypes', {
                active: 1,
                createdByUserId: 'de918065-9638-486c-b867-babf264a3dc6'
            }, {
                transaction: genericServiceTxn
            });
    
            expect(entityType.data).toBe(null);
            expect(entityType.error instanceof APIError).toBe(true);
            expect(entityType.error.status).toBe(500);
            expect(entityType.error.code).toBe('0000');
        });
    });
    
    describe('Create Multiple', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });

        it('For valid input: Should return status as 201', async () => {
            const entityTypes = await genericService.genericCreateMultiple('EntityTypes', [
                {
                    name: 'Corporate',
                    active: 1,
                    createdByUserId: 'de918065-9638-486c-b867-babf264a3dc6'
                },
                {
                    name: 'Government',
                    active: 1,
                    createdByUserId: 'de918065-9638-486c-b867-babf264a3dc6'
                }
            ], {
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.error).toBe(null);
        });
    
        it('For invalid input: Should return an Error object', async () => {
            const entityTypes = await genericService.genericCreateMultiple('EntityTypes', [
                {
                    active: 1,
                    createdByUserId: 'de918065-9638-486c-b867-babf264a3dc6'
                },
                {
                    active: 1,
                    createdByUserId: 'de918065-9638-486c-b867-babf264a3dc6'
                }
            ], {
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.data).toBe(null);
            expect(entityTypes.error instanceof APIError).toBe(true);
            expect(entityTypes.error.status).toBe(500);
            expect(entityTypes.error.code).toBe('0000');
        });
    });

    describe('Get One', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });

        it('For valid input: Should return the correct data object', async () => {
            const entityType = await genericService.genericGetOne('EntityTypes', {
                where: {
                    name: 'Private',
                    createdByUserId: 'de918065-9638-486c-b867-babf264a3dc6',
                },
                transaction: genericServiceTxn
            });

            expect(entityType.error).toBe(null);
            expect(entityType.data.name).toBe('Private');
            expect(entityType.data.createdByUserId).toBe('de918065-9638-486c-b867-babf264a3dc6');
        });

        it('For invalid input: Should return an Error object', async () => {
            const entityType = await genericService.genericGetOne('EntityType', {
                ...{},
                transaction: genericServiceTxn
            });

            expect(entityType.data).toBe(null);
            expect(entityType.error instanceof APIError).toBe(true);
            expect(entityType.error.status).toBe(500);
            expect(entityType.error.code).toBe('0000');
        });
    });
    
    describe('Get by ID', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });

        it('For valid input: Should return an data object', async () => {
            const entityType = await genericService.genericGetById('EntityTypes', 'd55eda4e-b70c-445a-a969-122e8c21d66b', {
                transaction: genericServiceTxn
            });
    
            expect(entityType.error).toBe(null);
            expect(entityType.data.id).toBe('d55eda4e-b70c-445a-a969-122e8c21d66b');
        });
    
        it('For invalid input: Should return an Error object', async () => {
            const entityType = await genericService.genericGetById('EntityTypes', {
                id: 'e56eda4e-b70c-446a-a979-122e8c21d67b'
            }, {
                transaction: genericServiceTxn
            });
    
            expect(entityType.data).toBe(null);
            expect(entityType.error instanceof APIError).toBe(true);
            expect(entityType.error.status).toBe(500);
            expect(entityType.error.code).toBe('0000');
        });
    });
    
    describe('Get All', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });

        it('For valid input: Should return data object(s)', async () => {
            const entityTypes = await genericService.genericGetAll('EntityTypes', {
                where: {},
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.error).toBe(null);
            expect(entityTypes.data.length).toBeGreaterThan(0);
        });
    
        it('For invalid input: Should return an Error object', async () => {
            const entityTypes = await genericService.genericGetAll('EntityType', {
                ...{},
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.data).toBe(null);
            expect(entityTypes.error instanceof APIError).toBe(true);
            expect(entityTypes.error.status).toBe(500);
            expect(entityTypes.error.code).toBe('0000');
        });
    });
    
    describe('Get and Count All', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });
        
        it('For valid input: Should return data object(s) and total count', async () => {
            const entityTypes = await genericService.genericGetAndCountAll('EntityTypes', {
                where: {},
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.error).toBe(null);
            expect(entityTypes.data.count).toBeGreaterThan(0);
        });
    
        it('For invalid input: Should return an Error object', async () => {
            const entityTypes = await genericService.genericGetAndCountAll('EntityType', {
                ...{},
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.data).toBe(null);
            expect(entityTypes.error instanceof APIError).toBe(true);
            expect(entityTypes.error.status).toBe(500);
            expect(entityTypes.error.code).toBe('0000');
        });
    });
    
    describe('Update', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });

        it('For valid input: Should return number of data object(s) updated', async () => {
            const entityTypes = await genericService.genericUpdate('EntityTypes', {
                active: 0
            }, {
                where: {
                    active: 1
                },
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.error).toBe(null);
            expect(entityTypes.data[0]).toBeGreaterThan(0);
        });
    
        it('For invalid input: Should return an Error object', async () => {
            const entityTypes = await genericService.genericUpdate('EntityTypes', {}, {
                ...{},
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.data).toBe(null);
            expect(entityTypes.error instanceof APIError).toBe(true);
            expect(entityTypes.error.status).toBe(500);
            expect(entityTypes.error.code).toBe('0000');
        });
    });
    
    describe('Delete All', () => {
        beforeEach(async () => {
            genericServiceTxn = await db.sequelize.transaction();
        });
    
        afterEach(async () => {
            await genericServiceTxn.rollback();
        });

        it('For valid input: Should return number of data object(s) deleted', async () => {
            const entityTypes = await genericService.genericDeleteAll('EntityTypes', {
                where: {
                    active: 1
                },
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.error).toBe(null);
            expect(entityTypes.data).toBeGreaterThan(0);
        });
    
        it('For invalid input: Should return an Error object', async () => {
            const entityTypes = await genericService.genericDeleteAll('EntityTypes', {
                where: {
                    isDefault: 1
                },
                transaction: genericServiceTxn
            });
    
            expect(entityTypes.data).toBe(null);
            expect(entityTypes.error instanceof APIError).toBe(true);
            expect(entityTypes.error.status).toBe(500);
            expect(entityTypes.error.code).toBe('0000');
        });
    });
});