# Title

sme-bd

# Description: 

Main Back-end server for SME Product. Handles the REST API requests from the SME Product front-end.

# Pre-requisites:

**Dependencies:**
1.	NodeJS v18.14.0.
2.	PostgreSQL DB v14.
3.	pgAdmin or phpPgAdmin

**Download links of dependencies:**
1.	NodeJS v18.14.0: <https://nodejs.org/download/release/v18.14.0/>
2.	PostgreSQL DB v14: <https://www.postgresql.org/download/>
3.  pgAdmin (Windows): <https://www.pgadmin.org/download/>
4.  phpPgAdmin (Linux): <https://github.com/phppgadmin/phppgadmin>

# Procedure:

1.  Install PostgreSQL DB v14 and then install pgAdmin (for Windows OS) or phpPgAdmin (for Linux).
2.  Change the password to 'tiger' of default administrator account with username 'postgres'.
3.  Open pgAdmin or phpPgAdmin, and create 2 databases with names 'sme-bd-dev' (for dev env) and 'sme-bd-prod' (for prod env) respectively.
3.  Install NodeJS v18.14.0.
4.  Open Command Prompt or terminal and change the terminal directory to the project folder.
5.  Inside the project folder in the terminal, run the command 'npm i', which will install all the dependencies required for the project to run.
6.  After successful installation of dependencies, run 'npm start' to start the server which will automatically apply all the DB changes and will also seed the DB with the required data.
7. If DB connection is successful, the server will start running on port 3007 (for 'development' environment) or on port 4007 (for 'production' environment).